"""Compile/run the real TargetHud ctor/onRender with bundled ImGui, mock GUI/clock.
No Windows renderer, game, screenshots or FPS claims. Requires g++.
"""
from pathlib import Path
import subprocess
import tempfile
import os

root=Path(__file__).resolve().parents[1]
hud=(root/"src/modules/hud_modules.cpp").read_text(encoding="utf-8")
header=(root/"src/modules/hud_modules.h").read_text(encoding="utf-8")
overlay=(root/"src/overlay/overlay.h").read_text(encoding="utf-8")
cls=header[header.index("class TargetHudModule"):header.index("class TimeModule")]
cls=cls.replace("private:", "public:")  # test visibility only
info=overlay[overlay.index("struct TargetHudInfo"):overlay.index("// Render thread, once per frame while")]
render=hud[hud.index("namespace {",hud.index("// ======================== Target HUD")):
           hud.index("// ======================== Time")]
free=hud[hud.index("void AddFreePositionSettings("):hud.index("// Edit-mode chrome")]
prefix=r"""
#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>
#include "core/module.h"
#include "utils/gui_render.h"
#include "overlay/target_health.hpp"
using ULONGLONG=unsigned long long;
ULONGLONG clockMs=10000;
ULONGLONG GetTickCount64(){return clockMs;}
int checks=0;
#define CHECK(x) do {++checks;if(!(x)){std::fprintf(stderr,"line %d: %s\n",__LINE__,#x);std::abort();}}while(0)
std::vector<std::string> texts;
namespace nf {
namespace fonts { ImFont* Bold(){return ImGui::GetFont();} }
namespace gui {
ImVec2 GetScreenSize(){return ImVec2(1280,720);}
float GetDeltaTime(){return 1.0f/60.0f;}
float GetTextScale(){return 1.0f;}
float Clamp(float x,float a,float b){return std::clamp(x,a,b);}
ImDrawList* Bg(){return ImGui::GetBackgroundDrawList();}
ImColor Accent(){return ImColor(100,200,250);}
void FillShadowRect(const ImVec4&,const ImColor&,float,float,ImDrawList*){}
void FillGradientV(const ImVec4&,const ImColor&,const ImColor&,float,float,float,ImDrawList*){}
void FillCircle(const ImVec2&,float,const ImColor&,float,int,ImDrawList*){}
void DrawString(const ImVec2&,const char* t,const ImColor&,float size,float,bool,ImDrawList*,ImFont*){
    CHECK(std::isfinite(size) && size>=0);texts.emplace_back(t);
}
float GetTextWidth(const char* t,float s,ImFont*){return std::strlen(t)*s*9.0f;}
float GetTextHeight(float s,ImFont*){return 18*s;}
}
enum Anchor {TopLeft,TopRight,BottomLeft,BottomRight};
std::vector<std::string> HudPositionNames(){return {"TL","TR","BL","BR"};}
ImVec2 HudResolvePos(bool,float,float,const ImVec2&,const ImVec2&,int){return ImVec2(400,400);}
void HudEditChrome(Module*,const char*,const ImVec2&,const ImVec2&,BoolSetting*,NumberSetting*,NumberSetting*,NumberSetting*){}
void GlassSurface(const ImVec4&,float,float,ImDrawList*){}
namespace overlay {
"""
middle=r"""
TargetHudInfo fixture{};
bool visible=true, editor=false, g_showMenu=false;
bool GetTargetHudInfo(TargetHudInfo* out){*out=fixture;return visible;}
bool HudEditActive(){return editor;}
void UpdateTargetLook(float,int){}
void SetTargetHudEstimateStep(float){}
} // overlay
"""
tests=r"""
} // nf
int frame(nf::TargetHudModule& m) {
    texts.clear();clockMs+=16;
    ImGui::NewFrame();m.onRender();
    auto* draw=ImGui::GetBackgroundDrawList();
    for(auto& v:draw->VtxBuffer)CHECK(std::isfinite(v.pos.x)&&std::isfinite(v.pos.y));
    int count=draw->VtxBuffer.Size;
    ImGui::EndFrame();return count;
}
bool text(const char* s){return std::find(texts.begin(),texts.end(),s)!=texts.end();}
int numbers(const nf::TargetHudModule& m){int n=0;for(auto& x:m.m_nums)n+=x.t>=0;return n;}
int main(){
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename=nullptr;
    ImGui::GetIO().DisplaySize=ImVec2(1280,720);
    ImGui::GetIO().DeltaTime=1.0f/60.0f;
    unsigned char* pixels;int w,h;
    ImGui::GetIO().Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);
    {
    nf::TargetHudModule m;
    m.m_shake->mValue=m.m_particles->mValue=false;
    auto& info=nf::overlay::fixture;
    char actorA{},actorB{};
    info.actor=&actorA;info.session=1;std::strcpy(info.name,"Target");
    info.distValid=true;info.dist=3.2f;info.maxHealth=20;
    frame(m);CHECK(text("?"));CHECK(text("Урон: ?"));CHECK(m.m_hpShown==0 && numbers(m)==0);
    for(int i=0;i<20;++i)frame(m);
    int unknown=frame(m);
    info.healthValid=true;info.health=0;
    int zero=frame(m);CHECK(text("0"));CHECK(zero==unknown);
    info.health=10;
    for(int i=0;i<20;++i)frame(m);
    int filled=frame(m);CHECK(filled>zero && text("10"));
    // One worker loss appears once even across many rendering frames.
    info.health=8;info.lastDamage=2;info.totalLoss=2;info.lossAt=clockMs;info.lossGen=1;
    frame(m);CHECK(numbers(m)==1);CHECK(text("Урон: 2.0"));CHECK(text("-2.0"));
    for(int i=0;i<5;++i)frame(m);
    CHECK(numbers(m)==1);
    // Approximate fallback: marked with ≈ and never mixed with exact HP.
    info.healthValid=false;info.healthEstimated=true;info.estimatedHealth=19;
    info.estimatedDamage=1;info.estimatedAt=clockMs;info.totalLoss=2;
    frame(m);CHECK(text("≈19"));CHECK(text("Урон: ≈1"));
    info.health=5;info.totalLoss=5;info.lastDamage=1;info.lossAt=clockMs;info.lossGen=3;
    frame(m);CHECK(numbers(m)==2 && text("-3.0")); // two worker changes, one frame
    info.healthValid=false;info.healthEstimated=false;frame(m);
    CHECK(text("?") && m.m_hpShown==0 && m.m_hpTrail==0);
    // A different target cannot inherit a floating number.
    info.actor=&actorB;info.session=2;info.totalLoss=0;info.lossAt=0;info.lastDamage=0;
    frame(m);CHECK(numbers(m)==0 && text("Урон: ?"));
    info.healthValid=true;info.health=10;frame(m);
    info.health=7;info.lastDamage=3;info.totalLoss=3;info.lossAt=clockMs;frame(m);
    CHECK(numbers(m)==1);
    // Same actor address, new tracking session: clear effects too.
    ++info.session;info.totalLoss=0;info.lossAt=0;info.lastDamage=0;
    frame(m);CHECK(numbers(m)==0 && m.m_seenLoss==0);
    info.health=6;info.lastDamage=1;info.totalLoss=1;info.lossAt=clockMs;frame(m);
    CHECK(text("Урон: 1.0"));
    clockMs+=3100;frame(m);CHECK(text("Урон: ?"));
    m.m_damageNumbers->mValue=false;info.totalLoss=2;info.lossAt=clockMs;
    frame(m);CHECK(!text("Урон: 1.0") && !text("Урон: ?"));
    // Editor preview and fade-out remain executable.
    nf::overlay::visible=false;nf::overlay::editor=true;frame(m);CHECK(text("15"));
    nf::overlay::editor=false;for(int i=0;i<30;++i)frame(m);CHECK(m.m_actor==nullptr);
    }
    ImGui::DestroyContext();
    std::printf("Target HUD render: %d checks passed (real ImGui, mock GUI/game).\n",checks);
}
"""
code=prefix+info+middle+cls+free+render+tests
with tempfile.TemporaryDirectory(prefix="nf_r17_render_") as temp:
    cpp=Path(temp)/"render.cpp";exe=Path(temp)/"render"
    cpp.write_text(code,encoding="utf-8")
    imgui=root/"src/third_party/imgui"
    subprocess.run(["g++","-std=c++20","-O1","-g","-fsanitize=address,undefined",
        "-fno-omit-frame-pointer","-fno-pie","-no-pie","-I",str(root/"src"),"-I",str(imgui),
        str(cpp),*[str(imgui/n) for n in ["imgui.cpp","imgui_draw.cpp","imgui_tables.cpp","imgui_widgets.cpp"]],
        "-o",str(exe)],check=True)
    subprocess.run([str(exe)],check=True,env=dict(os.environ,ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
        UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1"))
