// module_guard.h - guarded execution of module callbacks.
//
// Every module callback (on_enable / on_disable / on_tick / on_render) runs ON
// THE GAME'S RENDER THREAD, inside the Present hook. A module that hangs,
// spins or faults there freezes the whole game - and because the external
// input masks used to be released only from that very thread, it also locked
// out the entire desktop (keyboard dead, mouse frozen, hard reset). That was
// the freeze this project was debugged for; see
// docs/FREEZE_ROOTCAUSE_AND_PATCH.md.
//
// This guard makes a single bad module non-fatal:
//   1. it marks the active module/phase so the overlay watchdog can NAME the
//      culprit in the log if the frame never finishes;
//   2. it wraps the call in SEH - a faulting module is disabled, the frame
//      (and the game) carries on;
//   3. it times the call: >5 ms is logged (this is a 60+ fps render thread),
//      >100 ms disables the module. A module must NEVER block.
//
// NOTE: ASCII only in this file.

#pragma once

namespace modules {

class Module;

struct ModulePhaseGuard {
    enum Phase {
        ENABLE = 0,
        DISABLE,
        TICK,
        RENDER,
        SETTINGS,
    };

    // Runs one lifecycle callback safely. 'm' is disabled if it faults or
    // overruns its time budget.
    static void run(Module* m, Phase phase);

    static const char* phaseName(Phase phase);
};

} // namespace modules
