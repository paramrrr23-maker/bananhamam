// keys.cpp - fused per-frame keyboard snapshot.

#include "utils/keys.h"

#include <Windows.h>
#include <cstdio>
#include <cstring>
#include <vector>

namespace nf {
namespace keys {
namespace {

bool g_cur[256] = {};
bool g_prev[256] = {};
bool g_pend[256] = {};     // staged by FeedKey (any thread), merged by BeginFrame
bool g_hasPend[256] = {};
bool g_asyncAlive = false;  // sticky: async poll proved capable at least once
std::vector<unsigned int> g_chars;
CRITICAL_SECTION g_cs;
bool g_csInit = false;

void EnsureCs() {
    if (!g_csInit) { InitializeCriticalSection(&g_cs); g_csInit = true; }
}

void AppendUtf8(char* buf, size_t cap, size_t& len, unsigned int cp) {
    char tmp[4];
    int n = 0;
    if (cp < 0x80) { tmp[0] = (char)cp; n = 1; }
    else if (cp < 0x800) {
        tmp[0] = (char)(0xC0 | (cp >> 6)); tmp[1] = (char)(0x80 | (cp & 0x3F)); n = 2;
    } else {
        tmp[0] = (char)(0xE0 | (cp >> 12)); tmp[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        tmp[2] = (char)(0x80 | (cp & 0x3F)); n = 3;
    }
    if (len + (size_t)n + 1 > cap) return;
    for (int i = 0; i < n; i++) buf[len++] = tmp[i];
    buf[len] = 0;
}

} // namespace

void BeginFrame() {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    // One async sample per key (a single call each). Mouse buttons are owned
    // by ImGui, skip them.
    bool sample[256] = {};
    bool anyAsync = false;
    for (int i = 0; i < 256; i++) {
        if (i == VK_LBUTTON || i == VK_RBUTTON || i == VK_MBUTTON ||
            i == VK_XBUTTON1 || i == VK_XBUTTON2) continue;
        if (GetAsyncKeyState(i) & 0x8000) { sample[i] = true; anyAsync = true; }
    }
    // Sticky capability flag: once ANY key is ever seen down via the poll,
    // the sandbox allows async queries and the poll becomes authoritative
    // for releases too. Until then the poll only ever ADDS downs, so a dead,
    // all-zero sandbox poll can never erase WndProc-fed state.
    g_asyncAlive |= anyAsync;
    for (int i = 0; i < 256; i++) {
        g_prev[i] = g_cur[i];
        if (g_hasPend[i]) { g_cur[i] = g_pend[i]; g_hasPend[i] = false; }
        else if (g_asyncAlive) g_cur[i] = sample[i];
        else if (sample[i]) g_cur[i] = true;
    }
    LeaveCriticalSection(&g_cs);
}

void Reset() {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    std::memset(g_cur, 0, sizeof(g_cur));
    std::memset(g_prev, 0, sizeof(g_prev));
    std::memset(g_pend, 0, sizeof(g_pend));
    std::memset(g_hasPend, 0, sizeof(g_hasPend));
    g_chars.clear();
    LeaveCriticalSection(&g_cs);
}

void FeedKey(unsigned int vk, bool down) {
    if (vk >= 256) return;
    EnsureCs();
    EnterCriticalSection(&g_cs);
    // Stage only: BeginFrame merges pending into cur, so fed edges can never
    // be torn or lost between the snapshot and the queries.
    g_pend[vk] = down;
    g_hasPend[vk] = true;
    LeaveCriticalSection(&g_cs);
}

void FeedChar(unsigned int ch) {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    if (g_chars.size() < 64) g_chars.push_back(ch);
    LeaveCriticalSection(&g_cs);
}

bool Down(unsigned int vk) {
    return vk < 256 ? g_cur[vk] : false;
}

bool PressedThisFrame(unsigned int vk) {
    return vk < 256 ? (g_cur[vk] && !g_prev[vk]) : false;
}

const char* Name(unsigned int vk) {
    static char s_buf[16];
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) {
        s_buf[0] = (char)vk; s_buf[1] = 0; return s_buf;
    }
    if (vk >= VK_F1 && vk <= VK_F24) {
        snprintf(s_buf, sizeof(s_buf), "F%u", vk - VK_F1 + 1); return s_buf;
    }
    switch (vk) {
        case VK_INSERT: return "INSERT";
        case VK_DELETE: return "DEL";
        case VK_HOME: return "HOME";
        case VK_END: return "END";
        case VK_PRIOR: return "PGUP";
        case VK_NEXT: return "PGDN";
        case VK_ESCAPE: return "ESC";
        case VK_TAB: return "TAB";
        case VK_CAPITAL: return "CAPS";
        case VK_SHIFT: return "SHIFT";
        case VK_LSHIFT: return "LSHIFT";
        case VK_RSHIFT: return "RSHIFT";
        case VK_CONTROL: return "CTRL";
        case VK_LCONTROL: return "LCTRL";
        case VK_RCONTROL: return "RCTRL";
        case VK_MENU: return "ALT";
        case VK_LMENU: return "LALT";
        case VK_RMENU: return "RALT";
        case VK_SPACE: return "SPACE";
        case VK_RETURN: return "ENTER";
        case VK_BACK: return "BACK";
        case VK_LEFT: return "LEFT";
        case VK_UP: return "UP";
        case VK_RIGHT: return "RIGHT";
        case VK_DOWN: return "DOWN";
        case VK_LBUTTON: return "LMB";
        case VK_RBUTTON: return "RMB";
        case VK_MBUTTON: return "MMB";
        default: break;
    }
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) {
        snprintf(s_buf, sizeof(s_buf), "NUM%u", vk - VK_NUMPAD0); return s_buf;
    }
    snprintf(s_buf, sizeof(s_buf), "VK%02X", vk & 0xFF);
    return s_buf;
}

bool TextInput(char* buf, size_t cap, bool active) {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    if (!active || !buf || cap == 0) { g_chars.clear(); LeaveCriticalSection(&g_cs); return false; }
    bool changed = false;
    size_t len = std::strlen(buf);
    unsigned int highSurrogate = 0;
    for (unsigned int ch : g_chars) {
        if (ch == 8) {  // backspace (may arrive as WM_CHAR too)
            if (len > 0) {
                // step back over one UTF-8 sequence
                do { len--; } while (len > 0 && (buf[len] & 0xC0) == 0x80);
                buf[len] = 0; changed = true;
            }
            continue;
        }
        if (ch < 32 || ch == 127) continue;   // control chars are not text
        if (ch >= 0xD800 && ch <= 0xDBFF) { highSurrogate = ch; continue; }
        unsigned int cp = ch;
        if (ch >= 0xDC00 && ch <= 0xDFFF && highSurrogate) {
            cp = 0x10000 + ((highSurrogate - 0xD800) << 10) + (ch - 0xDC00);
        }
        highSurrogate = 0;
        if (cp >= 0x10000) continue;          // outside BMP: skip (no emoji input)
        const size_t before = len;
        AppendUtf8(buf, cap, len, cp);
        if (len != before) changed = true;
    }
    g_chars.clear();
    LeaveCriticalSection(&g_cs);
    return changed;
}

} // namespace keys
} // namespace nf
