// stub_modules.h - menu-driven placeholder modules (no in-game effect yet).
//
// These exist so the ClickGUI roster matches the web prototype 1:1 while the
// real implementations are still ahead. Each stub is a plain Module with
// identity + default state; enabling one flips menu/HUD-list state only.
// When a real implementation lands, its class replaces the stub here and in
// the registry - the menu needs no changes (it renders the registry).

#pragma once

#include "core/module.h"

namespace nf {

class HudModule : public Module {
public:
    HudModule();
};

class SkyboxModule : public Module {
public:
    SkyboxModule();
};

class TargetHudModule : public Module {
public:
    TargetHudModule();
};

class ZoomModule : public Module {
public:
    ZoomModule();
};

class HotbarModule : public Module {
public:
    HotbarModule();
};

class TimeChangerModule : public Module {
public:
    TimeChangerModule();
};

} // namespace nf
