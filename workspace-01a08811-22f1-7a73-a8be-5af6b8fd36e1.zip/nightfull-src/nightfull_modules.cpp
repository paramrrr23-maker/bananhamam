// nightfull_modules.cpp - safe Nightfull client-side module roster.
//
// Only the modules that actually render in this overlay remain: the
// Interface/Watermark placeholder plus the small local roster. Everything
// that would be a no-op demo - combat, movement, performance, tools and so on -
// was removed from the menu on purpose.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/nightfull_modules.h"

#include <vector>

namespace modules {

std::vector<std::unique_ptr<Module>> CreateNightfullModules() {
    // The concrete visual roster is registered in module_registry.cpp. Keep
    // this factory available for future always-on Nightfull-only modules.
    return std::vector<std::unique_ptr<Module>>();
}

} // namespace modules
