namespace nf {
namespace overlay {
static void CooldownSample(void* screenView);
namespace {
static int JavaGamePatch();
static int JavaGamePatch() { return 111; }
static int JavaPlaceAllSlot() { return JavaGamePatch(); }
void SetupCallRegression() { CooldownSample(nullptr); (void)JavaPlaceAllSlot(); }
}
static void CooldownSampleImpl(void* screenView) { (void)screenView; (void)JavaGamePatch(); }
static void CooldownSample(void* screenView) { CooldownSampleImpl(screenView); }
void RunNamespaceRegression() { SetupCallRegression(); }
}
}
int main() { nf::overlay::RunNamespaceRegression(); }
