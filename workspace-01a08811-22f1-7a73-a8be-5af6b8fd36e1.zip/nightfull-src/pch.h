// pch.h - common precompiled-style header for the overlay DLL.
// Kept simple so every .cpp can just #include "pch.h" first.
//
// NOTE: ASCII only in this file (project rule: code files are pure ASCII).

#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <Windows.h>
#include <winver.h> // GetFileVersionInfoW / VerQueryValueW (game version logging)
#include <d3d11.h>
#include <d3d12.h>
#include <dxgi.h>
#include <dxgi1_2.h>
#include <dxgi1_4.h>

#ifdef _MSC_VER
#include <excpt.h>
#endif

#include <cstdio>
#include <cstdarg>
#include <cstdint>
#include <vector>
#include <memory>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_dx12.h"

#include "utils/logger.h"
#include "utils/math.h"