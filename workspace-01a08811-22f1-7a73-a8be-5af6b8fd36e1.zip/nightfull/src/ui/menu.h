// menu.h - the Nightfull ClickGUI (single renderer, prototype design).
//
// Layout: left sidebar (brand, workspace, 5 nav + 3 project items,
// community card, user profile) + topbar (breadcrumb, search, notifications,
// avatar) + 7 pages (overview, modules, HUD editor, themes, profiles,
// sources, settings) + modals + bottom-center toasts. Visual language
// mirrors the web prototype 1:1; all modules are local-only visuals.

#pragma once

namespace nf {
namespace ui {

// Register modules + load config + reset state (once, after ImGui context).
bool Init();
// Flush config (unload path).
void Shutdown();

// Full per-frame UI pass. Runs inside the ImGui frame: pushes the theme,
// dispatches keybinds, ticks+renders modules (HUD), autosaves the config
// and draws the menu while it is open or fading.
void Frame();

// Dismiss the topmost transient UI (text field, dropdown, popup, bind
// capture). Returns true when something was dismissed (ESC handling).
bool DismissTopmost();

// Bottom-left notification ("[Nightfull] ...").
void Toast(const char* fmt, ...);

} // namespace ui
} // namespace nf
