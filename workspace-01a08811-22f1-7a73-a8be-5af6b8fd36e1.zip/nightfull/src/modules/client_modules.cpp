// client_modules.cpp - menu + theme configuration holders.

#include "modules/client_modules.h"

#include <string>
#include <vector>

#include "utils/gui_theme.h"

namespace nf {

GeneralModule* GeneralModule::s_instance = nullptr;
ThemesModule* ThemesModule::s_instance = nullptr;

GeneralModule::GeneralModule()
    : Module("Client", "General", "Menu behaviour and chrome") {
    s_instance = this;
    hiddenFromLists = true;
    setEnabled(true);

    m_animation = addSetting<EnumSetting>("Animation", "Menu open animation.", AnimRise,
        std::vector<std::string>{ "Fade", "Rise", "Zoom" });
    m_easeSpeed = addSetting<NumberSetting>("Ease Speed", "Transition speed.", 14.0f, 4.0f, 24.0f, 0.5f);
    m_scrim = addSetting<NumberSetting>("Scrim", "Backdrop darkness.", 0.45f, 0.0f, 0.8f, 0.05f);
    m_rightPanels = addSetting<BoolSetting>("Side Panels", "Legacy side stack.", true);
    m_toasts = addSetting<BoolSetting>("Toasts", "Bottom-center notifications.", true);
    m_animations = addSetting<BoolSetting>("UI Animations", "Interface animation master switch.", true);
    m_blur = addSetting<BoolSetting>("UI Blur", "Translucent overlay panels.", true);
}

ThemesModule::ThemesModule()
    : Module("Client", "Themes", "Accent color and name style") {
    s_instance = this;
    hiddenFromLists = true;
    setEnabled(true);

    m_naming = addSetting<EnumSetting>("Naming", "How module names are displayed.", NamingSpaced,
        std::vector<std::string>{ "lowercase", "lower spaced", "Normal", "Spaced" });

    std::vector<std::string> themes;
    for (int i = 0; i < gui::ThemeCount(); i++) themes.push_back(gui::ThemeName(i));
    m_theme = addSetting<EnumSetting>("Theme", "Accent preset.", ThemeCustom, themes);

    m_colorSlots = addSetting<NumberSetting>("Color Slots", "Custom accent colors in the cycle.",
                                             1.0f, 1.0f, 6.0f, 1.0f);
    m_color1 = addSetting<ColorSetting>("Color 1", "Custom accent 1.", 0xFFC1F17C);
    m_color2 = addSetting<ColorSetting>("Color 2", "Custom accent 2.", 0xFF4E7BFF);
    m_color3 = addSetting<ColorSetting>("Color 3", "Custom accent 3.", 0xFF36D0DC);
    m_color4 = addSetting<ColorSetting>("Color 4", "Custom accent 4.", 0xFF4ACD8F);
    m_color5 = addSetting<ColorSetting>("Color 5", "Custom accent 5.", 0xFFFF9746);
    m_color6 = addSetting<ColorSetting>("Color 6", "Custom accent 6.", 0xFFFF5D78);
    m_colorSpeed = addSetting<NumberSetting>("Accent Motion", "Accent cycle speed.",
                                             3.0f, 0.25f, 20.0f, 0.05f);
    m_saturation = addSetting<NumberSetting>("Saturation", "Custom color saturation.",
                                             1.0f, 0.0f, 1.0f, 0.01f);

    const auto custom = [this] { return m_theme->mValue == ThemeCustom; };
    m_colorSlots->mIsVisible = custom;
    m_color1->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 1.0f; };
    m_color2->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 2.0f; };
    m_color3->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 3.0f; };
    m_color4->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 4.0f; };
    m_color5->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 5.0f; };
    m_color6->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 6.0f; };
    m_saturation->mIsVisible = custom;
}

} // namespace nf
