// overlay.cpp - the overlay engine: hooks, D3D11/D3D12 render, input.
//
// ONLY functionality: render a clickable ImGui menu inside the game window.
// No game logic hooks, no cheats, no world/entity/player access - just a
// proof-of-injection GUI (local demo module state only).
//
// Rendering:
//   - DirectX 11: imgui_impl_dx11 (device/context extracted from swapchain)
//   - DirectX 12: imgui_impl_dx12, drawn on the GAME's own command queue.
//     The game queue is captured via a vtable hook on
//     ID3D12CommandQueue::ExecuteCommandLists (slot 10). Drawing on the
//     game queue keeps our work ordered with the game's frame work (no
//     cross-queue race on the back buffer).
//
// Vtable hooks installed via a dummy swapchain / dummy D3D12 device:
//   IDXGISwapChain::Present              = slot  8
//   IDXGISwapChain::ResizeBuffers        = slot 13
//   ID3D12CommandQueue::ExecuteCommandLists = slot 10
//
// Crash safety: hook bodies are wrapped in SEH (MSVC __try/__except) so any
// overlay bug logs an error and disables the overlay instead of crashing the
// game. Every init/render step is logged to %TEMP%\overlay_dll.log.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "overlay.h"
#include "utils/entity_registry.h"

#include "ui/clickgui.h"
#include "game/bedrock_entt.hpp"
#include "modules/module_manager.h"
#include "modules/module_registry.h"
#include "modules/movement/movement_modules.h"
#include "modules/visual/flarial_visual_modules.h"
#include "modules/visual/visual_modules.h"
#include "utils/gui_render.h"
#include "utils/keys.h"
#include "utils/file_utils.h"

#include <algorithm>
#include <cfloat>
#include <cstring>
#include <cstdlib>
#include <sstream>
#include <string>

// Forward declaration: stock imgui hides this line behind '#if 0' to avoid
// dragging <windows.h> into the header; per its own comment we copy it into
// our .cpp and declare it at GLOBAL scope (so the name is not mangled into
// a namespace).
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ======================== SEH helpers (MSVC only) ========================
#ifdef _MSC_VER
namespace overlay {
namespace {
static void*  g_SehAddr = nullptr;
static DWORD  g_SehCode = 0;

// Captures exception info inside the __except FILTER expression (the only
// place GetExceptionInformation() may legally be called). The code/addr are
// then read by TraceSeh() from the __except BODY.
static int OverlaySehFilter(PEXCEPTION_POINTERS ep) {
    g_SehAddr = (void*)ep->ExceptionRecord->ExceptionAddress;
    g_SehCode = ep->ExceptionRecord->ExceptionCode;
    return EXCEPTION_EXECUTE_HANDLER;
}

// Resolve which module the faulting address belongs to (overlay.dll, the
// D3D12 runtime, DXGI, or the GPU driver) and log it. NOTE: reads the code
// captured by the filter - GetExceptionCode() may only be called directly
// inside an __except (filter or body), never in a helper function.
static void TraceSeh(const char* where) {
    char mod[MAX_PATH] = "?";
    HMODULE hm = nullptr;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)g_SehAddr, &hm)) {
        GetModuleFileNameA(hm, mod, MAX_PATH);
    }
    ULONGLONG rva = 0;
    if (g_SehAddr && hm) rva = (ULONGLONG)((BYTE*)g_SehAddr - (BYTE*)hm);
    LOG_ERROR("SEH exception code=0x%08X addr=%p module=%s+0x%llX (in %s)",
              g_SehCode, g_SehAddr, mod, rva, where);
    g_SehAddr = nullptr;
    g_SehCode = 0;
}
} // namespace
}
#endif // _MSC_VER

// ------- External key/mouse channel (injector watcher), shared layout -------
// The injector.exe process runs a watcher: it samples GetAsyncKeyState for
// K/INSERT/ESC/END (the injector is a NORMAL desktop process, so the
// keyboard works there - unlike inside the game's AppContainer) and it
// INCREMENTS the matching counters below via WriteProcessMemory into this
// DLL's address space. The overlay reads the counters, computes the delta
// against what it already applied and triggers that many events; the
// watcher never clears and the overlay never writes, so no press is lost
// or doubled even with concurrent access.
//
// While the GUI is OPEN the watcher additionally installs global low-level
// hooks (WH_KEYBOARD_LL / WH_MOUSE_LL) in ITS OWN (desktop) process, so the
// game receives NO keyboard keys and NO mouse clicks/wheel - "input goes
// only to the GUI". The GUI itself is fed from the mirrored fields below.
// The watcher captures button/key transitions INSIDE its low-level callbacks
// before swallowing them, then publishes cursor + buttons + wheel + keyboard.
// Polling GetAsyncKeyState after a hook veto is invalid: Windows invokes
// WH_*_LL before committing async state, and a vetoed event may never update it.
//
// FIELD ORDER MUST STAY IDENTICAL in injector.cpp (both sides use offsets):
//   [0] toggle counter (K / INSERT)         - watcher increments
//   [1] esc counter (closes the menu)       - watcher increments
//   [2] end counter (requests unload)       - watcher increments
//   [3] alive magic (0x5147C0DE once armed) - watcher writes once
//   [4] menuOpen (1 while the GUI is open)  - OVERLAY writes, watcher reads
//   [5] mx / [6] my (cursor screen coords)  - watcher writes while open
//   [7] mDown (bit0=LB bit1=RB bit2=MB bit3=XB1 bit4=XB2) - watcher writes
//   [8] keyhookOn (1 when Keyboard::feed detour is live)   - OVERLAY writes
//   [9] heartbeat  - incremented by the overlay WATCHDOG THREAD (not by the
//                    render thread). The injector uses it as a liveness
//                    proof: while it keeps changing, the overlay module and
//                    its control thread are alive.
//  [10] frameTick  - incremented by the RENDER thread on every hkPresent.
//                    The injector compares it with its own sample to detect
//                    "the overlay is alive but the render loop is stuck".
//  [11] stuckName  - 0 unless the watchdog detected a stuck render thread;
//                    then set to a small code (see kStuck*) for diagnostics.
//  [12] wheel      - cumulative vertical wheel steps captured by the watcher.
// [13..20] keys[8] - 256-bit VK down-state captured inside WH_KEYBOARD_LL.
//                    This MUST come from the hook event itself: a swallowed
//                    low-level event is not guaranteed to update
//                    GetAsyncKeyState before/after the callback.
//
// IMPORTANT: [9]/[10]/[11] are what keep the external input masks from ever
// being left installed. They MUST be written by threads that cannot be
// blocked by rendering. See OverlayWatchdogThread() below.
struct ExtKeyCounters {
    volatile LONG toggle;
    volatile LONG esc;
    volatile LONG end;
    volatile LONG alive;
    volatile LONG menuOpen;
    volatile LONG mx;
    volatile LONG my;
    volatile LONG mDown;
    volatile LONG keyhookOn;
    volatile LONG heartbeat;
    volatile LONG frameTick;
    volatile LONG stuckCode;
    volatile LONG wheel;
    volatile LONG keys[8];
    volatile LONG cpsLimiterOn;
    volatile LONG cpsLeft;
    volatile LONG cpsRight;
    volatile LONG chatOpen;   // [24] overlay: 1 while a TEXT-INPUT screen owns
                              //      the keyboard (chat, sign, book, ...).
                              //      Regular menus (start, pause, inventory)
                              //      do NOT set it - menu hotkeys work there.
    volatile LONG screenFlags; // [25] overlay screen classification:
                              //      bit0 (1) = current screen is hud_screen
                              //      bit1 (2) = screen name is known
                              //      (getScreenName live). The watcher drops
                              //      its cursor-visibility fallback gate once
                              //      bit1 is set, so K/INSERT open the GUI in
                              //      Minecraft's menus.
};
static_assert(sizeof(ExtKeyCounters) == 26 * sizeof(LONG), "shared input ABI changed");
extern "C" __declspec(dllexport) ExtKeyCounters g_ext_key_flags = {};
static const LONG kExtAliveMagic = 0x5147C0DE;

// Optional Bedrock runtime pointers discovered from versioned signatures.
// They stay null when a signature does not match, so unsupported builds keep
// the overlay alive without speculative memory writes.
static volatile void* g_guiDataPtr = nullptr;
static bool g_guiDataHookTried = false;
static bool g_screenSizeHookTried = false;
static bool g_screenSizeHookBad = false;   // runtime proof: hooked a lookalike
static bool g_gammaHookTried = false;
static bool g_perspectiveHookTried = false;
static bool g_freelookCameraHookTried = false;
static float g_savedGuiScale = 0.0f;
static bool g_savedGuiScaleValid = false;
static float g_savedGuiScaledResolution[2] = { 0.0f, 0.0f };
static void* g_clientInstancePtr = nullptr;  // captured by the screen-size hook
static int g_localPlayerVfunc = -1;          // ClientInstance vtable index of getLocalPlayer
                                             // (resolved later by TryInstallFlarialHooks)
static float g_lastRealScreenSize[2] = { 0.0f, 0.0f };  // args of the last game screen-size update

namespace overlay {

// ======================== Globals ========================
bool g_ExtKeysActive = false; // first external event seen -> disable frame key poll
// The menu starts HIDDEN; INSERT or K opens it. This matches classic
// ClickGUI behavior (no overlay at launch). The X button closes it.
bool           g_ShowMenu     = false;
int            g_clickCount   = 0;
bool           g_RenderD3D12  = false;
volatile LONG  g_SharedAbort  = 0;

// --- render-thread liveness (drives the external input masks) -------------
// g_lastFrameMs is stamped by hkPresent. A SEPARATE thread (see
// OverlayWatchdogThread) owns the shared menuOpen/heartbeat fields and force
// closes the menu when no frame has been seen for kFrameTimeoutMs, so a hung
// render thread can no longer leave the global input masks installed forever.
volatile LONG  g_lastFrameMs  = 0;
volatile LONG  g_watchdogStop = 0;

// --- diagnostics: what was the render thread doing when it got stuck? ----
// Set by ui/clickgui.cpp around every module callback and around the render
// phases; read by the watchdog so the log names the culprit instead of
// leaving you with a frozen machine and no clue.
const char* volatile g_activeModuleName = nullptr;
const char* volatile g_activePhase      = nullptr;

// --- Flarial-port shared state (see overlay.h) ---
void* g_hotbarTextureData = nullptr;       // BedrockTextureData* of the hotbar selector
float g_lastHitDistance = 0.0f;            // Reach Display
unsigned long g_lastHitTickMs = 0;
volatile LONG g_lastHitValid = 0;
volatile LONG g_pingMs = -1;               // real average ping (RakPeer hook)
volatile LONG g_critBurstStartMs = 0;      // Crit Particles: last landed hit
volatile LONG g_critBurstSeed = 0;

// --- Crit Particles (SystemDLC TargetESP-style): entity-centered bursts ----
CritBurst g_critBursts[kMaxCritBursts] = {};
volatile LONG g_critBurstHead = 0;
volatile LONG g_critBurstTick = 0;

// Monitoring HUD: local-player tick counter (bumped by the baseTick hook).
volatile LONG g_monitorTickCounter = 0;

// Target HUD: last attacked entity + hit timestamp.
volatile void* g_targetActor = nullptr;
volatile LONG  g_targetTickMs = 0;

// Damage events: filled by the attack hook when hp actually dropped.
DamageEvent   g_damageEvents[kMaxDamageEvents] = {};
volatile LONG g_damageHead = 0;

void PushCritBurst(const float pos[3], unsigned int entityKey, unsigned int seed) {
    const LONG head = InterlockedExchangeAdd(&g_critBurstHead, 1);
    CritBurst& b = g_critBursts[head % kMaxCritBursts];
    b.pos[0] = pos[0]; b.pos[1] = pos[1]; b.pos[2] = pos[2];
    b.entityKey = entityKey;
    b.seed = seed;
    b.startMs = GetTickCount();
    InterlockedExchange(&g_critBurstTick, head + 1);
}

namespace {

// --- Flarial-port hook prototypes (used by hkSetupAndRender below; defined
// --- further down in this file) --------------------------------------------
static void __fastcall hkDrawImage(void* ctx, void* textureData, float* imagePos,
                                   float* imageDim, float* uvPos, float* uvSize, bool unk);

// --- chat/text screen gate (ClientInstance::getScreenName) -----------------
using GetScreenNameFn = std::string(__fastcall*)(void*);
static GetScreenNameFn g_getScreenNameFn = nullptr;

// SEH wrapper for the game's getScreenName (returns std::string by value into
// the caller-provided 32-byte MSVC string buffer).
static bool CallGetScreenName(void* fn, void* ci, unsigned char* out) {
    __try {
        ((void(__fastcall*)(void*, void*))fn)(out, ci);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Text-input screens: the keyboard belongs to a text field, so the global
// hotkeys (K/INSERT/ESC/END) must not fire there. The names are Bedrock's own
// UI screen identifiers (ClientInstance::getScreenName).
static bool IsTextScreenName(const std::string& name) {
    return name.find("chat")            != std::string::npos ||
           name.find("sign")            != std::string::npos ||
           name.find("book")            != std::string::npos ||
           name.find("command_block")   != std::string::npos ||
           name.find("structure_block") != std::string::npos;
}

// True while the local player object exists -> a world/server is joined.
// Used as the in-world fallback when getScreenName has no signature. Lives
// here because PublishChatOpen needs it; g_localPlayerVfunc is resolved
// later (TryInstallFlarialHooks) - until then this simply reports false.
static bool LocalPlayerExists() {
    if (!g_clientInstancePtr || g_localPlayerVfunc <= 0) return false;
    __try {
        void** vtable = *(void***)g_clientInstancePtr;
        if (!vtable || !vtable[g_localPlayerVfunc]) return false;
        void* lp = ((void*(__fastcall*)(void*))vtable[g_localPlayerVfunc])(
            g_clientInstancePtr);
        return lp != nullptr;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Publishes g_ext_key_flags.chatOpen / screenFlags from the current screen
// name. Kept __try-free: the SEH lives inside CallGetScreenName.
static void PublishChatOpen(void* muirc) {
    if (!muirc || !g_getScreenNameFn) return;
    void* ci = *(void**)((uintptr_t)muirc + 0x8);
    if (!ci) return;
    alignas(8) unsigned char sbuf[32] = {};
    if (!CallGetScreenName(g_getScreenNameFn, ci, sbuf)) return;
    std::string name;
    memcpy(&name, sbuf, sizeof(name));  // take ownership of the game-constructed string

    // Classification:
    //   chat/sign/...  -> keyboard owned: no hotkeys at all (chatOpen=1);
    //   hud_screen     -> in world: hotkeys AND keybinds;
    //   other screens  -> the menu hotkeys K/INSERT still toggle the ClickGUI
    //                     (so it opens in Minecraft's menus); module keybinds
    //                     stay in-world - see DispatchKeybinds.
    const bool nameKnown = !name.empty();
    const bool inWorld = nameKnown ? (name == "hud_screen") : LocalPlayerExists();
    const bool textScreen = IsTextScreenName(name);
    g_ext_key_flags.chatOpen = textScreen ? 1 : 0;
    g_ext_key_flags.screenFlags = (inWorld ? 1 : 0) | 2;  // | 2: name known

    static bool nameLogged = false;
    if (!nameLogged) {
        LOG_INFO("screen: current screen name = \"%s\" (text=%d inWorld=%d)",
                 name.c_str(), textScreen ? 1 : 0, inWorld ? 1 : 0);
        nameLogged = true;
    }
}

// --- D3D11 ---
ID3D11Device*           g_Device    = nullptr;
ID3D11DeviceContext*    g_Context   = nullptr;
IDXGISwapChain*         g_SwapChain = nullptr;
ID3D11RenderTargetView* g_RTV       = nullptr;

// --- D3D12 ---
ID3D12Device*              g_d12Device    = nullptr;
ID3D12CommandAllocator*    g_d12CmdAlloc  = nullptr;
ID3D12GraphicsCommandList* g_d12CmdList   = nullptr;
ID3D12CommandQueue*        g_d12Queue     = nullptr; // GAME queue (never released)
// Our OWN DIRECT queue, used only for ImGui's internal uploads (font
// texture). The DX12 backend waits on a fence with an INFINITE timeout right
// after submitting to InitInfo.CommandQueue (imgui_impl_dx12.cpp:433-439);
// doing that on the game's queue from inside hkPresent can deadlock the
// game's render thread. A private queue makes that wait independent of the
// game's GPU work.
ID3D12CommandQueue*        g_d12OwnQueue  = nullptr;
ID3D12DescriptorHeap*      g_d12RtvHeap   = nullptr;
ID3D12DescriptorHeap*      g_d12SrvHeap   = nullptr; // CBV_SRV_UAV, shader-visible
UINT                       g_d12RtvSize   = 0;
D3D12_CPU_DESCRIPTOR_HANDLE g_d12RtvCpu{};
ID3D12Resource*            g_d12BB[4]     = {};
UINT                       g_d12FrameCount = 2;
ID3D12Fence*               g_d12Fence     = nullptr;
HANDLE                     g_d12FenceEvt  = nullptr;
UINT64                     g_d12FenceVal  = 0;

// --- shared state ---
bool                     g_Init          = false;
HWND                     g_hwnd          = nullptr;
HMODULE                  g_ModuleHandle = nullptr;

// --- render serialization -------------------------------------------------
// D3D12 command-list RECORDING is not thread-safe, and neither is the ImGui
// context. hkPresent / hkResizeBuffers can be reached from more than one game
// thread (render thread vs. the thread that resizes the swap chain), and
// hkResizeBuffers tears the whole D3D12 state down underneath the frame that
// is currently recording. Every render/teardown step therefore runs under
// this lock, and g_inRender guards re-entrancy (our own ExecuteCommandLists
// passes through the hooked vtable again).
CRITICAL_SECTION         g_RenderCs       = {};
volatile LONG            g_inRender       = 0;

// Input strategy (multi-layer, in order of reliability):
//   1. Keyboard::feed detour (MinHook, Solstice-style) - the ONLY source
//      that can also SWALLOW ESC while the menu is open. Active only when
//      the signature matches the installed game version.
//   2. External key watcher in injector.exe - injector is a NORMAL desktop
//      process (not the AppContainer), so GetAsyncKeyState there works
//      even though the same call inside the game returns 0 for keys
//      (proven: mouse works, keyboard never produces events). Injector
//      increments exported g_ext_key_flags counters via WriteProcessMemory
//      (deltas applied per frame, watcher never clears -> no double toggle).
//   3. Per-frame GetAsyncKeyState polling inside the game (render thread) -
//      fallback, usually disabled because the AppContainer swallows keys.
// While the GUI is OPEN the watcher additionally masks the game's input with
// global WH_KEYBOARD_LL/WH_MOUSE_LL hooks in its own process (keys and
// clicks never reach the game) and mirrors cursor+buttons into this struct
// for the GUI.
// The menu state (g_ShowMenu) is written and read on the same render
// thread, so there is no cross-thread race and no render round-trip.
bool                     g_InitTouched   = false; // InitD3D12 allocated something
bool                     g_InitBlocked   = false; // permanent failure, stop retrying
volatile LONG            g_RenderAborted = 0;     // overlay render crashed, disable it
bool                     g_ShuttingDown  = false; // process detaching, stop all work
bool                     g_UnloadRequested = false;
bool                     g_Unloaded         = false;
bool                     g_RehookTried     = false; // watchdog: one re-hook attempt done

// --- backend flags (safe shutdown even on partial init) ---
bool g_ImGuiCtx         = false;
bool g_Win32BackendInit = false;
bool g_Dx11BackendInit  = false;
bool g_Dx12BackendInit  = false;

// --- hook targets ---
typedef HRESULT(__stdcall* PresentFn)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(__stdcall* ResizeBuffersFn)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
typedef void(__stdcall* ExecCmdListsFn)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);
PresentFn       oPresent       = nullptr;
ResizeBuffersFn oResizeBuffers = nullptr;
ExecCmdListsFn  oExecCmdLists  = nullptr;

// Stored vtable pointers so a safe-unload can restore the original slots.
void** g_hookedSwapVtable  = nullptr;
void** g_hookedQueueVtable = nullptr;

// ImGui_ImplWin32_WndProcHandler is declared globally by
// imgui_impl_win32.h (included via pch.h) - no local extern needed.
static WNDPROC g_origWnd = nullptr;

// vtable slots (verified vs DirectX-Headers)
enum {
    PRESENT_INDEX        = 8,
    RESIZEBUFFERS_INDEX  = 13,
    EXEC_CMD_LISTS_INDEX = 10
};

// Defined after WndProc (further below); forward-declared so the init paths
// can call it.
void InstallWndProcHook();

// Defined below (after the render/init section). Installs the shared
// ExecuteCommandLists vtable hook; safe to call repeatedly (guarded once).
void HookCommandQueueVTable();

// Defined below (after the render/init section). Restores hooks and tears
// down the overlay; guarded internally against being called twice.
void FinishUnload();

// ======================== Find game windows ========================
// Minecraft (UWP) may have several top-level windows (splash, loading,
// main render). Collect ALL visible ones of our process: the main render
// window is whichever one accepts a dummy DXGI swapchain.

// Log the game's build version so the correct Keyboard::feed signature can be
// selected. Inside the UWP AppContainer the plain file-version APIs can fail
// silently, so EVERY step logs its outcome and we fall back to reading the
// VS_VERSIONINFO resource by hand (load our own EXE as a data file - always
// allowed for the process image).
void LogGameVersion() {
    wchar_t exe[MAX_PATH] = {};
    DWORD n = GetModuleFileNameW(nullptr, exe, MAX_PATH);
    if (n == 0) {
        LOG_INFO("game version: unknown (GetModuleFileNameW err=%lu)",
                 (unsigned long)GetLastError());
        return;
    }

    // Path 1: classic file-version APIs.
    DWORD handle = 0;
    DWORD sz = GetFileVersionInfoSizeW(exe, &handle);
    if (sz) {
        std::vector<BYTE> buf(sz);
        if (GetFileVersionInfoW(exe, handle, sz, buf.data())) {
            VS_FIXEDFILEINFO* ffi = nullptr;
            UINT flen = 0;
            if (VerQueryValueW(buf.data(), L"\\", (void**)&ffi, &flen) && ffi &&
                ffi->dwSignature == 0xFEEF04BD) {
                LOG_INFO("game version: %u.%u.%u.%u (file)",
                         HIWORD(ffi->dwFileVersionMS), LOWORD(ffi->dwFileVersionMS),
                         HIWORD(ffi->dwFileVersionLS), LOWORD(ffi->dwFileVersionLS));
                return;
            }
        }
        LOG_INFO("game version: file-version parse failed for %ls (err=%lu) - trying resource",
                 exe, (unsigned long)GetLastError());
    } else {
        LOG_INFO("game version: GetFileVersionInfoSizeW=0 err=%lu for %ls - trying resource",
                 (unsigned long)GetLastError(), exe);
    }

    // Path 2: load the image as data and walk VS_VERSIONINFO manually.
    HMODULE hmod = LoadLibraryExW(exe, nullptr, LOAD_LIBRARY_AS_DATAFILE);
    if (!hmod) {
        LOG_INFO("game version: unknown (LOAD_LIBRARY_AS_DATAFILE err=%lu)",
                 (unsigned long)GetLastError());
        return;
    }
    HRSRC rsrc = FindResourceW(hmod, (LPCWSTR)MAKEINTRESOURCE(1), (LPCWSTR)RT_VERSION);
    if (!rsrc) {
        LOG_INFO("game version: unknown (no RT_VERSION resource)");
        FreeLibrary(hmod);
        return;
    }
    HGLOBAL hg = LoadResource(hmod, rsrc);
    const BYTE* data = (const BYTE*)LockResource(hg);
    DWORD dataSz = SizeofResource(hmod, rsrc);
    // VS_VERSIONINFO: 3 WORDs header + key "VS_VERSION_INFO\0" (UTF-16) +
    // padding to 4 -> VS_FIXEDFILEINFO sits at fixed offset 40 (17 chars
    // incl. terminator = 34 bytes, 6 + 34 = 40, already aligned).
    if (data && dataSz >= 40 + sizeof(VS_FIXEDFILEINFO)) {
        const VS_FIXEDFILEINFO* ffi =
            (const VS_FIXEDFILEINFO*)(data + 40);
        if (ffi->dwSignature == 0xFEEF04BD) {
            LOG_INFO("game version: %u.%u.%u.%u (resource)",
                     HIWORD(ffi->dwFileVersionMS), LOWORD(ffi->dwFileVersionMS),
                     HIWORD(ffi->dwFileVersionLS), LOWORD(ffi->dwFileVersionLS));
        } else {
            LOG_INFO("game version: unknown (resource sig=0x%08lX)",
                     (unsigned long)ffi->dwSignature);
        }
    } else {
        LOG_INFO("game version: unknown (resource too small, sz=%lu)", (unsigned long)dataSz);
    }
    FreeLibrary(hmod);
}
BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lp) {
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == GetCurrentProcessId() && IsWindowVisible(hwnd)) {
        std::vector<HWND>* list = (std::vector<HWND>*)lp;
        list->push_back(hwnd);
    }
    return TRUE;
}

std::vector<HWND> CollectGameWindows() {
    std::vector<HWND> list;
    EnumWindows(EnumProc, (LPARAM)&list);
    auto area = [](HWND h) -> LONG {
        RECT r{}; GetWindowRect(h, &r);
        return (r.right - r.left) * (r.bottom - r.top);
    };
    for (size_t i = 1; i < list.size(); i++)
        for (size_t j = i; j > 0 && area(list[j - 1]) < area(list[j]); j--)
            std::swap(list[j - 1], list[j]);
    return list;
}

void LogWindowInfo(HWND hwnd, const char* tag) {
    RECT r{}; GetWindowRect(hwnd, &r);
    DWORD style = GetWindowLongW(hwnd, GWL_STYLE);
    LOG_INFO("window[%s]: hwnd=%p rect=%ldx%ld+%ld+%ld style=0x%08lX",
             tag, hwnd, r.right - r.left, r.bottom - r.top, r.left, r.top, style);
}

// ======================== D3D11 helpers ========================
bool CreateRT11() {
    if (!g_SwapChain) return false;
    ID3D11Texture2D* bb = nullptr;
    HRESULT hr = g_SwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb);
    if (FAILED(hr) || !bb) {
        LOG_ERROR("CreateRT11: GetBuffer hr=%08X", hr);
        return false;
    }
    hr = g_Device->CreateRenderTargetView(bb, nullptr, &g_RTV);
    if (FAILED(hr)) LOG_ERROR("CreateRT11: CreateRenderTargetView hr=%08X", hr);
    bb->Release();
    return g_RTV != nullptr;
}

void CleanupRT11() {
    if (g_RTV) { g_RTV->Release(); g_RTV = nullptr; }
}

// ======================== D3D12 helpers ========================
void D3D12CreateRTVs(IDXGISwapChain* sc) {
    g_d12RtvCpu = g_d12RtvHeap->GetCPUDescriptorHandleForHeapStart();
    for (UINT i = 0; i < g_d12FrameCount; i++) {
        if (g_d12BB[i]) { g_d12BB[i]->Release(); g_d12BB[i] = nullptr; }
        ID3D12Resource* bb = nullptr;
        if (FAILED(sc->GetBuffer(i, IID_PPV_ARGS(&bb)))) continue;
        D3D12_CPU_DESCRIPTOR_HANDLE h = g_d12RtvCpu;
        h.ptr += (SIZE_T)i * g_d12RtvSize;
        g_d12Device->CreateRenderTargetView(bb, nullptr, h);
        g_d12BB[i] = bb;
    }
}

void D3D12CleanupRTs() {
    for (UINT i = 0; i < g_d12FrameCount; i++) {
        if (g_d12BB[i]) { g_d12BB[i]->Release(); g_d12BB[i] = nullptr; }
    }
}

// Release all D3D12 objects we created. NEVER release g_d12Queue - it is
// the GAME's command queue and we only borrowed the pointer.
void D3D12Cleanup() {
    if (g_d12CmdList)   { g_d12CmdList->Release();   g_d12CmdList   = nullptr; }
    if (g_d12CmdAlloc)  { g_d12CmdAlloc->Release();  g_d12CmdAlloc  = nullptr; }
    D3D12CleanupRTs();
    if (g_d12RtvHeap)   { g_d12RtvHeap->Release();   g_d12RtvHeap   = nullptr; }
    if (g_d12SrvHeap)   { g_d12SrvHeap->Release();   g_d12SrvHeap   = nullptr; }
    if (g_d12Fence)     { g_d12Fence->Release();     g_d12Fence     = nullptr; }
    if (g_d12FenceEvt)  { CloseHandle(g_d12FenceEvt); g_d12FenceEvt = nullptr; }
    if (g_d12OwnQueue)  { g_d12OwnQueue->Release();  g_d12OwnQueue  = nullptr; }
    if (g_d12Device)    { g_d12Device->Release();    g_d12Device    = nullptr; }
}

// ======================== Per-frame input ========================
// Bedrock renders via DX12 and reads the mouse through RawInput/CoreWindow,
// so the game window does NOT receive classic WM_MOUSEMOVE / WM_LBUTTONDOWN
// messages. ImGui's Win32 backend only sees messages that arrive at the
// window, which is why the menu hovered but never reacted before. The
// standard fix used by overlays on such games: poll GetCursorPos +
// GetAsyncKeyState every frame and feed the state into ImGui directly.
// Return the best client window for input. On Bedrock the swapchain can
// report OutputWindow=0 because it renders through CoreWindow, while the
// real top-level game HWND is still visible to EnumWindows. Prefer the HWND
// captured by MainThread, but refresh it from the foreground window when the
// foreground belongs to this process.
HWND ResolveInputWindow() {
    HWND hwnd = g_hwnd;
    HWND foreground = GetForegroundWindow();
    if (foreground && IsWindow(foreground)) {
        DWORD pid = 0;
        GetWindowThreadProcessId(foreground, &pid);
        if (pid == GetCurrentProcessId() && IsWindowVisible(foreground)) {
            hwnd = foreground;
            g_hwnd = foreground;
        }
    }
    return (hwnd && IsWindow(hwnd)) ? hwnd : nullptr;
}

void SetCursorVisible(bool visible) {
    // ShowCursor uses a per-thread display counter, and Bedrock may change
    // that counter while entering a world. When the menu is OPEN we force
    // the OS cursor visible for the ClickGUI. When the menu is CLOSED we do
    // NOT touch the cursor at all - the game owns it, and with the menu
    // starting hidden by default we must never hide the in-game cursor.
    //
    // Performance: this runs once per frame via UpdateHotkeys. ClipCursor /
    // ReleaseCapture / SetCursor every frame are expensive (they visibly
    // lag the menu). We only do them ONCE when the state actually changes
    // (g_cursorGuiActive tracks whether the GUI currently owns the cursor).
    static bool g_cursorGuiActive = false;
    static HCURSOR g_arrow = LoadCursor(nullptr, IDC_ARROW);
    if (!g_arrow) g_arrow = LoadCursor(nullptr, IDC_ARROW);

    // How many times WE raised the ShowCursor display counter. Tracked so the
    // "show" step can never spin (see below) and so the "hide" step can undo
    // exactly our own contribution.
    static int g_showBalance = 0;

    if (!visible) {
        if (g_cursorGuiActive) {
            // Give back exactly what we took: ShowCursor uses a display
            // counter that Bedrock also decrements, so rebalancing keeps the
            // in-game cursor state intact when the menu closes.
            while (g_showBalance > 0) { ShowCursor(FALSE); g_showBalance--; }
            ReleaseCapture();
            ClipCursor(nullptr);
            g_cursorGuiActive = false;
        }
        return;
    }

    if (!g_cursorGuiActive) {
        ClipCursor(nullptr);
        ReleaseCapture();
        g_cursorGuiActive = true;
    }

    // FIX (this was the hard system freeze).
    // The old code did:
    //     while (ShowCursor(TRUE) < 0) {}
    // ShowCursor only bumps a display counter that Bedrock keeps pushing down
    // (it hides the OS cursor while you are in a world). The loop therefore
    // either ran for a very long time or never ended - and it ran ON THE
    // GAME'S RENDER THREAD, inside hkPresent. Present() never returned, the
    // game froze with the GUI open, and because menuOpen was left at 1 the
    // external global input masks never came off: keyboard dead (Windows key
    // only), mouse frozen, hard reset required. That is exactly what the log
    // of the failing run shows (last line: "menu: toggle -> visible=1
    // source=external", then nothing).
    //
    // Bounded replacement: raise the counter at most a handful of times, stop
    // as soon as the OS cursor is actually visible, and never spin. If the OS
    // cursor stays hidden we simply draw our own (io.MouseDrawCursor is set
    // by UpdateCursorVisibility) - the GUI works either way.
    for (int i = 0; i < 4 && g_showBalance < 4; i++) {
        CURSORINFO chk{};
        chk.cbSize = sizeof(chk);
        if (GetCursorInfo(&chk) && (chk.flags & CURSOR_SHOWING) != 0)
            break;
        ShowCursor(TRUE);
        g_showBalance++;
    }
    SetCursor(g_arrow);
}

void UpdateCursorVisibility() {
    ImGuiIO& io = ImGui::GetIO();
    const bool guiCursor = g_ShowMenu;

    io.MouseDrawCursor = guiCursor;
    SetCursorVisible(guiCursor);
}

bool PollKeyDown(int vk) {
    // GetAsyncKeyState is the primary source. GetKeyState is a fallback for
    // UWP focus transitions where the async state can briefly return zero.
    SHORT asyncState = GetAsyncKeyState(vk);
    if ((asyncState & 0x8000) != 0)
        return true;
    return (GetKeyState(vk) & 0x8000) != 0;
}

// ======================== Keyboard::feed hook (Solstice approach) ========================
// Solstice reads keys from the game's OWN input dispatcher by detouring
// Keyboard::feed(key, isDown) (see Solstice KeyHook.cpp). That works inside
// the AppContainer sandbox because it uses the game's internal input path,
// not global Win32 APIs (RegisterHotKey / WH_KEYBOARD_LL are blocked there,
// and GetAsyncKeyState on a bare worker thread without a message queue
// returns 0 forever). We replicate that: scan the game binary for the
// signature used by Solstice, detour Keyboard::feed with MinHook, and
// toggle the menu from inside the game's key dispatch. If the signature
// does not match the installed game version we fall back to per-frame
// GetAsyncKeyState polling (still better than nothing).
#include <MinHook.h>

// Signature of Keyboard::feed (Solstice SigManager, v1.21.101-1.21.111):
//   E8 ? ? ? ? E9 03 03 ? ? 0F BE 73 16 44 0F B7 7B 12 44 0F
// type RefSig, offset 1 -> result points at the E8 CALL; the function
// address = match + 5 + rel32.
static const uint8_t kKeyFeedPattern[] = {
    0xE8, 0x00, 0x00, 0x00, 0x00, 0xE9, 0x03, 0x03, 0x00, 0x00,
    0x0F, 0xBE, 0x73, 0x16, 0x44, 0x0F, 0xB7, 0x7B, 0x12, 0x44, 0x0F
};
static const char kKeyFeedMask[] =
    "x????" // E8 ? ? ? ?
    "xxx??" // E9 03 03 ? ?
    "xxxxxxxxxxxx"; // 0F BE 73 16 44 0F B7 7B 12 44 0F  (12 fixed)
static const size_t kKeyFeedLen = 21;

typedef void(__cdecl* KeyboardFeedFn)(uint32_t key, bool isDown);
static KeyboardFeedFn  oKeyboardFeed   = nullptr;
static bool            g_KeyHookActive = false;
static bool            g_KeyHookTried  = false;
static volatile LONG   g_FeedKeys[8]   = {}; // 256-bit state when Keyboard::feed hook is active

// Packet/Flarial mouse dispatcher state.  Bedrock sends movement, button and
// wheel transitions through MouseDevice::feed (called ClickFunc in Packet).
// The hook only publishes POD state here; ImGui is touched later on the
// render thread, so the game input thread never races the ImGui context.
using MouseFeedFn = void(__fastcall*)(void*, char, char, short, short,
                                      short, short, char);
static MouseFeedFn  g_mouseFeedOriginal = nullptr;
static bool         g_MouseHookActive   = false;
static bool         g_MouseHookTried    = false;
static volatile LONG g_gameMouseX       = 0;
static volatile LONG g_gameMouseY       = 0;
static volatile LONG g_gameMouseButtons = 0;
static volatile LONG g_gameMouseWheel   = 0;
static volatile LONG g_gameMouseValid  = 0;
// DLL-local raw relative cursor channel.  It is captured before the raw
// packet is neutralized for Minecraft, so the GUI still moves even when the
// external watcher is unavailable or the game keeps the OS cursor centered.
static volatile LONG g_localRawDx      = 0;
static volatile LONG g_localRawDy      = 0;
// MouseDevice::feed also carries relative deltas. Keep this channel separate
// from raw input so the render thread can prefer the game's dispatcher when
// both paths report the same physical movement (avoids double-speed cursor).
static volatile LONG g_localFeedDx     = 0;
static volatile LONG g_localFeedDy     = 0;

// Defined in the Java Hotkeys section below: performs the Flarial-style
// inventory swap for a pressed hotbar bind (positive VK or negative mouse
// code). Safe to call for any bind value - it filters non-binds itself.
static void JavaHotkeysTrySwap(int bindValue);

static void __fastcall hkMouseFeed(void* mouseDevice, char mouseButton,
                                    char isDown, short mouseX, short mouseY,
                                    short relativeMovementX,
                                    short relativeMovementY, char a8) {
    // Defined in the Java Hotkeys section below (Flarial inventory swaps).
    // Bedrock stores mouse binds as -100 + buttonCode with the feed's own
    // numbering: 1=LMB (-99), 2=RMB (-98), 3=MMB (-97), 5=X1 (-95), 6=X2 (-94).
    // Releases pass 0 so the press guard re-arms.
    if (mouseButton >= 1 && mouseButton <= 6 && mouseButton != 4 &&
        !overlay::g_ShowMenu) {
        JavaHotkeysTrySwap(isDown == 1 ? (-100 + (int)mouseButton) : 0);
    }

    (void)mouseDevice;
    (void)a8;

    if (mouseButton == 0) {
        // Packet exposes the current client-space position on movement events.
        InterlockedExchange(&g_gameMouseX, (LONG)mouseX);
        InterlockedExchange(&g_gameMouseY, (LONG)mouseY);
        InterlockedExchange(&g_gameMouseValid, 1);
        if (g_ShowMenu && (relativeMovementX != 0 || relativeMovementY != 0)) {
            InterlockedExchangeAdd(&g_localFeedDx, (LONG)relativeMovementX);
            InterlockedExchangeAdd(&g_localFeedDy, (LONG)relativeMovementY);
        }
        if (g_MouseHookActive && g_ShowMenu)
            return;
        if (g_mouseFeedOriginal)
            g_mouseFeedOriginal(mouseDevice, mouseButton, isDown, mouseX,
                                mouseY, relativeMovementX, relativeMovementY,
                                a8);
        return;
    }

    switch (mouseButton) {
        case 1: // left
            if (isDown) InterlockedOr(&g_gameMouseButtons, 1);
            else       InterlockedAnd(&g_gameMouseButtons, ~1L);
            break;
        case 2: // right
            if (isDown) InterlockedOr(&g_gameMouseButtons, 2);
            else       InterlockedAnd(&g_gameMouseButtons, ~2L);
            break;
        case 3: // middle
            if (isDown) InterlockedOr(&g_gameMouseButtons, 4);
            else       InterlockedAnd(&g_gameMouseButtons, ~4L);
            break;
        case 4: // wheel: Packet uses +120/-120 in isDown
            if (isDown != 0)
                InterlockedExchangeAdd(&g_gameMouseWheel, isDown > 0 ? 1 : -1);
            break;
        default:
            break;
    }

    // Button and wheel packets also carry the current pointer coordinates on
    // Bedrock builds that use MouseDevice::feed. Keep the latest position even
    // when the user clicks without generating a separate move packet.
    if (mouseX >= 0 && mouseY >= 0) {
        InterlockedExchange(&g_gameMouseX, (LONG)mouseX);
        InterlockedExchange(&g_gameMouseY, (LONG)mouseY);
        InterlockedExchange(&g_gameMouseValid, 1);
    }

    // This is the Packet cancellation point: button-down, wheel and movement
    // packets do not reach Minecraft while the ClickGUI is open. A button-up
    // is still forwarded so a click that was already held when the menu
    // opened cannot remain logically stuck in the game.
    const bool buttonRelease = (mouseButton >= 1 && mouseButton <= 3 && !isDown);
    if (g_MouseHookActive && g_ShowMenu && !buttonRelease)
        return;
    if (g_mouseFeedOriginal)
        g_mouseFeedOriginal(mouseDevice, mouseButton, isDown, mouseX, mouseY,
                            relativeMovementX, relativeMovementY, a8);
}

static bool FeedKeyDown(UINT vk) {
    if (vk > 0xFF) return false;
    const LONG bit = (LONG)(1u << (vk & 31));
    return (g_FeedKeys[vk >> 5] & bit) != 0;
}

static void SetFeedKey(UINT vk, bool down) {
    if (vk > 0xFF) return;
    const LONG bit = (LONG)(1u << (vk & 31));
    if (down) InterlockedOr(&g_FeedKeys[vk >> 5], bit);
    else      InterlockedAnd(&g_FeedKeys[vk >> 5], ~bit);

    if (vk == VK_LSHIFT || vk == VK_RSHIFT)
        SetFeedKey(VK_SHIFT, FeedKeyDown(VK_LSHIFT) || FeedKeyDown(VK_RSHIFT));
    else if (vk == VK_LCONTROL || vk == VK_RCONTROL)
        SetFeedKey(VK_CONTROL, FeedKeyDown(VK_LCONTROL) || FeedKeyDown(VK_RCONTROL));
    else if (vk == VK_LMENU || vk == VK_RMENU)
        SetFeedKey(VK_MENU, FeedKeyDown(VK_LMENU) || FeedKeyDown(VK_RMENU));
}

// Linear byte scan of every executable section of the main module.
uintptr_t ScanExecutableSections(HMODULE module) {
    const uint8_t* base = (const uint8_t*)module;
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD s = 0; s < nt->FileHeader.NumberOfSections; s++, sec++) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* start = base + sec->VirtualAddress;
        const uint8_t* end   = start + sec->Misc.VirtualSize;
        for (const uint8_t* p = start; p + kKeyFeedLen <= end; p++) {
            if (p[0] != kKeyFeedPattern[0]) continue; // fast reject on 0xE8
            bool ok = true;
            for (size_t k = 0; k < kKeyFeedLen; k++) {
                if (kKeyFeedMask[k] == 'x' && p[k] != kKeyFeedPattern[k]) {
                    ok = false;
                    break;
                }
            }
            if (ok) return (uintptr_t)p;
        }
    }
    return 0;
}

static uintptr_t ScanPattern(HMODULE module, const uint8_t* pattern,
                             const char* mask, size_t length) {
    if (!module || !pattern || !mask || length == 0) return 0;
    const uint8_t* base = (const uint8_t*)module;
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD s = 0; s < nt->FileHeader.NumberOfSections; ++s, ++sec) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* begin = base + sec->VirtualAddress;
        const uint8_t* end = begin + sec->Misc.VirtualSize;
        for (const uint8_t* p = begin; p + length <= end; ++p) {
            bool match = true;
            for (size_t i = 0; i < length; ++i) {
                if (mask[i] == 'x' && p[i] != pattern[i]) { match = false; break; }
            }
            if (match) return (uintptr_t)p;
        }
    }
    return 0;
}

// Parse the space-separated signatures used by Solstice/Flarial. Keeping the
// parser here lets us carry several version candidates without hand-counting
// byte arrays and masks, which is particularly error-prone for wildcard-heavy
// GuiData signatures.
static bool BuildPattern(const char* signature, std::vector<uint8_t>* bytes,
                         std::string* mask) {
    if (!signature) return false;
    std::istringstream stream(signature);
    std::string token;
    while (stream >> token) {
        if (token == "?" || token == "??") {
            bytes->push_back(0);
            mask->push_back('?');
            continue;
        }
        char* end = nullptr;
        const unsigned long value = std::strtoul(token.c_str(), &end, 16);
        if (!end || *end != '\0' || value > 0xFFul) return false;
        bytes->push_back((uint8_t)value);
        mask->push_back('x');
    }
    return !bytes->empty();
}

static uintptr_t ScanSignature(HMODULE module, const char* signature) {
    std::vector<uint8_t> bytes;
    std::string mask;
    if (!BuildPattern(signature, &bytes, &mask)) return 0;
    return ScanPattern(module, bytes.data(), mask.c_str(), bytes.size());
}

// Ambiguity-aware scan: counts matches but stops at 2. A signature matching
// more than once may have caught a lookalike function, and hooking - or worse,
// CALLING with forged arguments - a lookalike is a crash. Returns the number
// of matches found (0, 1 or 2 = "2 or more"); *firstOut gets the first hit.
static int ScanSignatureMatches(HMODULE module, const char* signature,
                                uintptr_t* firstOut) {
    std::vector<uint8_t> bytes;
    std::string mask;
    if (firstOut) *firstOut = 0;
    if (!BuildPattern(signature, &bytes, &mask)) return 0;
    const uint8_t* base = (const uint8_t*)module;
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    if (!base || dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    int matches = 0;
    const size_t length = bytes.size();
    for (WORD s = 0; s < nt->FileHeader.NumberOfSections && matches < 2; ++s, ++sec) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* begin = base + sec->VirtualAddress;
        const uint8_t* end   = begin + sec->Misc.VirtualSize;
        for (const uint8_t* p = begin; p + length <= end; ++p) {
            bool ok = true;
            for (size_t i = 0; i < length; ++i) {
                if (mask[i] == 'x' && p[i] != bytes[i]) { ok = false; break; }
            }
            if (ok) {
                if (matches == 0 && firstOut) *firstOut = (uintptr_t)p;
                if (++matches >= 2) break;
            }
        }
    }
    return matches;
}

using GuiMessageFn = void(__fastcall*)(void*, const std::string&, char*, bool);
static GuiMessageFn g_guiMessageOriginal = nullptr;
static void ApplyGameGuiScale();

static void __fastcall hkGuiDataMessage(void* self, const std::string& msg,
                                         char* params, bool flag) {
    if (self) g_guiDataPtr = self;
    if (g_guiMessageOriginal)
        g_guiMessageOriginal(self, msg, params, flag);
}

static void TryInstallGuiDataHook() {
    if (g_guiDataHookTried) return;
    g_guiDataHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    // Exact Solstice 1.21.111 signature first, then Flarial's wildcarded
    // variants used by nearby Bedrock builds.
    static const char* candidates[] = {
        "40 55 53 56 57 41 56 48 8D AC 24 A0 FE FF FF 48 81 EC 60 02 00 00 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 50 01 00 00 41",
        "40 55 53 56 57 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 41 0F B6 F9",
        "40 55 53 56 57 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 45 0F B6 F1",
        "40 55 53 56 57 41 56 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 41 0F B6 F0"
    };
    uintptr_t fn = 0;
    for (const char* candidate : candidates) {
        fn = ScanSignature(game, candidate);
        if (fn) break;
    }
    if (!fn) { LOG_INFO("game: GuiData::displayClientMessage signature not found"); return; }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGuiDataMessage,
                                 (LPVOID*)&g_guiMessageOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: GuiData hook active=%d status=%d", st == MH_OK ? 1 : 0, (int)st);
    } else {
        LOG_INFO("game: GuiData hook unavailable status=%d", (int)st);
    }
}

// This method runs whenever Bedrock rebuilds its screen-size variables and
// receives the live ClientInstance as its first argument. Capturing GuiData
// here makes GUI Scale independent of chat/system-message traffic.
using UpdateScreenFn = void(__fastcall*)(void*, void*, void*, float);
static UpdateScreenFn g_updateScreenOriginal = nullptr;

// Defined in the Flarial port engine section below (crash hardening).
static bool LooksLikeGameObject(const void* object);

static void __fastcall hkUpdateScreenSize(void* client, void* totalScreen,
                                          void* safeZone, float forcedScale) {
    // Only trust the first argument when it looks like a real ClientInstance:
    // a false-positive signature hands us a lookalike function whose first
    // argument is arbitrary - and everything downstream (GuiData at +0x578,
    // the forced scale call) dereferences it.
    if (client && LooksLikeGameObject(client)) {
        __try {
            // 1.21.11x (the requested 1.21.111 line) uses this Flarial offset.
            void* guiData = *(void**)((uintptr_t)client + 0x578);
            if (guiData) g_guiDataPtr = guiData;
            g_clientInstancePtr = client;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (totalScreen) {
        __try {
            // Remember the game's real screen-size arguments; the Flarial
            // GuiScale forced call reuses them verbatim.
            const float* ts = (const float*)totalScreen;
            if (ts[0] > 1.0f && ts[1] > 1.0f) {
                g_lastRealScreenSize[0] = ts[0];
                g_lastRealScreenSize[1] = ts[1];
            }
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (g_updateScreenOriginal)
        g_updateScreenOriginal(client, totalScreen, safeZone, forcedScale);
    // NOTE: no GuiScale re-apply here. Flarial applies its scale ONLY from
    // render-thread events (SetupAndRender); this hook can fire on a
    // non-render thread, and a nested _updateScreenSizeVariables + UI relayout
    // from inside its own detour would race the frame. hkPresent re-applies
    // the scale on the next frame instead.
}

static void TryInstallScreenSizeHook() {
    if (g_screenSizeHookTried) return;
    g_screenSizeHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    // Flarial SigInit::init21110 - the exact 1.21.11X (1.21.110-119) variant,
    // prologue spills rbx/rbp/rsi/rdi/r12-r15 and stores xmm10 via 44 0F 29 90.
    // Older candidates (1.26.x / 1.21.131.x layouts) follow as fallbacks.
    static const char* candidates[] = {
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 90 ? ? ? ? 44 0F 29 98 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 FB",
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 50 ? 44 0F 29 98 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 FB",
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 50 ? 44 0F 29 98 ? ? ? ? 44 0F 29 A0 ? ? ? ? 44 0F 29 A8 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 F3 4D 8B E0",
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 98 ? ? ? ?"
    };
    uintptr_t fn = 0, fallback = 0;
    for (const char* candidate : candidates) {
        uintptr_t first = 0;
        const int matches = ScanSignatureMatches(game, candidate, &first);
        if (matches == 1) { fn = first; break; }        // unambiguous: take it
        if (matches > 1 && !fallback) {
            fallback = first;                            // ambiguous: last resort
            LOG_INFO("game: screen-size signature is ambiguous (2+ matches) - kept as fallback");
        }
    }
    if (!fn) fn = fallback;
    if (!fn) {
        LOG_INFO("game: ClientInstance::_updateScreenSizeVariables signature not found");
        return;
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkUpdateScreenSize,
                                 (LPVOID*)&g_updateScreenOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: screen-size hook active=%d status=%d", st == MH_OK ? 1 : 0, (int)st);
    } else {
        LOG_INFO("game: screen-size hook unavailable status=%d", (int)st);
    }
}

using GammaFn = float(__fastcall*)(uintptr_t);
static GammaFn g_gammaOriginal = nullptr;

static float __fastcall hkGamma(uintptr_t self) {
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "FullBright") == 0 && mod->enabled()) {
            auto* fb = static_cast<modules::FullBright*>(mod.get());
            return fb->m_currentGamma;
        }
    }
    // Solstice deliberately normalizes gamma to vanilla brightness while the
    // module is disabled instead of preserving a stale options value.
    return 1.0f;
}

static void TryInstallGammaHook() {
    if (g_gammaHookTried) return;
    g_gammaHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    static const char* candidates[] = {
        "48 83 EC 28 48 8B 01 48 8D 54 24 30 41 B8 34 00 00 00",
        "48 83 EC 28 48 8B 01 48 8D 54 24 30 41 B8 36 00 00 00",
        "48 83 EC ? 48 8B ? 48 8D ? ? ? 41 B8 ? ? ? ?"
    };
    uintptr_t fn = 0;
    for (const char* candidate : candidates) {
        fn = ScanSignature(game, candidate);
        if (fn) break;
    }
    if (!fn) { LOG_INFO("game: Options::getGamma signature not found"); return; }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGamma,
                                 (LPVOID*)&g_gammaOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: gamma hook active=%d status=%d", st == MH_OK ? 1 : 0, (int)st);
    } else {
        LOG_INFO("game: gamma hook unavailable status=%d", (int)st);
    }
}

using PerspectiveFn = int(__fastcall*)(uintptr_t);
static PerspectiveFn g_perspectiveOriginal = nullptr;

static int __fastcall hkGetViewPerspective(uintptr_t self) {
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "Freelook") == 0 && mod->enabled()) {
            auto* freelook = static_cast<modules::Freelook*>(mod.get());
            return freelook->m_mode ? freelook->m_mode->mValue : 1;
        }
    }
    return g_perspectiveOriginal ? g_perspectiveOriginal(self) : 0;
}

static void TryInstallPerspectiveHook() {
    if (g_perspectiveHookTried) return;
    g_perspectiveHookTried = true;
    const uintptr_t fn = ScanSignature(GetModuleHandleW(nullptr),
        "48 83 EC ? 48 8B 01 48 8D 54 ? ? 41 B8 03 00 00 00");
    if (!fn) {
        LOG_INFO("game: getViewPerspective signature not found");
        return;
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGetViewPerspective,
                                 (LPVOID*)&g_perspectiveOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: perspective hook active=%d status=%d", st == MH_OK ? 1 : 0, (int)st);
    } else {
        LOG_INFO("game: perspective hook unavailable status=%d", (int)st);
    }
}

// Packet-Source camera path. LocalPlayer::updateFromCamera is the point where
// Bedrock copies camera rotation into the player. Returning early there keeps
// freelook rotation visual-only; the normal camera collision/raycast code is
// still executed, so the camera cannot see through blocks.
using CameraEulerFn = void(__fastcall*)(void*, float*);
using CameraSetOrientationFn = void(__fastcall*)(void*, float, float, float);
using UpdateFromCameraFn = void(__fastcall*)(uintptr_t, void*);
static CameraEulerFn g_cameraEuler = nullptr;
static CameraSetOrientationFn g_cameraSetOrientation = nullptr;
static UpdateFromCameraFn g_updateFromCameraOriginal = nullptr;

static void NormalizeAngles(ImVec2& angles) {
    while (angles.x > 180.0f) angles.x -= 360.0f;
    while (angles.x < -180.0f) angles.x += 360.0f;
    while (angles.y > 180.0f) angles.y -= 360.0f;
    while (angles.y < -180.0f) angles.y += 360.0f;
}

static bool ReadPacketCameraAngles(void* camera, ImVec2& out) {
    if (!camera || !g_cameraEuler) return false;
    float euler[3] = {0.0f, 0.0f, 0.0f};
    g_cameraEuler(camera, euler);
    const bool front = *(bool*)((uintptr_t)camera + 0x110);
    out.y = euler[1] * 57.295776f + *(float*)((uintptr_t)camera + 280);
    out.x = (euler[0] * 57.295776f + *(float*)((uintptr_t)camera + 276)) *
            (front ? -1.0f : 1.0f);
    NormalizeAngles(out);
    return true;
}

static void SetPacketCameraAngles(void* camera, const ImVec2& angles) {
    if (!camera || !g_cameraSetOrientation) return;
    constexpr float kPiOver180 = 0.01745329251994329577f;
    g_cameraSetOrientation(camera,
                            (-angles.y - 180.0f) * kPiOver180,
                            -angles.x * kPiOver180, 0.0f);
}

static void __fastcall hkUpdateFromCamera(uintptr_t self, void* camera) {
    modules::Freelook* freelook = nullptr;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "Freelook") == 0) {
            freelook = static_cast<modules::Freelook*>(mod.get());
            break;
        }
    }
    if (!freelook || !camera || (!freelook->redirectMouse && freelook->resetViewTick < 0)) {
        if (g_updateFromCameraOriginal) g_updateFromCameraOriginal(self, camera);
        return;
    }

    __try {
        freelook->cameraFacesFront = *(bool*)((uintptr_t)camera + 0x110);
        freelook->isThirdPerson = *(bool*)((uintptr_t)camera + 0x80);

        if (!freelook->initialCaptured) {
            if (ReadPacketCameraAngles(camera, freelook->initialViewAngles)) {
                freelook->lastCameraAngle = freelook->initialViewAngles;
                freelook->initialCaptured = true;
            }
        }

        if (freelook->resetViewTick >= 0 && freelook->initialCaptured) {
            if (freelook->resetViewTick > 0) {
                const float dx = freelook->initialViewAngles.x - freelook->lastCameraAngle.x;
                const float dy = freelook->initialViewAngles.y - freelook->lastCameraAngle.y;
                freelook->lastCameraAngle.x += dx * 0.28f;
                freelook->lastCameraAngle.y += dy * 0.28f;
                freelook->resetViewTick--;
                if (std::fabs(dx) < 0.15f && std::fabs(dy) < 0.15f)
                    freelook->resetViewTick = 0;
            } else {
                freelook->lastCameraAngle = freelook->initialViewAngles;
                freelook->redirectMouse = false;
                freelook->resetViewTick = -1;
            }
            SetPacketCameraAngles(camera, freelook->lastCameraAngle);
            return;
        }

        if (freelook->redirectMouse) {
            // Capture the camera's current visual rotation but do not call the
            // original update routine that would rotate the player entity.
            ReadPacketCameraAngles(camera, freelook->lastCameraAngle);
            return;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        // Fall back to vanilla behavior if an unsupported camera layout is hit.
    }
    if (g_updateFromCameraOriginal) g_updateFromCameraOriginal(self, camera);
}

static void TryInstallFreelookCameraHook() {
    if (g_freelookCameraHookTried) return;
    g_freelookCameraHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    const uintptr_t euler = ScanSignature(game,
        "48 8B C4 53 48 81 EC ? ? ? ? 0F 29 70 ? 48 8B DA 0F 29 78 ? F3");
    const uintptr_t setOrientation = ScanSignature(game,
        "40 53 48 81 EC ? ? ? ? 0F 29 74 24 ? 0F 57");
    const uintptr_t update = ScanSignature(game,
        "48 89 5C 24 10 57 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 80");
    if (!euler || !setOrientation || !update) {
        LOG_INFO("game: Packet Freelook camera signatures incomplete (euler=%d set=%d update=%d)",
                 euler ? 1 : 0, setOrientation ? 1 : 0, update ? 1 : 0);
        return;
    }
    g_cameraEuler = reinterpret_cast<CameraEulerFn>(euler);
    g_cameraSetOrientation = reinterpret_cast<CameraSetOrientationFn>(setOrientation);
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)update, (LPVOID)&hkUpdateFromCamera,
                                 (LPVOID*)&g_updateFromCameraOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)update);
        LOG_INFO("game: Packet Freelook hook active=%d status=%d", st == MH_OK ? 1 : 0, (int)st);
    } else {
        LOG_INFO("game: Packet Freelook hook unavailable status=%d", (int)st);
    }
}

// ---- Flarial port engine: GuiScale / Animations / Reach Display -----------
// Ports of Flarial's GuiScale::updateScale, Animations::onDrawImage and
// ReachCounter on top of the same game hooks Flarial uses for Bedrock
// 1.21.1xx: ScreenView::setupAndRender, mce::TextureGroup::getTexture,
// ClientInstance::_updateScreenSizeVariables and the MinecraftUIRenderContext
// vtable drawImage slot (index 7, >= 1.21.50). Everything is
// signature-scanned and SEH-guarded; a missed signature just means the
// feature stays inactive.

static void* g_screenViewPtr = nullptr;    // ScreenView* from setupAndRender
static uintptr_t g_getPositionFn = 0;      // UIControl::getPosition

// Cached "Animations" module pointer for the hot drawImage path.
static modules::Module* s_animationsModule = nullptr;
static bool AnimationsEnabled() {
    if (!s_animationsModule) {
        for (const auto& mod : modules::Modules().modules()) {
            if (mod && std::strcmp(mod->name(), "Animations") == 0) {
                s_animationsModule = mod.get();
                break;
            }
        }
    }
    return s_animationsModule && s_animationsModule->enabled();
}

// Raw GuiData field write (Solstice AutoScale style) - fallback only. The
// pointer comes from signature hooks; verify it points at writable memory and
// at a field that currently holds a sane gui scale before writing.
static void RawApplyGameGuiScale(float target) {
    if (!g_guiDataPtr) return;
    __try {
        float* scale = (float*)((uintptr_t)g_guiDataPtr + 0x5C);            // mGuiScale
        const float current = *scale;
        if (!(current > 0.05f && current < 20.0f)) return;  // not a GuiData shape
        *(float*)((uintptr_t)g_guiDataPtr + 0x5C) = target;                 // mGuiScale
        *(float*)((uintptr_t)g_guiDataPtr + 0x60) = 1.0f / target;          // mScalingMultiplier
        float resolutionX = *(float*)((uintptr_t)g_guiDataPtr + 0x40);      // mResolution
        float resolutionY = *(float*)((uintptr_t)g_guiDataPtr + 0x44);
        if (resolutionX <= 1.0f || resolutionY <= 1.0f) {
            const ImVec2 screen = gui::GetScreenSize();
            resolutionX = screen.x;
            resolutionY = screen.y;
        }
        *(float*)((uintptr_t)g_guiDataPtr + 0x50) = resolutionX / target;   // mResolutionScaled
        *(float*)((uintptr_t)g_guiDataPtr + 0x54) = resolutionY / target;
        LOG_INFO("guiscale: raw GuiData write %.2f -> %.2f", current, target);
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
}

// ---- pointer validation (crash hardening for the GuiScale relayout) -------
// The relayout WRITES into game objects (the cachedPositionDirty flag) and
// calls game functions on them. SEH catches access violations, but it cannot
// catch heap corruption: if one of the offsets ever lands on a non-control
// object, the flag write silently corrupts the heap and the process dies
// later with an uncatchable fail-fast. Every object is therefore required to
// start with a vtable pointer into the game image before anything is written
// or called; one bad object aborts the whole walk instead of half-writing it.
static uintptr_t g_gameImageBase = 0;
static size_t     g_gameImageSize = 0;

static void CacheGameImageRange() {
    if (g_gameImageBase) return;
    const uint8_t* base = (const uint8_t*)GetModuleHandleW(nullptr);
    if (!base) return;
    const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    const IMAGE_NT_HEADERS* nt = (const IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    g_gameImageBase = (uintptr_t)base;
    g_gameImageSize = nt->OptionalHeader.SizeOfImage;
}

static bool PageReadable(const void* p) {
    if (!p) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(p, &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
    return true;
}

// Controls, ClientInstance and ScreenView are polymorphic: their first quad
// word is a vtable pointer into the game's own image. Anything else is
// garbage and must not be touched.
static bool LooksLikeGameObject(const void* object) {
    if (!object) return false;
    CacheGameImageRange();
    if (!g_gameImageBase || !PageReadable(object)) return false;
    const uintptr_t vft = *(const uintptr_t*)object;
    if (vft < g_gameImageBase || vft >= g_gameImageBase + g_gameImageSize) return false;
    return PageReadable((const void*)vft);
}

// Flarial UIControl::updatePosition (>= 1.21.40): mark the cached position
// dirty (flags |= 1 at 0x18) and re-run UIControl::getPosition. Walks the
// VisualTree root -> children vector. UIControl::children is a
// std::vector<shared_ptr<UIControl>> at **0x90** in 1.21.1xx (Flarial
// OffsetInit: 0x90 since 1.21.2X; the 0xA0 value is the 1.20.3X layout).
using GetPositionFn = void* (__fastcall*)(void*);

// Returns false when the walk hit anything that does not look like a real
// UIControl: the caller must treat the relayout as failed and retry on a
// later frame. Writes happen only after the object passed validation.
static bool WalkUiControl(void* control, int depth, int* visited) {
    // Flarial walks every control with no limits; the caps here only stop a
    // corrupted/sliced child list from spinning. A real HUD tree (hotbar +
    // chat + bossbar + overlays) fits far below them.
    if (!control || depth > 128 || *visited > 262144) return false;
    if (!LooksLikeGameObject(control)) return false;  // abort BEFORE any write
    ++(*visited);
    __try {
        *(int*)((uintptr_t)control + 0x18) |= 1;  // cachedPositionDirty
        // Without the getPosition signature we can still force the game's own
        // UI update loop to recompute every cached position on the next frame.
        if (g_getPositionFn) ((GetPositionFn)g_getPositionFn)(control);
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    __try {
        void** begin = *(void***)((uintptr_t)control + 0x90);      // children.begin
        void** end   = *(void***)((uintptr_t)control + 0x90 + 0x8); // children.end
        if (!begin) return true;                       // empty vector: leaf
        if (end <= begin || (end - begin) > 8192) return false;  // garbage slice
        if (!PageReadable(begin)) return false;
        for (void** it = begin; it != end; ++it) {
            void* child = *it;
            if (child && !WalkUiControl(child, depth + 1, visited)) return false;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    return true;
}

static bool RelayoutUiTree() {
    if (!g_screenViewPtr) return false;
    __try {
        if (!LooksLikeGameObject(g_screenViewPtr)) return false;
        void* visualTree = *(void**)((uintptr_t)g_screenViewPtr + 0x48);  // ScreenView::VisualTree
        if (!visualTree || !PageReadable(visualTree)) return false;
        void* root = *(void**)((uintptr_t)visualTree + 0x8);              // VisualTree::root
        if (!root) return false;
        int visited = 0;
        return WalkUiControl(root, 0, &visited);
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

// Set when the scale was applied but the relayout did not complete (bad tree
// state, screen mid-transition). The next frames retry ONLY the relayout,
// until it succeeds or the retries are exhausted.
static bool g_guiScaleRelayoutPending = false;
static int  g_guiScaleRelayoutFails   = 0;

// Returns true when the relayout actually completed (no more retries needed).
static bool TrackRelayoutResult(bool ok) {
    if (ok) {
        g_guiScaleRelayoutPending = false;
        g_guiScaleRelayoutFails = 0;
        return true;
    }
    if (++g_guiScaleRelayoutFails == 1 || g_guiScaleRelayoutFails % 300 == 0)
        LOG_INFO("guiscale: relayout deferred (%d tries), scale value already applied",
                 g_guiScaleRelayoutFails);
    if (g_guiScaleRelayoutFails >= 600) {  // ~10 s of failures: give up quietly
        g_guiScaleRelayoutPending = false;
        g_guiScaleRelayoutFails = 0;
    }
    return false;
}

// Flarial GuiScale::updateScale(): push the scale through the game's own
// ClientInstance::_updateScreenSizeVariables (so MC recomputes GuiData
// itself), then relayout the UI control tree (hotbar, inventory, chat, ...).
static void FlarialUpdateScale(float newScale) {
    // The ClientInstance must look like a real game object: it came from a
    // signature hook's first argument, and a false-positive hook would hand
    // us garbage. Calling the real function with a garbage self is a crash.
    if (!g_updateScreenOriginal || !LooksLikeGameObject(g_clientInstancePtr)) {
        g_guiScaleRelayoutPending = false;
        RawApplyGameGuiScale(newScale);
        return;
    }
    if (newScale < 1.0f) newScale = 1.0f;
    // Flarial passes GuiData::ScreenSize - the game's live resolution - and a
    // zero safe zone. Cached copies are only a fallback so a resize between
    // updates can never feed stale numbers in.
    float screenSize[2] = { 0.0f, 0.0f };
    __try {
        if (g_guiDataPtr) {
            const float* gs = (const float*)((uintptr_t)g_guiDataPtr + 0x40); // GuiData::ScreenSize
            screenSize[0] = gs[0];
            screenSize[1] = gs[1];
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    if (screenSize[0] <= 1.0f || screenSize[1] <= 1.0f) {
        screenSize[0] = g_lastRealScreenSize[0];
        screenSize[1] = g_lastRealScreenSize[1];
    }
    if (screenSize[0] <= 1.0f || screenSize[1] <= 1.0f) {
        const ImVec2 screen = gui::GetScreenSize();
        screenSize[0] = screen.x;
        screenSize[1] = screen.y;
    }
    float safeZone[2] = { 0.0f, 0.0f };  // Flarial passes a zero safe zone
    __try {
        g_updateScreenOriginal(g_clientInstancePtr, screenSize, safeZone, newScale);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_guiScaleRelayoutPending = false;
        return;
    }
    // Runtime proof that the hooked function really is
    // _updateScreenSizeVariables: it must maintain GuiData::GuiScale from its
    // scale argument. If the field did not take the new value, the hook sits
    // on a lookalike - permanently stop calling it (one forged call already
    // happened; never repeat it) and use raw GuiData writes instead.
    bool verified = false;
    if (g_guiDataPtr) {
        __try {
            const float after = *(const float*)((uintptr_t)g_guiDataPtr + 0x5C);
            verified = (after > newScale - 0.001f) && (after < newScale + 0.001f);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (!verified && !g_screenSizeHookBad) {
        g_screenSizeHookBad = true;
        LOG_ERROR("guiscale: screen-size hook ignored the forced scale - it is a "
                  "false positive; disabling it and using raw GuiData writes");
        RawApplyGameGuiScale(newScale);
        g_guiScaleRelayoutPending = false;
        return;
    }
    TrackRelayoutResult(RelayoutUiTree());
}

// Flarial GuiScale::update(): only touch the game when its current gui scale
// differs from the module target; on disable restore the saved original once.
static void ApplyGameGuiScale() {
    // GuiData hangs off ClientInstance (offset 0x578 in 1.21.1xx, Flarial
    // "ClientInstance::guiData"). Resolve it from whichever pointer we have,
    // so the module works on the first enabled frame even when the
    // screen-size hook has not fired yet.
    if (!g_guiDataPtr && g_clientInstancePtr) {
        __try {
            g_guiDataPtr = *(void**)((uintptr_t)g_clientInstancePtr + 0x578);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (!g_guiDataPtr) return;
    float target = 0.0f;
    bool enabled = false;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "GUI Scale") == 0) {
            auto* gs = static_cast<modules::GuiScale*>(mod.get());
            enabled = mod->enabled();
            target = gs->m_scale ? gs->m_scale->mValue : 2.0f;
            break;
        }
    }
    __try {
        float* scale = (float*)((uintptr_t)g_guiDataPtr + 0x5C);
        if (!enabled) {
            if (g_savedGuiScaleValid) {
                LOG_INFO("guiscale: restore %.2f", g_savedGuiScale);
                FlarialUpdateScale(g_savedGuiScale);
                g_savedGuiScaleValid = false;
            }
            return;
        }
        target = target < 1.0f ? 1.0f : (target > 4.0f ? 4.0f : target);
        if (!g_savedGuiScaleValid) {
            g_savedGuiScale = *scale;
            g_savedGuiScaleValid = true;
        }
        if (*scale != target) {
            LOG_INFO("guiscale: %.2f -> %.2f (relayout %s)", *scale, target,
                     g_getPositionFn ? "getPosition" : "dirty-flag only");
            FlarialUpdateScale(target);
        } else if (g_guiScaleRelayoutPending) {
            // The scale value is already in place; finish the deferred
            // relayout only (screen was mid-transition when it was applied).
            if (TrackRelayoutResult(RelayoutUiTree()))
                LOG_INFO("guiscale: deferred relayout completed");
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
}

// ---- ScreenView::setupAndRender (Flarial's per-frame UI timing) -----------
using SetupAndRenderFn = void(__fastcall*)(void*, void*);
static SetupAndRenderFn g_setupAndRenderOriginal = nullptr;

// ---- mce::TextureGroup::getTexture ----------------------------------------
using GetTextureFn = void* (__fastcall*)(void*, void*, void*, bool, void*, int, void*);
static GetTextureFn g_getTextureOriginal = nullptr;

// ---- MinecraftUIRenderContext vtable drawImage (slot 7, >= 1.21.50) -------
using DrawImageFn = void(__fastcall*)(void*, void*, float*, float*, float*, float*, bool);
static DrawImageFn g_drawImageOriginal = nullptr;

// ---- GameMode::attack (1.21.50+ layout) ------------------------------------
using AttackFn = void(__fastcall*)(void*, void*, bool);
static AttackFn g_attackOriginal = nullptr;

static void __fastcall hkSetupAndRender(void* screenView, void* muirc) {
    __try {
        if (screenView) g_screenViewPtr = screenView;
        if (muirc) {
            // MinecraftUIRenderContext::clientInstance = 0x8. Validate before
            // trusting: a garbage value here poisons every forced-scale call.
            void* ci = *(void**)((uintptr_t)muirc + 0x8);
            if (ci && LooksLikeGameObject(ci)) g_clientInstancePtr = ci;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}

    // Publish "a chat/text-input screen is open" for the global hotkey gates
    // (K in the chat box must not open the ClickGUI). The screen name comes
    // from the game's own ClientInstance::getScreenName.
    PublishChatOpen(muirc);

    if (muirc && !g_drawImageOriginal) {
        __try {
            void** vtable = *(void***)muirc;
            if (vtable && vtable[7]) {
                MH_STATUS st = MH_CreateHook(vtable[7], (LPVOID)&hkDrawImage,
                                             (LPVOID*)&g_drawImageOriginal);
                if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED)
                    MH_EnableHook(vtable[7]);
                LOG_INFO("game: MinecraftUIRenderContext::drawImage hook status=%d", (int)st);
            }
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }

    if (g_setupAndRenderOriginal) g_setupAndRenderOriginal(screenView, muirc);
    ApplyGameGuiScale();  // Flarial fires SetupAndRenderEvent after the screen renders
}

// Flarial Animations::animate, verbatim.
static float FlarialAnimate(float endPoint, float current, float speed) {
    if (speed < 0.0) speed = 0.0;
    else if (speed > 1.0) speed = 1.0;
    float dif = (((endPoint) > (current)) ? (endPoint) : (current)) -
                (((endPoint) < (current)) ? (endPoint) : (current));
    float factor = dif * speed;
    return current + (endPoint > current ? factor : -factor);
}

static float s_hotbarLerpedX = 0.0f;
static bool  s_hotbarLerpValid = false;

static void __fastcall hkDrawImage(void* ctx, void* textureData, float* imagePos,
                                   float* imageDim, float* uvPos, float* uvSize, bool unk) {
    float pos[2] = { imagePos ? imagePos[0] : 0.0f, imagePos ? imagePos[1] : 0.0f };
    __try {
        // Flarial Animations::onDrawImage: lerp the selected-hotbar-slot
        // highlight square toward its target X while slots are switched.
        if (textureData && textureData == overlay::g_hotbarTextureData && imagePos) {
            if (!s_hotbarLerpValid) {
                s_hotbarLerpedX = imagePos[0];
                s_hotbarLerpValid = true;
            }
            float speed = 7.0f;
            for (const auto& mod : modules::Modules().modules()) {
                if (mod && std::strcmp(mod->name(), "Animations") == 0) {
                    auto* anim = static_cast<modules::Animations*>(mod.get());
                    if (anim->m_speed) speed = anim->m_speed->mValue;
                    break;
                }
            }
            const float dt = gui::GetDeltaTime();
            const float frameFactor = gui::Clamp(dt * 60.0f, 0.1f, 4.0f);
            s_hotbarLerpedX = FlarialAnimate(imagePos[0], s_hotbarLerpedX,
                                             (0.016f * speed) * frameFactor);
            pos[0] = s_hotbarLerpedX;
            pos[1] = imagePos[1];
        } else {
            s_hotbarLerpValid = false;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { s_hotbarLerpValid = false; }

    if (g_drawImageOriginal)
        g_drawImageOriginal(ctx, textureData, pos, imageDim, uvPos, uvSize, unk);
}

static void* __fastcall hkGetTexture(void* self, void* result, void* location,
                                     bool forceReload, void* a5, int a6, void* a7) {
    void* ret = g_getTextureOriginal
                    ? g_getTextureOriginal(self, result, location, forceReload, a5, a6, a7)
                    : nullptr;
    __try {
        if (result && location && AnimationsEnabled()) {
            // ResourceLocation: Core::PathBuffer<std::string> at 0x8; MSVC
            // std::string - inline buffer, size at +0x10, capacity at +0x18
            // (relative to the string itself).
            const unsigned long long len  = *(const unsigned long long*)((uintptr_t)location + 0x18);
            const unsigned long long cap  = *(const unsigned long long*)((uintptr_t)location + 0x20);
            if (len == 32 && cap >= len) {
                const char* p = (cap < 16) ? (const char*)((uintptr_t)location + 0x8)
                                           : *(const char**)((uintptr_t)location + 0x8);
                if (p && std::memcmp(p, "textures/ui/selected_hotbar_slot", 32) == 0)
                    overlay::g_hotbarTextureData = *(void**)result;  // TexturePtr -> BedrockTextureData*
            }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    return ret;
}

// ==================== HitResult probe (Reach Display + Crit Particles) ======
// target->getLevel()->getHitResult() - layout per the 1.21.x SDK
// (mStartPos@0x0, mRayDir@0xC, mType@0x18, mPos@0x2C, WeakEntityRef@0x38 with
// the entity id at 0x48). The Level / hitResult offsets are not published for
// every 1.21.11x build, so the probe (1) uses a cached pair when one was
// validated earlier, (2) tries a few fixed candidates, and (3) falls back to
// a bounded scan: Level* candidates inside the Actor, then HitResult-shaped
// records inside each Level (type in {BLOCK, ENTITY, NOTHING} + coherent
// world coordinates make false positives vanishingly rare).
struct HitResultRead {
    bool     ok = false;
    float    startPos[3] = {};   // camera eye at pick time
    float    hitPos[3]   = {};   // hit point on the target
    int      type = 0;
    unsigned entityKey = 0;      // hit-result entity id (low dword)
};

static bool ProbeHitRecordAt(uintptr_t base, uintptr_t hrOff, HitResultRead* out) {
    __try {
        const int type = *(const int*)(base + hrOff + 0x18);
        if (type != 0 && type != 1 && type != 3) return false;
        const float* sp = (const float*)(base + hrOff);
        const float* rd = (const float*)(base + hrOff + 0xC);   // mRayDir
        const float* hp = (const float*)(base + hrOff + 0x2C);
        for (int i = 0; i < 3; i++) {
            if (!(sp[i] > -1e6f && sp[i] < 1e6f)) return false;
            if (!(hp[i] > -1e6f && hp[i] < 1e6f)) return false;
        }
        // the pick ray direction is stored normalized - rejects zeroed or
        // random memory regions that would otherwise pass the type check
        const float rl = sqrtf(rd[0] * rd[0] + rd[1] * rd[1] + rd[2] * rd[2]);
        if (!(rl > 0.85f && rl < 1.15f)) return false;
        if (sp[1] < -128.0f || sp[1] > 1024.0f) return false;
        const float dx = hp[0] - sp[0];
        const float dy = hp[1] - sp[1];
        const float dz = hp[2] - sp[2];
        const float d = sqrtf(dx * dx + dy * dy + dz * dz);
        if (d < 0.05f || d > 64.0f) return false;
        for (int i = 0; i < 3; i++) {
            out->startPos[i] = sp[i];
            out->hitPos[i]   = hp[i];
        }
        out->type = type;
        const unsigned key = *(const unsigned int*)(base + hrOff + 0x48);
        out->entityKey = (key < 0x1000000u) ? key : 0;
        out->ok = true;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// The (Actor+X -> Level, Level+Y -> HitResult) pair, found by the scan and
// reused afterwards; offsets are stable within one game session. The cache
// anchor is normally the Actor; the ClientInstance fallback needs its own.
static bool        s_probeCacheHave = false;
static bool        s_probeCacheIsClient = false;
static uintptr_t   s_probeCacheLevelOff = 0;
static uintptr_t   s_probeCacheHrOff    = 0;

// entt entity id: EntityContext lives at Actor+0x8, the id at +0x8 inside it.
static unsigned ActorEntityId(void* actor) {
    if (!actor) return 0;
    __try {
        const unsigned id = *(const unsigned*)((uintptr_t)actor + 0x10);
        return (id < 0x1000000u) ? id : 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
}

// Scan one host object for an ENTITY hit-result whose WeakEntityRef id equals
// entId. Prefilter is two integer reads per offset (type, id) - the full
// float validation only runs for the rare surviving candidate, so the whole
// scan costs a few ms instead of hundreds.
static bool ScanHostForEntityHit(uintptr_t host, unsigned entId,
                                 uintptr_t begin, uintptr_t end,
                                 HitResultRead* out) {
    if (!entId) return false;
    __try {
        for (uintptr_t ho = begin; ho <= end; ho += 4) {
            if (*(const int*)(host + ho + 0x18) != 1) continue;
            if (*(const unsigned*)(host + ho + 0x48) != entId) continue;
            HitResultRead tmp;
            memset(&tmp, 0, sizeof(tmp));
            if (ProbeHitRecordAt(host, ho, &tmp)) {
                *out = tmp;
                return true;
            }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    return false;
}

// entId != 0 -> attack path: only records naming that entity are accepted
// (and a scan runs while no offset pair is cached). entId == 0 -> eye path:
// any structurally valid record is usable, but only an entity record within
// attack reach may latch the cache.
static void ProbeHitResult(void* actor, unsigned entId, HitResultRead* out) {
    if (!actor) return;
    const uintptr_t a = (uintptr_t)actor;

    // 1) previously validated pair
    if (s_probeCacheHave) {
        void* host = nullptr;
        if (s_probeCacheIsClient) {
            host = g_clientInstancePtr;
        } else {
            __try { host = *(void**)(a + s_probeCacheLevelOff); }
            __except (EXCEPTION_EXECUTE_HANDLER) { host = nullptr; }
        }
        if (host && ProbeHitRecordAt((uintptr_t)host, s_probeCacheHrOff, out)) {
            if (entId == 0 || out->type == 1) return;
        }
        out->ok = false;
    }

    // 2) fixed candidates from earlier builds
    static const uintptr_t kLevelOffsets[]     = { 0x230, 0x250, 0x258, 0x1D8 };
    static const uintptr_t kHitResultOffsets[] = { 0x1E8, 0x1E0, 0x230, 0x240 };
    for (uintptr_t lo : kLevelOffsets) {
        void* level = nullptr;
        __try { level = *(void**)(a + lo); }
        __except (EXCEPTION_EXECUTE_HANDLER) { level = nullptr; }
        if (!level) continue;
        for (uintptr_t ho : kHitResultOffsets) {
            HitResultRead tmp;
            memset(&tmp, 0, sizeof(tmp));
            if (!ProbeHitRecordAt((uintptr_t)level, ho, &tmp)) continue;
            const float dx = tmp.hitPos[0] - tmp.startPos[0];
            const float dy = tmp.hitPos[1] - tmp.startPos[1];
            const float dz = tmp.hitPos[2] - tmp.startPos[2];
            const float d = sqrtf(dx * dx + dy * dy + dz * dz);
            const bool strong = tmp.type == 1 && d >= 0.3f && d <= 12.0f
                                && (entId == 0 || tmp.entityKey == entId);
            if (strong) {
                s_probeCacheHave = true;
                s_probeCacheIsClient = false;
                s_probeCacheLevelOff = lo;
                s_probeCacheHrOff = ho;
                LOG_INFO("crit particles: hit-result found (fixed off Actor+0x%X Level+0x%X)",
                         (unsigned)lo, (unsigned)ho);
            }
            if (strong || (entId == 0 && tmp.type != 1)) {
                *out = tmp;
                return;
            }
        }
    }
    if (out->ok) return;

    // 3) id-anchored scan: Level* candidates inside the Actor (Actor is
    // >0xC00 bytes in 1.21.x), entity-hit records inside each. Only runs on
    // the attack path while no pair is cached - a few ms with the prefilter.
    if (entId != 0 && !s_probeCacheHave) {
        for (uintptr_t lo = 0x60; lo <= 0x1000; lo += 8) {
            void* level = nullptr;
            __try { level = *(void**)(a + lo); }
            __except (EXCEPTION_EXECUTE_HANDLER) { continue; }
            if (!level || ((uintptr_t)level & 7) != 0 || (uintptr_t)level < 0x10000)
                continue;
            if (ScanHostForEntityHit((uintptr_t)level, entId, 0x40, 0x1800, out)) {
                s_probeCacheHave = true;
                s_probeCacheIsClient = false;
                s_probeCacheLevelOff = lo;
                s_probeCacheHrOff = 0;   // resolved by a re-scan below
                // find the exact record offset for the cache
                for (uintptr_t ho = 0x40; ho <= 0x1800; ho += 4) {
                    HitResultRead tmp;
                    memset(&tmp, 0, sizeof(tmp));
                    if (ProbeHitRecordAt((uintptr_t)level, ho, &tmp)
                        && tmp.type == 1 && tmp.entityKey == entId) {
                        s_probeCacheHrOff = ho;
                        break;
                    }
                }
                LOG_INFO("crit particles: hit-result SCAN found (Actor+0x%X Level+0x%X)",
                         (unsigned)lo, (unsigned)s_probeCacheHrOff);
                return;
            }
        }

        // 4) last resort: the pick result may live directly inside a
        // ClientInstance sub-object rather than in Level
        if (g_clientInstancePtr
            && ScanHostForEntityHit((uintptr_t)g_clientInstancePtr, entId,
                                    0x40, 0x1400, out)) {
            s_probeCacheHave = true;
            s_probeCacheIsClient = true;
            s_probeCacheLevelOff = 0;
            for (uintptr_t ho = 0x40; ho <= 0x1400; ho += 4) {
                HitResultRead tmp;
                memset(&tmp, 0, sizeof(tmp));
                if (ProbeHitRecordAt((uintptr_t)g_clientInstancePtr, ho, &tmp)
                    && tmp.type == 1 && tmp.entityKey == entId) {
                    s_probeCacheHrOff = ho;
                    break;
                }
            }
            LOG_INFO("crit particles: hit-result SCAN found in ClientInstance+0x%X",
                     (unsigned)s_probeCacheHrOff);
            return;
        }
    }
}

static float ReadHitDistance(void* actor) {
    HitResultRead hr;
    ProbeHitResult(actor, ActorEntityId(actor), &hr);
    if (!hr.ok) return -1.0f;
    const float dx = hr.hitPos[0] - hr.startPos[0];
    const float dy = hr.hitPos[1] - hr.startPos[1];
    const float dz = hr.hitPos[2] - hr.startPos[2];
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

// ==================== Crit Particles camera engine ==========================
// The bursts are drawn in world space around the hit point, so the module
// needs a world->screen projection. Bedrock keeps the camera view matrix
// inside ClientInstance, but the offset moves between builds; instead of one
// guessed offset we scan the object for a 3x3-orthonormal float block and
// accept the candidate that projects the camera eye (the hit result's
// mStartPos, probed every frame above) onto the screen center. FOV comes
// from options.txt ("fov"), vertical, default 70.
static float s_gameFovDeg = 70.0f;

static float        s_critEyePos[3]  = {};
static bool         s_critEyeValid   = false;
static float        s_critEyeY[32]   = {};
static unsigned long s_critEyeMs[32] = {};
static int          s_critEyeHead    = 0;
static int          s_critEyeCount   = 0;

static float        s_critViewMat[16] = {};
static int          s_critViewMode    = 0;   // bit0: transposed, bit1: +Z forward
static bool         s_critViewValid   = false;
static unsigned long s_critMatrixTryMs = 0;

// SEH-guarded 64-byte read (the scan walks unmapped padding freely).
static bool CritReadFloats(const void* addr, float out[16]) {
    __try {
        memcpy(out, addr, sizeof(float) * 16);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static void CritLocalPlayerPtr(void** outLp) {
    *outLp = nullptr;
    if (!g_clientInstancePtr || g_localPlayerVfunc <= 0) return;
    __try {
        void** vtable = *(void***)g_clientInstancePtr;
        if (!vtable || !vtable[g_localPlayerVfunc]) return;
        *outLp = ((void*(__fastcall*)(void*))vtable[g_localPlayerVfunc])(
            g_clientInstancePtr);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        *outLp = nullptr;
    }
}

// View transform of the cached matrix. Two storage orientations (row-major
// glm-style vs transposed) and both camera-forward conventions are probed.
static void CritViewTransform(const float p[3], float* ox, float* oy, float* oz) {
    const float* m = s_critViewMat;
    if (s_critViewMode & 1) {
        *ox = p[0] * m[0] + p[1] * m[1] + p[2] * m[2] + m[3];
        *oy = p[0] * m[4] + p[1] * m[5] + p[2] * m[6] + m[7];
        *oz = p[0] * m[8] + p[1] * m[9] + p[2] * m[10] + m[11];
    } else {
        *ox = p[0] * m[0] + p[1] * m[4] + p[2] * m[8] + m[12];
        *oy = p[0] * m[1] + p[1] * m[5] + p[2] * m[9] + m[13];
        *oz = p[0] * m[2] + p[1] * m[6] + p[2] * m[10] + m[14];
    }
    if (s_critViewMode & 2) *oz = -*oz;
}

static bool CritMatOrthonormal(const float m[16], int consecutive) {
    // consecutive: transform reads rows as consecutive triples (x*m[0..2]),
    // otherwise rows are strided triples (x*m[0], y*m[4], z*m[8] + m[12]).
    float r[3][3];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            r[i][j] = consecutive ? m[i * 4 + j] : m[j * 4 + i];
    for (int i = 0; i < 3; i++) {
        const float n = sqrtf(r[i][0] * r[i][0] + r[i][1] * r[i][1] + r[i][2] * r[i][2]);
        if (fabsf(n - 1.0f) > 1e-2f) return false;
    }
    for (int i = 0; i < 3; i++)
        for (int j = i + 1; j < 3; j++) {
            const float d = r[i][0] * r[j][0] + r[i][1] * r[j][1] + r[i][2] * r[j][2];
            if (fabsf(d) > 1e-2f) return false;
        }
    const float det =
        r[0][0] * (r[1][1] * r[2][2] - r[1][2] * r[2][1]) -
        r[0][1] * (r[1][0] * r[2][2] - r[1][2] * r[2][0]) +
        r[0][2] * (r[1][0] * r[2][1] - r[1][1] * r[2][0]);
    return det > 0.0f;   // proper rotation, no mirroring
}

static void CritTryFindViewMatrix() {
    if (!g_clientInstancePtr || !s_critEyeValid) return;
    const uintptr_t base = (uintptr_t)g_clientInstancePtr;
    float best[16] = {};
    int   bestMode = 0;
    float bestErr  = 1e9f;
    for (uintptr_t off = 0x40; off + 64 <= 0x1800; off += 8) {
        float m[16];
        if (!CritReadFloats((const char*)base + off, m)) continue;
        bool finite = true;
        for (int i = 0; i < 16 && finite; i++)
            if (!(m[i] > -1e9f && m[i] < 1e9f)) finite = false;
        if (!finite) continue;
        for (int mode = 0; mode < 4; mode++) {
            if (!CritMatOrthonormal(m, mode & 1)) continue;
            float saveMat[16];
            const int saveMode = s_critViewMode;
            memcpy(saveMat, s_critViewMat, sizeof(saveMat));
            memcpy(s_critViewMat, m, sizeof(m));
            s_critViewMode = mode;
            float cx, cy, cz;
            CritViewTransform(s_critEyePos, &cx, &cy, &cz);
            const bool inFront = (mode & 2) ? (cz > 0.05f) : (cz < -0.05f);
            if (inFront) {
                const float err = sqrtf(cx * cx + cy * cy);
                if (err < bestErr) {
                    bestErr = err;
                    bestMode = mode;
                    memcpy(best, m, sizeof(m));
                }
            }
            memcpy(s_critViewMat, saveMat, sizeof(saveMat));
            s_critViewMode = saveMode;
        }
    }
    // A true view matrix projects the eye to ~(0, 0) with float-noise error;
    // anything above a few hundredths of a block is a wrong candidate.
    if (bestErr < 0.02f) {
        memcpy(s_critViewMat, best, sizeof(best));
        s_critViewMode = bestMode;
        s_critViewValid = true;
        LOG_INFO("crit particles: view matrix captured (mode=%d, center err=%.4f)",
                 bestMode, bestErr);
    }
}

// ---- Actor position via vtable getters: state + prototypes ----------------
// (definitions are further below, before hkGameModeAttack; declared here so
// overlay::UpdateCritCamera above can use them)
static int   s_posSlot = -1;        // locked vtable slot (-1 = not locked)
static int   s_posSlots[8] = {};    // candidate slots from the last probe
static int   s_posSlotCount = 0;
static unsigned long s_posProbeNextMs = 0;
static bool  IsPureLoadGetter(const unsigned char* c);
static bool  ActorReadPos(int slot, void* actor, float out[3]);
static void  ProbePosSlots(void* lp);

// last hit-result probe (aim detection): type + entity key of the record the
// crosshair ray currently points at (0/1/3 = block/entity/nothing)
static int      s_lastProbeType = 0;
static unsigned s_lastProbeKey  = 0;

// unified read: entt StateVectorComponent first, locked vtable getter second
static bool  CritReadEntityPos(void* actor, float out[3]);
static bool  CritReadEntityVelY(void* actor, float* outVelY);
static float s_critVelY = 0.0f;
static bool  s_critVelValid = false;

} // anonymous namespace (split so overlay:: members can be defined below)
} // namespace overlay (paused, resumed below)
namespace overlay {
void UpdateCritCamera() {
    // 1) refresh the camera eye from the local player's position getter
    //    (eye = feet + 1.62); the eye also drives the view-matrix validation
    void* lp = nullptr;
    CritLocalPlayerPtr(&lp);
    if (lp && s_posSlot < 0) {
        const unsigned long nowMs = GetTickCount();
        if (s_posSlotCount == 0 && nowMs - s_posProbeNextMs >= 500) {
            s_posProbeNextMs = nowMs;
            ProbePosSlots(lp);
        }
    }
    if (lp) {
        float pp[3];
        if (CritReadEntityPos(lp, pp)) {
            s_critEyePos[0] = pp[0];
            s_critEyePos[1] = pp[1] + 1.62f;
            s_critEyePos[2] = pp[2];
            s_critEyeValid = true;
            const unsigned long now = GetTickCount();
            s_critEyeY[s_critEyeHead]  = pp[1];
            s_critEyeMs[s_critEyeHead] = now;
            s_critEyeHead = (s_critEyeHead + 1) % 32;
            if (s_critEyeCount < 32) s_critEyeCount++;
            float vy = 0.0f;
            s_critVelValid = CritReadEntityVelY(lp, &vy);
            if (s_critVelValid) s_critVelY = vy;
        } else {
            s_critEyeValid = false;
            s_critVelValid = false;
        }
        // aim detection: what is the crosshair ray pointing at right now
        HitResultRead hr;
        ProbeHitResult(lp, 0, &hr);
        if (hr.ok) {
            s_lastProbeType = hr.type;
            s_lastProbeKey  = hr.entityKey;
        } else {
            s_lastProbeType = 0;
            s_lastProbeKey  = 0;
        }
    } else {
        s_critEyeValid = false;
        s_critVelValid = false;
        s_lastProbeType = 0;
        s_lastProbeKey  = 0;
    }

    // 2) discover the view matrix once (retry every 500 ms until it lands);
    // when a stale capture exists, re-check it against the live eye position
    const unsigned long now = GetTickCount();
    if (!s_critViewValid) {
        if (now - s_critMatrixTryMs >= 500) {
            s_critMatrixTryMs = now;
            CritTryFindViewMatrix();
        }
    } else if (s_critEyeValid && now - s_critMatrixTryMs >= 500) {
        s_critMatrixTryMs = now;
        float cx, cy, cz;
        CritViewTransform(s_critEyePos, &cx, &cy, &cz);
        const bool inFront = (s_critViewMode & 2) ? (cz > 0.0f) : (cz < 0.0f);
        if (!inFront || sqrtf(cx * cx + cy * cy) > 0.25f) {
            s_critViewValid = false;
            LOG_ERROR("crit particles: view matrix stale (eye err=%.3f) - recapturing",
                      sqrtf(cx * cx + cy * cy));
        }
    }
}

bool ProjectWorldToScreen(const float pos[3], float* outX, float* outY,
                          float* outDepth) {
    if (!s_critViewValid) return false;
    float cx, cy, cz;
    CritViewTransform(pos, &cx, &cy, &cz);
    const bool behind = (s_critViewMode & 2) ? (cz <= 0.05f) : (cz >= -0.05f);
    if (behind) return false;
    ImGuiIO& io = ImGui::GetIO();
    const float w = io.DisplaySize.x, h = io.DisplaySize.y;
    if (w < 2.0f || h < 2.0f) return false;
    const float fovRad = s_gameFovDeg * 3.14159265f / 180.0f;
    const float tanY = tanf(0.5f * fovRad);
    const float tanX = tanY * (w / h);
    const float depth = (s_critViewMode & 2) ? cz : -cz;
    *outX = w * 0.5f + (cx / depth) * (w * 0.5f) / tanX;
    *outY = h * 0.5f - (cy / depth) * (h * 0.5f) / tanY;
    if (outDepth) *outDepth = depth;
    return true;
}

float GetCritFocalPx() {
    ImGuiIO& io = ImGui::GetIO();
    const float fovRad = s_gameFovDeg * 3.14159265f / 180.0f;
    return (io.DisplaySize.y * 0.5f) / tanf(0.5f * fovRad);
}
} // namespace overlay
namespace overlay { // resumed
namespace { // anonymous namespace continues

// Vertical eye speed (blocks/s) over the last ~8 samples; needs a history
// spanning at least 40 ms - 0 while there is not enough data (treated as
// "not falling", i.e. no crit).
static float CritEyeVelocityY() {
    // direct velocity from StateVectorComponent when entt works
    if (s_critVelValid) return s_critVelY;
    if (s_critEyeCount < 5) return 0.0f;
    const int last = (s_critEyeHead - 1 + 32) % 32;
    int old = -1;
    for (int back = 4; back <= 12; back++) {
        const int c = (s_critEyeHead - 1 - back + 64) % 32;
        if (s_critEyeMs[last] - s_critEyeMs[c] >= 40) { old = c; break; }
    }
    if (old < 0) return 0.0f;
    const float dt = (float)(s_critEyeMs[last] - s_critEyeMs[old]) / 1000.0f;
    if (dt <= 0.0f) return 0.0f;
    return (s_critEyeY[last] - s_critEyeY[old]) / dt;
}

// ==================== Actor position via safe vtable getters ================
// The position lives behind entt components whose offsets move between
// builds, so instead the actor's vtable is probed for PURE-LOAD getter
// functions (mov rax,[rcx+d]; ret and the two-load component chain). Only
// those are ever called, and the returned Vec3 is validated. The slot is
// locked on the first attack, when the target is known to be within reach
// of the local player - a wrong getter cannot pass that check consistently.

// mov rax,[rcx+d]; ret patterns only - anything else is never called.
static bool IsPureLoadGetter(const unsigned char* c) {
    __try {
        if (c[0] != 0x48 || c[1] != 0x8B) return false;
        if (c[2] == 0x01 && c[3] == 0xC3) return true;                     // [rcx]
        if (c[2] == 0x41 && c[4] == 0xC3) return true;                     // [rcx+d8]
        if (c[2] == 0x81 && c[7] == 0xC3) return true;                     // [rcx+d32]
        if (c[2] == 0x41 && c[4] == 0x48 && c[5] == 0x8B && c[6] == 0x40 && c[8] == 0xC3)
            return true;                                                   // [[rcx+d8]+d8]
        if (c[2] == 0x81 && c[7] == 0x48 && c[8] == 0x8B && c[9] == 0x80 && c[14] == 0xC3)
            return true;                                                   // [[rcx+d32]+d32]
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    return false;
}

static bool ActorReadPos(int slot, void* actor, float out[3]) {
    if (slot < 0 || !actor) return false;
    void** vtable = nullptr;
    __try { vtable = *(void***)actor; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    if (!vtable || !vtable[slot]) return false;
    void* p = nullptr;
    __try { p = ((void* (__fastcall*)(void*))vtable[slot])(actor); }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    if (!p) return false;
    __try {
        for (int i = 0; i < 3; i++) {
            const float v = ((const float*)p)[i];
            if (!(v > -1e6f && v < 1e6f)) return false;
            out[i] = v;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    if (out[1] < -128.0f || out[1] > 1024.0f) return false;
    if (fabsf(out[0]) > 4096.0f || fabsf(out[2]) > 4096.0f) return false;
    return true;
}

// Scan the actor's vtable for pure-load getters whose result looks like a
// world position (called only on the local player).
static void ProbePosSlots(void* lp) {
    if (s_posSlotCount > 0 || s_posSlot >= 0 || !lp) return;
    void** vtable = nullptr;
    __try { vtable = *(void***)lp; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return; }
    if (!vtable) return;
    for (int i = 3; i < 160 && s_posSlotCount < 8; i++) {
        void* fn = vtable[i];
        if (!fn) continue;
        if (!IsPureLoadGetter((const unsigned char*)fn)) continue;
        float p[3];
        if (ActorReadPos(i, lp, p))
            s_posSlots[s_posSlotCount++] = i;
    }
    if (s_posSlotCount > 0) {
        char buf[64] = {};
        int n = 0;
        for (int i = 0; i < s_posSlotCount && n < 60; i++)
            n += sprintf_s(buf + n, sizeof(buf) - n, "%d ", s_posSlots[i]);
        LOG_INFO("crit particles: position getter candidates: %s", buf);
    }
}

// entt StateVectorComponent is the primary source (FeetPos + velocity);
// the locked vtable getter is the fallback when entt does not match.
static bool CritReadEntityPos(void* actor, float out[3]) {
    float vel[3];
    if (game::ActorReadStateVector(actor, out, vel)) return true;
    if (s_posSlot >= 0 && ActorReadPos(s_posSlot, actor, out)) return true;
    return false;
}

static bool CritReadEntityVelY(void* actor, float* outVelY) {
    float pos[3], vel[3];
    if (game::ActorReadStateVector(actor, pos, vel)) {
        *outVelY = vel[1];
        return true;
    }
    return false;
}

// One-shot background diagnostic: when the probe cannot find the hit result,
// dump what is actually in memory around the attacked actor so the correct
// record shape / offsets can be derived from the log.
struct CritDumpCtx {
    void*    actor;
    void*    gamemode;
    unsigned entId;
};

static void CritDumpScanHost(const char* tag, uintptr_t host,
                             uintptr_t begin, uintptr_t end,
                             void* actor, unsigned entId,
                             int* modern, int* legacy) {
    for (uintptr_t ho = begin; ho <= end && (*modern < 6 || *legacy < 4); ho += 4) {
        int type = 0;
        bool readable = false;
        __try {
            type = *(const int*)(host + ho + 0x18);
            readable = true;
        } __except (EXCEPTION_EXECUTE_HANDLER) { readable = false; }
        if (!readable) return;   // host region unmapped further out

        if (type == 1 && *modern < 6) {
            unsigned id = 0;
            float sp[3] = {}, hp[3] = {};
            bool ok = false;
            __try {
                id = *(const unsigned*)(host + ho + 0x48);
                for (int i = 0; i < 3; i++) {
                    sp[i] = ((const float*)(host + ho))[i];
                    hp[i] = ((const float*)(host + ho + 0x2C))[i];
                }
                ok = true;
            } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
            if (ok) {
                (*modern)++;
                LOG_INFO("crit dump: modern type=1 @%s+0x%X id=%u entId=%u "
                         "start=(%.1f %.1f %.1f) pos=(%.1f %.1f %.1f)",
                         tag, (unsigned)ho, id, entId,
                         sp[0], sp[1], sp[2], hp[0], hp[1], hp[2]);
            }
        }

        // legacy PointingStruct pick pattern: a direct pointer to the actor
        if (*legacy < 4) {
            void* ep = nullptr;
            bool ok = false;
            __try {
                ep = *(void**)(host + ho + 0x20);
                ok = true;
            } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }
            if (ok && ep == actor) {
                int ltype = 0;
                void* ep2 = nullptr;
                float rv[3] = {};
                __try {
                    ltype = *(const int*)(host + ho);
                    ep2 = *(void**)(host + ho + 0x28);
                    for (int i = 0; i < 3; i++)
                        rv[i] = ((const float*)(host + ho + 0x14))[i];
                } __except (EXCEPTION_EXECUTE_HANDLER) {}
                (*legacy)++;
                LOG_INFO("crit dump: legacy ptr-match @%s+0x%X type=%d "
                         "rayHitVec=(%.1f %.1f %.1f) ep2=%p",
                         tag, (unsigned)ho, ltype,
                         rv[0], rv[1], rv[2], ep2);
            }
        }
    }
}

static DWORD WINAPI CritDumpThread(LPVOID param) {
    CritDumpCtx ctx = *(CritDumpCtx*)param;
    delete (CritDumpCtx*)param;

    void* vt = nullptr;
    unsigned selfIdProbe = 0;
    __try {
        vt = *(void**)ctx.actor;
        selfIdProbe = *(const unsigned*)((uintptr_t)ctx.actor + 0x10);
    } __except (EXCEPTION_EXECUTE_HANDLER) { vt = nullptr; }
    LOG_INFO("crit dump: actor=%p vtable=%p id@+0x10=%u entId=%u",
             ctx.actor, vt, selfIdProbe, ctx.entId);

    int modern = 0, legacy = 0, lvlCand = 0;
    for (uintptr_t lo = 0x60; lo <= 0x1400 && lvlCand < 400; lo += 8) {
        void* level = nullptr;
        bool readable = false;
        __try {
            level = *(void**)((uintptr_t)ctx.actor + lo);
            readable = true;
        } __except (EXCEPTION_EXECUTE_HANDLER) { readable = false; }
        if (!readable) break;
        if (!level || ((uintptr_t)level & 7) != 0 || (uintptr_t)level < 0x10000)
            continue;
        lvlCand++;
        CritDumpScanHost("lvl", (uintptr_t)level, 0x40, 0x2000,
                         ctx.actor, ctx.entId, &modern, &legacy);
    }
    LOG_INFO("crit dump: actor ptr-candidates=%d modern=%d legacy=%d",
             lvlCand, modern, legacy);

    if (g_clientInstancePtr) {
        modern = 0; legacy = 0;
        CritDumpScanHost("ci", (uintptr_t)g_clientInstancePtr, 0x40, 0x2400,
                         ctx.actor, ctx.entId, &modern, &legacy);
        LOG_INFO("crit dump: clientInstance modern=%d legacy=%d", modern, legacy);
    }
    if (ctx.gamemode) {
        modern = 0; legacy = 0;
        CritDumpScanHost("gm", (uintptr_t)ctx.gamemode, 0x8, 0x200,
                         ctx.actor, ctx.entId, &modern, &legacy);
        LOG_INFO("crit dump: gamemode modern=%d legacy=%d", modern, legacy);
    }
    LOG_INFO("crit dump: complete");
    return 0;
}

static void __fastcall hkGameModeAttack(void* gamemode, void* actor, bool a3) {
    // Target HUD: remember the attacked entity
    if (actor) {
        g_targetActor = actor;
        g_targetTickMs = (LONG)GetTickCount();
    }

    // ---- Reach Display (hit-result probe, best effort) --------------------
    const unsigned entId = ActorEntityId(actor);
    HitResultRead hr;
    ProbeHitResult(actor, entId, &hr);
    if (hr.ok && hr.type == 1 && (entId == 0 || hr.entityKey == entId)) {
        const float dx = hr.hitPos[0] - hr.startPos[0];
        const float dy = hr.hitPos[1] - hr.startPos[1];
        const float dz = hr.hitPos[2] - hr.startPos[2];
        const float d = sqrtf(dx * dx + dy * dy + dz * dz);
        overlay::g_lastHitDistance = d;
        overlay::g_lastHitTickMs = GetTickCount();
        InterlockedExchange(&overlay::g_lastHitValid, 1);
    }

    // ---- Crit Particles: entity-centered burst via the position getter ----
    if (actor) {
        void* lp = nullptr;
        CritLocalPlayerPtr(&lp);

        // lock the position getter on the first attack: the target MUST be
        // within reach of the player, so a wrong getter is rejected
        if (s_posSlot < 0 && lp) {
            if (s_posSlotCount == 0)
                ProbePosSlots(lp);
            for (int i = 0; i < s_posSlotCount && s_posSlot < 0; i++) {
                float tp[3], pp[3];
                if (!ActorReadPos(s_posSlots[i], actor, tp)) continue;
                if (!ActorReadPos(s_posSlots[i], lp, pp)) continue;
                const float dx = tp[0] - pp[0];
                const float dy = tp[1] - pp[1];
                const float dz = tp[2] - pp[2];
                const float d = sqrtf(dx * dx + dy * dy + dz * dz);
                if (d >= 0.3f && d <= 6.5f) {
                    s_posSlot = s_posSlots[i];
                    LOG_INFO("crit particles: position getter locked: vtable[%d] "
                             "(target dist %.2f, target=(%.1f %.1f %.1f))",
                             s_posSlot, d, tp[0], tp[1], tp[2]);
                }
            }
        }

        if (lp) {
            float tp[3], pp[3];
            const bool tpOk = CritReadEntityPos(actor, tp);
            const bool ppOk = CritReadEntityPos(lp, pp);
            static unsigned long s_failLogTick = 0;
            if ((!tpOk || !ppOk) && GetTickCount() - s_failLogTick >= 2000) {
                s_failLogTick = GetTickCount();
                float probe[3], vel[3];
                const bool enttTarget =
                    game::ActorReadStateVector(actor, probe, vel);
                LOG_INFO("crit particles: read failed (targetPos=%d playerPos=%d "
                         "enttTarget=%d slot=%d candidates=%d)",
                         tpOk ? 1 : 0, ppOk ? 1 : 0, enttTarget ? 1 : 0,
                         s_posSlot, s_posSlotCount);
            }
            if (tpOk && ppOk) {
                const float ex = pp[0], ey = pp[1] + 1.62f, ez = pp[2];
                const float dx = tp[0] - ex;
                const float dy = tp[1] - ey;
                const float dz = tp[2] - ez;
                const float reach = sqrtf(dx * dx + dy * dy + dz * dz);

                // Crit gate: the attacker must be falling (SystemDLC isFloat).
                const float vy = CritEyeVelocityY();
                const bool falling = vy < -0.02f;

                // Damage gate: Bedrock entity immunity is 10 ticks (500 ms) -
                // a second hit inside the window deals no damage, so it must
                // not emit a burst (this stops click-spam from flooding).
                const unsigned long now = GetTickCount();
                const unsigned key = (unsigned)((uintptr_t)actor & 0xFFFFFFFFu);
                static struct { unsigned key; unsigned long ms; } s_recent[8] = {};
                int seen = -1, freeSlot = -1, oldest = 0;
                for (int i = 0; i < 8; i++) {
                    if (s_recent[i].key == key) { seen = i; break; }
                    if (s_recent[i].key == 0 && freeSlot < 0) freeSlot = i;
                    if (s_recent[i].ms < s_recent[oldest].ms) oldest = i;
                }
                const bool damageLanded = (seen < 0) || (now - s_recent[seen].ms >= 500);

                static unsigned long s_critLogTick = 0;
                if (now - s_critLogTick >= 1000) {
                    s_critLogTick = now;
                    LOG_INFO("crit particles: hit target=(%.1f %.1f %.1f) reach=%.2f "
                             "vy=%.2f falling=%d dmg=%d",
                             tp[0], tp[1], tp[2], reach, vy,
                             falling ? 1 : 0, damageLanded ? 1 : 0);
                }
                if (falling && damageLanded && reach <= 7.0f) {
                    const int slot = (seen >= 0) ? seen
                                     : (freeSlot >= 0 ? freeSlot : oldest);
                    s_recent[slot].key = key;
                    s_recent[slot].ms = now;
                    const unsigned seed = (unsigned)(now ^ (uintptr_t)actor);
                    overlay::PushCritBurst(tp, key, seed);
                    InterlockedExchange(&overlay::g_critBurstStartMs, (LONG)now);
                    InterlockedExchange(&overlay::g_critBurstSeed, (LONG)seed);
                }
            }
        }
    }
    if (g_attackOriginal) g_attackOriginal(gamemode, actor, a3);

    // ---- damage detection (AFTER the attack applied) -----------------------
    // The game's invulnerability window means a click inside 500 ms deals no
    // damage; comparing hp before/after filters those out, so every event
    // below is REAL damage.
    if (actor) {
        float hp = 0.0f;
        if (game::ActorReadHealth(actor, &hp)) {
            static struct { void* a; float hp; } s_track[8] = {};
            int found = -1, freeSlot = -1, oldest = 0;
            for (int i = 0; i < 8; ++i) {
                if (s_track[i].a == actor) { found = i; break; }
                if (!s_track[i].a && freeSlot < 0) freeSlot = i;
                if (s_track[i].a && s_track[i].hp < s_track[oldest].hp) oldest = i;
            }
            const int slot = (found >= 0) ? found
                             : (freeSlot >= 0 ? freeSlot : oldest);
            if (found >= 0 && s_track[found].hp - hp > 0.01f) {
                const LONG head = InterlockedExchangeAdd(&g_damageHead, 1);
                DamageEvent& ev = g_damageEvents[head % kMaxDamageEvents];
                ev.actor = actor;
                ev.ms = GetTickCount();
                ev.amount = s_track[found].hp - hp;
            }
            s_track[slot].a = actor;
            s_track[slot].hp = hp;
        }
    }
}

static bool g_flarialHooksTried = false;

// ---- RakPeer::GetAveragePing hook (real ping, Flarial RaknetTick port) ----
// The game's own RakNet calls GetAveragePing (server browse, connect,
// in-game ticks). We hook it once AT STARTUP so the connect-phase calls are
// captured too, remember (RakPeer, guid) from the first call, and a small
// background thread then re-queries the original every second - so the
// watermark ping stays live even if the game itself stops calling it.
//
// NOTE: the background self-poll is GONE. It kept calling GetAveragePing on
// a RakPeer captured from an earlier call (often the server-list pinger)
// from a foreign thread. When the user then joined a server, the game tore
// that peer down and raced the new connection against our stale calls -
// RakNet is NOT safe with us here, and joining servers kept failing while
// local worlds (no RakNet) worked. The ping HUD now updates from the game's
// own hooked calls only, exactly like Flarial's watermark.
using GetAveragePingFn = int(__fastcall*)(void*, void*);
static GetAveragePingFn g_getAveragePingOriginal = nullptr;
static bool g_pingHookTried = false;

static int __fastcall hkGetAveragePing(void* self, void* guid) {
    const int ping = g_getAveragePingOriginal ? g_getAveragePingOriginal(self, guid) : -1;
    if (ping >= 0) InterlockedExchange(&overlay::g_pingMs, (LONG)ping);
    return ping;
}

static void TryInstallPingHook() {
    if (g_pingHookTried) return;
    g_pingHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t fn = ScanSignature(game,
        "48 8B C4 48 81 EC 58 01 00 00 0F 10 4A 10 4C 8B 1A 4C 3B 1D ? ? ? ? "
        "48 89 58 08 48 8B D9 0F 29 70 E8 0F 29 78 D8 0F 10 7A 20 0F 11 4C 24 10 "
        "74 46 44 8B 49 14");
    if (!fn) {
        LOG_INFO("game: RakPeer::GetAveragePing signature not found");
        return;
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGetAveragePing,
                                 (LPVOID*)&g_getAveragePingOriginal);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        MH_EnableHook((LPVOID)fn);
    }
    LOG_INFO("game: RakPeer::GetAveragePing hook status=%d", (int)st);
}

// ---- Java Hotkeys (Flarial JavaInventoryHotkeys port) ---------------------
// Tracks the hovered container slot and its collection through
// ContainerScreenController::_onContainerSlotHovered (which also hands us the
// live controller pointer), then performs the Java-style swap the moment a
// bound key or mouse button is pressed inside a container screen. The press
// arrives through the already-installed Keyboard::feed / MouseDevice::feed
// detours - the exact same dispatch point Flarial's KeyEvent/MouseEvent
// listeners use - so no container-tick hook is needed (the tick signature
// proved unreliable on this build). The swap itself calls the game's own
// _handleTakeAll/_handlePlaceAll handlers - the same server-approved path a
// shift-click uses. No packets are crafted manually.
using SlotHoveredFn = int64_t(__fastcall*)(void*, const std::string*, int64_t);
static SlotHoveredFn g_slotHoveredOriginal = nullptr;

static void* volatile s_lastController = nullptr;  // live ContainerScreenController*
static volatile LONG s_hoveredSlot = -1;
static volatile LONG s_hoveredTime = 0;
static char s_hoveredCollection[64] = {};
static std::string s_hotbarKeys[9];          // parsed options.txt values (string form)
static unsigned long s_optionsNextRead = 0;
// One-swap-per-physical-press guard (reset by ResetKeyMirrors on menu
// transitions; see JavaHotkeysTrySwap).
static volatile LONG s_jhHeldBind = 0;
// Flarial-style pending swap: the bind press only QUEUES the request; it is
// drained inside _onContainerSlotHovered - i.e. during the live controller's
// own tick, which is the only context where the container-screen handlers
// actually act (calling them from the input threads compiles, runs and does
// nothing - verified on 1.21.111).
static volatile LONG s_pendingHotbar = -1;   // hotbar slot 0..8
static volatile LONG s_pendingAt     = 0;    // queue timestamp

static bool JavaHotkeysEnabled() {
    static modules::Module* s_mod = nullptr;
    if (!s_mod) {
        for (const auto& m : modules::Modules().modules())
            if (m && std::strcmp(m->name(), "Java Hotkeys") == 0) { s_mod = m.get(); break; }
    }
    return s_mod && s_mod->enabled();
}

// options.txt: <package>\LocalState\games\com.mojang\minecraftpe\options.txt
// IMPORTANT: %LOCALAPPDATA% inside the game's AppContainer points into the
// package's AC sandbox (.../AC/...), so the naive getenv/expand path resolves
// to a nested garbage path - that is exactly why binds never loaded. The
// working root is the same one the config system uses (APPDATA\..\Local\...),
// exposed here through file_utils::RoamingStatePathW: LocalState is the
// sibling directory of RoamingState.
// Flarial reads only the ACTIVE keyboard type's bindings: the prefix is
// keyboard_type_1_* when ctrl_fullkeyboardgameplay=1, else keyboard_type_0_*.
static void ReadHotbarOptions() {
    std::wstring path = file_utils::RoamingStatePathW();
    if (!path.empty()) {
        path += L"..\\LocalState\\games\\com.mojang\\minecraftpe\\options.txt";
    } else {
        // Fallback: walk from APPDATA (the config system's proven root).
        wchar_t* appdata = nullptr;
        size_t   len     = 0;
        if (_wdupenv_s(&appdata, &len, L"APPDATA") == 0 && appdata) {
            path = std::wstring(appdata) + L"\\..\\Local\\Packages"
                   L"\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState"
                   L"\\games\\com.mojang\\minecraftpe\\options.txt";
            free(appdata);
        }
    }
    if (path.empty()) {
        static bool s_envOnce = false;
        if (!s_envOnce) {
            s_envOnce = true;
            LOG_ERROR("java hotkeys: cannot resolve LocalState - no hotbar binds");
        }
        return;
    }

    FILE* f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"rb") != 0 || !f) {
        static bool s_openOnce = false;
        if (!s_openOnce) {
            s_openOnce = true;
            char np[MAX_PATH * 2] = {};
            WideCharToMultiByte(CP_UTF8, 0, path.c_str(), -1,
                                np, sizeof(np), nullptr, nullptr);
            LOG_ERROR("java hotkeys: options.txt open failed: %s", np);
        }
        return;
    }
    char line[512];
    std::string keys0[9];
    std::string keys1[9];
    std::string ctrlFull;
    while (fgets(line, sizeof(line), f)) {
        // Bedrock writes "key=value" on older builds but "key:value" on
        // 1.21.11x (verified against the live options.txt) - accept both,
        // whichever separator comes first on the line.
        char* eq = strchr(line, '=');
        const char* colon = strchr(line, ':');
        if (!eq || (colon && colon < eq)) eq = const_cast<char*>(colon);
        if (!eq) continue;
        *eq = 0;
        std::string key(line);
        // trim CR/LF/space around both parts
        while (!key.empty() && (key.back() == '\r' || key.back() == '\n' || key.back() == ' ')) key.pop_back();
        std::string val = eq + 1;
        while (!val.empty() && (val.back() == '\r' || val.back() == '\n' || val.back() == ' ')) val.pop_back();
        if (key == "ctrl_fullkeyboardgameplay") { ctrlFull = val; continue; }
        if (key == "fov" || key == "field_of_view") {
            // Crit Particles projection needs the vertical FOV (default 70).
            const float v = (float)atof(val.c_str());
            if (v >= 30.0f && v <= 110.0f) s_gameFovDeg = v;
            continue;
        }
        for (int i = 0; i < 9; i++) {
            char n0[64], n1[64];
            sprintf_s(n0, sizeof(n0), "keyboard_type_0_key.hotbar.%d", i + 1);
            sprintf_s(n1, sizeof(n1), "keyboard_type_1_key.hotbar.%d", i + 1);
            if (key == n0) keys0[i] = val;
            else if (key == n1) keys1[i] = val;
        }
    }
    fclose(f);
    const bool full = (ctrlFull == "1");
    const std::string* active = full ? keys1 : keys0;
    for (int i = 0; i < 9; i++) s_hotbarKeys[i] = active[i];

    // Diagnostics: log the parsed binds whenever they change.
    static char s_bindsLog[160] = {};
    char sig[160] = {};
    for (int i = 0; i < 9; i++) {
        char b[16];
        sprintf_s(b, sizeof(b), "%s ", s_hotbarKeys[i].empty() ? "-" : s_hotbarKeys[i].c_str());
        strcat_s(sig, b);
    }
    if (std::strcmp(sig, s_bindsLog) != 0) {
        strncpy_s(s_bindsLog, sizeof(s_bindsLog), sig, _TRUNCATE);
        LOG_INFO("java hotkeys: binds [full=%d] %s", full ? 1 : 0, sig);
    }
}

// vtable-index helper (Flarial's Memory::CallVFuncI)
template <typename Ret, typename... Args>
static Ret CallVFunc(int index, void* self, Args... args) {
    void** vtable = *(void***)self;
    return ((Ret(__fastcall*)(void*, Args...))(vtable[index]))(self, args...);
}

// inventory chain: localPlayer -> supplies(0x5B8) -> inventory(0xB8) -> getItem(vfunc 7)
static void* GetInventoryItem(int slot) {
    if (!g_clientInstancePtr || g_localPlayerVfunc < 0) return nullptr;
    void* lp = CallVFunc<void*>(g_localPlayerVfunc, g_clientInstancePtr);
    if (!lp) return nullptr;
    void* supplies = *(void**)((uintptr_t)lp + 0x5B8);
    if (!supplies) return nullptr;
    void* inv = *(void**)((uintptr_t)supplies + 0xB8);
    if (!inv) return nullptr;
    return CallVFunc<void*>(7, inv, slot);
}

// Flarial checks ItemStack::getItem() (the Item* inside the stack, WeakPtr at
// +0x8), not the stack pointer itself: Bedrock returns a valid empty stack for
// air slots, so only a non-null Item means the slot actually holds something.
static bool StackHasItem(void* stack) {
    if (!stack) return false;
    __try {
        return *(void**)((uintptr_t)stack + 0x8) != nullptr;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static int ClassifyCollection(const std::string& name) {
    if (name == "hotbar_items") return 1;        // hotbar
    if (name == "inventory_items") return 2;     // main inventory
    if (name.find("_output") != std::string::npos) return 3;  // crafting output
    return 0;                                    // other
}

static void HandleTakeAll(void* ctrl, const std::string& col, int32_t slot,
                          LONG takeAllSlot, LONG placeAllSlot) {
    // Flarial pair on consecutive vtable slots: TakeAll / PlaceAll / PlaceOne
    // (PlaceAll=57 on 1.21.110 per their offset table => TakeAll=56). At the
    // first swap the live controller's vtable is scanned for the E8-sig
    // TakeAll address; when found, THAT slot (and slot+1 for PlaceAll) is
    // used, which self-corrects any vtable shift on this exact build.
    const LONG take = takeAllSlot > 0 ? takeAllSlot : 56;
    const LONG place = placeAllSlot > 0 ? placeAllSlot : 57;
    CallVFunc<void>((int)take, ctrl, col, slot);
    (void)place;
}

static void HandlePlaceAll(void* ctrl, const std::string& col, int32_t slot,
                           LONG placeAllSlot) {
    CallVFunc<void>((int)(placeAllSlot > 0 ? placeAllSlot : 57), ctrl, col, slot);
}

// Flarial JavaInventoryHotkeys::swap, verbatim logic
static void JavaSwap(void* ctrl, const std::string& srcCol, int32_t srcSlot, int32_t dstSlot,
                     LONG takeAllSlot, LONG placeAllSlot) {
    const int srcType = ClassifyCollection(srcCol);

    if (srcType == 3) {  // crafting output: take the result into the hotbar slot
        LOG_INFO("java hotkeys: swap branch=output col=%s slot=%d -> hotbar=%d",
                 srcCol.c_str(), (int)srcSlot, (int)dstSlot);
        HandleTakeAll(ctrl, srcCol, srcSlot, takeAllSlot, placeAllSlot);
        HandlePlaceAll(ctrl, "hotbar_items", dstSlot, placeAllSlot);
        return;
    }

    void* srcItem = (srcType == 1) ? GetInventoryItem(srcSlot)
                  : (srcType == 2) ? GetInventoryItem(9 + srcSlot)
                  : nullptr;
    void* dstItem = GetInventoryItem(dstSlot);
    const bool srcFilled = StackHasItem(srcItem);
    const bool dstFilled = StackHasItem(dstItem);
    LOG_INFO("java hotkeys: swap branch=%s src=%s dst=%s col=%s slot=%d -> hotbar=%d",
             (srcFilled && dstFilled) ? "both" : (srcFilled ? "src-only" :
              dstFilled ? "src-empty" : "both-empty"),
             srcFilled ? "item" : "empty", dstFilled ? "item" : "empty",
             srcCol.c_str(), (int)srcSlot, (int)dstSlot);

    if (!srcFilled && dstFilled) {
        // hovered slot is empty but the hotbar slot has an item: move it out
        HandleTakeAll(ctrl, "hotbar_items", dstSlot, takeAllSlot, placeAllSlot);
        HandlePlaceAll(ctrl, srcCol, srcSlot, placeAllSlot);
        HandlePlaceAll(ctrl, "hotbar_items", dstSlot, placeAllSlot);
        return;
    }

    HandleTakeAll(ctrl, srcCol, srcSlot, takeAllSlot, placeAllSlot);
    HandlePlaceAll(ctrl, "hotbar_items", dstSlot, placeAllSlot);
    HandlePlaceAll(ctrl, srcCol, srcSlot, placeAllSlot);
}

static bool canSwapCollection(const std::string_view name) {
    const bool isItemContainer = name.find("_item") != std::string_view::npos;
    const bool isRecipe = name.find("recipe_") != std::string_view::npos;
    const bool isSearch = name.find("search") != std::string_view::npos;
    return isItemContainer || (isRecipe && !isSearch);
}

// SEH wrapper: the swap runs game code on a controller we only know through
// the hover hook, so a stale pointer must never take the game down.
static void JavaSwapSeh(void* ctrl, const std::string* col,
                        int32_t srcSlot, int32_t dstSlot,
                        LONG takeAllSlot, LONG placeAllSlot) {
    __try {
        JavaSwap(ctrl, *col, srcSlot, dstSlot, takeAllSlot, placeAllSlot);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("java hotkeys: swap SEH 0x%08lX - controller %p dropped",
                  GetExceptionCode(), ctrl);
        InterlockedExchange(&s_hoveredSlot, -1);
        s_lastController = nullptr;
    }
}

// Liveness gate for a swap. ClientInstance::getScreenName FAULTS when called
// The swap executor, called from the Keyboard/MouseDevice feed detours (the
// game's own input dispatch thread - where Flarial's listeners run). The
// bind match happens FIRST so everything below only runs for real hotbar
// binds, never for ordinary gameplay keys.
static void JavaHotkeysTrySwap(int bindValue) {
    if (overlay::g_ShowMenu) return;

    // One swap per physical press: the OS auto-repeats a held key as fresh
    // keydown events, so the same bind is ignored until its release arrives
    // (callers pass bindValue=0 for releases, which re-arms the guard).
    if (bindValue == 0) {
        InterlockedExchange(&s_jhHeldBind, 0);
        return;
    }
    const LONG held = InterlockedExchange(&s_jhHeldBind, (LONG)bindValue);
    if (held == (LONG)bindValue) return;   // auto-repeat of the held bind

    // refresh the options file at most every 5 s (binds may change)
    const unsigned long now = GetTickCount();
    if (now >= s_optionsNextRead) {
        ReadHotbarOptions();
        s_optionsNextRead = now + 5000;
    }

    int slot = -1;
    for (int i = 0; i < 9; i++) {
        const std::string& codeStr = s_hotbarKeys[i];
        if (!codeStr.empty() && atoi(codeStr.c_str()) == bindValue) {
            slot = i;
            break;
        }
    }
    if (slot < 0) return;   // this key/button is not a hotbar bind

    // The press only QUEUES the swap; the live controller's own tick (the
    // slot-hover stream) drains it - same split as Flarial's input events and
    // ContainerScreenControllerTick. Hotbar binds collide with ordinary
    // gameplay keys (1-9 switching), so a bind match alone must never spam.
    if (!JavaHotkeysEnabled()) return;
    LOG_INFO("java hotkeys: queued hotbar=%d bind=%d", slot, bindValue);
    InterlockedExchange(&s_pendingHotbar, (LONG)slot);
    InterlockedExchange(&s_pendingAt, (LONG)GetTickCount());
}

// Mouse binds also need a render-thread fallback: Bedrock may never dispatch
// X1/X2 through MouseDevice::feed (the feed trace proves what arrives).
// GetAsyncKeyState works for mouse buttons inside the AppContainer - the same
// poll the GUI cursor already relies on. JavaHotkeysTrySwap re-validates all
// container state and runs the swap under SEH, so this is safe to call here.
static void JavaHotkeysFramePoll() {
    if (overlay::g_ShowMenu) return;
    static const int vks[5] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON,
                                VK_XBUTTON1, VK_XBUTTON2 };
    static bool prev[5] = {};
    for (int b = 0; b < 5; b++) {
        const bool down = PollKeyDown(vks[b]);
        if (down && !prev[b])      JavaHotkeysTrySwap(-99 - b);
        else if (!down && prev[b]) JavaHotkeysTrySwap(0);   // re-arm the guard
        prev[b] = down;
    }
}

// Drains a queued swap. Called from the slot-hover hook (inside the live
// controller's tick) and from the per-frame poll - both end up here, and the
// pending slot is consumed atomically so the swap runs exactly once.

// SEH-guarded peek of the raw Item* inside a container slot's stack.
static const void* PeekStackItem(int slot) {
    void* st = GetInventoryItem(slot);
    if (!st) return nullptr;
    __try {
        return *(void**)((uintptr_t)st + 8);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

static void ProcessPendingSwap(void* ctrl) {
    const LONG pending = InterlockedExchange(&s_pendingHotbar, -1);
    if (pending < 0 || pending > 8) return;
    const DWORD age = GetTickCount() - (ULONG)s_pendingAt;
    if (age > 500UL) return;   // stale request (screen closed before the tick)

    const int hovered = InterlockedCompareExchange(&s_hoveredSlot, -1, -1);
    if (hovered < 0) return;
    const std::string collection = s_hoveredCollection;
    if (!canSwapCollection(collection)) return;

    // Self-calibrating vtable pair. Static analysis is a dead end on this
    // build (no RTTI, no symbols; the Flarial E8 signature resolves to a
    // function that faults and is NOT in the controller vtable, while the
    // documented 56/57 pair runs safely but does nothing - so the layout
    // shifted). Instead: try candidate TakeAll/PlaceAll pairs around the
    // documented range, one per swap press, and WATCH THE ACTUAL INVENTORY -
    // when the hotbar slot's Item* changes, that pair is the real one and it
    // is locked in for the rest of the session.
    struct VtPair { int take; int place; };
    static const VtPair kCandidates[] = {
        {56, 57}, {57, 58}, {55, 56}, {58, 59},
        {54, 55}, {56, 58}, {57, 59}, {55, 57},
    };
    static bool s_calibrated = false;
    static int  s_takeSlot = 56;
    static int  s_placeSlot = 57;
    static int  s_nextCandidate = 0;
    static bool s_exhaustedLogged = false;

    if (!s_calibrated) {
        if (s_nextCandidate >= (int)(sizeof(kCandidates) / sizeof(kCandidates[0]))) {
            if (!s_exhaustedLogged) {
                s_exhaustedLogged = true;
                LOG_ERROR("java hotkeys: calibration exhausted - no pair moved "
                          "items (need a different call form)");
            }
            return;
        }
        const VtPair& c = kCandidates[s_nextCandidate++];
        s_takeSlot = c.take;
        s_placeSlot = c.place;
    }

    // Observable feedback: the hotbar slot's Item pointer (stack+8) before
    // and after the call. A real swap always changes it. (SEH lives in the
    // helper - __try cannot coexist with the std::string in this function.)
    const void* itemBefore = PeekStackItem((int)pending);

    LOG_INFO("java hotkeys: swap hovered=%d hotbar=%d take=%d place=%d%s",
             hovered, (int)pending, s_takeSlot, s_placeSlot,
             s_calibrated ? "" : " (calibrating)");
    JavaSwapSeh(ctrl, &collection, (int32_t)hovered, (int32_t)pending,
                s_takeSlot, s_placeSlot);

    if (!s_calibrated) {
        const void* itemAfter = PeekStackItem((int)pending);
        if (itemBefore != itemAfter) {
            s_calibrated = true;
            LOG_INFO("java hotkeys: CALIBRATED take=%d place=%d - items move",
                     s_takeSlot, s_placeSlot);
        }
        // else: this pair did nothing - the next press tries the next pair.
    }
}

static int64_t __fastcall hkContainerSlotHovered(void* self, const std::string* collectionName, int64_t slot) {
    __try {
        if (collectionName && slot >= 0 && LooksLikeGameObject(self)) {
            // The hovered event hands us the live ContainerScreenController -
            // the swap later runs against exactly this pointer.
            s_lastController = self;
            const size_t len = std::min(collectionName->size(), sizeof(s_hoveredCollection) - 1);
            memcpy(s_hoveredCollection, collectionName->c_str(), len);
            s_hoveredCollection[len] = 0;
            InterlockedExchange(&s_hoveredSlot, (LONG)slot);
            InterlockedExchange(&s_hoveredTime, (LONG)GetTickCount());

            // Drain a queued bind swap in the controller's own tick context.
            ProcessPendingSwap(self);

            // Diagnostics: prove hover tracking works (rate-limited).
            static volatile LONG s_hoverEvents = 0;
            static volatile LONG s_lastHoverLog = 0;
            static char s_lastHoverCol[64] = {};
            const LONG events = InterlockedIncrement(&s_hoverEvents);
            const DWORD nowMs = GetTickCount();
            if (events == 1 || (nowMs - (ULONG)s_lastHoverLog) > 10000UL ||
                std::strcmp(s_lastHoverCol, s_hoveredCollection) != 0) {
                InterlockedExchange(&s_lastHoverLog, (LONG)nowMs);
                strncpy_s(s_lastHoverCol, sizeof(s_lastHoverCol),
                          s_hoveredCollection, _TRUNCATE);
                LOG_INFO("java hotkeys: hovered slot=%lld collection='%s' (events=%d)",
                         (long long)slot, s_hoveredCollection, (int)events);
            }
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    return g_slotHoveredOriginal ? g_slotHoveredOriginal(self, collectionName, slot) : 0;
}

static void TryInstallFlarialHooks() {
    if (g_flarialHooksTried) return;
    g_flarialHooksTried = true;
    HMODULE game = GetModuleHandleW(nullptr);

    static const char* kSetupAndRender[] = {
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B FA 48 89 55",
        "48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 BC 24 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B FA"
    };
    static const char* kGetTexture[] = {
        "40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 45 0F B6 F9 44 88 4C 24",
        "40 53 55 56 57 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 41 0F B6 E9"
    };
    static const char* kAttack[] = {
        "48 89 ? ? ? 48 89 ? ? ? 48 89 ? ? ? 55 41 ? 41 ? 41 ? 41 ? 48 8D ? ? ? ? ? ? 48 81 EC ? ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? ? ? 45 0F ? ? 4C 8B ? 48 8B ? 45 33 ? 44 89",
        "48 89 ? ? ? 48 89 ? ? ? 48 89 ? ? ? 55 41 ? 41 ? 41 ? 41 ? 48 8D ? ? ? ? ? ? 48 81 EC ? ? ? ? 48 8B ? ? ? ? ? 48 33 ? 48 89 ? ? ? ? ? 45 0F ? ? 4C 8B ? 48 8B"
    };
    static const char* kGetPosition[] = {
        // Effective Flarial sig for 1.21.11X (inherited from the 1.21.3X
        // block, never overridden up to 1.21.11). Fully concrete - try first.
        "48 89 5C 24 10 48 89 74 24 18 57 48 83 EC 60 0F 29 74 24 50 0F 29 7C 24 40 48 8B 05 ? ? ? ? 48 33 C4 48 89 44 24 30",
        // Wildcarded 1.21.13X variant as fallback.
        "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 29 74 24 ? 0F 29 7C 24 ? 48 8B F9 F6 41"
    };

    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;

    // Uniqueness-first selection for the hooks whose address we CALL with our
    // own arguments or whose target we dereference at hardcoded offsets.
    uintptr_t fn = 0, fallback = 0;
    for (const char* sig : kSetupAndRender) {
        uintptr_t first = 0;
        const int matches = ScanSignatureMatches(game, sig, &first);
        if (matches == 1) { fn = first; break; }
        if (matches > 1 && !fallback) fallback = first;
    }
    if (!fn) fn = fallback;
    if (fn) {
        MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkSetupAndRender,
                                     (LPVOID*)&g_setupAndRenderOriginal);
        if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: ScreenView::setupAndRender hook active=1 status=%d", (int)st);
    } else {
        LOG_INFO("game: ScreenView::setupAndRender signature not found");
    }

    fn = 0;
    for (const char* sig : kGetTexture) { fn = ScanSignature(game, sig); if (fn) break; }
    if (fn) {
        MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGetTexture,
                                     (LPVOID*)&g_getTextureOriginal);
        if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: TextureGroup::getTexture hook active=1 status=%d", (int)st);
    } else {
        LOG_INFO("game: TextureGroup::getTexture signature not found");
    }

    fn = 0;
    for (const char* sig : kAttack) { fn = ScanSignature(game, sig); if (fn) break; }
    if (fn) {
        MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkGameModeAttack,
                                     (LPVOID*)&g_attackOriginal);
        if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: GameMode::attack hook active=1 status=%d", (int)st);
    } else {
        LOG_INFO("game: GameMode::attack signature not found");
    }

    // UIControl::getPosition gets CALLED on every walked control with the
    // control as self: a lookalike here corrupts or crashes. Unique match
    // only - an ambiguous candidate is refused outright.
    for (const char* sig : kGetPosition) {
        uintptr_t first = 0;
        if (ScanSignatureMatches(game, sig, &first) == 1) {
            g_getPositionFn = first;
            break;
        }
    }
    LOG_INFO("game: UIControl::getPosition found=%d", g_getPositionFn != 0);

    // ---- Java Hotkeys: container UI hook -----------------------------------
    // Only _onContainerSlotHovered is hooked: it fires on every slot change,
    // hands us the live controller pointer and proved reliable on this build.
    // The container-tick hook was removed - its signature matched a function
    // that never runs on 1.21.111, and the swap is driven from the input feed
    // detours instead (see JavaHotkeysTrySwap).
    static const char* kSlotHovered[] = {
        "48 89 5C 24 10 48 89 6C 24 18 48 89 7C 24 20 41 56 48 83 EC 20 45 33 F6 41 8B E8"
    };
    static const char* kLocalPlayerIndex[] = {
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0 0F 84 ? ? ? ? 48 8B C8",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0 0F 84 ? ? ? ? 0F",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ?"
    };

    fn = 0;
    for (const char* sig : kSlotHovered) { fn = ScanSignature(game, sig); if (fn) break; }
    if (fn) {
        MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkContainerSlotHovered,
                                     (LPVOID*)&g_slotHoveredOriginal);
        if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) MH_EnableHook((LPVOID)fn);
        LOG_INFO("game: ContainerScreenController::_onContainerSlotHovered hook status=%d", (int)st);
    } else {
        LOG_INFO("game: ContainerScreenController::_onContainerSlotHovered signature not found");
    }

    // getLocalPlayer vfunc: each sig variant embeds the vtable byte-offset of
    // the getLocalPlayer virtual call. Validate by CALLING it on the live
    // ClientInstance (inside SEH) and checking the returned player is a
    // plausible object (non-null, EntityContext with a valid entity at +8).
    for (const char* sig : kLocalPlayerIndex) {
        const uintptr_t site = ScanSignature(game, sig);
        if (!site) continue;
        const int vfunc = *(const int*)(site + 9) / 8;
        if (vfunc <= 0 || vfunc > 500) continue;
        if (!g_clientInstancePtr) { g_localPlayerVfunc = vfunc; break; }

        bool ok = false;
        __try {
            void** vtable = *(void***)g_clientInstancePtr;
            if (vtable && vtable[vfunc]) {
                using GetLpFn = void*(__fastcall*)(void*);
                void* lp = ((GetLpFn)vtable[vfunc])(g_clientInstancePtr);
                if (lp) {
                    // EntityContext at Actor+0x8: registry ref + entity id
                    void* reg = *(void**)((uintptr_t)lp + 0x8);
                    if (reg) ok = true;
                }
            }
        } __except (EXCEPTION_EXECUTE_HANDLER) { ok = false; }

        if (ok) {
            g_localPlayerVfunc = vfunc;
            LOG_INFO("game: ClientInstance::getLocalPlayer vfunc=%d (validated)", vfunc);
            break;
        }
        LOG_INFO("game: getLocalPlayer vfunc=%d rejected by validation", vfunc);
    }
    if (g_localPlayerVfunc <= 0) {
        LOG_INFO("game: ClientInstance::getLocalPlayer not resolved (no sig matched)");
    }

    // _handleTakeAll/_handlePlaceAll resolve at swap time from the live
    // controller's vtable (56/57) - no signature scan needed. The old E8
    // call-site signature resolved to a wrong address on 1.21.111 and made
    // every swap fault, so it was removed entirely.

    // ClientInstance::getScreenName - drives the chat/text-input gate for the
    // global hotkeys (K must not open the GUI while typing in chat).
    static const char* kScreenName[] = {
        "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B EA 48 8B 01 "
        "48 8D 54 24 ? 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 90 48 8B 48 ? 48 8B 01 48 8B D5 "
        "48 8B 80 ? ? ? ? FF 15 ? ? ? ? 90"
    };
    fn = 0;
    for (const char* sig : kScreenName) { fn = ScanSignature(game, sig); if (fn) break; }
    if (fn) {
        g_getScreenNameFn = (GetScreenNameFn)fn;
        LOG_INFO("game: ClientInstance::getScreenName found");
    } else {
        LOG_INFO("game: ClientInstance::getScreenName signature not found");
    }
}

// MinHook detour body. key = VK code, isDown = pressed/released, exactly as
// the game dispatches it. We only read the two keys the GUI needs; oFunc is
// still called for everything so the game behaves normally (only ESC while
// the menu is open is swallowed, like Solstice swallows keys when ImGui
// wants to capture keyboard input).
static void __cdecl hkKeyboardFeed(uint32_t key, bool isDown) {
    // Capture every transition for the GUI before deciding whether the game
    // should receive it. This is the in-process equivalent of the watcher's
    // 256-bit keyboard mirror.
    SetFeedKey(key, isDown);

    // Solstice's AutoSprint uses the game's input handler. The current
    // Bedrock build exposes that handler through this already-installed feed
    // detour, so mirror a held CTRL sprint while W is held. Releases are
    // always paired, including when the module is switched off.
    static bool injectedSprintKey = false;
    bool autoSprint = false;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "AutoSprint") == 0) {
            auto* sprint = static_cast<modules::Sprint*>(mod.get());
            autoSprint = mod->enabled() && sprint->m_always && sprint->m_always->mValue;
            break;
        }
    }
    if (!autoSprint && injectedSprintKey && oKeyboardFeed) {
        oKeyboardFeed(VK_CONTROL, false);
        injectedSprintKey = false;
    }
    if (key == 'W' && oKeyboardFeed) {
        if (isDown && autoSprint && !injectedSprintKey) {
            oKeyboardFeed(VK_CONTROL, true);
            injectedSprintKey = true;
        } else if (!isDown && injectedSprintKey) {
            oKeyboardFeed(VK_CONTROL, false);
            injectedSprintKey = false;
        }
    }

    if (isDown) {
        // Only a TEXT-INPUT screen (chat, sign, book, ...) owns the keyboard.
        // Regular menus (start menu, pause, inventory) do NOT block the menu
        // hotkeys anymore - the ClickGUI must open there too. Our own open
        // menu is exempt anyway: K/INSERT must still close it.
        const bool screenOwnsKeys = g_ext_key_flags.chatOpen != 0;
        if (!screenOwnsKeys && (key == VK_INSERT || key == 'K')) {
            g_ShowMenu = !g_ShowMenu;
            g_ext_key_flags.menuOpen = g_ShowMenu ? 1 : 0;
            LOG_INFO("menu: toggle -> visible=%d source=keyhook", g_ShowMenu ? 1 : 0);
            return; // swallow: the game does not need K/INSERT at all
        }
        if (key == VK_ESCAPE && g_ShowMenu) {
            g_ShowMenu = false;
            g_ext_key_flags.menuOpen = 0;
            LOG_INFO("menu: ESC -> visible=0 source=keyhook (swallowed)");
            return; // swallow the press so the game pause menu stays closed
        }
        if (key == VK_END && !g_UnloadRequested && !screenOwnsKeys) {
            g_UnloadRequested = true;
            LOG_INFO("menu: END -> unload requested source=keyhook");
            return; // swallow
        }
        // GUI is OPEN: the game must not react to ANY other key (WASD move,
        // space jump, E/B inventory, numbers hotbar...). Swallow every press.
        if (g_ShowMenu)
            return;
    }

    // Java Hotkeys (Flarial's KeyEvent): the press reaches the game's own
    // input dispatch - the exact moment Flarial listens at. Bedrock keyboard
    // binds are stored as the same codes the feed reports (VK on Windows).
    // Releases pass 0 so the press guard re-arms.
    if (!g_ShowMenu)
        JavaHotkeysTrySwap(isDown ? (int)key : 0);

    // Flarial Null Movement: when opposite movement keys are held together,
    // forward only the most recently pressed key on each axis. The physical
    // state is retained so releasing that key immediately reactivates the
    // still-held opposite key. This uses the existing Keyboard::feed hook and
    // does not need a fragile player/input-handler offset.
    static bool physical[4] = {false, false, false, false}; // W S A D
    static int activeVertical = -1;
    static int activeHorizontal = -1;
    bool nullEnabled = false;
    bool nullVertical = true;
    bool nullHorizontal = true;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "Null Movement") == 0) {
            auto* nm = static_cast<modules::NullMovement*>(mod.get());
            nullEnabled = mod->enabled();
            nullVertical = !nm->m_vertical || nm->m_vertical->mValue;
            nullHorizontal = !nm->m_horizontal || nm->m_horizontal->mValue;
            break;
        }
    }
    if (!nullEnabled) {
        for (bool& state : physical) state = false;
        activeVertical = activeHorizontal = -1;
        if (oKeyboardFeed) oKeyboardFeed(key, isDown);
        return;
    }

    int index = -1;
    if (key == 'W') index = 0;
    else if (key == 'S') index = 1;
    else if (key == 'A') index = 2;
    else if (key == 'D') index = 3;
    if (index < 0) {
        if (oKeyboardFeed) oKeyboardFeed(key, isDown);
        return;
    }

    const bool vertical = index < 2;
    const bool enabledAxis = vertical ? nullVertical : nullHorizontal;
    if (!enabledAxis) {
        physical[index] = isDown;
        if (oKeyboardFeed) oKeyboardFeed(key, isDown);
        return;
    }

    bool& physicalKey = physical[index];
    int& active = vertical ? activeVertical : activeHorizontal;
    const int opposite = vertical ? (index == 0 ? 1 : 0)
                                  : (index == 2 ? 3 : 2);
    const uint32_t oppositeKey = opposite == 0 ? 'W' :
                                 opposite == 1 ? 'S' :
                                 opposite == 2 ? 'A' : 'D';

    physicalKey = isDown;
    if (isDown) {
        if (active != index && active >= 0 && oKeyboardFeed) {
            const uint32_t oldKey = active == 0 ? 'W' : active == 1 ? 'S' :
                                    active == 2 ? 'A' : 'D';
            oKeyboardFeed(oldKey, false);
        }
        active = index;
        if (oKeyboardFeed) oKeyboardFeed(key, true);
        return;
    }

    if (active != index)
        return; // release for a key that was suppressed by the opposite key
    if (oKeyboardFeed) oKeyboardFeed(key, false);
    if (physical[opposite]) {
        active = opposite;
        if (oKeyboardFeed) oKeyboardFeed(oppositeKey, true);
    } else {
        active = -1;
    }
}

void TryInstallKeyboardHook() {
    if (g_KeyHookTried) return;
    g_KeyHookTried = true;

    uintptr_t match = ScanExecutableSections(GetModuleHandleW(nullptr));
    if (!match) {
        LOG_INFO("input: Keyboard::feed signature not found - using frame polling fallback");
        return;
    }
    // RefSig: match points at "E8 rel32" -> target = match + 5 + rel32.
    uintptr_t feed = match + 5 + (uintptr_t)(int32_t)(*(int32_t*)(match + 1));
    LOG_INFO("input: Keyboard::feed found at %p (sig match %p)", (void*)feed, (void*)match);

    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("input: MH_Initialize failed status=%d", (int)st);
        return;
    }
    st = MH_CreateHook((LPVOID)feed, (LPVOID)&hkKeyboardFeed, (LPVOID*)&oKeyboardFeed);
    if (st != MH_OK) {
        LOG_ERROR("input: MH_CreateHook(Keyboard::feed) failed status=%d", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)feed);
    g_KeyHookActive = (st == MH_OK);
    // Tell the external watcher: when the in-process keyhook is live it
    // already swallows the game's keys, so the watcher must NOT install its
    // global WH_KEYBOARD_LL mask (which would otherwise eat K/ESC before the
    // detour ever sees them). Mouse masking stays with the watcher.
    g_ext_key_flags.keyhookOn = g_KeyHookActive ? 1 : 0;
    LOG_INFO("input: Keyboard::feed hook active=%d status=%d", g_KeyHookActive ? 1 : 0, (int)st);
}

// ======================== Packet/Flarial mouse hook =======================
// Packet calls this MouseDevice::feed hook ClickFunc.  The first signature is
// the 1.21.11x function prologue used by Packet; the second is Flarial's call
// site signature used on nearby Bedrock builds.  Keeping both makes the hook
// version-tolerant without dereferencing speculative game objects.
void TryInstallMouseHook() {
    if (g_MouseHookTried) return;
    g_MouseHookTried = true;

    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t fn = ScanSignature(game,
        "48 8B C4 48 89 58 ? 48 89 68 ? 48 89 70 ? 57 41 54 41 55 41 56 41 57 48 83 EC ? 44 0F B7 BC 24 ? ? ? ? 48 8B D9");

    if (!fn) {
        const uintptr_t callSite = ScanSignature(game, "E8 ? ? ? ? 40 88 6C 1F");
        if (callSite) {
            const int32_t rel = *(const int32_t*)(callSite + 1);
            fn = callSite + 5 + (intptr_t)rel;
        }
    }

    if (!fn) {
        LOG_INFO("input: MouseDevice::feed signature not found - using watcher/raw fallback");
        return;
    }

    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("input: MH_Initialize(mouse) failed status=%d", (int)init);
        return;
    }
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&hkMouseFeed,
                                 (LPVOID*)&g_mouseFeedOriginal);
    if (st == MH_ERROR_ALREADY_CREATED) {
        // A previous install attempt may have created the detour while this
        // frame was racing another initialization path.  Do not enable an
        // unknown trampoline; keep the fallback path in that case.
        LOG_INFO("input: MouseDevice::feed hook already exists at %p", (void*)fn);
        return;
    }
    if (st != MH_OK) {
        LOG_ERROR("input: MH_CreateHook(MouseDevice::feed) failed status=%d", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)fn);
    g_MouseHookActive = (st == MH_OK);
    LOG_INFO("input: MouseDevice::feed hook active=%d status=%d target=%p",
             g_MouseHookActive ? 1 : 0, (int)st, (void*)fn);
}

// ======================== Raw input block (camera/input freeze while GUI open) ========================
// In a world, Minecraft reads the mouse through WM_INPUT raw input
// (GetRawInputData / GetRawInputBuffer) - that is why the external watcher's
// low-level hooks are blind to camera movement and why the OS cursor looks
// "parked" (the game pins it to the window center). If the version-specific
// MouseDevice::feed hook is available, mouse packets are left intact and the
// Packet-style dispatcher hook cancels them at the correct game boundary. If
// that signature is unavailable, we fall back to a valid inert mouse packet.
// Raw keyboard packets are neutralized in both cases.
typedef UINT(WINAPI* GetRawInputDataFn)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
typedef UINT(WINAPI* GetRawInputBufferFn)(RAWINPUT*, PUINT, UINT);
typedef BOOL(WINAPI* SetCursorPosFn)(int, int);
typedef BOOL(WINAPI* ClipCursorFn)(const RECT*);
typedef HWND(WINAPI* SetCaptureFn)(HWND);
typedef int(WINAPI* ShowCursorFn)(BOOL);
static GetRawInputDataFn   oGetRawInputData   = nullptr;
static GetRawInputBufferFn oGetRawInputBuffer = nullptr;
static SetCursorPosFn      oSetCursorPos      = nullptr;
static ClipCursorFn        oClipCursor        = nullptr;
static SetCaptureFn        oSetCapture        = nullptr;
static ShowCursorFn        oShowCursor        = nullptr;
static bool                g_RawBlockTried    = false;
static bool                g_RawBlockActive   = false;

static void CaptureLocalRawInput(const RAWINPUT* ri) {
    if (!g_ShowMenu || !ri || ri->header.dwType != RIM_TYPEMOUSE)
        return;
    if (ri->data.mouse.usFlags & MOUSE_MOVE_ABSOLUTE)
        return;
    InterlockedExchangeAdd(&g_localRawDx, ri->data.mouse.lLastX);
    InterlockedExchangeAdd(&g_localRawDy, ri->data.mouse.lLastY);
}

// Neutralize game actions in a RAWINPUT while preserving the packet shape.
// When preserveMouse is true, the MouseDevice::feed detour needs the mouse
// payload; keyboard payloads are still made inert.
//
// WHY NOT "return 0" (the old implementation): GetRawInputData's contract is
// "number of bytes copied". Returning 0 makes the caller allocate a ZERO-byte
// buffer and then parse a RAWINPUT out of it - an out-of-bounds read and a
// heap-corruption / UB hazard INSIDE the game, triggered at random later.
// Returning (UINT)-1 is not better: some callers treat that as "device lost"
// and spin. The only safe suppression is a valid, correctly sized RAWINPUT
// whose payload is inert.
static void NeutralizeRawInput(RAWINPUT* ri, bool preserveMouse) {
    if (!ri) return;
    if (ri->header.dwType == RIM_TYPEMOUSE) {
        if (!preserveMouse) {
            ri->data.mouse.lLastX = 0;
            ri->data.mouse.lLastY = 0;
            ri->data.mouse.usButtonFlags = 0;
            ri->data.mouse.usButtonData = 0;
        }
    } else if (ri->header.dwType == RIM_TYPEKEYBOARD) {
        // Keep the struct valid: the game dispatches on Message, and WM_NULL
        // is ignored by every RawInput keyboard path.
        ri->data.keyboard.Message = WM_NULL;
        ri->data.keyboard.VKey    = 0;
    }
}

static UINT WINAPI hkGetRawInputData(HRAWINPUT h, UINT cmd, LPVOID data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        UINT ret = oGetRawInputData(h, cmd, data, size, hdr);
        if (g_ShowMenu && cmd == RID_INPUT && data && ret > 0 &&
            ret != (UINT)-1)
            CaptureLocalRawInput((const RAWINPUT*)data);
        if (g_ShowMenu && cmd == RID_INPUT && data && ret > 0 &&
            ret != (UINT)-1)
            // With the external watcher active, it owns the GUI cursor and
            // the game's raw mouse stream must be inert even if a build's
            // MouseDevice::feed signature resolves to a nearby helper.
            NeutralizeRawInput((RAWINPUT*)data,
                               g_MouseHookActive && !g_ExtKeysActive);
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

static UINT WINAPI hkGetRawInputBuffer(RAWINPUT* data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        UINT ret = oGetRawInputBuffer(data, size, hdr);
        if (g_ShowMenu && data && ret > 0 && ret != (UINT)-1) {
            RAWINPUT* ri = data;
            for (UINT i = 0; i < ret; i++) {
                const DWORD step = ri->header.dwSize;
                CaptureLocalRawInput(ri);
                NeutralizeRawInput(ri,
                                   g_MouseHookActive && !g_ExtKeysActive);
                if (step < sizeof(RAWINPUTHEADER)) break; // malformed: stop
                ri = (RAWINPUT*)((BYTE*)ri + step);
            }
        }
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

// Bedrock normally recenters and clips the OS cursor while the player owns
// the mouse. Those calls fight the ClickGUI's cursor and make it appear stuck
// even though ImGui is receiving button events. The hooks are inert while the
// menu is closed, and only reject the game's cursor-grab calls while open.
static BOOL WINAPI hkSetCursorPos(int x, int y) {
    if (g_ShowMenu) return TRUE;
    return oSetCursorPos ? oSetCursorPos(x, y) : FALSE;
}

static BOOL WINAPI hkClipCursor(const RECT* rect) {
    // Our GUI calls ClipCursor(nullptr) to release the game's capture when it
    // opens. Only reject a new non-null game clip while the menu owns input.
    if (g_ShowMenu && rect != nullptr) return TRUE;
    return oClipCursor ? oClipCursor(rect) : FALSE;
}

static HWND WINAPI hkSetCapture(HWND hwnd) {
    if (g_ShowMenu) return nullptr;
    return oSetCapture ? oSetCapture(hwnd) : nullptr;
}

static int WINAPI hkShowCursor(BOOL show) {
    // Keep the game from hiding the cursor underneath the menu. ImGui also
    // draws a cursor, so returning a positive display count is sufficient.
    if (g_ShowMenu && !show) return 1;
    return oShowCursor ? oShowCursor(show) : 1;
}

void TryInstallRawInputBlock() {
    if (g_RawBlockTried) return;
    g_RawBlockTried = true;

    HMODULE u32 = GetModuleHandleA("user32.dll");
    if (!u32) return;
    FARPROC p1 = GetProcAddress(u32, "GetRawInputData");
    FARPROC p2 = GetProcAddress(u32, "GetRawInputBuffer");
    FARPROC p3 = GetProcAddress(u32, "SetCursorPos");
    FARPROC p4 = GetProcAddress(u32, "ClipCursor");
    FARPROC p5 = GetProcAddress(u32, "SetCapture");
    FARPROC p6 = GetProcAddress(u32, "ShowCursor");
    if (!p1 && !p2 && !p3 && !p4 && !p5 && !p6) {
        LOG_INFO("input: raw input block unavailable (user32 exports?)");
        return;
    }

    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("input: MH_Initialize failed status=%d", (int)st);
        return;
    }

    bool ok = false;
    if (p1) {
        st = MH_CreateHook((LPVOID)p1, (LPVOID)&hkGetRawInputData, (LPVOID*)&oGetRawInputData);
        if (st != MH_OK) LOG_ERROR("input: MH_CreateHook(GetRawInputData) status=%d", (int)st);
        else if (MH_EnableHook((LPVOID)p1) == MH_OK) ok = true;
    }
    if (p2) {
        st = MH_CreateHook((LPVOID)p2, (LPVOID)&hkGetRawInputBuffer, (LPVOID*)&oGetRawInputBuffer);
        if (st != MH_OK) LOG_ERROR("input: MH_CreateHook(GetRawInputBuffer) status=%d", (int)st);
        else if (MH_EnableHook((LPVOID)p2) == MH_OK) ok = true;
    }
    if (p3) {
        st = MH_CreateHook((LPVOID)p3, (LPVOID)&hkSetCursorPos, (LPVOID*)&oSetCursorPos);
        if (st == MH_OK && MH_EnableHook((LPVOID)p3) == MH_OK) ok = true;
    }
    if (p4) {
        st = MH_CreateHook((LPVOID)p4, (LPVOID)&hkClipCursor, (LPVOID*)&oClipCursor);
        if (st == MH_OK && MH_EnableHook((LPVOID)p4) == MH_OK) ok = true;
    }
    if (p5) {
        st = MH_CreateHook((LPVOID)p5, (LPVOID)&hkSetCapture, (LPVOID*)&oSetCapture);
        if (st == MH_OK && MH_EnableHook((LPVOID)p5) == MH_OK) ok = true;
    }
    if (p6) {
        st = MH_CreateHook((LPVOID)p6, (LPVOID)&hkShowCursor, (LPVOID*)&oShowCursor);
        if (st == MH_OK && MH_EnableHook((LPVOID)p6) == MH_OK) ok = true;
    }
    g_RawBlockActive = ok;
    if (ok)
        LOG_INFO("input: raw input block active (camera/input swallowed while GUI open)");
}

// Called every frame from UpdateInputStateImpl() ON THE RENDER THREAD.
// GetAsyncKeyState only reports state for threads that process input
// messages (have a message queue). The render thread is exactly that
// thread - the same one that already successfully polls the mouse. Edge
// detection (prev*) turns a key repeat into exactly one toggle.
void PollHotkeyState() {
    // Chat/text screens own the keyboard - never toggle from them.
    if (g_ext_key_flags.chatOpen)
        return;

    // When the Keyboard::feed detour is live it already delivers every
    // game-dispatched key press exactly once - do NOT double-poll, or a
    // single K press would toggle twice (open then closed instantly).
    // Same for the EXTERNAL watcher (injector writes g_ext_key_flags):
    // once it has delivered its first event we trust it exclusively and
    // keep the (provably dead in this AppContainer) in-process polling off.
    if (g_KeyHookActive || g_ExtKeysActive)
        return;

    static bool prevInsert = false;
    static bool prevK      = false;
    static bool prevEsc    = false;
    static bool prevEnd    = false;

    const bool insertDown = PollKeyDown(VK_INSERT);
    const bool kDown      = PollKeyDown('K');
    const bool escDown    = PollKeyDown(VK_ESCAPE);
    const bool endDown    = PollKeyDown(VK_END);

    bool stateChanged = false;
    if ((insertDown && !prevInsert) || (kDown && !prevK)) {
        g_ShowMenu = !g_ShowMenu;
        LOG_INFO("menu: toggle -> visible=%d source=frame", g_ShowMenu ? 1 : 0);
        stateChanged = true;
    }
    if (escDown && !prevEsc && g_ShowMenu) {
        g_ShowMenu = false;
        g_ext_key_flags.menuOpen = 0;
        LOG_INFO("menu: ESC -> visible=0 source=frame");
        stateChanged = true;
    }
    if (endDown && !prevEnd && !g_UnloadRequested) {
        g_UnloadRequested = true;
        LOG_INFO("menu: END -> unload requested source=frame");
    }

    prevInsert = insertDown;
    prevK      = kDown;
    prevEsc    = escDown;
    prevEnd    = endDown;

    // If the menu just opened/closed, make the OS cursor follow immediately
    // (the periodic sync in UpdateHotkeys runs once per frame - this makes
    // the cursor responsive the very same frame the key is pressed).
    if (stateChanged)
        UpdateCursorVisibility();
}

void UpdateInputStateImpl() {
    ImGuiIO& io = ImGui::GetIO();
    HWND inputWindow = ResolveInputWindow();
    static unsigned long long inputFrames = 0;
    if (inputFrames++ == 0)
        LOG_INFO("input: polling active hwnd=%p menu=%d", inputWindow, g_ShowMenu ? 1 : 0);

    // The watcher is authoritative for button transitions because its
    // low-level hook captures clicks before they are swallowed. Position is
    // kept in-process: in a world Bedrock parks the desktop cursor and the
    // watcher's absolute point therefore stops changing. The DLL combines
    // MouseDevice::feed deltas with raw-input deltas below.
    const bool useMirrorButtons = g_ExtKeysActive && g_ShowMenu;
    const bool useGameMouseButtons = !useMirrorButtons && g_ShowMenu &&
                                     g_MouseHookActive &&
                                     (g_gameMouseValid != 0);
    static LONG localCursorX = 0;
    static LONG localCursorY = 0;
    static bool localCursorInit = false;
    static bool localRawSeen = false;
    static bool previousMenu = false;
    if (g_ShowMenu != previousMenu) {
        // MouseDevice::feed button-up packets are intentionally swallowed
        // while the GUI is open. Clear the local mirror on close so a held
        // GUI button cannot leak into the next menu session.
        if (!g_ShowMenu) {
            InterlockedExchange(&g_gameMouseButtons, 0);
            InterlockedExchange(&g_gameMouseWheel, 0);
            InterlockedExchange(&g_gameMouseValid, 0);
            InterlockedExchange(&g_localRawDx, 0);
            InterlockedExchange(&g_localRawDy, 0);
            InterlockedExchange(&g_localFeedDx, 0);
            InterlockedExchange(&g_localFeedDy, 0);
            localCursorInit = false;
            localRawSeen = false;
        } else {
            // Start a fresh GUI cursor session at the current OS position;
            // subsequent raw deltas are accumulated from this point.
            InterlockedExchange(&g_localRawDx, 0);
            InterlockedExchange(&g_localRawDy, 0);
            InterlockedExchange(&g_localFeedDx, 0);
            InterlockedExchange(&g_localFeedDy, 0);
            localCursorInit = false;
            localRawSeen = false;
        }
        previousMenu = g_ShowMenu;
    }

    POINT pt{};
    bool pointIsClient = false;
    if (g_ShowMenu) {
        if (!localCursorInit) {
            POINT seed{};
            // Prefer the watcher's last absolute point only for the initial
            // seed. Once open, relative deltas are the sole source of motion.
            if (useMirrorButtons && g_ext_key_flags.mx != 0 &&
                g_ext_key_flags.my != 0) {
                seed.x = (LONG)g_ext_key_flags.mx;
                seed.y = (LONG)g_ext_key_flags.my;
                if (inputWindow)
                    ScreenToClient(inputWindow, &seed);
            } else {
                GetCursorPos(&seed);
                if (inputWindow)
                    ScreenToClient(inputWindow, &seed);
            }
            localCursorX = seed.x;
            localCursorY = seed.y;
            localCursorInit = true;
        }

        const LONG feedDx = InterlockedExchange(&g_localFeedDx, 0);
        const LONG feedDy = InterlockedExchange(&g_localFeedDy, 0);
        const LONG rawDx = InterlockedExchange(&g_localRawDx, 0);
        const LONG rawDy = InterlockedExchange(&g_localRawDy, 0);
        // When both hooks observe one physical event, MouseDevice::feed is
        // the canonical path and the matching raw packet is discarded. If
        // feed is unavailable, raw deltas remain a complete fallback.
        const bool haveFeedDelta = feedDx != 0 || feedDy != 0;
        const LONG dx = haveFeedDelta ? feedDx : rawDx;
        const LONG dy = haveFeedDelta ? feedDy : rawDy;
        if (dx != 0 || dy != 0) {
            localCursorX += dx;
            localCursorY += dy;
            localRawSeen = true;
        } else if (!localRawSeen && g_MouseHookActive &&
                   (g_gameMouseValid != 0)) {
            // Some builds dispatch MouseDevice::feed without exposing the
            // original raw packet to user32. Use its client-space position as
            // the initial/fallback cursor source until relative deltas appear.
            localCursorX = (LONG)g_gameMouseX;
            localCursorY = (LONG)g_gameMouseY;
        }
        pt.x = localCursorX;
        pt.y = localCursorY;
        pointIsClient = true;
    } else {
        GetCursorPos(&pt); // normal path (menu closed, or no watcher)
    }
    if (inputWindow && !pointIsClient)
        ScreenToClient(inputWindow, &pt);
    if (g_ShowMenu) {
        const ImVec2 display = io.DisplaySize;
        if (display.x > 1.0f) {
            if (pt.x < 0) pt.x = 0;
            if (pt.x >= (LONG)display.x) pt.x = (LONG)display.x - 1;
        }
        if (display.y > 1.0f) {
            if (pt.y < 0) pt.y = 0;
            if (pt.y >= (LONG)display.y) pt.y = (LONG)display.y - 1;
        }
    }
    io.AddMousePosEvent((float)pt.x, (float)pt.y);

    static const int  vkC[5] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
    static bool prev[5]      = { false, false, false, false, false };
    for (int i = 0; i < 5; i++) {
        bool down;
        if (useMirrorButtons) {
            down = ((g_ext_key_flags.mDown >> i) & 1) != 0;
        } else if (useGameMouseButtons) {
            down = ((g_gameMouseButtons >> i) & 1) != 0;
        } else {
            // Use the high bit only. The low "pressed since last call" bit is
            // shared with other callers and Bedrock can consume it before the
            // overlay sees it.
            down = PollKeyDown(vkC[i]);
        }
        if (down != prev[i]) {
            prev[i] = down;
            io.AddMouseButtonEvent(i, down);
            if (down) {
                g_clickCount++;
                LOG_INFO("input: mouse button %d pressed at (%.0f, %.0f) hwnd=%p%s",
                         i, io.MousePos.x, io.MousePos.y, inputWindow,
                         useMirrorButtons ? " (mirrored)" : "");
            }
        }
    }

    // The watcher publishes a cumulative counter, so no wheel notch is lost
    // when the render FPS is lower than the watcher's 500 Hz loop.
    static LONG sMirrorWheel = 0;
    static LONG sGameWheel   = 0;
    if (!g_ShowMenu)
        sGameWheel = 0;
    if (useMirrorButtons) {
        const LONG wheelNow = g_ext_key_flags.wheel;
        const LONG wheelDelta = wheelNow - sMirrorWheel;
        if (wheelDelta != 0)
            io.AddMouseWheelEvent(0.0f, (float)wheelDelta);
        sMirrorWheel = wheelNow;
    } else if (useGameMouseButtons) {
        const LONG wheelNow = g_gameMouseWheel;
        const LONG wheelDelta = wheelNow - sGameWheel;
        if (wheelDelta != 0)
            io.AddMouseWheelEvent(0.0f, (float)wheelDelta);
        sGameWheel = wheelNow;
    }

    // Keyboard hotkeys are polled HERE, on the render thread - the same
    // thread whose GetAsyncKeyState polling already proves the mouse works
    // (see PollHotkeyState). K/INSERT toggle the menu, ESC closes it, END
    // requests a safe unload.
    PollHotkeyState();

    // Java Hotkeys: per-frame mouse-bind fallback (the feed may not deliver
    // side buttons). Gated inside on menu state; swaps re-validate all
    // container state themselves.
    JavaHotkeysFramePoll();
}

void UpdateHotkeys() {
    // --- External key watcher (injector.exe, reliable in/outside the
    // AppContainer) ---
    // The injector is a normal desktop process (not the game's sandbox), so
    // GetAsyncKeyState works there for keyboard keys - which the same call
    // INSIDE the game provably does not (mouse works, keys never do). It
    // increments g_ext_key_flags counters via WriteProcessMemory:
    //   [0] toggle (K/INSERT), [1] ESC, [2] END, [3] alive magic.
    // We read the counters, apply the DELTA since the last frame and never
    // clear them (the watcher only ever increments) => one physical press
    // is exactly one event, no lost or doubled toggles.
    if (g_ext_key_flags.alive == kExtAliveMagic)
        g_ExtKeysActive = true; // watcher live: stop the dead frame key poll

    // Keep the watcher informed EVERY frame (both keyhook and watcher modes):
    //   - menuOpen tells the watcher when to install its global input masks
    //     (WH_KEYBOARD_LL/WH_MOUSE_LL) so the game sees NO keys/clicks while
    //     the GUI is open;
    //   - keyhookOn tells the watcher NOT to install the keyboard mask when
    //     the in-game Keyboard::feed detour already blocks keys in-process
    //     (otherwise the swallowed K/ESC would never reach the detour).
    g_ext_key_flags.menuOpen   = g_ShowMenu ? 1 : 0;
    g_ext_key_flags.keyhookOn  = g_KeyHookActive ? 1 : 0;

    // Publish CPS limiter settings to the external watcher. The watcher owns
    // the low-level mouse callback, so it is the only place that can reject a
    // click before Minecraft receives it.
    LONG limiterOn = 0, cpsLeft = 16, cpsRight = 24;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "CPS Limiter") == 0) {
            auto* limiter = static_cast<modules::CPSLimiter*>(mod.get());
            limiterOn = mod->enabled() ? 1 : 0;
            if (limiter->m_left) cpsLeft = (LONG)limiter->m_left->mValue;
            if (limiter->m_right) cpsRight = (LONG)limiter->m_right->mValue;
            break;
        }
    }
    InterlockedExchange(&g_ext_key_flags.cpsLimiterOn, limiterOn);
    InterlockedExchange(&g_ext_key_flags.cpsLeft, cpsLeft);
    InterlockedExchange(&g_ext_key_flags.cpsRight, cpsRight);

    // When the Keyboard::feed detour is active it is the ONLY key source
    // (it can also swallow ESC): ignore the external counters entirely so a
    // single K press is not processed twice (keyhook + watcher).
    if (g_KeyHookActive) {
        UpdateCursorVisibility();
        return;
    }

    LONG tToggle = g_ext_key_flags.toggle;
    LONG tEsc    = g_ext_key_flags.esc;
    LONG tEnd    = g_ext_key_flags.end;

    static LONG sLastToggle = -1;
    static LONG sLastEsc    = -1;
    static LONG sLastEnd    = -1;
    if (sLastToggle == -1) { // first frame: remember the baseline, no events yet
        sLastToggle = tToggle;
        sLastEsc    = tEsc;
        sLastEnd    = tEnd;
    }

    LONG dToggle = tToggle - sLastToggle;
    LONG dEsc    = tEsc    - sLastEsc;
    LONG dEnd    = tEnd    - sLastEnd;
    sLastToggle = tToggle;
    sLastEsc    = tEsc;
    sLastEnd    = tEnd;

    // Chat/text screens own the keyboard - drop the watcher events collected
    // while the user was typing instead of toggling the menu.
    if (g_ext_key_flags.chatOpen) {
        UpdateCursorVisibility();
        return;
    }

    bool stateChanged = false;
    for (LONG i = 0; i < dToggle; i++) { // usually exactly one
        g_ShowMenu = !g_ShowMenu;
        g_ext_key_flags.menuOpen = g_ShowMenu ? 1 : 0;
        LOG_INFO("menu: toggle -> visible=%d source=external", g_ShowMenu ? 1 : 0);
        stateChanged = true;
    }
    if (dEsc > 0 && g_ShowMenu) {
        g_ShowMenu = false;
        g_ext_key_flags.menuOpen = 0;
        LOG_INFO("menu: ESC -> visible=0 source=external");
        stateChanged = true;
    }
    if (dEnd > 0 && !g_UnloadRequested) {
        g_UnloadRequested = true;
        LOG_INFO("menu: END -> unload requested source=external");
    }

    if (stateChanged)
        UpdateCursorVisibility();
}

// ======================== Hook: game command queue capture ========================
void __stdcall hkExecCmdLists(ID3D12CommandQueue* queue, UINT count,
                              ID3D12CommandList* const* lists) {
#ifdef _MSC_VER
    __try {
#endif
        static int s_calls = 0;
        if (s_calls < 3) {
            D3D12_COMMAND_QUEUE_DESC qd = queue->GetDesc();
            LOG_INFO("queue exec call #%d: type=%d flags=0x%X count=%u",
                     s_calls + 1, (int)qd.Type, qd.Flags, count);
        }
        s_calls++;

        if (!g_d12Queue) {
            // Capture only the GAME's DIRECT (graphics) queue. The game may
            // also have COPY/COMPUTE queues; drawing on those would fail.
            D3D12_COMMAND_QUEUE_DESC qd = queue->GetDesc();
            if (qd.Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
                InterlockedExchangePointer((PVOID volatile*)&g_d12Queue, queue);
                LOG_INFO("d12: game DIRECT command queue captured: %p ret=%u", queue, count);
            }
        }
        oExecCmdLists(queue, count, lists);
#ifdef _MSC_VER
        g_SehAddr = nullptr;
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("hkExecCmdLists");
    }
#endif
}

// If the game window was never resolved (ImGui_ImplWin32_Init(nullptr) when
// neither the swapchain's OutputWindow nor the window enumeration produced a
// HWND), the Win32 backend's GetClientRect fails every frame and reports a
// 0x0 display size. ImGui then clips every draw call: the overlay "runs"
// (hooks, hotkeys and menu state all keep working) but NOTHING is visible.
// Fall back to the swapchain's dimensions, which are always authoritative.
static void EnsureOverlayDisplaySize(float w, float h) {
    ImGuiIO& io = ImGui::GetIO();
    if (io.DisplaySize.x <= 1.0f || io.DisplaySize.y <= 1.0f)
        io.DisplaySize = ImVec2(w, h);
}

// ======================== D3D12 frame ========================
// Draw the ImGui frame (D3D12 path). Called inside hkPresent. Our command
// list is executed on the GAME's command queue so it is ordered after the
// game's own frame work and before the swapchain Present.
void RenderD3D12Frame(IDXGISwapChain* sc) {
    static int s_r12Frames = 0;
    const bool dbg = (s_r12Frames < 8);

    if (!g_d12Queue || !g_d12CmdList || !g_d12CmdAlloc || !g_d12Fence || !g_d12FenceEvt)
        return;

    // Which back buffer is being presented?
    IDXGISwapChain3* sc3 = nullptr;
    UINT idx = 0;
    if (SUCCEEDED(sc->QueryInterface(IID_PPV_ARGS(&sc3)))) {
        idx = sc3->GetCurrentBackBufferIndex();
        sc3->Release();
    }

    ID3D12Resource* bb = g_d12BB[idx % g_d12FrameCount];
    if (!bb) return;

    // The render hook must never block the game thread waiting for our own
    // previous overlay work. If the GPU is still busy, skip this overlay
    // frame and let the next Present try again; a missed HUD frame is cheaper
    // than introducing a 500 ms hitch into Minecraft.
    if (g_d12Fence->GetCompletedValue() < g_d12FenceVal) {
        if (dbg) LOG_INFO("r12: previous overlay work still in flight - skipping frame");
        return;
    }

    if (FAILED(g_d12CmdAlloc->Reset())) {
        if (dbg) LOG_INFO("r12: command allocator reset failed - skipping frame");
        return;
    }
    if (FAILED(g_d12CmdList->Reset(g_d12CmdAlloc, nullptr))) {
        if (dbg) LOG_INFO("r12: command list reset failed - skipping frame");
        return;
    }

    // PRESENT -> RENDER_TARGET
    D3D12_RESOURCE_BARRIER barrier = {};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = bb;
    barrier.Transition.Subresource = 0;
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    g_d12CmdList->ResourceBarrier(1, &barrier);

    D3D12_CPU_DESCRIPTOR_HANDLE rtv = g_d12RtvCpu;
    rtv.ptr += (SIZE_T)(idx % g_d12FrameCount) * g_d12RtvSize;
    g_d12CmdList->OMSetRenderTargets(1, &rtv, FALSE, nullptr);

    // The ImGui DX12 backend binds the font texture through a root
    // descriptor table, which requires OUR SRV heap to be bound as the
    // current descriptor heap of the command list. Without this the first
    // draw reads from an unbound heap (GPU fault / crash on first frame).
    g_d12CmdList->SetDescriptorHeaps(1, &g_d12SrvHeap);

    // ImGui frame (first call here lazily builds the pipeline state and
    // uploads the font texture - the historically fragile step)
    ImGui_ImplDX12_NewFrame();
    // The stock Win32 backend only supplies display/time and may inspect a
    // different HWND; it must not be the source of mouse state for Bedrock.
    // Poll our own state after it, so our events are the final ones for the
    // frame.
    ImGui_ImplWin32_NewFrame();
    {
        D3D12_RESOURCE_DESC bbDesc = bb->GetDesc();
        EnsureOverlayDisplaySize((float)bbDesc.Width, (float)bbDesc.Height);
    }
    UpdateInputState();
    ImGui::NewFrame();
    ui::Render();
    ImGui::Render();
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12CmdList);

    // RENDER_TARGET -> PRESENT
    barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    g_d12CmdList->ResourceBarrier(1, &barrier);

    g_d12CmdList->Close();

    ID3D12CommandList* lists[] = { g_d12CmdList };
    g_d12Queue->ExecuteCommandLists(1, lists);   // game queue: ordered with game work

    const UINT64 nextFence = g_d12FenceVal + 1;
    if (FAILED(g_d12Queue->Signal(g_d12Fence, nextFence))) {
        if (dbg) LOG_INFO("r12: fence signal failed - disabling overlay frame");
        return;
    }
    g_d12FenceVal = nextFence;

    if (s_r12Frames < 8) s_r12Frames++;
}

// ======================== Init via D3D12 ========================
// We must draw on the game's own queue. It is captured by hkExecCmdLists
// before the first Present of each frame, so by the time hkPresent runs
// during the first frame it is normally already set.
bool InitD3D12(IDXGISwapChain* sc) {
    // Install the ExecuteCommandLists queue hook the first time we run (the
    // game is already rendering by now - safe to create our own D3D12 device
    // and patch the shared vtable). The DIRECT queue itself is only captured
    // from the NEXT frame's ExecCmdLists, hence the retry below on the first
    // Present.
    HookCommandQueueVTable();

    if (!g_d12Queue) {
        LOG_INFO("d12: game command queue not captured yet - will retry");
        return false; // retried next Present, nothing allocated yet
    }

    g_InitTouched = true;

    ID3D12Device* dev = nullptr;
    HRESULT hr = sc->GetDevice(IID_PPV_ARGS(&dev));
    if (FAILED(hr) || !dev) {
        LOG_ERROR("d12: GetDevice failed hr=%08X", hr);
        return false;
    }
    LOG_INFO("d12: device extracted: %p", dev);

    DXGI_SWAP_CHAIN_DESC dsc{};
    if (FAILED(sc->GetDesc(&dsc))) {
        LOG_ERROR("d12: GetDesc failed");
        dev->Release();
        return false;
    }
    UINT fc = dsc.BufferCount ? dsc.BufferCount : 2;
    if (fc < 1) fc = 1;
    if (fc > 4) fc = 4;
    g_d12FrameCount = fc;
    LOG_INFO("d12: swapchain %ux%u buffers=%u fmt=%d hwnd=%p",
             dsc.BufferDesc.Width, dsc.BufferDesc.Height, fc,
             (int)dsc.BufferDesc.Format, dsc.OutputWindow);

    // The swapchain's OutputWindow IS the real game window (the one the
    // game renders into). Capture it here on the first Present - the window
    // may not have existed yet when the injector thread enumerated windows
    // (splash/loading), which left g_hwnd=null and input in screen coords.
    if (dsc.OutputWindow && !g_hwnd) {
        g_hwnd = dsc.OutputWindow;
        LOG_INFO("d12: game window captured from swapchain: %p", g_hwnd);
    }

    g_d12Device = dev; // keep the reference from GetDevice

    // Our own DIRECT queue, used ONLY for ImGui's internal GPU uploads.
    // imgui_impl_dx12.cpp:433-439 submits the font-texture upload to
    // InitInfo.CommandQueue and then blocks on WaitForSingleObject(event,
    // INFINITE). On the GAME's queue that wait sits inside hkPresent and depends
    // on the game's GPU work draining - a stuck frame there freezes the game
    // (and, with the input masks on, the whole desktop). A private queue makes
    // the wait depend only on our own upload.
    {
        D3D12_COMMAND_QUEUE_DESC oqd{};
        oqd.Type  = D3D12_COMMAND_LIST_TYPE_DIRECT;
        oqd.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
        if (FAILED(dev->CreateCommandQueue(&oqd, IID_PPV_ARGS(&g_d12OwnQueue)))) {
            g_d12OwnQueue = nullptr;
            LOG_ERROR("d12: private upload queue FAILED - falling back to the game queue");
        }
    }

    // RTV descriptor heap for the back buffers
    D3D12_DESCRIPTOR_HEAP_DESC hd{};
    hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    hd.NumDescriptors = fc;
    if (FAILED(dev->CreateDescriptorHeap(&hd, IID_PPV_ARGS(&g_d12RtvHeap)))) {
        LOG_ERROR("d12: RTV heap FAILED");
        D3D12Cleanup();
        return false;
    }
    g_d12RtvSize = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12CreateRTVs(sc);
    LOG_INFO("d12: RTV heap + back-buffer views ok");

    if (FAILED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                           IID_PPV_ARGS(&g_d12CmdAlloc)))) {
        LOG_ERROR("d12: command allocator FAILED");
        D3D12Cleanup();
        return false;
    }
    if (FAILED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_d12CmdAlloc,
                                      nullptr, IID_PPV_ARGS(&g_d12CmdList)))) {
        LOG_ERROR("d12: command list FAILED");
        D3D12Cleanup();
        return false;
    }
    g_d12CmdList->Close();
    LOG_INFO("d12: command list ok");

    if (FAILED(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&g_d12Fence)))) {
        LOG_ERROR("d12: fence FAILED");
        D3D12Cleanup();
        return false;
    }
    g_d12FenceEvt = CreateEvent(nullptr, FALSE, FALSE, nullptr);
    if (!g_d12FenceEvt) {
        LOG_ERROR("d12: fence event FAILED");
        D3D12Cleanup();
        return false;
    }
    LOG_INFO("d12: fence ok");

    // SRV descriptor heap (CBV_SRV_UAV + SHADER_VISIBLE) -- ImGui's font
    // texture lives here. This must be a DIFFERENT heap from the RTV heap.
    D3D12_DESCRIPTOR_HEAP_DESC sd{};
    sd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    sd.NumDescriptors = 1;
    sd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if (FAILED(dev->CreateDescriptorHeap(&sd, IID_PPV_ARGS(&g_d12SrvHeap)))) {
        LOG_ERROR("d12: SRV heap FAILED");
        D3D12Cleanup();
        return false;
    }
    LOG_INFO("d12: SRV (shader-visible) heap ok");

    // ImGui context + theme (shared by both paths)
    if (!g_ImGuiCtx) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        g_ImGuiCtx = true;
        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        // Leave cursor management enabled in the Win32 backend. It will
        // hide the OS cursor while MouseDrawCursor=true and restore the
        // normal game cursor when the menu is closed.
        ui::ApplyStyle();
        modules::RegisterAllModules();
    }
    HWND hwnd = dsc.OutputWindow ? dsc.OutputWindow : (g_hwnd ? g_hwnd : GetActiveWindow());
    if (!hwnd)
        LOG_ERROR("d12: game window NOT resolved at ImGui init - display size will fall back to the swapchain");
    if (!g_Win32BackendInit) {
        ImGui_ImplWin32_Init(hwnd);
        g_Win32BackendInit = true;
    }
    D3D12_CPU_DESCRIPTOR_HANDLE cpu = g_d12SrvHeap->GetCPUDescriptorHandleForHeapStart();
    D3D12_GPU_DESCRIPTOR_HANDLE gpu = g_d12SrvHeap->GetGPUDescriptorHandleForHeapStart();
    DXGI_FORMAT fmt = dsc.BufferDesc.Format == DXGI_FORMAT_UNKNOWN
                          ? DXGI_FORMAT_R8G8B8A8_UNORM
                          : dsc.BufferDesc.Format;

    // IMPORTANT (imgui 1.91.5+): the legacy 6-arg ImGui_ImplDX12_Init() no
    // longer receives the command queue, but the backend reads
    // InitInfo.CommandQueue when it lazily uploads the font texture on the
    // first frame (ImGui_ImplDX12_CreateFontsTexture). Leaving it NULL makes
    // it call ExecuteCommandLists() through a null pointer -> AV 0xC0000005
    // on the very first rendered frame. Use the InitInfo-based API and pass
    // the (game) command queue.
    ImGui_ImplDX12_InitInfo info{};
    info.Device = g_d12Device;
    info.NumFramesInFlight = (int)fc;
    info.RTVFormat = fmt;
    info.SrvDescriptorHeap = g_d12SrvHeap;
    // Our private queue, NOT the game one - see the comment above. The upload
    // is fenced by the backend itself, so the resource is safe to sample on
    // the game's queue afterwards.
    info.CommandQueue = g_d12OwnQueue ? g_d12OwnQueue : g_d12Queue;
    info.LegacySingleSrvCpuDescriptor = cpu;
    info.LegacySingleSrvGpuDescriptor = gpu;
    if (!ImGui_ImplDX12_Init(&info)) {
        LOG_ERROR("d12: ImGui_ImplDX12_Init FAILED");
        D3D12Cleanup();
        return false;
    }
    g_Dx12BackendInit = true;
    LOG_INFO("d12: ImGui backends ok");

    // Eagerly create the ImGui pipeline state AND upload the font texture.
    // The backend normally does this lazily on the very first drawn frame;
    // doing it here (still inside the SEH-protected init path) moves the
    // fragile step out of the frame loop, so a failure here disables the
    // overlay instead of crashing a rendered frame.
    ImGui_ImplDX12_NewFrame();
    LOG_INFO("d12: ImGui device objects (pso+font) created");

    g_RenderD3D12 = true;
    g_Init = true;
    LOG_INFO("ImGui initialized via D3D12 (sc=%p, queue=%p, hwnd=%p, frames=%u)",
             sc, g_d12Queue, hwnd, fc);
    return true;
}

// ======================== Full overlay shutdown ========================
// Internal implementation (anonymous namespace). The public
// overlay::OverlayShutdown() below is just a wrapper.
void ShutdownImpl() {
    LOG_INFO("OverlayShutdown begin");

    if (g_d12Fence && g_d12FenceEvt) {
        if (g_d12Fence->GetCompletedValue() < g_d12FenceVal) {
            g_d12Fence->SetEventOnCompletion(g_d12FenceVal, g_d12FenceEvt);
            // BOUNDED on purpose: this runs on the game's render thread (from
            // hkResizeBuffers). An INFINITE wait here turns any stuck GPU or
            // a lost device into a permanent game freeze - and with the
            // external input masks installed, into a locked-out desktop.
            if (WaitForSingleObject(g_d12FenceEvt, 1000) != WAIT_OBJECT_0)
                LOG_ERROR("OverlayShutdown: GPU fence not reached in 1000 ms - releasing objects anyway (device may be lost/hung)");
        }
    }

    if (g_Dx12BackendInit)  { ImGui_ImplDX12_Shutdown();  g_Dx12BackendInit  = false; }
    if (g_Dx11BackendInit)  { ImGui_ImplDX11_Shutdown();  g_Dx11BackendInit  = false; }
    if (g_Win32BackendInit) { ImGui_ImplWin32_Shutdown(); g_Win32BackendInit = false; }
    if (g_ImGuiCtx)         { ImGui::DestroyContext();    g_ImGuiCtx         = false; }

    D3D12Cleanup();
    CleanupRT11();
    if (g_Context) { g_Context->Release(); g_Context = nullptr; }
    if (g_Device)  { g_Device->Release();  g_Device  = nullptr; }

    g_RenderD3D12  = false;
    g_Init         = false;
    g_InitTouched  = false;
    g_InitBlocked  = false;
    InterlockedExchange(&g_RenderAborted, 0);
    LOG_INFO("OverlayShutdown done");
}

// Restore the WndProc we replaced (if still installed).
void RestoreWndProc() {
    if (g_origWnd && g_hwnd && IsWindow(g_hwnd)) {
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_origWnd);
        g_origWnd = nullptr;
    }
}

// Restore the vtable slots we patched (Present, ResizeBuffers, ExecCmdLists).
// Called only on a deliberate unload (END) or process detach.
void RestoreHooks() {
    if (g_hookedSwapVtable) {
        if (oPresent)       g_hookedSwapVtable[PRESENT_INDEX]       = (void*)oPresent;
        if (oResizeBuffers) g_hookedSwapVtable[RESIZEBUFFERS_INDEX] = (void*)oResizeBuffers;
        g_hookedSwapVtable = nullptr;
    }
    if (g_hookedQueueVtable) {
        if (oExecCmdLists)  g_hookedQueueVtable[EXEC_CMD_LISTS_INDEX] = (void*)oExecCmdLists;
        g_hookedQueueVtable = nullptr;
    }
    oPresent = nullptr;
    oResizeBuffers = nullptr;
    oExecCmdLists = nullptr;
    LOG_INFO("hooks restored to originals");
}

// Called from hkPresent after the current frame is done: tear the overlay
// down and restore everything. Subsequent game presents call the original.
void FinishUnload() {
    if (g_Unloaded) return;
    ShutdownImpl();
    RestoreWndProc();
    RestoreHooks();
    g_Unloaded = true;
    g_ShowMenu = false;
    SetCursorVisible(false);
    LOG_INFO("overlay unloaded (hooks restored; DLL stays mapped for stability)");
}

// ======================== WndProc ========================
// NOTE: the WndProc is deliberately NOT installed on the game window.
// Replacing the WndProc of a UWP/CoreWindow root can crash the process on
// the first message (input is handled manually via GetCursorPos /
// GetAsyncKeyState, so the Win32 backend's message handler is not needed).
// This stub is kept SEH-guarded only as a safety net in case someone
// re-enables the hook later.
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
#ifdef _MSC_VER
    __try {
#endif
        if (g_Init && ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;
        return CallWindowProcW(g_origWnd, hWnd, msg, wParam, lParam);
#ifdef _MSC_VER
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("WndProc");
        if (g_origWnd)
            return CallWindowProcW(g_origWnd, hWnd, msg, wParam, lParam);
        return DefWindowProcW(hWnd, msg, wParam, lParam);
    }
#endif
}

// Deliberately a NO-OP: we must NOT replace the game window's WndProc (see
// the note above). Input is done by manual polling in UpdateInputState().
void InstallWndProcHook() {
    // Intentionally does nothing.
}

// ======================== Hooked Present ========================
HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        static bool traced        = false;
        static bool abortedLogged = false;
        static int  failedAttempts = 0;

        // Liveness stamp: the watchdog thread and (through the shared block)
        // the injector watcher use it to notice a render thread that stopped
        // ticking. MUST be the first thing this hook does.
        InterlockedExchange(&g_lastFrameMs, (LONG)GetTickCount());
        InterlockedIncrement(&g_ext_key_flags.frameTick);

        if (!g_Init && !g_ShuttingDown && !g_Unloaded) {
            // --- try D3D11 first ---
            HRESULT hr11 = sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_Device);
            if (SUCCEEDED(hr11) && g_Device) {
                g_Device->GetImmediateContext(&g_Context);
                g_SwapChain = sc;
                if (g_Context && CreateRT11()) {
                    if (!g_ImGuiCtx) {
                        IMGUI_CHECKVERSION();
                        ImGui::CreateContext();
                        g_ImGuiCtx = true;
                        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
                        // Cursor visibility is controlled explicitly by
                        // UpdateCursorVisibility on every frame.
                        ui::ApplyStyle();
                        modules::RegisterAllModules();
                    }
                    // Capture the real game window from the swapchain BEFORE
                    // initializing the Win32 backend (it needs the HWND).
                    DXGI_SWAP_CHAIN_DESC dsc{};
                    if (SUCCEEDED(sc->GetDesc(&dsc))) {
                        if (dsc.OutputWindow && !g_hwnd) {
                            g_hwnd = dsc.OutputWindow;
                            LOG_INFO("d11: game window captured from swapchain: %p", g_hwnd);
                        }
                        LOG_INFO("swapchain: %ux%u format=%d swapfx=%d",
                                 dsc.BufferDesc.Width, dsc.BufferDesc.Height,
                                 (int)dsc.BufferDesc.Format, (int)dsc.SwapEffect);
                    }
                    HWND hwnd = g_hwnd ? g_hwnd : GetActiveWindow();
                    if (!g_Win32BackendInit) { ImGui_ImplWin32_Init(hwnd); g_Win32BackendInit = true; }
                    if (!g_Dx11BackendInit)  { ImGui_ImplDX11_Init(g_Device, g_Context); g_Dx11BackendInit = true; }
                    g_RenderD3D12 = false;
                    g_Init = true;
                    if (!g_hwnd) g_hwnd = hwnd;
                    LOG_INFO("ImGui initialized via D3D11 (sc=%p, hwnd=%p)", sc, hwnd);
                } else {
                    LOG_ERROR("hkPresent: D3D11 device ok but ctx/rt failed");
                    CleanupRT11();
                    if (g_Context) { g_Context->Release(); g_Context = nullptr; }
                    if (g_Device)  { g_Device->Release();  g_Device  = nullptr; }
                }
            } else {
                // --- D3D12 swapchain: init over the game's own queue ---
                if (!g_InitBlocked) {
                    if (InitD3D12(sc)) {
                        LOG_INFO("hkPresent: D3D12 mode engaged");
                    } else if (g_InitTouched) {
                        g_InitBlocked = true;
                        LOG_ERROR("hkPresent: D3D12 init failed, permanently disabled (hr11=%08X)", hr11);
                    }
                    // else: nothing allocated (queue not captured yet) -> retry next Present
                }
                failedAttempts++;
                if (failedAttempts == 1 || failedAttempts % 240 == 0)
                    LOG_INFO("hkPresent: D3D11 path hr=%08X (attempt %d)", hr11, failedAttempts);
            }
        }

        if (g_Init) {
            if (!traced) { LOG_INFO("hkPresent: rendering started"); traced = true; }

            // Install the Keyboard::feed detour once, after the game is fully
            // rendering. When the signature matches the installed game version
            // this is the primary (Solstice-style) key source; otherwise the
            // frame polling fallback stays active.
            TryInstallKeyboardHook();
            // Packet/Flarial mouse dispatcher: this is the cancellation point
            // that prevents click-through and camera rotation while the GUI is
            // open. The raw-input fallback is only used when this signature is
            // unavailable.
            TryInstallMouseHook();
            TryInstallGuiDataHook();
            TryInstallScreenSizeHook();
            TryInstallGammaHook();
            TryInstallPerspectiveHook();
            TryInstallFreelookCameraHook();
            TryInstallFlarialHooks();
            TryInstallPingHook();
            ApplyGameGuiScale();

            // Install the raw-input block once: while the GUI is open the game
            // must receive NO raw mouse/keyboard input (camera can't turn,
            // no click-through). Stable user32 API - version independent.
            TryInstallRawInputBlock();

            UpdateHotkeys();

            if (g_RenderAborted) {
                if (!abortedLogged) { abortedLogged = true; LOG_ERROR("hkPresent: rendering permanently disabled after exception"); }
            } else {
                // Serialize everything that records D3D12 commands or touches
                // the ImGui context: neither is thread-safe, and
                // hkResizeBuffers tears the objects down from whatever thread
                // the game resizes on. Also blocks re-entrancy (our own
                // ExecuteCommandLists goes through the hooked vtable).
                EnterCriticalSection(&g_RenderCs);
                if (InterlockedExchange(&g_inRender, 1) == 0) {
                    g_activePhase = g_RenderD3D12 ? "render_d3d12" : "render_d3d11";
                    if (g_RenderD3D12) {
                        RenderD3D12Frame(sc);
                    } else {
                        ImGui_ImplDX11_NewFrame();
                        ImGui_ImplWin32_NewFrame();
                        {
                            DXGI_SWAP_CHAIN_DESC sd{};
                            if (SUCCEEDED(sc->GetDesc(&sd)))
                                EnsureOverlayDisplaySize((float)sd.BufferDesc.Width,
                                                         (float)sd.BufferDesc.Height);
                        }
                        UpdateInputState();
                        ImGui::NewFrame();
                        ui::Render();
                        ImGui::Render();
                        g_Context->OMSetRenderTargets(1, &g_RTV, nullptr);
                        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
                    }
                    g_activePhase = nullptr;
                    InterlockedExchange(&g_inRender, 0);
                }
                LeaveCriticalSection(&g_RenderCs);
            }

            // Clean unload request (END): restore everything after this frame.
            if (g_UnloadRequested)
                FinishUnload();
        }
#ifdef _MSC_VER
        g_SehAddr = nullptr;
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("hkPresent");
        if (!g_Init) {
            g_InitBlocked = true;
            g_InitTouched = true;
            LOG_ERROR("hkPresent: init blocked after exception");
        } else {
            InterlockedExchange(&g_RenderAborted, 1);
            LOG_ERROR("hkPresent: rendering disabled after exception");
        }
    }
#endif
    // VSync Disabler is deliberately implemented at the final Present call,
    // after all overlay work has completed. This avoids touching swapchain
    // state and simply requests an immediate present for the game frame.
    bool disableVsync = false;
    for (const auto& mod : modules::Modules().modules()) {
        if (mod && std::strcmp(mod->name(), "VSync Disabler") == 0) {
            disableVsync = mod->enabled();
            break;
        }
    }
    return oPresent(sc, disableVsync ? 0u : sync, flags);
}

// ======================== Hooked ResizeBuffers ========================
// Full teardown on resize (proven MCBE DX12 base): re-init on next Present.
HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* sc, UINT bd, UINT w, UINT h,
                                  DXGI_FORMAT fmt, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        if (g_Init) {
            // Resize can be driven from a different thread than the one that
            // is recording a frame in hkPresent. Take the same lock so the
            // teardown cannot pull the D3D12 objects out from under an
            // in-flight RenderD3D12Frame() (a classic DX12 crash/hang).
            EnterCriticalSection(&g_RenderCs);
            ShutdownImpl();
            LeaveCriticalSection(&g_RenderCs);
            LOG_INFO("hkResizeBuffers: overlay torn down, will re-init on next Present");
        }
#ifdef _MSC_VER
        g_SehAddr = nullptr;
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("hkResizeBuffers pre-step");
    }
#endif
    return oResizeBuffers(sc, bd, w, h, fmt, flags);
}

// ======================== VTable hook ========================
void HookVTable(void** vtable, int index, void* hook, void** original) {
    DWORD oldProtect;
    *original = vtable[index];
    VirtualProtect(&vtable[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtect);
    vtable[index] = hook;
    VirtualProtect(&vtable[index], sizeof(void*), oldProtect, &oldProtect);
}

// ======================== Dummy swapchain for vtable ========================
// Minecraft (UWP) runs in AppContainer: creating a swapchain on the desktop
// window is forbidden (E_ACCESSDENIED). Create it on a candidate window of
// THE GAME itself (or on a fallback hidden window we create in-process).
// Several creation paths are tried because the window state (fullscreen,
// loading, flip vs discard) changes which one is accepted.
bool TryCreateDummySwapChain(HWND window,
                             IDXGISwapChain** outSC,
                             ID3D11Device** outDev,
                             ID3D11DeviceContext** outCtx) {
    if (!window) return false;

    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 1;
    sd.BufferDesc.Width = 2;
    sd.BufferDesc.Height = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = window;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL fl;
    HRESULT hr;

    // Path A: one-shot device + swapchain (hardware)
    hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        nullptr, 0, D3D11_SDK_VERSION,
        &sd, outSC, outDev, &fl, outCtx);
    if (SUCCEEDED(hr)) return true;
    LOG_INFO("dummy path A (CreateDeviceAndSwapChain): hr=%08X", hr);

    // Device alone (hardware, then WARP)
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
                           D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                           nullptr, 0, D3D11_SDK_VERSION, &dev, &fl, &ctx);
    if (FAILED(hr)) {
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr,
                               D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                               nullptr, 0, D3D11_SDK_VERSION, &dev, &fl, &ctx);
        LOG_INFO("dummy device (warp): hr=%08X", hr);
    }
    if (FAILED(hr)) return false;

    IDXGIDevice* dxgiDev = nullptr;
    IDXGIAdapter* adapter = nullptr;
    IDXGISwapChain* sc = nullptr;
    hr = E_FAIL;

    // Path B: IDXGIFactory2::CreateSwapChainForHwnd (flip model, UWP-friendly)
    if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDev))) {
        if (SUCCEEDED(dxgiDev->GetAdapter(&adapter))) {
            IDXGIFactory2* factory2 = nullptr;
            if (SUCCEEDED(adapter->GetParent(__uuidof(IDXGIFactory2), (void**)&factory2))) {
                DXGI_SWAP_CHAIN_DESC1 sd1 = {};
                sd1.Width = 2;
                sd1.Height = 2;
                sd1.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                sd1.SampleDesc.Count = 1;
                sd1.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
                sd1.BufferCount = 2;
                sd1.Scaling = DXGI_SCALING_STRETCH;
                sd1.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
                sd1.AlphaMode = DXGI_ALPHA_MODE_IGNORE;
                IDXGISwapChain1* sc1 = nullptr;
                hr = factory2->CreateSwapChainForHwnd(dev, window, &sd1, nullptr, nullptr, &sc1);
                LOG_INFO("dummy path B (CreateSwapChainForHwnd flip): hr=%08X", hr);
                if (SUCCEEDED(hr) && sc1) {
                    factory2->Release();
                    adapter->Release();
                    dxgiDev->Release();
                    *outSC = sc1;
                    *outDev = dev;
                    *outCtx = ctx;
                    return true;
                }
                factory2->Release();
            }
        }
    }

    // Path C: legacy IDXGIFactory::CreateSwapChain
    if (dxgiDev) {
        if (adapter) {
            IDXGIFactory* factory = nullptr;
            if (SUCCEEDED(adapter->GetParent(__uuidof(IDXGIFactory), (void**)&factory))) {
                hr = factory->CreateSwapChain(dev, &sd, &sc);
                LOG_INFO("dummy path C (legacy CreateSwapChain): hr=%08X", hr);
                factory->Release();
            }
        }
    }

    if (SUCCEEDED(hr) && sc) {
        *outSC = sc;
        *outDev = dev;
        *outCtx = ctx;
        if (adapter) adapter->Release();
        if (dxgiDev) dxgiDev->Release();
        return true;
    }

    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (adapter) adapter->Release();
    if (dxgiDev) dxgiDev->Release();
    return false;
}

// Last-resort candidate window: our own hidden top-level window. It is not
// the desktop (which AppContainer denies), so DXGI usually accepts it, and
// the swapchain vtable is process-global anyway.
HWND CreateFallbackWindow() {
    HWND w = CreateWindowExW(0, L"STATIC", L"dummy_hook_window", WS_POPUP,
                             0, 0, 2, 2, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    if (w) LOG_INFO("fallback hidden window created: %p", w);
    return w;
}

// ======================== Dummy D3D12 device: hook ExecuteCommandLists ========================
// All ID3D12CommandQueue objects in the process share the same vtable, so
// patching the dummy queue's ExecuteCommandLists also patches the game queue.
// Installed lazily from InitD3D12 (on the first Present) - creating our own
// D3D12 device/queue and patching the shared D3D12 vtable while the game is
// still initializing D3D12 crashes the game before the first frame (observed
// hard crash right after "ExecuteCommandLists hook installed" when called
// from MainThread at startup).
void HookCommandQueueVTable() {
    static bool s_installed = false;
    if (s_installed) return;
#ifdef _MSC_VER
    __try {
#endif
        ID3D12Device* tmpDev = nullptr;
        HRESULT hr = D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&tmpDev));
        if (FAILED(hr)) {
            LOG_ERROR("dummy D3D12 device FAILED hr=%08X (DX12 overlay unavailable)", hr);
            return;
        }
        D3D12_COMMAND_QUEUE_DESC qd{};
        qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        qd.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
        ID3D12CommandQueue* tmpQ = nullptr;
        if (FAILED(tmpDev->CreateCommandQueue(&qd, IID_PPV_ARGS(&tmpQ)))) {
            LOG_ERROR("dummy D3D12 queue FAILED");
            tmpDev->Release();
            return;
        }
        void** vt = *(void***)tmpQ;
        g_hookedQueueVtable = vt;
        HookVTable(vt, EXEC_CMD_LISTS_INDEX, (void*)hkExecCmdLists, (void**)&oExecCmdLists);
        LOG_INFO("ExecuteCommandLists hook installed: oExec=%p", oExecCmdLists);
        tmpQ->Release();
        tmpDev->Release();
        s_installed = (oExecCmdLists != nullptr);
#ifdef _MSC_VER
        g_SehAddr = nullptr;
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("HookCommandQueueVTable");
    }
#endif
}

// ======================== Present watchdog ========================
// Sometimes the game does NOT present through the swapchain vtable we patched
// (the game may have created its real swapchain/device AFTER our early dummy,
// or be stuck on a loading screen that never presents, or the app restarted).
// These symptoms all look identical in the log: everything up to
// "MainThread done" appears, then NOTHING (no "ExecuteCommandLists hook
// installed", no "hkPresent", no "rendering started"). The watchdog watches
// for exactly that and, once, attempts a RE-HOOK on the current foreground
// window (undo the dead patch, create a fresh dummy, re-patch). Separately it
// retries the game-version log (module fully initialized by then).

// One-time re-hook attempt. Safe to call once; guarded by g_RehookTried.
void RehookPresentOnce() {
    if (g_RehookTried) return;
    g_RehookTried = true;
    if (g_Init || g_Unloaded || g_ShuttingDown) return; // nothing to do

    RestoreHooks(); // undo the (apparently dead) first patch if any
    LOG_INFO("diag: hkPresent never fired - retrying swapchain hook...");

    HWND target = GetForegroundWindow();
    DWORD fpid = 0;
    if (target) GetWindowThreadProcessId(target, &fpid);
    if (fpid != GetCurrentProcessId() || !target) {
        std::vector<HWND> wins = CollectGameWindows();
        if (wins.empty()) {
            LOG_INFO("diag: re-hook: no game window available");
            return;
        }
        target = wins[0];
    }
    if (!target) {
        LOG_INFO("diag: re-hook: no target window");
        return;
    }

    IDXGISwapChain* sc = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    if (!TryCreateDummySwapChain(target, &sc, &dev, &ctx)) {
        LOG_INFO("diag: re-hook: dummy swapchain failed on hwnd=%p", target);
        return;
    }
    void** vt = *(void***)sc;
    g_hookedSwapVtable = vt;
    HookVTable(vt, PRESENT_INDEX, (void*)hkPresent, (void**)&oPresent);
    HookVTable(vt, RESIZEBUFFERS_INDEX, (void*)hkResizeBuffers, (void**)&oResizeBuffers);
    ctx->Release();
    dev->Release();
    sc->Release();
    LOG_INFO("diag: re-hook installed on hwnd=%p oPresent=%p", target, oPresent);
}

void WatchdogImpl() {
    DWORD t0 = GetTickCount();
    LOG_INFO("diag: present watchdog armed (logs if hkPresent does not fire)");
    bool rehooked = false;
    DWORD nextLog = 5000;
    for (;;) {
        if (g_SharedAbort || g_ShuttingDown || g_Unloaded) return;
        if (g_Init) return; // rendering started - all good
        DWORD el = GetTickCount() - t0;

        if (el >= 8000 && !rehooked) {
            // Game is not presenting through the patched vtable. Undo the
            // first patch and re-hook on the current game window - one
            // attempt, so a late-created swapchain gets hooked.
            rehooked = true;
            LOG_INFO("diag: still no hkPresent after 8 s - retrying swapchain hook");
            RehookPresentOnce();
        } else if (el >= nextLog && el < 8000) {
            LOG_INFO("diag: hkPresent not observed after %lu s", el / 1000);
            nextLog += 5000;
        } else if (rehooked && el >= nextLog && el < 90000) {
            // Keep watching after the re-hook: the game may still be loading
            // (the present loop starts late on some machines).
            LOG_INFO("diag: still waiting for the game present loop (%lu s)", el / 1000);
            nextLog += 10000;
        }
        Sleep(250);
    }
}

DWORD WINAPI WatchdogThread(LPVOID) {
#ifdef _MSC_VER
    __try {
#endif
        WatchdogImpl();
#ifdef _MSC_VER
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("watchdog");
    }
#endif
    return 0;
}

// ======================== Overlay watchdog (input-mask safety net) ========
// The external watcher (injector.exe) installs GLOBAL WH_KEYBOARD_LL /
// WH_MOUSE_LL masks and removes them only when it observes menuOpen == 0 in
// the shared block. Until now that value was published by hkPresent, i.e. by
// the game's RENDER thread. When that thread hangs (a module bug, the old
// while(ShowCursor(TRUE) < 0) spin, a stuck GPU fence) menuOpen is frozen at 1
// and the entire desktop stays masked: keyboard dead except the Windows key,
// mouse frozen, hard reset required. That is precisely the failure in
// overlay_dll.log / overlay_watcher.log of the frozen run.
//
// This thread removes that single point of failure. It never renders, never
// touches D3D or ImGui, and therefore keeps running even when the render
// thread is wedged:
//   * it publishes menuOpen / keyhookOn / heartbeat from its own loop, so the
//     masks no longer depend on the render thread's liveness;
//   * it force-closes the menu when no frame has been seen for
//     kFrameTimeoutMs - menuOpen then goes to 0 and the watcher removes the
//     masks on its own (the injector also drops them on a stale heartbeat);
//   * it logs the phase/module the render thread was stuck in, so the culprit
//     is named in the log instead of "it just froze".
static const DWORD kFrameTimeoutMs = 2000;

DWORD WINAPI OverlayWatchdogThread(LPVOID) {
#ifdef _MSC_VER
    __try {
#endif
        while (!g_watchdogStop && !g_ShuttingDown) {
            const DWORD now   = GetTickCount();
            const DWORD last  = (DWORD)g_lastFrameMs;
            const DWORD since = now - last;   // unsigned: wrap-safe

            if (g_ShowMenu && last != 0 && since > kFrameTimeoutMs) {
                LOG_ERROR("watchdog: no frame for %lu ms while the menu was open "
                          "(phase=%s module=%s) - force closing the menu so the "
                          "global input masks are released",
                          (unsigned long)since,
                          g_activePhase      ? g_activePhase      : "?",
                          g_activeModuleName ? g_activeModuleName : "-");
                g_ext_key_flags.stuckCode = 1;
                g_ShowMenu = false;           // -> menuOpen=0 -> masks off
            }

            // Publish state that rendering cannot block. hkPresent publishes
            // the same values every frame; both derive from g_ShowMenu, so
            // they can never disagree.
            g_ext_key_flags.menuOpen  = g_ShowMenu ? 1 : 0;
            g_ext_key_flags.keyhookOn = g_KeyHookActive ? 1 : 0;
            InterlockedIncrement(&g_ext_key_flags.heartbeat);
            Sleep(100);
        }
#ifdef _MSC_VER
        g_SehAddr = nullptr;
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("OverlayWatchdogThread");
    }
#endif
    // Leaving for good: make sure nothing can hold the masks open.
    g_ext_key_flags.menuOpen = 0;
    return 0;
}

} // namespace (anonymous)

// ==================== Monitoring HUD support ================================
// Everything below sits in overlay:: scope; the anonymous namespace above
// provides the signature scanner and the local-player resolver.

static void* g_baseTickOriginal = nullptr;
static bool  g_baseTickTried = false;

// Actor::baseTick fires for every actor on every game tick (20/s); counting
// only the LOCAL player's ticks gives the client tick rate (Flarial "TPS").
// Every actor also updates the id->actor registry used for crosshair aim.
static struct {
    unsigned      id;
    void*         actor;
    unsigned long ms;
} s_actorMap[256] = {};

static __int64 __fastcall hkActorBaseTick(void* actor, void* state) {
    const __int64 r = g_baseTickOriginal
        ? ((__int64(__fastcall*)(void*, void*))g_baseTickOriginal)(actor, state)
        : 0;
    if (actor) {
        const unsigned long now = GetTickCount();

        // registry: actor pointers (aim resolution + Target HUD + Hitboxes).
        // Keyed by the pointer itself - no dependence on the EntityContext id.
        __try {
            auto& e = s_actorMap[((uintptr_t)actor / 8) % 256];
            e.id = 1;
            e.actor = actor;
            e.ms = now;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}

        static void* s_lp = nullptr;
        static unsigned long s_lpNextMs = 0;
        if (!s_lp || now - s_lpNextMs >= 1000) {
            s_lpNextMs = now;
            void* lp = nullptr;
            CritLocalPlayerPtr(&lp);
            s_lp = lp;
        }
        if (s_lp && actor == s_lp)
            InterlockedExchangeAdd(&overlay::g_monitorTickCounter, 1);
    }
    return r;
}

// Resolve an entt id to a recently-ticked actor pointer.
static void* ResolveActorById(unsigned key) {
    if (!key) return nullptr;
    const auto& e = s_actorMap[key % 256];
    if (e.id != key) return nullptr;
    if (GetTickCount() - e.ms > 600) return nullptr;
    return e.actor;
}

// The entity under the crosshair: project every recently-ticked actor's
// upper-body point through the cached view matrix and pick the one closest
// to the screen center within a depth-scaled radius. The LOCAL PLAYER is
// excluded - it projects exactly onto the screen center (it is the camera)
// and would otherwise shadow every real target.
void* GetCrosshairEntity() {
    if (!s_critViewValid) return nullptr;
    ImGuiIO& io = ImGui::GetIO();
    const float cx = io.DisplaySize.x * 0.5f;
    const float cy = io.DisplaySize.y * 0.5f;
    if (cx < 2.0f) return nullptr;

    static void* s_local = nullptr;
    static unsigned long s_localNextMs = 0;
    const unsigned long nowMs = GetTickCount();
    if (!s_local || nowMs - s_localNextMs >= 1000) {
        s_localNextMs = nowMs;
        CritLocalPlayerPtr(&s_local);
    }

    void* best = nullptr;
    float bestD = 1e9f;
    const unsigned long now = GetTickCount();
    for (auto& e : s_actorMap) {
        if (!e.actor || !e.id || now - e.ms > 500) continue;
        if (e.actor == s_local) continue;   // the camera itself - never a target
        float pos[3], vel[3];
        if (!game::ActorReadStateVector(e.actor, pos, vel)) continue;
        const float p[3] = { pos[0], pos[1] + 1.0f, pos[2] };   // upper body
        float sx, sy, depth;
        if (!ProjectWorldToScreen(p, &sx, &sy, &depth)) continue;
        if (depth < 0.8f || depth > 64.0f) continue;
        const float dx = sx - cx, dy = sy - cy;
        const float dist = sqrtf(dx * dx + dy * dy);
        float radius = 250.0f / depth;
        if (radius < 22.0f) radius = 22.0f;
        if (radius > 140.0f) radius = 140.0f;
        if (dist < radius && dist < bestD) {
            bestD = dist;
            best = e.actor;
        }
    }
    return best;
}

int GetActors(void** out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    static void* s_local = nullptr;
    static unsigned long s_localNextMs = 0;
    const unsigned long nowMs = GetTickCount();
    if (!s_local || nowMs - s_localNextMs >= 1000) {
        s_localNextMs = nowMs;
        CritLocalPlayerPtr(&s_local);
    }
    const unsigned long now = GetTickCount();
    int n = 0;
    for (auto& e : s_actorMap) {
        if (!e.actor || !e.id || now - e.ms > 500) continue;
        if (e.actor == s_local) continue;   // never draw your own box
        out[n++] = e.actor;
        if (n >= maxOut) break;
    }
    return n;
}

void TryInstallBaseTickHook() {
    if (g_baseTickTried) return;
    g_baseTickTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    // Flarial "Actor::vtable" for 1.21.11x: a lea rax,[rip+disp32] resolving
    // the Actor vtable; baseTick sits in slot 25 (Actor::baseTickVft).
    const uintptr_t site = ScanSignature(game,
        "48 8D 05 ? ? ? ? 48 89 01 49 8B 01 48 89 41 ? 49 8B 41");
    if (!site) {
        LOG_INFO("monitoring: Actor::vtable signature not found - TPS off");
        return;
    }
    const int disp = *(const int*)(site + 3);
    const uintptr_t vft = site + disp + 7;
    void* target = nullptr;
    __try { target = *(void**)(vft + 25 * sizeof(void*)); }
    __except (EXCEPTION_EXECUTE_HANDLER) { target = nullptr; }
    if (!target) {
        LOG_INFO("monitoring: baseTick slot empty - TPS off");
        return;
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    MH_STATUS st = MH_CreateHook(target, (LPVOID)&hkActorBaseTick,
                                 &g_baseTickOriginal);
    if (st == MH_OK) st = MH_EnableHook(target);
    LOG_INFO("monitoring: baseTick hook status=%d", (int)st);
}

namespace {

uintptr_t MonReadPtr(uintptr_t base, uintptr_t off) {
    __try { return *(const uintptr_t*)(base + off); }
    __except (EXCEPTION_EXECUTE_HANDLER) { return 0; }
}

// MSVC std::string: SSO buffer / ptr at +0x0, size at +0x10, capacity +0x18.
bool MonReadIpString(uintptr_t strAddr, char* dst, unsigned dstLen) {
    __try {
        const unsigned long long len = *(const unsigned long long*)(strAddr + 0x10);
        const unsigned long long cap = *(const unsigned long long*)(strAddr + 0x18);
        if (len == 0 || len >= dstLen || len >= 64) return false;
        const char* p = (cap < 16) ? (const char*)strAddr
                                   : *(const char* const*)strAddr;
        if (!p) return false;
        for (unsigned long long i = 0; i < len; ++i)
            if (p[i] < 0x20 || (unsigned char)p[i] > 0x7E) return false;
        memcpy(dst, p, (size_t)len);
        dst[len] = 0;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

} // namespace

bool GetServerIpString(char* out, unsigned outLen) {
    if (!out || outLen < 65) return false;
    out[0] = 0;
    if (!g_clientInstancePtr) return false;

    // ClientInstance -> LoopbackPacketSender -> NetworkSystem ->
    // RemoteConnectorComposite -> RaknetConnector -> JoinedIp std::string.
    // Candidate offsets are Flarial's values across the 1.21.x buckets; the
    // printable-ASCII validation makes a wrong combination read as empty.
    static const uintptr_t kSenderOffs[]    = { 0x1C8, 0xF8 };
    static const uintptr_t kNetSysOffs[]    = { 0xF0, 0x90, 0x80 };
    static const uintptr_t kCompositeOffs[] = { 0x70, 0x60 };
    static const uintptr_t kIpOffs[]        = { 0x3F0, 0x3E0, 0x3C0 };

    // winning combination, cached for the rest of the session
    static int cSender = -1, cNet = -1, cComp = -1, cIp = -1;
    char ip[65];

    if (cSender >= 0) {
        const uintptr_t sender = MonReadPtr((uintptr_t)g_clientInstancePtr,
                                            kSenderOffs[cSender]);
        const uintptr_t net = sender ? MonReadPtr(sender, 0x20) : 0;
        const uintptr_t comp = net ? MonReadPtr(net, kNetSysOffs[cNet]) : 0;
        const uintptr_t rak = comp ? MonReadPtr(comp, kCompositeOffs[cComp]) : 0;
        if (rak && MonReadIpString(rak + kIpOffs[cIp], ip, sizeof(ip))) {
            strcpy_s(out, outLen, ip);
            return true;
        }
        return false;
    }

    for (int a = 0; a < 2 && !out[0]; ++a) {
        const uintptr_t sender = MonReadPtr((uintptr_t)g_clientInstancePtr,
                                            kSenderOffs[a]);
        if (!sender) continue;
        for (int b = 0; b < 3 && !out[0]; ++b) {
            const uintptr_t net = MonReadPtr(sender, 0x20);
            if (!net) continue;
            const uintptr_t comp = MonReadPtr(net, kNetSysOffs[b]);
            if (!comp) continue;
            for (int c = 0; c < 2 && !out[0]; ++c) {
                const uintptr_t rak = MonReadPtr(comp, kCompositeOffs[c]);
                if (!rak) continue;
                for (int d = 0; d < 3 && !out[0]; ++d) {
                    if (MonReadIpString(rak + kIpOffs[d], ip, sizeof(ip))) {
                        cSender = a; cNet = b; cComp = c; cIp = d;
                        strcpy_s(out, outLen, ip);
                    }
                }
            }
        }
    }
    return out[0] != 0;
}

bool GetLocalPlayerState(float pos[3], float vel[3]) {
    void* lp = nullptr;
    CritLocalPlayerPtr(&lp);
    if (!lp) return false;
    return game::ActorReadStateVector(lp, pos, vel);
}

// Public key-poll wrapper. The anon-namespace PollKeyDown() above has internal
// linkage, so ui/clickgui.cpp cannot call it directly; this re-exports it.
// The ClickGUI needs it to bind a module to a key: while binding is armed it
// scans virtual-key codes for the next press.
// Inject a synthetic key event through the game's own Keyboard::feed detour.
// Same mechanism as AutoSprint's synthetic CTRL: the event enters the game's
// input pipeline exactly like a physical key press. Requires the feed hook
// (signature-matched build); without it the callers degrade gracefully.
// SEH-protected effect collection (no C++ objects with destructors here, so
// __try is allowed). The component vector lives in game memory.
static bool g_potionLogged = false;

// True while the local player object exists -> a world/server is joined.
// Used as the in-world fallback when getScreenName has no signature.
static int FillPotionEffects(overlay::PotionEffect* out, int maxOut) {
    __try {
        void* lp = CallVFunc<void*>(g_localPlayerVfunc, g_clientInstancePtr);
        if (!lp) {
            if (!g_potionLogged) { LOG_INFO("potions: no local player (vfunc=%d)", g_localPlayerVfunc); g_potionLogged = true; }
            return 0;
        }
        auto* ctx = reinterpret_cast<V1_20_50::EntityContext*>(
            (uintptr_t)lp + 0x8);
        if (!ctx->isValid()) {
            if (!g_potionLogged) { LOG_INFO("potions: entity context invalid"); g_potionLogged = true; }
            return 0;
        }
        auto* comp = ctx->tryGetComponent<MobEffectsComponent>();
        if (!comp) {
            if (!g_potionLogged) { LOG_INFO("potions: MobEffectsComponent not present on player"); g_potionLogged = true; }
            return 0;
        }
        int n = 0;
        // The component's vector is declared with an empty instance type in
        // our mirror; reinterpret it with the real 1.21.30 instance layout.
        const auto& effects = *reinterpret_cast<const std::vector<MobEffectInstanceData1_21_30>*>(&comp->effects);
        for (const auto& e : effects) {
            if (n >= maxOut) break;
            out[n].id = (unsigned)e.id;
            out[n].duration = e.duration;
            out[n].amplifier = e.amplifier;
            out[n].noCounter = e.noCounter;
            ++n;
        }
        if (!g_potionLogged) {
            LOG_INFO("potions: component read ok, effects=%d", n);
            g_potionLogged = true;
        }
        return n;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        if (!g_potionLogged) { LOG_ERROR("potions: SEH while reading MobEffectsComponent"); g_potionLogged = true; }
        return 0;
    }
}

bool IsChatOpen() {
    return g_ext_key_flags.chatOpen != 0;
}

// True while the player is inside a world/server: the screen name is
// "hud_screen" (or, when getScreenName has no signature, the local player
// object exists). HUD plates (Potions, Keybinds) render only then.
bool IsInWorld() {
    if (g_ext_key_flags.screenFlags & 2)  // screen name known
        return (g_ext_key_flags.screenFlags & 1) != 0;
    return LocalPlayerExists();
}

// System-wide cursor visibility: the game hides the cursor in-world and
// shows it whenever any UI screen (inventory, chest, chat, pause) is up.
// A cheap and version-independent "a screen owns the mouse" signal.
bool IsCursorVisible() {
    CURSORINFO ci{ sizeof(CURSORINFO) };
    if (!GetCursorInfo(&ci)) return false;
    return (ci.flags & CURSOR_SHOWING) != 0;
}

// Active mob effects: local player -> EntityContext (Actor+0x8) ->
// entt registry try_get<MobEffectsComponent> (LeviLamina/Flarial technique,
// type ids matched through the hashed type-name string).
int GetPotionEffects(PotionEffect* out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    if (!g_clientInstancePtr || g_localPlayerVfunc < 0) {
        if (!g_potionLogged) { LOG_INFO("potions: unavailable (client=%d localPlayerVfunc=%d)", g_clientInstancePtr ? 1 : 0, g_localPlayerVfunc); g_potionLogged = true; }
        return 0;
    }
    return FillPotionEffects(out, maxOut);
}

bool InjectGameKey(int vk, bool down) {
    if (vk <= 0 || vk > 0xFF) return false;
    if (!g_KeyHookActive || !oKeyboardFeed) return false;
    __try {
        oKeyboardFeed((uint32_t)vk, down);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// ---- Flarial TextHotkey send path: TextPacket -> sendToServer -------------
// Packet classes have a virtual destructor, so releasing the shared_ptr runs
// the GAME's control-block deleter - no cross-CRT delete happens even though
// this DLL uses a static CRT.
struct GamePacket { void* vtable; };
using CreatePacketFn = std::shared_ptr<GamePacket>(__fastcall*)(int);
static CreatePacketFn g_createPacketFn = nullptr;
static bool g_createPacketTried = false;

// SEH wrappers (C2712: __try is not allowed around objects with destructors,
// so the shared_ptr lives only in SendChatText and these helpers are plain).
static void* ReadPacketSender() {
    __try {
        return *(void**)((uintptr_t)g_clientInstancePtr + 0x1C8);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

static bool CraftChatPacket(void* pkt, const char* message) {
    __try {
        // TextPacket layout (pre-1.21.130, Flarial SDK): type@0x30,
        // name@0x38, message@0x58, translationNeeded@0xB8, xuid@0xC0,
        // platformId@0xE0. The packet was fully constructed by the game, so
        // the std::string fields are live objects we can assign into.
        const uintptr_t p = (uintptr_t)pkt;
        *(int8_t*)(p + 0x30) = 1;              // TextPacketType::CHAT
        *(std::string*)(p + 0x38) = "";        // source name (server overrides)
        *(std::string*)(p + 0x58) = message;   // the chat message
        *(bool*)(p + 0xB8) = false;            // translationNeeded
        ((std::string*)(p + 0xC0))->clear();   // xuid
        ((std::string*)(p + 0xE0))->clear();   // platformId
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static bool SendViaSender(void* sender, void* pkt) {
    // LoopbackPacketSender::sendToServer = vtable slot 2
    // (slot 0 = deleting dtor, slot 1 = send).
    __try {
        void** vtable = *(void***)sender;
        if (!vtable || !vtable[2]) return false;
        ((void(__fastcall*)(void*, void*))vtable[2])(sender, pkt);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool SendChatText(const char* message) {
    if (!message || !*message) return false;
    if (!g_clientInstancePtr) return false;

    // MinecraftPackets::createPacket (Flarial sig for 1.21.11x).
    if (!g_createPacketFn && !g_createPacketTried) {
        g_createPacketTried = true;
        HMODULE game = GetModuleHandleW(nullptr);
        uintptr_t fn = ScanSignature(game,
            "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 60 "
            "48 8B 05 ? ? ? ? 48 33 C4 48 89 44 24 58 48 8B F9 48 89 4C 24 38");
        if (fn) {
            g_createPacketFn = (CreatePacketFn)fn;
            LOG_INFO("game: MinecraftPackets::createPacket found");
        } else {
            LOG_INFO("game: MinecraftPackets::createPacket signature not found");
        }
    }
    if (!g_createPacketFn) return false;

    void* sender = ReadPacketSender();
    if (!sender) return false;

    // createPacket(9) = TextPacket, returned as std::shared_ptr by value
    // (MSVC hidden sret: RCX = return buffer, EDX = id) - exactly how
    // Flarial's SDK::createPacket declares it.
    std::shared_ptr<GamePacket> pkt = g_createPacketFn(9);
    if (!pkt) return false;

    if (!CraftChatPacket(pkt.get(), message)) return false;
    return SendViaSender(sender, pkt.get());
}

bool IsKeyDown(int vk) {
    if (vk <= 0 || vk > 0xFF)
        return false;

    // Read the same transition stream the input veto uses: either the
    // in-process Keyboard::feed hook (captures EVERY transition, menu open or
    // closed), or the external watcher's WH_KEYBOARD_LL / GetAsyncKeyState
    // mirror (now also written while the menu is closed, which is exactly
    // when module keybinds fire). GetAsyncKeyState inside the AppContainer is
    // provably dead for keyboard keys, so PollKeyDown is only the last
    // fallback when no capture source owns the input.
    if (g_KeyHookActive)
        return FeedKeyDown((UINT)vk);
    if (g_ExtKeysActive) {
        const LONG bit = (LONG)(1u << (vk & 31));
        return (g_ext_key_flags.keys[vk >> 5] & bit) != 0;
    }
    return PollKeyDown(vk);
}

void ResetKeyMirrors() {
    // Both mirrors are only fed while the menu is open. Leftover bits from the
    // previous session would otherwise read as "held" on the first frame of the
    // next one, and because that frame's "previous" snapshot was taken from a
    // different source (the in-process poll), every leftover bit looks like a
    // fresh press.
    for (int i = 0; i < 8; i++) {
        InterlockedExchange(&g_FeedKeys[i], 0);
        InterlockedExchange(&g_ext_key_flags.keys[i], 0);
    }
    // Java Hotkeys: a bind held while the menu (or its key source) toggled
    // must not swallow the first press of the next session.
    InterlockedExchange(&s_jhHeldBind, 0);
}

// ======================== Public: shutdown ========================
void OverlayShutdown() {
    // Flush the menu state first: the game can be closed right after this and
    // the autosave is debounced, so an unsaved change would otherwise be lost.
    ui::SaveState();
    ShutdownImpl();
}

// ======================== Public: input ========================
void UpdateInputState() {
    UpdateInputStateImpl();
}

// ======================== Public: unload ========================
void RequestUnload() {
    g_UnloadRequested = true;
}

void NotifyDetach() {
    g_ShuttingDown = true;
    InterlockedExchange(&g_SharedAbort, 1);
    InterlockedExchange(&g_watchdogStop, 1);

    // Never leave the global input masks installed: the watcher drops them as
    // soon as menuOpen reads 0 (and on a stale heartbeat).
    g_ShowMenu = false;
    g_ext_key_flags.menuOpen = 0;
    Sleep(150); // give the watchdog thread a moment to exit before we unload
#ifdef _MSC_VER
    __try {
#endif
        RestoreWndProc();
        if (g_Init || g_InitTouched) {
            // Try, never block: if a frame is in flight (or the render thread
            // is already wedged) a blocking wait here would hang the unload.
            if (TryEnterCriticalSection(&g_RenderCs)) {
                ShutdownImpl();
                LeaveCriticalSection(&g_RenderCs);
            } else {
                LOG_ERROR("DLL detach: render lock is busy - skipping teardown");
            }
        }
        RestoreHooks();
        LOG_INFO("DLL detached");
#ifdef _MSC_VER
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("DLL detach");
    }
#endif
}

// ======================== Thread entry ========================
// NOTE: the body lives in MainThreadImpl() because MSVC forbids __try in a
// function that contains C++ objects with destructors (std::vector etc.)
// - error C2712. MainThread is a thin SEH wrapper around it.
void MainThreadImpl(HMODULE hModule) {
    g_ModuleHandle = hModule;
    LOG_INFO("MainThread started, pid=%lu", GetCurrentProcessId());

    // Serialization for D3D12 command recording and ImGui access. Must exist
    // before the first hkPresent can run.
    InitializeCriticalSection(&g_RenderCs);

    // Safety net for the external input masks (see OverlayWatchdogThread):
    // publishes menuOpen/heartbeat from a thread that rendering cannot block
    // and releases the masks if the render thread ever stops ticking.
    HANDLE ow = CreateThread(nullptr, 0, OverlayWatchdogThread, nullptr, 0, nullptr);
    if (ow) CloseHandle(ow);
    else LOG_ERROR("MainThread: could not start the overlay watchdog (input masks are unprotected)");

    // Log the exact game build (ProductVersion) - used to pick the right
    // Keyboard::feed signature if the Solstice one does not match.
    LogGameVersion();

    // RakNet ping hook goes up EARLY: the game queries GetAveragePing during
    // server browsing and connect, before the first rendered frame.
    TryInstallPingHook();

    while (!GetModuleHandleA("d3d11.dll")) {
        Sleep(100);
        if (g_SharedAbort) return;
    }
    LOG_INFO("d3d11.dll found");

    // IMPORTANT: do NOT create the dummy swapchain / D3D11+D3D12 devices and
    // do NOT touch the DXGI/D3D12 vtables while the game is still starting
    // (splash, D3D12 still initializing). On --launch the injector hits the
    // process within the first second - creating devices and patching
    // vtables that early destabilizes the game's DXGI init and crashes it
    // before the first frame. So: first WAIT until the game actually
    // created at least one visible window of its own, and only then create
    // our fallback window + dummy swapchain and install the hooks.
    int attempts = 0;

    for (;;) {
        std::vector<HWND> candidates = CollectGameWindows();
        if (candidates.empty()) {
            attempts++;
            if (attempts == 1 || attempts % 40 == 0)
                LOG_INFO("waiting for game window... (%d)", attempts);
            Sleep(250);
            continue;
        }

        // The game has a visible window now - safe to create our own dummy
        // (the game's DXGI/D3D12 init is far enough that a second swapchain
        // does not destabilize it).
        HWND fallback = CreateFallbackWindow();
        if (fallback) candidates.push_back(fallback);

        for (size_t i = 0; i < candidates.size(); i++) {
            if (g_SharedAbort) { if (fallback) DestroyWindow(fallback); return; }

            IDXGISwapChain* fakeSC = nullptr;
            ID3D11Device* fakeDev = nullptr;
            ID3D11DeviceContext* fakeCtx = nullptr;

            if (attempts == 0 && i == 0)
                LogWindowInfo(candidates[i], "candidate");

            if (TryCreateDummySwapChain(candidates[i], &fakeSC, &fakeDev, &fakeCtx)) {
                if (candidates[i] != fallback && IsWindow(candidates[i]))
                    g_hwnd = candidates[i];
                LOG_INFO("dummy swapchain OK on hwnd=%p (attempt %d)", candidates[i], attempts + 1);

                void** vtable = *(void***)fakeSC;
                g_hookedSwapVtable = vtable;
                HookVTable(vtable, PRESENT_INDEX, (void*)hkPresent, (void**)&oPresent);
                HookVTable(vtable, RESIZEBUFFERS_INDEX, (void*)hkResizeBuffers, (void**)&oResizeBuffers);
                LOG_INFO("hooks installed: oPresent=%p oResize=%p", oPresent, oResizeBuffers);

                // D3D12 queue hook is installed LAZILY from InitD3D12 (first
                // Present) - not here - because creating our own D3D12 device
                // and patching the shared D3D12 vtable while the game is
                // still starting up crashes it before the first frame.

                fakeCtx->Release();
                fakeDev->Release();
                fakeSC->Release();
                LOG_INFO("dummy swapchain released");

                if (fallback) DestroyWindow(fallback);
                // K/INSERT/ESC/END: the injector's EXTERNAL key watcher
                // (--watch child, a normal desktop process) writes into the
                // exported g_ext_key_flags counters, read every frame in
                // UpdateHotkeys() on the render thread. In-process keyboard
                // polling stays on as a fallback but is provably dead inside
                // the AppContainer (mouse works, keys never arrive).
                LOG_INFO("MainThread done");

                // Present watchdog: if hkPresent never fires (game not
                // presenting through the patched vtable), it logs and retries
                // the hook once - see RehookPresentOnce(). Diagnostic only;
                // safe to ignore if rendering starts normally.
                HANDLE wd = CreateThread(nullptr, 0, WatchdogThread, nullptr, 0, nullptr);
                if (wd) CloseHandle(wd);
                return;
            }
        }

        if (fallback) DestroyWindow(fallback);
        attempts++;
        if (attempts == 1 || attempts % 40 == 0)
            LOG_INFO("retrying dummy swapchain... (%d)", attempts);
        Sleep(250);
    }
}

void MainThread(HMODULE hModule) {
#ifdef _MSC_VER
    __try {
#endif
        MainThreadImpl(hModule);
#ifdef _MSC_VER
    } __except(OverlaySehFilter(GetExceptionInformation())) {
        TraceSeh("MainThread");
    }
#endif
}

} // namespace overlay
