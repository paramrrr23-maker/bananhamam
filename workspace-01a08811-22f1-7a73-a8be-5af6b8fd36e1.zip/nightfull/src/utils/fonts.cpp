// fonts.cpp - font roles loaded from the fonts/ folder next to the DLL.

#include "utils/fonts.h"

#include <Windows.h>
#include <cstdio>

#include "imgui.h"
#include "utils/logger.h"

namespace nf {
namespace fonts {
namespace {

ImFont* g_ui = nullptr;
ImFont* g_uiSemi = nullptr;
ImFont* g_bold = nullptr;
ImFont* g_title = nullptr;
ImFont* g_mono = nullptr;
ImFont* g_icon = nullptr;

// Lucide PUA codepoints used by the menu (see the icon table in menu.cpp).
// Stored statically: the atlas reads the ranges when it builds, after Init.
const ImWchar* IconRanges() {
    static const ImWchar r[] = {
        0x20, 0x7E,         // 'x' (close) lives at ASCII 0x78 in this font
        0xE038, 0xE038,     // activity
        0xE049, 0xE049,     // arrow-right
        0xE04D, 0xE04D,     // arrow-up-right
        0xE059, 0xE059,     // bell
        0xE05F, 0xE05F,     // book-open
        0xE061, 0xE061,     // box
        0xE06C, 0xE06C,     // check
        0xE06D, 0xE06D,     // chevron-down
        0xE06F, 0xE06F,     // chevron-right
        0xE082, 0xE082,     // circle-help
        0xE0AC, 0xE0AC,     // crosshair
        0xE0B6, 0xE0B6,     // ellipsis (more-horizontal)
        0xE0B9, 0xE0B9,     // external-link
        0xE0DF, 0xE0DF,     // gamepad-2
        0xE0FF, 0xE0FF,     // layout-grid (hotbar)
        0xE113, 0xE113,     // maximize-2
        0xE11D, 0xE11D,     // monitor
        0xE11E, 0xE11E,     // moon
        0xE13C, 0xE13C,     // play
        0xE13D, 0xE13D,     // plus
        0xE151, 0xE151,     // search
        0xE178, 0xE178,     // sun
        0xE180, 0xE180,     // target
        0xE18E, 0xE18E,     // trash-2
        0xE1B4, 0xE1B4,     // zap
        0xE1C1, 0xE1C1,     // layout-dashboard
        0xE1DD, 0xE1DD,     // palette
        0xE1FF, 0xE1FF,     // shield-check
        0xE245, 0xE245,     // settings-2
        0xE284, 0xE284,     // keyboard
        0xE28D, 0xE28D,     // git-fork (repo links)
        0xE29A, 0xE29A,     // sliders-horizontal
        0xE333, 0xE333,     // folder-heart
        0xE412, 0xE412,     // sparkles
        0xE455, 0xE455,     // arrow-down-to-line
        0xE529, 0xE529,     // layers-3
        0,
    };
    return r;
}

ImFont* LoadOne(const wchar_t* path, float px, const char* role,
                const ImWchar* ranges, ImFontConfig* cfg = nullptr) {
    DWORD attrs = GetFileAttributesW(path);
    if (attrs == INVALID_FILE_ATTRIBUTES) {
        LOG_ERROR("fonts: missing %ls (%s) - fallback engaged", path, role);
        return nullptr;
    }
    // ImGui takes UTF-8 narrow paths: convert.
    char narrow[MAX_PATH * 3] = {};
    WideCharToMultiByte(CP_UTF8, 0, path, -1, narrow, sizeof(narrow), nullptr, nullptr);
    ImFont* loaded = ImGui::GetIO().Fonts->AddFontFromFileTTF(narrow, px, cfg, ranges);
    if (!loaded) LOG_ERROR("fonts: failed to load %s (%s)", narrow, role);
    else LOG_INFO("fonts: role %s <- %s", role, narrow);
    return loaded;
}

void PathFor(const wchar_t* base, const wchar_t* file, wchar_t* out, size_t cap) {
    _snwprintf_s(out, cap, _TRUNCATE, L"%s\\%s", base, file);
}

ImFont* WithFallback(ImFont* f) {
    return f ? f : ImGui::GetFont();
}

} // namespace

bool Init(const wchar_t* dllDir) {
    wchar_t base[MAX_PATH] = {};
    _snwprintf_s(base, _TRUNCATE, L"%s\\fonts", dllDir ? dllDir : L".");
    LOG_INFO("fonts: dir %ls", base);
    // Last-resort source: the Windows system font always has Cyrillic, so
    // text stays readable when fonts/ did not travel with the DLL. (If the
    // sandbox blocks the read, roles fall through to the ImGui default.)
    wchar_t sysFont[MAX_PATH] = {};
    {
        wchar_t windir[MAX_PATH] = {};
        GetWindowsDirectoryW(windir, MAX_PATH);
        _snwprintf_s(sysFont, _TRUNCATE, L"%s\\Fonts\\arial.ttf", windir);
    }
    auto sysfix = [&](ImFont** slot, float px, const char* role, const ImWchar* ranges) {
        if (*slot) return;
        *slot = LoadOne(sysFont, px, role, ranges);
        if (*slot) LOG_INFO("fonts: %s via system fallback", role);
    };

    // ImGui's Cyrillic ranges already include Basic Latin + Latin-1.
    const ImWchar* textRanges = ImGui::GetIO().Fonts->GetGlyphRangesCyrillic();
    const ImWchar* iconRanges = IconRanges();

    struct Job { const wchar_t* file; float px; ImFont** out; const char* role;
                 const ImWchar* ranges; };
    Job jobs[] = {
        { L"Manrope-Regular.ttf",     20.0f, &g_ui,     "UI",     textRanges },
        { L"Manrope-SemiBold.ttf",    20.0f, &g_uiSemi, "UISemi", textRanges },
        { L"Manrope-Bold.ttf",        20.0f, &g_bold,   "Bold",   textRanges },
        { L"JetBrainsMono-Regular.ttf", 16.0f, &g_mono, "Mono",   textRanges },
        { L"lucide.ttf",              20.0f, &g_icon,   "Icon",   iconRanges },
    };
    bool allOk = true;
    wchar_t path[MAX_PATH] = {};
    for (const Job& j : jobs) {
        PathFor(base, j.file, path, MAX_PATH);
        *j.out = LoadOne(path, j.px, j.role, j.ranges);
        if (!*j.out) allOk = false;
    }

    // Display face: Space Grotesk has no Cyrillic, so Manrope Bold is merged
    // in as the fallback source for the same ranges (system font if Manrope
    // itself is missing - an unmerged Title would show ??? for Russian).
    PathFor(base, L"SpaceGrotesk-Bold.ttf", path, MAX_PATH);
    g_title = LoadOne(path, 22.0f, "Title", textRanges);
    PathFor(base, L"Manrope-Bold.ttf", path, MAX_PATH);
    if (g_title) {
        ImFontConfig merge;
        merge.MergeMode = true;
        if (!LoadOne(path, 22.0f, "TitleFallback", textRanges, &merge) &&
            !LoadOne(sysFont, 22.0f, "TitleFallback", textRanges, &merge))
            allOk = false;
    } else {
        g_title = LoadOne(path, 22.0f, "Title", textRanges);
    }
    sysfix(&g_ui, 20.0f, "UI", textRanges);
    sysfix(&g_uiSemi, 20.0f, "UISemi", textRanges);
    sysfix(&g_bold, 20.0f, "Bold", textRanges);
    sysfix(&g_title, 22.0f, "Title", textRanges);
    sysfix(&g_mono, 16.0f, "Mono", textRanges);
    // NOTE: Icon (Lucide) has no system fallback: with fonts/ missing the
    // callers skip glyphs, so icons vanish instead of showing tofu.

    // Guarantee a default font exists even when every file is missing.
    ImGui::GetIO().Fonts->AddFontDefault();
    LOG_INFO("fonts: init %s", allOk ? "ok" : "with fallbacks");
    return allOk;
}

void Shutdown() {
    g_ui = g_uiSemi = g_bold = g_title = g_mono = g_icon = nullptr;
}

ImFont* UI() { return WithFallback(g_ui); }
ImFont* UISemi() { return WithFallback(g_uiSemi); }
ImFont* Bold() { return WithFallback(g_bold); }
ImFont* Title() { return WithFallback(g_title); }
ImFont* Mono() { return WithFallback(g_mono); }
ImFont* Icon() { return g_icon; }          // nullptr when missing: callers skip glyphs
ImFont* Current() { return UI(); }

} // namespace fonts
} // namespace nf
