// menu.cpp - the Nightfull ClickGUI (single polished renderer).
//
// Frame orchestration (theme push, keybinds, module tick/render, autosave)
// plus all drawing: the reference shell, module board, inspector tabs, HUD,
// modals and toasts. Everything is laid out in a design space scaled uniformly
// to the screen. Visual language follows the attached Nightfull reference:
// deep glass, warm accent light, rounded surfaces and restrained borders;
// all existing module behavior stays intact.

#include "ui/menu.h"

#include <Windows.h>
#include <psapi.h>
#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "imgui.h"

#include "core/module_guard.h"
#include "core/module_manager.h"
#include "modules/client_modules.h"
#include "modules/registry.h"
#include "modules/text_hotkeys.h"
#include "modules/theme_presets.h"
#include "overlay/overlay.h"
#include "utils/config.h"
#include "utils/easing.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"
#include "utils/logger.h"

namespace nf {
namespace ui {
namespace {

// ============================ palette ============================
// Obsidian shell tokens (prototype: bg #07090d, panel #0d1118,
// panel2 #111722, line #202938, text #eef3fb, muted #7f8ba0,
// accent #7c5cff, mint #20d9a4).
// The theme engine still drives HUD accents and glow colors; the shell
// chrome below uses the theme accent (c.accent) so a theme change
// repaints the whole client at once.
ImColor kField(11, 16, 23);
ImColor kModuleBg(23, 24, 27);      // module body (matches the search plate)
ImColor kBorder(32, 41, 56);        // --line
ImColor kEdge(4, 6, 10);
ImColor kText(238, 243, 251);       // --text
ImColor kMuted(127, 139, 160);      // --muted
ImColor kFaint(86, 98, 119);
ImColor kTrack(7, 10, 17);
ImColor kKnobOff(118, 130, 151);
ImColor kKnobOn(255, 255, 255);
ImColor kBtnText(4, 18, 10);
ImColor kSecBg(24, 28, 36);
ImColor kSecBorder(58, 64, 76);
ImColor kSecText(223, 226, 233);
ImColor kMint(61, 220, 132);        // legacy green (kept for compat)
ImColor kMintHi(138, 255, 190);
ImColor kAmber(255, 196, 77);
ImColor kRed(255, 107, 107);

ImColor Hex(unsigned hex) {
    // Normalize the old neutral literals into the reference's blue-black
    // glass scale while preserving saturated preview artwork and accents.
    if (hex == 0xC1F17C) return ImColor(0xD9, 0x77, 0x57);
    const int r = (int)((hex >> 16) & 255);
    const int g = (int)((hex >> 8) & 255);
    const int b = (int)(hex & 255);
    const int hi = std::max(r, std::max(g, b));
    const int lo = std::min(r, std::min(g, b));
    if (hi - lo <= 18) {
        const float lum = 0.2126f * r + 0.7152f * g + 0.0722f * b;
        if (lum < 32.0f) return ImColor(0x0D, 0x0F, 0x12);
        if (lum < 76.0f) return ImColor(0x17, 0x1B, 0x22);
        if (lum < 132.0f) return ImColor(0x2B, 0x31, 0x3C);
        if (lum < 190.0f) return ImColor(0x9B, 0xA1, 0xAD);
        return ImColor(0xF6, 0xF0, 0xE7);
    }
    return ImColor(r, g, b);
}

// ============================ icons (Lucide PUA) ============================
namespace Icon {
constexpr unsigned Dashboard = 0xE1C1;
constexpr unsigned Box = 0xE061;
constexpr unsigned Monitor = 0xE11D;
constexpr unsigned Palette = 0xE1DD;
constexpr unsigned FolderHeart = 0xE333;
constexpr unsigned GitFork = 0xE28D;
constexpr unsigned BookOpen = 0xE05F;
constexpr unsigned Settings2 = 0xE245;
constexpr unsigned Search = 0xE151;
constexpr unsigned Bell = 0xE059;
constexpr unsigned ChevronRight = 0xE06F;
constexpr unsigned ChevronUp = 0xE070;
constexpr unsigned ChevronDown = 0xE06D;
constexpr unsigned Plus = 0xE13D;
constexpr unsigned Check = 0xE06C;
constexpr unsigned X = 0x78;
constexpr unsigned ArrowRight = 0xE049;
constexpr unsigned ArrowUpRight = 0xE04D;
constexpr unsigned Sliders = 0xE29A;
constexpr unsigned Sparkles = 0xE412;
constexpr unsigned Keyboard = 0xE284;
constexpr unsigned Layers = 0xE529;
constexpr unsigned Gamepad = 0xE0DF;
constexpr unsigned Shield = 0xE1FF;
constexpr unsigned Zap = 0xE1B4;
constexpr unsigned Crosshair = 0xE0AC;
constexpr unsigned Sun = 0xE178;
constexpr unsigned Moon = 0xE11E;
constexpr unsigned Maximize = 0xE113;
constexpr unsigned Activity = 0xE038;
constexpr unsigned Target = 0xE180;
constexpr unsigned Grid = 0xE0FF;
constexpr unsigned Trash = 0xE18E;
constexpr unsigned Ellipsis = 0xE0B6;
constexpr unsigned Help = 0xE082;
constexpr unsigned External = 0xE0B9;
constexpr unsigned Download = 0xE455;
} // namespace Icon

// ============================ metrics ============================
constexpr float kMainW = 1160.0f, kMainH = 700.0f, kMainR = 14.0f;
constexpr float kSideW = 232.0f, kTopH = 74.0f;
constexpr float kContX = 267.0f;                       // 232 + 35 pad, web sidebar width
constexpr float kContW = 858.0f;                       // 1160 - 267 - 35
constexpr float kContY = 106.0f;                       // 74 + 32 pad
constexpr float kViewB = 694.0f;                       // scroll viewport bottom

enum Page { P_Overview = 0, P_Modules, P_Hud, P_Themes, P_Profiles, P_Sources, P_Settings };
enum Modal { M_None = 0, M_Save, M_Update, M_Help, M_Module };

const char* kPageTitles[7] = {
    "Обзор", "Модули", "Редактор HUD", "Внешний вид", "Конфигурации", "Репозитории", "Настройки",
};
const char* kPageSubs[7] = {
    "Настрой детали. Почувствуй разницу. Играй по-своему.",
    "Управление модулями и их параметрами.",
    "Каждый элемент — на своём месте. Перетащи HUD в редакторе.",
    "Интерфейс, который отражает твой стиль.",
    "Твои настройки. Сохранены и всегда под рукой.",
    "Открытый код, источники вдохновения и заметки по проекту.",
    "Сделай Nightfull удобным для себя.",
};

// Accent presets from the Nightfull reference palette.
struct AccentDef { unsigned hex; const char* name; const char* desc; };
const AccentDef kAccents[5] = {
    { 0xD97757, "Ember Dusk", "Тёплый медный акцент ночного интерфейса." },
    { 0x77C59A, "Mint Glass", "Спокойный зелёный сигнал состояния." },
    { 0xC7798C, "Moon Rose", "Мягкий приглушённый розовый." },
    { 0x83A5B7, "Arctic Slate", "Холодный сине-серый свет." },
    { 0xA883B7, "Amethyst Fog", "Глубокий фиолетовый акцент." },
};

// ============================ frame context ============================
struct Ctx {
    ImDrawList* d = nullptr;
    float s = 1.0f;                 // design px -> screen px
    float alpha = 1.0f;             // menu fade
    ImVec2 origin;                  // design (0,0) in screen px
    float offsetY = 0.0f;           // design scroll offset
    bool interact = false;
    float dt = 0.016f;
    ImColor accent = ImColor(255, 255, 255);

    float px(float v) const { return v * s; }
    ImVec2 P(float x, float y) const {
        return ImVec2(origin.x + x * s, origin.y + (y + offsetY) * s);
    }
    ImVec2 Mouse() const {
        const ImVec2 m = gui::GetMousePos();
        return ImVec2((m.x - origin.x) / s, (m.y - origin.y) / s - offsetY);
    }
    bool Hover(float x, float y, float w, float h) const {
        const ImVec2 m = Mouse();
        return m.x >= x && m.y >= y && m.x < x + w && m.y < y + h;
    }
    bool Clicked() const {
        return interact && (overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0));
    }
    bool RightClicked() const {
        return interact && (overlay::g_guiMousePressed[1] || ImGui::IsMouseClicked(1));
    }
};

// ============================ state ============================
gui::EasingUtil g_ease;
Page g_page = P_Overview;
float g_scroll[7] = {}, g_scrollTo[7] = {}, g_contentH[7] = {};
bool g_loaded = false;
bool g_animsOff = false;
bool g_modalAnimInit = false;
float g_modalAnim = 0.0f;

Modal g_modal = M_None;
Module* g_selMod = nullptr;         // module settings modal target
bool g_notif = false;               // notification panel open
int g_notifFrame = -1;
bool g_notifRead = false;
bool g_listening = false;           // menu-key capture
int g_category = 0;                 // 0 all, 1 visual, 2 interface, 3 utils, 4 HUD, 5 enabled
const char* kCategories[6] = { "Все модули", "Визуал", "Интерфейс", "Утилиты", "HUD", "Включённые" };
const char* kRefCategoryNames[7] = {
    "Combat", "Movement", "Visual", "HUD", "World", "Client", "Themes"
};
const char* kRefCategoryLetters[7] = { "C", "M", "V", "H", "W", "N", "G" };

struct Field { enum Kind { None, Search, Profile } kind = None; };
Field g_field;
char g_search[64] = {};
char g_profileName[48] = {};
StringSetting* g_stringEditSetting = nullptr;
char g_stringEditBuf[512] = {};
std::string g_stringEditOriginal;     // restored on ESC
bool g_stringFieldHovered = false;    // set by the field that owns the edit
NumberSetting* g_keyEditSetting = nullptr;

float* g_dragV = nullptr;           // float slider under drag
float g_dragMin = 0.0f, g_dragMax = 1.0f;
ImVec4 g_dragRect;
Ctx g_dragCtx;

struct ToastItem { std::string text; unsigned long long until; };
std::vector<ToastItem> g_toasts;

std::vector<std::wstring> g_profiles;
bool g_profilesDirty = true;
std::string g_activeProfile = "Default";
std::map<std::string, bool> g_factory;   // ctor-default enabled states

std::map<std::string, std::pair<float, float>> g_modVis;  // id -> {scale, opacity}

// Scroll state for the settings portion of the module modal. The modal shell,
// header, preview controls and footer remain fixed; only the typed module
// settings viewport scrolls.
float g_moduleScroll = 0.0f;
float g_moduleScrollTo = 0.0f;

float g_hudX = 5.0f, g_hudY = 8.0f;       // canvas percents
float g_hudScale = 100.0f;
bool g_hudDrag = false;
float g_hudGrabX = 0.0f, g_hudGrabY = 0.0f; // pointer offset inside the widget

// The native renderer now follows the attached reference shell directly:
// brand/command/status topbar, profile sidebar, three-column module board and
// one inspector with Settings, Themes and HUD tabs. The older page renderer
// remains below as source-compatible helpers, but is no longer mounted.
constexpr float kRefMainW = 1440.0f, kRefMainH = 900.0f;
constexpr float kRefSideW = 238.0f, kRefRightW = 366.0f;
constexpr float kRefGap = 8.0f, kRefTopH = 64.0f;
constexpr float kRefCenterX = kRefSideW + kRefGap;
constexpr float kRefRightX = kRefMainW - kRefRightW;
constexpr float kRefCenterW = kRefMainW - kRefCenterX - 16.0f;
constexpr float kRefBodyY = kRefTopH + kRefGap;
constexpr float kRefStatusH = 0.0f;    // Aurora status strip removed (compact shell)
constexpr float kRefBodyH = kRefMainH - kRefBodyY - kRefStatusH;
constexpr int kRefCategoryCount = 7;

int g_refCategory = -1; // All; 0..5 real categories, 6 themes
bool g_systemFavoritesOnly = false;
bool g_systemConfigs = false;
float g_systemColumnScroll[3] = {}, g_systemColumnTarget[3] = {};
EnumSetting* g_systemEnum = nullptr;
ImVec4 g_systemEnumRect;
int g_systemEnumFrame = -1;
int g_refTab = 0;                         // 0 Settings, 1 Themes, 2 HUD
Module* g_systemFocus = nullptr;
Module* g_refSelected = nullptr;
float g_refScroll = 0.0f, g_refScrollTo = 0.0f;
float g_refInspectorScroll = 0.0f, g_refInspectorScrollTo = 0.0f;
float g_refPanelY[kRefCategoryCount] = {};
float g_refContentH = 0.0f, g_refInspectorContentH = 0.0f;
bool g_refCompact = false;
bool g_refDeepGlass = false;
bool g_refListeningKey = false;
// Inline General settings panel (the client settings live here now that the
// right inspector is gone; toggled by the sidebar Settings button).
bool g_showGeneral = false;
float g_refRadius = 28.0f;
float g_refGrain = 0.18f;
float g_refUiScale = 1.0f;

unsigned g_hash = 0, g_lastHash = 0;
bool g_savePending = false;
unsigned long long g_changedAt = 0;

// Frame-rate-independent animation factor (1 = snap when animations off).
float AF(float dt, float speed) {
    if (g_animsOff) return 1.0f;
    return gui::Clamp(dt * speed, 0.0f, 1.0f);
}
float HoverAnim(unsigned id, bool hovered, float dt) {
    static float slots[256] = {};
    float& v = slots[id & 255];
    v = gui::Animate(hovered ? 1.0f : 0.0f, v, AF(dt, 14.0f));
    return v;
}
unsigned HashStr(const char* s, unsigned salt) {
    unsigned h = 2166136261u ^ salt;
    for (const unsigned char* p = (const unsigned char*)s; *p; p++) { h ^= *p; h *= 16777619u; }
    return h;
}

float MenuTextScale() { return gui::Clamp(gui::GetTextScale() / 2.5f, 0.85f, 1.25f); }

// ============================ text helpers ============================
// Design-space metrics. Raw ImFont pixels are multiplied by the global text
// scale to match gui::DrawString output (which scales inside); the result is
// divided back to design units so right-aligned/centered callers stay exact.
float TextW(ImFont* f, const char* s, float pt, float sc) {
    if (!f || !s || pt * sc <= 0.1f) return 0.0f;
    return f->CalcTextSizeA(pt * sc * MenuTextScale(), FLT_MAX, 0.0f, s).x / sc;
}
float TextH(ImFont* f, float pt, float sc) {
    if (!f || pt * sc <= 0.1f) return pt;
    return f->CalcTextSizeA(pt * sc * MenuTextScale(), FLT_MAX, 0.0f, "Ag").y / sc;
}
void Text(const Ctx& c, float x, float y, const char* s, ImFont* f,
          float pt, const ImColor& col, float aMul = 1.0f) {
    if (!s || !*s || pt * c.s < 1.0f) return;
    if (!f) f = ImGui::GetFont();
    c.d->AddText(f, pt * c.s * MenuTextScale(), c.P(x, y),
        ImGui::ColorConvertFloat4ToU32(ImVec4(col.Value.x, col.Value.y, col.Value.z,
                                          col.Value.w * c.alpha * aMul)), s);
}
void TextRight(const Ctx& c, float rightX, float y, const char* s, ImFont* f,
               float pt, const ImColor& col, float aMul = 1.0f) {
    Text(c, rightX - TextW(f, s, pt, c.s), y, s, f, pt, col, aMul);
}
// Word-wrap to maxLines; returns lines used. Splits on ASCII space only
// (byte-safe for UTF-8: continuation bytes never equal 0x20).
int WrapText(const Ctx& c, float x, float y, float w, const char* s, ImFont* f,
             float pt, const ImColor& col, int maxLines = 2) {
    const float lh = TextH(f, pt, c.s) + 3.0f;
    std::string cur, word;
    int line = 0;
    auto flush = [&](bool last) {
        if (cur.empty() && !last) return;
        if (line < maxLines) { Text(c, x, y + line * lh, cur.c_str(), f, pt, col); line++; }
    };
    for (const char* p = s; ; p++) {
        const bool end = *p == 0 || *p == ' ';
        if (!end) word += *p;
        if (end || *p == 0) {
            std::string trial = cur.empty() ? word : cur + " " + word;
            if (TextW(f, trial.c_str(), pt, c.s) > w && !cur.empty()) { flush(false); cur = word; }
            else cur = trial;
            word.clear();
            if (*p == 0) break;
        }
    }
    flush(true);
    return line > 0 ? line : 1;
}
// ASCII-only lowercase (UTF-8 multibyte sequences pass through untouched).
void AsciiLower(char* d, size_t cap, const char* s) {
    size_t i = 0;
    for (; s && s[i] && i + 1 < cap; i++) {
        const unsigned char ch = (unsigned char)s[i];
        d[i] = (ch >= 'A' && ch <= 'Z') ? (char)(ch + 32) : (char)ch;
    }
    d[i] = 0;
}

// ============================ shape helpers ============================
float StyleRadius(float r) {
    // Web CSS uses 10–14px rounded surfaces instead of the old 4–8px cards.
    if (r <= 0.0f) return 0.0f;
    if (r <= 4.0f) return 6.0f;
    if (r <= 8.0f) return 10.0f;
    return std::max(12.0f, r);
}
void FillR(const Ctx& c, float x, float y, float w, float h,
           const ImColor& col, float r, float aMul = 1.0f) {
    const ImVec2 a = c.P(x, y), b = c.P(x + w, y + h);
    gui::FillRect(ImVec4(a.x, a.y, b.x, b.y), col, c.alpha * aMul, c.px(StyleRadius(r)), c.d);
}
void StrokeR(const Ctx& c, float x, float y, float w, float h,
             const ImColor& col, float r, float t, float aMul = 1.0f) {
    const ImVec2 a = c.P(x, y), b = c.P(x + w, y + h);
    gui::StrokeRect(ImVec4(a.x, a.y, b.x, b.y), col, c.px(StyleRadius(r)), c.px(t), c.alpha * aMul, c.d);
}
void FillGradV(const Ctx& c, float x, float y, float w, float h,
               const ImColor& top, const ImColor& bottom, float aTop, float aBottom) {
    const ImVec2 a = c.P(x, y), b = c.P(x + w, y + h);
    gui::FillGradientV(ImVec4(a.x, a.y, b.x, b.y), top, bottom,
                       c.alpha * aTop, c.alpha * aBottom, 0.0f, c.d);
}
void StrokeDashed(const Ctx& c, float x, float y, float w, float h,
                  const ImColor& col, float aMul = 1.0f) {
    const ImU32 u = ImColor(col.Value.x, col.Value.y, col.Value.z, col.Value.w * c.alpha * aMul);
    const float dash = 7.0f, gap = 5.0f, t = c.px(1.2f);
    auto edge = [&](float x0, float y0, float x1, float y1) {
        const float len = std::sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
        if (len <= 0.0f) return;
        const float dx = (x1 - x0) / len, dy = (y1 - y0) / len;
        for (float d = 0.0f; d < len; d += dash + gap) {
            const float e = std::min(d + dash, len);
            c.d->AddLine(c.P(x0 + dx * d, y0 + dy * d), c.P(x0 + dx * e, y0 + dy * e), u, t);
        }
    };
    edge(x, y, x + w, y); edge(x + w, y, x + w, y + h);
    edge(x + w, y + h, x, y + h); edge(x, y + h, x, y);
}
// Fills the area under a single-valued ridgeline (x strictly increasing)
// down to baseY. Points are design-space.
void FillRidge(const Ctx& c, const ImVec2* r, int n, float baseY, const ImColor& col) {
    const ImU32 u = ImColor(col.Value.x, col.Value.y, col.Value.z, col.Value.w * c.alpha);
    for (int i = 0; i + 1 < n; i++) {
        const ImVec2 a = c.P(r[i].x, r[i].y), b = c.P(r[i + 1].x, r[i + 1].y);
        const ImVec2 aB = c.P(r[i].x, baseY), bB = c.P(r[i + 1].x, baseY);
        c.d->AddTriangleFilled(a, b, bB, u);
        c.d->AddTriangleFilled(a, bB, aB, u);
    }
}
void IconGlyph(const Ctx& c, unsigned cp, float cx, float cy, float px,
               const ImColor& col, float aMul = 1.0f) {
    ImFont* f = fonts::Icon();
    if (!f || px * c.s < 1.0f) return;
    char s[5] = {};
    if (cp < 0x80) { s[0] = (char)cp; }
    else {
        s[0] = (char)(0xE0 | (cp >> 12));
        s[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        s[2] = (char)(0x80 | (cp & 0x3F));
    }
    const float sizePx = px * c.s;
    const ImVec2 sz = f->CalcTextSizeA(sizePx, FLT_MAX, 0.0f, s);
    const ImVec2 p = c.P(cx, cy);
    c.d->AddText(f, sizePx, ImVec2(p.x - sz.x * 0.5f, p.y - sz.y * 0.5f),
        ImGui::ColorConvertFloat4ToU32(ImVec4(col.Value.x,col.Value.y,col.Value.z,col.Value.w*c.alpha*aMul)), s);
}
// Nightfull mark (32x32 vector path from the reference), accent filled.
void Logo(const Ctx& c, float x, float y, float w, const ImColor& col, float aMul = 1.0f) {
    const ImU32 u = ImColor(col.Value.x, col.Value.y, col.Value.z, col.Value.w * c.alpha * aMul);
    const float k = w / 32.0f;
    auto Pt = [&](float vx, float vy) { return c.P(x + vx * k, y + vy * k); };
    const ImVec2 s1[] = { Pt(7, 24), Pt(7, 8), Pt(14, 12), Pt(14, 24) };
    const ImVec2 s2[] = { Pt(18, 24), Pt(18, 8), Pt(25, 8), Pt(25, 28) };
    const ImVec2 s3[] = { Pt(14, 12), Pt(25, 20), Pt(25, 28), Pt(14, 20) };
    c.d->AddConvexPolyFilled(s1, 4, u);
    c.d->AddConvexPolyFilled(s2, 4, u);
    c.d->AddConvexPolyFilled(s3, 4, u);
}

// ============================ module metadata ============================
unsigned ModuleIcon(const char* name) {
    if (!name) return Icon::Box;
    if (!std::strcmp(name, "HUD")) return Icon::Dashboard;
    if (!std::strcmp(name, "Crosshair") || !std::strcmp(name, "Crosshair Strokes"))
        return Icon::Crosshair;
    if (!std::strcmp(name, "Skybox")) return Icon::Sun;
    if (!std::strcmp(name, "Keystrokes")) return Icon::Keyboard;
    if (!std::strcmp(name, "FPS Counter")) return Icon::Activity;
    if (!std::strcmp(name, "Target HUD")) return Icon::Target;
    if (!std::strcmp(name, "Zoom")) return Icon::Maximize;
    if (!std::strcmp(name, "Hotbar")) return Icon::Grid;
    if (!std::strcmp(name, "Time Changer")) return Icon::Moon;
    if (!std::strcmp(name, "AutoSprint")) return Icon::Zap;
    if (!std::strcmp(name, "FullBright")) return Icon::Sun;
    if (!std::strcmp(name, "GUI Scale")) return Icon::Maximize;
    if (!std::strcmp(name, "Java Hotkeys")) return Icon::Keyboard;
    if (!std::strcmp(name, "NoHurtCam")) return Icon::Shield;
    if (!std::strcmp(name, "Potions")) return Icon::Activity;
    if (!std::strcmp(name, "Cooldowns")) return Icon::Activity;
    if (!std::strcmp(name, "Keybinds")) return Icon::Keyboard;
    if (!std::strcmp(name, "Motion Blur")) return Icon::Activity;
    if (!std::strcmp(name, "World Particles")) return Icon::Sparkles;
    return Icon::Box;
}
// Preview scene kind: 0 hud, 1 crosshair, 2 sky, 3 keys, 4 fps, 5 target, 6 zoom, 7 hotbar.
int ModulePreview(const char* name) {
    if (!name) return 0;
    if (!std::strcmp(name, "HUD")) return 0;
    if (!std::strcmp(name, "Crosshair")) return 1;
    if (!std::strcmp(name, "Skybox")) return 2;
    if (!std::strcmp(name, "Keystrokes")) return 3;
    if (!std::strcmp(name, "FPS Counter")) return 4;
    if (!std::strcmp(name, "Target HUD")) return 5;
    if (!std::strcmp(name, "Zoom")) return 6;
    if (!std::strcmp(name, "Hotbar")) return 7;
    if (!std::strcmp(name, "Time Changer")) return 2;
    return 0;
}
int EnabledCount() {
    int n = 0;
    for (const auto& m : modules().modules())
        if (m && !m->hiddenFromLists && m->enabled()) n++;
    return n;
}
int VisibleCount() {
    int n = 0;
    for (const auto& m : modules().modules())
        if (m && !m->hiddenFromLists) n++;
    return n;
}
Module* FindModule(const char* name) {
    for (const auto& m : modules().modules())
        if (m && !std::strcmp(m->name(), name)) return m.get();
    return nullptr;
}
void ApplyModuleState(Module* m, bool on) {
    if (!m || m->enabled() == on) return;
    m->setEnabled(on);
    LOG_INFO("menu: %s -> %s", m->name(), on ? "ON" : "OFF");
    ModulePhaseGuard::run(m, on ? ModulePhaseGuard::Phase::Enable
                                : ModulePhaseGuard::Phase::Disable);
}
void SetAccent(unsigned hex) {
    ThemesModule* tm = ThemesModule::instance();
    if (!tm || !tm->m_theme || !tm->m_colorSlots || !tm->m_color1) return;
    tm->m_theme->setValue(ThemesModule::ThemeCustom);
    tm->m_colorSlots->setValue(1.0f);
    tm->m_color1->mValue[0] = ((hex >> 16) & 255) / 255.0f;
    tm->m_color1->mValue[1] = ((hex >> 8) & 255) / 255.0f;
    tm->m_color1->mValue[2] = (hex & 255) / 255.0f;
    tm->m_color1->mValue[3] = 1.0f;
    LOG_INFO("menu: accent -> #%06X", hex);
}
bool IsAccent(unsigned hex) {
    ThemesModule* tm = ThemesModule::instance();
    if (!tm || !tm->m_theme || !tm->m_color1) return hex == 0xD97757;
    if (tm->m_theme->mValue != ThemesModule::ThemeCustom) return hex == 0xD97757;
    const float r = ((hex >> 16) & 255) / 255.0f;
    const float g = ((hex >> 8) & 255) / 255.0f;
    const float b = (hex & 255) / 255.0f;
    return std::fabs(tm->m_color1->mValue[0] - r) < 0.02f &&
           std::fabs(tm->m_color1->mValue[1] - g) < 0.02f &&
           std::fabs(tm->m_color1->mValue[2] - b) < 0.02f;
}

// ============================ widgets ============================
// Toggle pill (29x16). Returns true when clicked.
bool Toggle(Ctx& c, float x, float y, bool on, float& anim) {
    const float w = 29.0f, h = 16.0f;
    anim = gui::Animate(on ? 1.0f : 0.0f, anim, AF(c.dt, 12.0f));
    const bool hov = c.Hover(x, y, w, h);
    if (on) FillR(c, x, y, w, h, c.accent, h * 0.5f);
    else FillR(c, x, y, w, h, kTrack, h * 0.5f, hov ? 1.0f : 0.9f);
    const float kx = gui::Lerp(x + 8.0f, x + w - 8.0f, anim);
    ImColor kc = gui::LerpColor(kKnobOff, kKnobOn, anim);
    c.d->AddCircleFilled(c.P(kx, y + h * 0.5f), c.px(5.0f),
        ImColor(kc.Value.x, kc.Value.y, kc.Value.z, c.alpha), 14);
    return hov && c.Clicked();
}
// Primary / secondary button with optional leading icon. Returns clicked.
bool Button(Ctx& c, float x, float y, float w, float h, const char* label,
            bool primary, unsigned iconCp = 0, float iconPx = 15.0f, bool enabled = true) {
    const bool hov = enabled && c.Hover(x, y, w, h);
    const float ha = HoverAnim(HashStr(label, (unsigned)(x * 3 + y * 7 + (primary ? 1 : 0))), hov, c.dt);
    const float lift = primary ? ha * 1.0f : 0.0f;
    const float am = enabled ? 1.0f : 0.45f;
    if (primary) {
        FillR(c, x, y - lift, w, h, gui::LerpColor(c.accent, ImColor(255, 255, 255), ha * 0.12f),
              6.0f, am);
    } else {
        FillR(c, x, y, w, h, gui::LerpColor(kSecBg, Hex(0x2B3026), ha), 6.0f, am);
        StrokeR(c, x, y, w, h, gui::LerpColor(kSecBorder, Hex(0x596548), ha), 6.0f, 1.0f, am);
    }
    const ImColor fg = primary ? kBtnText : kSecText;
    float contentW = TextW(fonts::UISemi(), label, 10, c.s);
    if (iconCp) contentW += iconPx + 8.0f;
    float cx = x + (w - contentW) * 0.5f;
    const float cy = y - lift + h * 0.5f;
    if (iconCp) {
        IconGlyph(c, iconCp, cx + iconPx * 0.5f, cy, iconPx, fg, am);
        cx += iconPx + 8.0f;
    }
    Text(c, cx, cy - TextH(fonts::UISemi(), 10, c.s) * 0.5f, label, fonts::UISemi(), 10, fg, am);
    return enabled && hov && c.Clicked();
}
// Trailing-icon variant (label + icon after, e.g. "Сохранить конфиг ↗").
bool ButtonTrail(Ctx& c, float x, float y, float w, float h, const char* label,
                 bool primary, unsigned iconCp, float iconPx = 13.0f) {
    const bool hov = c.Hover(x, y, w, h);
    const float ha = HoverAnim(HashStr(label, (unsigned)(x * 5 + y * 11 + 77)), hov, c.dt);
    if (primary) {
        FillR(c, x, y, w, h, gui::LerpColor(c.accent, ImColor(255, 255, 255), ha * 0.12f), 6.0f);
    } else {
        FillR(c, x, y, w, h, gui::LerpColor(kSecBg, Hex(0x2B3026), ha), 6.0f);
        StrokeR(c, x, y, w, h, gui::LerpColor(kSecBorder, Hex(0x596548), ha), 6.0f, 1.0f);
    }
    const ImColor fg = primary ? kBtnText : kSecText;
    const float contentW = TextW(fonts::UISemi(), label, 10, c.s) + 8.0f + iconPx;
    const float cx = x + (w - contentW) * 0.5f;
    const float cy = y + h * 0.5f;
    Text(c, cx, cy - TextH(fonts::UISemi(), 10, c.s) * 0.5f, label, fonts::UISemi(), 10, fg);
    IconGlyph(c, iconCp, cx + contentW - iconPx * 0.5f, cy, iconPx, fg);
    return hov && c.Clicked();
}
// Text link (label + optional trailing icon). Width auto-measured.
bool TextLink(Ctx& c, float x, float y, const char* label, unsigned iconCp = 0,
              float pt = 9.0f, float iconPx = 13.0f) {
    float w = TextW(fonts::UISemi(), label, pt, c.s);
    if (iconCp) w += 5.0f + iconPx;
    const float h = std::max(TextH(fonts::UISemi(), pt, c.s), iconPx) + 4.0f;
    const bool hov = c.Hover(x, y - 2, w, h);
    const float ha = HoverAnim(HashStr(label, (unsigned)(x + y * 3 + pt)), hov, c.dt);
    const ImColor col = gui::LerpColor(Hex(0xA7ACA3), c.accent, ha);
    Text(c, x, y, label, fonts::UISemi(), pt, col);
    if (iconCp)
        IconGlyph(c, iconCp, x + w - iconPx * 0.5f,
                  y + TextH(fonts::UISemi(), pt, c.s) * 0.5f, iconPx, col);
    return hov && c.Clicked();
}
// Small square icon button. Returns clicked.
bool IconButton(Ctx& c, float x, float y, float sz, unsigned iconCp, float iconPx) {
    const bool hov = c.Hover(x, y, sz, sz);
    const float ha = HoverAnim(HashStr("ib", (unsigned)(x * 7 + y * 13 + iconCp)), hov, c.dt);
    if (ha > 0.01f) FillR(c, x, y, sz, sz, Hex(0x282C25), 5.0f, ha);
    IconGlyph(c, iconCp, x + sz * 0.5f, y + sz * 0.5f, iconPx,
              gui::LerpColor(Hex(0x888D94), c.accent, ha));
    return hov && c.Clicked();
}
// Keybind keycap. Width auto-measured. Click handled by caller.
float KeycapW(const Ctx& c, const char* label) {
    return TextW(fonts::Title(), label, 11, c.s) + 18.0f;
}
void Keycap(const Ctx& c, float x, float y, const char* label, bool listening) {
    const float w = KeycapW(c, label), h = 24.0f;
    FillR(c, x, y, w, h, Hex(0x26282B), 4.0f);
    if (listening) StrokeR(c, x, y, w, h, c.accent, 4.0f, 1.0f);
    else StrokeR(c, x, y, w, h, Hex(0x35393C), 4.0f, 1.0f);
    const float tw = TextW(fonts::Title(), label, 11, c.s);
    Text(c, x + (w - tw) * 0.5f, y + (h - TextH(fonts::Title(), 11, c.s)) * 0.5f,
         label, fonts::Title(), 11, listening ? c.accent : Hex(0xC7CBCE));
}
// Float slider (thin glass track). Returns hovered.
void SetSliderFromMouse(const Ctx& c, float x, float w, float* v, float mn, float mx) {
    const float mouseX = c.Mouse().x;
    const float t = gui::Clamp((mouseX - x) / std::max(1.0f, w), 0.0f, 1.0f);
    *v = mn + t * (mx - mn);
}

// Gooey effect (libraries.dev/gooey flavor) for sliders: the knob is a
// liquid blob that stretches along its velocity and trails merging droplets
// behind it. State is keyed by the bound float pointer.
struct GooSlider { const float* v; float lastFx; float stretch; };
static GooSlider g_gooSliders[24] = {};

// r25: interactive color picker state (module settings cards). Clicking a
// color row expands an inline HSV editor under it; dragging anywhere inside
// captures until release, exactly like the slider goo capture.
static Setting* g_colorEditSetting = nullptr;   // currently expanded row
static Setting* g_colorDrag = nullptr;          // active drag capture
static int g_colorDragArea = 0;                 // 0 = SV square, 1 = hue, 2 = alpha
static ImVec4 g_colorDragRect = ImVec4(0, 0, 0, 0);
static Ctx g_colorDragCtx;
static float g_colorHue = 0.0f;                 // stable hue cache while open

static void ColorRgbToHsvF(float r, float g, float b, float* h, float* s, float* v) {
    const float mx = std::max(r, std::max(g, b));
    const float mn = std::min(r, std::min(g, b));
    *v = mx;
    const float d = mx - mn;
    *s = mx <= 0.0f ? 0.0f : d / mx;
    if (d <= 0.0f) { *h = 0.0f; return; }
    float hh;
    if (mx == r) hh = (g - b) / d + (g < b ? 6.0f : 0.0f);
    else if (mx == g) hh = (b - r) / d + 2.0f;
    else hh = (r - g) / d + 4.0f;
    *h = hh / 6.0f;
}

// r25: apply one drag sample to the captured color setting.
static void ApplyColorDrag(ColorSetting* cs) {
    if (!cs) return;
    const Ctx& c = g_colorDragCtx;
    const ImVec2 m = c.Mouse();
    if (g_colorDragArea == 0) {
        const float rw = std::max(1.0f, g_colorDragRect.z - g_colorDragRect.x);
        const float rh = std::max(1.0f, g_colorDragRect.w - g_colorDragRect.y);
        const float sat = gui::Clamp((m.x - g_colorDragRect.x) / rw, 0.0f, 1.0f);
        const float val = 1.0f - gui::Clamp((m.y - g_colorDragRect.y) / rh, 0.0f, 1.0f);
        const ImColor rgb = ImColor::HSV(g_colorHue, sat, val, 1.0f);
        cs->mValue[0] = rgb.Value.x;
        cs->mValue[1] = rgb.Value.y;
        cs->mValue[2] = rgb.Value.z;
    } else if (g_colorDragArea == 1) {
        const float rh = std::max(1.0f, g_colorDragRect.w - g_colorDragRect.y);
        g_colorHue = gui::Clamp((m.y - g_colorDragRect.y) / rh, 0.0f, 1.0f);
        float h, sat, val;
        ColorRgbToHsvF(cs->mValue[0], cs->mValue[1], cs->mValue[2], &h, &sat, &val);
        const ImColor rgb = ImColor::HSV(g_colorHue, sat, val, 1.0f);
        cs->mValue[0] = rgb.Value.x;
        cs->mValue[1] = rgb.Value.y;
        cs->mValue[2] = rgb.Value.z;
    } else {
        const float rw = std::max(1.0f, g_colorDragRect.z - g_colorDragRect.x);
        cs->mValue[3] = gui::Clamp((m.x - g_colorDragRect.x) / rw, 0.0f, 1.0f);
    }
}

static void UpdateColorDrag() {
    if (!g_colorDrag) return;
    // Same capture-release semantics as UpdateFloatDrag: a transient missing
    // Down bit while the game suppresses input must not drop the drag.
    const bool released = overlay::g_guiMouseReleased[0] || ImGui::IsMouseReleased(0);
    const bool pressedAgain = overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0);
    if (released && !pressedAgain) {
        g_colorDrag = nullptr;
        return;
    }
    ApplyColorDrag(static_cast<ColorSetting*>(g_colorDrag));
}

static GooSlider* GooSliderFor(const float* v) {
    for (GooSlider& g : g_gooSliders)
        if (g.v == v) return &g;
    for (GooSlider& g : g_gooSliders) {
        if (!g.v) { g.v = v; g.lastFx = -1.0f; g.stretch = 0.0f; return &g; }
    }
    return &g_gooSliders[0];
}

bool SliderF(Ctx& c, float x, float y, float w, float* v, float mn, float mx) {
    const float trackH = 4.0f, knobR = 7.0f;
    const float cy = y + knobR;
    // Make the hit band larger than the 4px visual line. This is important at
    // scaled resolutions and also makes the HUD editor feel like a real
    // control instead of requiring pixel-perfect clicks.
    const bool hov = c.Hover(x - 8, y - 9, w + 16, knobR * 2 + 18);
    const float t = gui::Clamp((*v - mn) / std::max(0.0001f, mx - mn), 0.0f, 1.0f);
    const float fx = x + t * w;

    // Velocity-stretched blob: squash & stretch along the motion, decaying
    // back to a round knob when idle.
    GooSlider* goo = GooSliderFor(v);
    const float gdt = std::max(0.001f, gui::GetDeltaTime());
    const float vx = (goo->lastFx >= 0.0f && std::fabs(fx - goo->lastFx) < 60.0f)
                         ? (fx - goo->lastFx) / gdt
                         : 0.0f;
    goo->lastFx = fx;
    goo->stretch += (gui::Clamp(vx / 750.0f, -1.0f, 1.0f) - goo->stretch) *
                    std::min(1.0f, gdt * 12.0f);
    const float st = goo->stretch;

    FillR(c, x, cy - trackH * 0.5f, w, trackH, kTrack, trackH * 0.5f);
    if (t > 0.001f) FillR(c, x, cy - trackH * 0.5f, fx - x, trackH, c.accent, trackH * 0.5f, 0.95f);

    const ImU32 knobCol = ImGui::GetColorU32(
        ImVec4(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha));
    const ImU32 knobGlow = ImGui::GetColorU32(
        ImVec4(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha * 0.25f));
    const float rx = c.px(knobR * (1.0f + 0.85f * std::fabs(st)));
    const float ry = c.px(knobR * (1.0f - 0.30f * std::fabs(st)));
    // Soft halo first, then the solid blob and its trailing droplets (drawn
    // opaque so they merge seamlessly, like touching goo).
    c.d->AddEllipseFilled(c.P(fx, cy), ImVec2(rx * 1.7f, ry * 1.7f), knobGlow, 0.0f, 16);
    if (std::fabs(st) > 0.04f) {
        const float dir = st >= 0.0f ? 1.0f : -1.0f;
        for (int k = 3; k >= 1; --k) {
            const float tx = fx - dir * (float)k * 6.5f * std::fabs(st) *
                                      (1.0f + std::fabs(st));
            const float tr = c.px(knobR * (0.78f - 0.16f * (float)k));
            c.d->AddCircleFilled(c.P(tx, cy), tr, knobCol, 14);
        }
    }
    c.d->AddEllipseFilled(c.P(fx, cy), ImVec2(rx, ry), knobCol, 0.0f, 16);
    // Refresh the captured geometry from the currently rendered slider. The
    // reference shell can move while dragging (scroll, animation, GUI-scale
    // slider itself); keeping the first-frame Ctx made the drag appear frozen
    // until the menu was closed and reopened.
    if (g_dragV == v && !overlay::g_guiMouseReleased[0]) {
        g_dragMin = mn;
        g_dragMax = mx;
        g_dragRect = ImVec4(x, y, x + w, y + knobR * 2);
        g_dragCtx = c;
        SetSliderFromMouse(c, x, w, v, mn, mx);
    }
    if (hov && c.Clicked() && !g_dragV) {
        g_dragV = v; g_dragMin = mn; g_dragMax = mx;
        g_dragRect = ImVec4(x, y, x + w, y + knobR * 2);
        g_dragCtx = c;
        // A click is also a valid slider operation. Update immediately rather
        // than waiting for the next frame's drag update.
        SetSliderFromMouse(c, x, w, v, mn, mx);
    }
    return hov;
}
// SystemDLC flavor: a small value bubble riding on the slider knob, so the
// current value is readable right at the control (module settings cards).
void SliderBubble(Ctx& c, float x, float y, float w, const float* v,
                  float mn, float mx, float step) {
    if (!v || mx <= mn) return;
    if (g_dragV != v && !c.Hover(x - 8, y - 9, w + 16, 32)) return;
    const float t = gui::Clamp((*v - mn) / std::max(0.0001f, mx - mn), 0.0f, 1.0f);
    char b[24];
    if (step >= 1.0f) snprintf(b, sizeof(b), "%.0f", *v);
    else if (step >= 0.1f) snprintf(b, sizeof(b), "%.1f", *v);
    else snprintf(b, sizeof(b), "%.2f", *v);
    const float bw = TextW(fonts::UISemi(), b, 9, c.s) + 12.0f;
    const float bx = gui::Clamp(x + w * t - bw * 0.5f, x - 2.0f, x + w - bw + 2.0f);
    const float by = y - 23.0f;
    FillR(c, bx, by, bw, 16.0f, Hex(0x1B211B), 6.0f, 0.96f);
    StrokeR(c, bx, by, bw, 16.0f, c.accent, 6.0f, 1.0f, 0.85f);
    Text(c, bx + 6.0f, by + (16.0f - TextH(fonts::UISemi(), 9, c.s)) * 0.5f, b,
         fonts::UISemi(), 9, c.accent);
}
void UpdateFloatDrag() {
    if (!g_dragV) return;
    // A drag is an explicit GUI capture: keep it alive until a release edge
    // arrives. In the in-world relative-input path the continuous Down bit can
    // be absent for a frame while W/game input is being suppressed; treating
    // that transient gap as a release reduces the slider to click-only mode.
    const bool released = overlay::g_guiMouseReleased[0] || ImGui::IsMouseReleased(0);
    const bool pressedAgain = overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0);
    if (released && !pressedAgain) {
        g_dragV = nullptr;
        return;
    }
    const Ctx& c = g_dragCtx;
    const float x = c.Mouse().x;
    const float t = gui::Clamp((x - g_dragRect.x) / std::max(1.0f, g_dragRect.z - g_dragRect.x),
                               0.0f, 1.0f);
    *g_dragV = g_dragMin + t * (g_dragMax - g_dragMin);
}
// Accent color dot with selected ring. Returns clicked.
bool ColorDot(const Ctx& c, float x, float y, float d, const ImColor& col, bool selected) {
    const bool hov = c.Hover(x - 3, y - 3, d + 6, d + 6);
    c.d->AddCircleFilled(c.P(x + d * 0.5f, y + d * 0.5f), c.px(d * 0.5f),
        ImColor(col.Value.x, col.Value.y, col.Value.z, c.alpha), 18);
    if (selected) {
        c.d->AddCircle(c.P(x + d * 0.5f, y + d * 0.5f), c.px(d * 0.5f + 3.0f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 18, c.px(1.2f));
        IconGlyph(c, Icon::Check, x + d * 0.5f, y + d * 0.5f, 8.0f, Hex(0x20291D));
    } else if (hov) {
        c.d->AddCircle(c.P(x + d * 0.5f, y + d * 0.5f), c.px(d * 0.5f + 3.0f),
            ImColor(1.0f, 1.0f, 1.0f, c.alpha * 0.35f), 18, c.px(1.0f));
    }
    return hov && c.Clicked();
}
void EndStringEdit(bool keep);
// Text field (search / profile name). Claim flag set by caller via out param.
void TextField(Ctx& c, float x, float y, float w, float h, Field::Kind kind,
               char* buf, size_t cap, const char* placeholder, bool searchIcon) {
    const bool hov = c.Hover(x, y, w, h);
    const bool active = g_field.kind == kind;
    FillR(c, x, y, w, h, kField, 7.0f);
    if (kind == Field::Search) StrokeR(c, x, y, w, h, active ? c.accent : kBorder, 7.0f, 1.0f);
    else StrokeR(c, x, y, w, h, active ? c.accent : Hex(0x414D35), 7.0f, active ? 1.3f : 1.0f);
    float tx = x + 12.0f;
    if (searchIcon) {
        IconGlyph(c, Icon::Search, x + 20, y + h * 0.5f, 15.0f, kMuted);
        tx = x + 38.0f;
    }
    const bool empty = buf[0] == 0;
    const float th = TextH(fonts::UI(), 13, c.s);
    const float maxW = w - (tx - x) - (kind == Field::Search ? 52.0f : 12.0f);
    // Clip long text on the left (keep the caret visible).
    const char* shown = empty ? placeholder : buf;
    std::string vis;
    if (!empty) {
        vis = buf;
        while (vis.size() > 4 && TextW(fonts::UI(), vis.c_str(), 13, c.s) > maxW) {
            size_t bytes = 1;
            while (bytes < vis.size() && ((unsigned char)vis[bytes] & 0xC0) == 0x80) ++bytes;
            vis.erase(0, bytes);
        }
        shown = vis.c_str();
    }
    Text(c, tx, y + (h - th) * 0.5f, shown, fonts::UI(), 13,
         empty ? kMuted : kText, 1.0f);
    if (active && ((ImGui::GetFrameCount() / 30) % 2 == 0)) {
        const float tw = empty ? 0.0f : TextW(fonts::UI(), shown, 13, c.s);
        FillR(c, tx + tw + 2, y + 8, 1.6f, h - 16, c.accent, 0.0f, 0.9f);
    }
    if (kind == Field::Search) {
        // "Ctrl K" hint keycap.
        const char* hint = "Ctrl K";
        const float hw = TextW(fonts::UI(), hint, 11, c.s) + 10.0f;
        FillR(c, x + w - hw - 8, y + (h - 18) * 0.5f, hw, 18, kTrack, 4.0f);
        StrokeR(c, x + w - hw - 8, y + (h - 18) * 0.5f, hw, 18, kBorder, 4.0f, 1.0f);
        Text(c, x + w - hw - 8 + 5, y + (h - TextH(fonts::UI(), 11, c.s)) * 0.5f,
             hint, fonts::UI(), 11, kMuted);
    }
    if (hov && c.Clicked() && !active) {
        EndStringEdit(true);
        g_keyEditSetting = nullptr;
        keys::TextInput(nullptr, 0, false);
        g_field.kind = kind;
    }
}
bool EnterPressed() {
    return keys::PressedThisFrame(VK_RETURN) || keys::PressedThisFrame(VK_SEPARATOR);
}

void UpdateTextField() {
    if (g_field.kind == Field::None) return;
    char* buf = g_field.kind == Field::Search ? g_search : g_profileName;
    const size_t cap = g_field.kind == Field::Search ? sizeof(g_search) : sizeof(g_profileName);
    keys::TextInput(buf, cap, true);
    if (EnterPressed()) g_field.kind = Field::None;
}

// Cut a UTF-8 buffer to maxBytes without splitting a multi-byte sequence.
void TruncUtf8(char* buf, size_t maxBytes) {
    size_t len = std::strlen(buf);
    if (len <= maxBytes) return;
    len = maxBytes;
    while (len > 0 && ((unsigned char)buf[len] & 0xC0) == 0x80) --len;
    buf[len] = 0;
}
void NotifyTextHotkeysEdited(const Setting* s) {
    if (Module* th = modules().find("TextHotkeys"))
        static_cast<TextHotkeysModule*>(th)->onSlotEdited(s);
}
void PasteClipboard(char* buf, size_t cap) {
    if (!OpenClipboard(nullptr)) return;
    if (HANDLE h = GetClipboardData(CF_UNICODETEXT)) {
        if (const wchar_t* w = static_cast<const wchar_t*>(GlobalLock(h))) {
            std::wstring ws(w);
            GlobalUnlock(h);
            for (auto& ch : ws) if (ch == L'\r' || ch == L'\n' || ch == L'\t') ch = L' ';
            const int required = WideCharToMultiByte(CP_UTF8, 0, ws.c_str(), -1,
                                                     nullptr, 0, nullptr, nullptr);
            const size_t len = std::strlen(buf);
            if (required > 1 && len + 1 < cap) {
                std::string u8((size_t)required, '\0');
                if (WideCharToMultiByte(CP_UTF8, 0, ws.c_str(), -1,
                                       &u8[0], required, nullptr, nullptr) > 0) {
                    size_t take = std::min(cap - len - 1, (size_t)required - 1);
                    while (take > 0 && ((unsigned char)u8[take] & 0xC0) == 0x80) --take;
                    std::memcpy(buf + len, u8.data(), take);
                    buf[len + take] = 0;
                }
            }
        }
    }
    CloseClipboard();
}
void EndStringEdit(bool keep) {
    if (!g_stringEditSetting) return;
    if (!keep) g_stringEditSetting->mValue = g_stringEditOriginal;
    else NotifyTextHotkeysEdited(g_stringEditSetting);
    g_stringEditSetting = nullptr;
    g_stringEditBuf[0] = 0;
    g_stringEditOriginal.clear();
}
void BeginStringEdit(StringSetting* ss) {
    if (g_stringEditSetting == ss) return;
    EndStringEdit(true);
    g_field.kind = Field::None; // only one consumer of the text queue
    g_keyEditSetting = nullptr;
    keys::TextInput(nullptr, 0, false);          // drop stale queued chars
    g_stringEditSetting = ss;
    g_stringEditOriginal = ss->mValue;
    keys::SetTextCapture(true); // explicit field focus, including CoreWindow hosting
    LOG_INFO("input-r2: text field focused: %s", ss->mName.c_str());
    std::snprintf(g_stringEditBuf, sizeof(g_stringEditBuf), "%s", ss->mValue.c_str());
}

// r34: live editing - every typed character is written straight into the
// setting (autosave picks it up), so closing the menu or clicking away never
// loses text. Enter / click-away = done, ESC = revert, Ctrl+V = paste.
void UpdateStringField() {
    if (!g_stringEditSetting) return;
    const size_t maxLen = std::min(g_stringEditSetting->mMaxLength, sizeof(g_stringEditBuf) - 1);
    if (keys::Down(VK_CONTROL) && keys::PressedThisFrame('V'))
        PasteClipboard(g_stringEditBuf, sizeof(g_stringEditBuf));
    const bool typed = keys::TextInput(g_stringEditBuf, sizeof(g_stringEditBuf), true);
    if (typed) {
        static ULONGLONG nextTextDiag = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextTextDiag) {
            nextTextDiag = now + 1000;
            LOG_INFO("input-r2: text accepted (%u bytes)", (unsigned)std::strlen(g_stringEditBuf));
        }
    }
    TruncUtf8(g_stringEditBuf, maxLen);
    g_stringEditSetting->mValue = g_stringEditBuf;
    if (EnterPressed()) EndStringEdit(true);
}

void UpdateKeyField() {
    if (!g_keyEditSetting) return;
    for (int vk = 8; vk <= 0xFE; ++vk) {
        if (!keys::PressedThisFrame((unsigned)vk)) continue;
        if (vk == VK_ESCAPE) { g_keyEditSetting = nullptr; return; }
        if (vk == VK_BACK || vk == VK_DELETE) {
            g_keyEditSetting->setValue(0.0f);
            g_keyEditSetting = nullptr;
            Toast("Бинд сброшен");
            return;
        }
        if (vk == overlay::g_menuKey || vk == VK_END) {
            Toast("%s зарезервирована клиентом", keys::Name((unsigned)vk));
            continue;
        }
        // Generic modifiers arrive together with their L/R variant: prefer
        // the plain one so the bind fires whichever side is pressed.
        g_keyEditSetting->setValue((float)vk);
        NotifyTextHotkeysEdited(g_keyEditSetting);
        g_keyEditSetting = nullptr;
        Toast("Бинд: %s", keys::Name((unsigned)vk));
        break;
    }
}

// ============================ navigation ============================
void NavTo(Page p) {
    g_page = p;
    g_search[0] = 0;
    g_category = 0;
    g_field.kind = Field::None;
    EndStringEdit(true);
    g_keyEditSetting = nullptr;
    g_notif = false;
}

// ============================ module preview art ============================
// Procedural scenes for the 8 preview kinds. All coordinates are relative to
// (x, y, w, h); scale/alpha come from the caller's ctx.
void PreviewHud(const Ctx& c, float x, float y, float w, float h) {
    const float k = h / 105.0f;   // designed at 105px tall
    const float bx = x + 8 * k, by = y + 26 * k;
    const float bw = 150 * k, bh = 24 * k;
    FillR(c, bx, by, bw, bh, Hex(0x222B1B), 4.0f, 0.9f);
    StrokeR(c, bx, by, bw, bh, Hex(0x485236), 4.0f, 1.0f, 0.4f);
    Logo(c, bx + 6 * k, by + (bh - 12 * k) * 0.5f, 11 * k, c.accent);
    Text(c, bx + 21 * k, by + (bh - TextH(fonts::Title(), 9, c.s)) * 0.5f,
         "nightfull", fonts::Title(), 9, c.accent);
    const float sx = bx + 21 * k + TextW(fonts::Title(), "nightfull", 9, c.s) + 6 * k;
    c.d->AddLine(c.P(sx, by + 6 * k), c.P(sx, by + bh - 6 * k),
                 ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha * 0.3f),
                 c.px(1.0f));
    Text(c, sx + 4 * k, by + (bh - TextH(fonts::Title(), 6, c.s)) * 0.5f,
         "144 FPS", fonts::Title(), 6, c.accent);
    const float sx2 = sx + 4 * k + TextW(fonts::Title(), "144 FPS", 6, c.s) + 5 * k;
    c.d->AddLine(c.P(sx2, by + 6 * k), c.P(sx2, by + bh - 6 * k),
                 ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha * 0.3f),
                 c.px(1.0f));
    Text(c, sx2 + 4 * k, by + (bh - TextH(fonts::Title(), 6, c.s)) * 0.5f,
         "24 ms", fonts::Title(), 6, c.accent);
    // coords chip
    const float cy = by + bh + 6 * k;
    FillR(c, bx + 2 * k, cy, 96 * k, 16 * k, Hex(0x22251C), 3.0f);
    StrokeR(c, bx + 2 * k, cy, 96 * k, 16 * k, Hex(0x3F4533), 3.0f, 1.0f);
    Text(c, bx + 7 * k, cy + 3 * k, "XYZ 128, 64, -256", fonts::UI(), 6, c.accent);
    // level bars
    for (int i = 0; i < 8; i++) {
        const float bxi = x + w - (18 + (7 - i) * 7) * k;
        FillR(c, bxi, y + h - 28 * k, 5 * k, 8 * k, c.accent, 1.0f, i == 7 ? 0.2f : 0.8f);
    }
}
void PreviewCrosshair(const Ctx& c, float x, float y, float w, float h) {
    const float cx = x + w * 0.5f, cy = y + h * 0.5f - 4.0f;
    const float k = h / 105.0f;
    c.d->AddCircle(c.P(cx, cy), c.px(34.5f * k),
        ImColor(0x53 / 255.0f, 0x62 / 255.0f, 0x41 / 255.0f, c.alpha * 0.35f), 40, c.px(1.0f));
    // dashed outer ring
    for (int i = 0; i < 28; i++) {
        const float a0 = i * 6.2831853f / 28.0f, a1 = a0 + 6.2831853f / 28.0f * 0.55f;
        c.d->AddLine(c.P(cx + std::cos(a0) * 50 * k, cy + std::sin(a0) * 50 * k),
                     c.P(cx + std::cos(a1) * 50 * k, cy + std::sin(a1) * 50 * k),
            ImColor(0x53 / 255.0f, 0x62 / 255.0f, 0x41 / 255.0f, c.alpha * 0.5f), c.px(1.0f));
    }
    IconGlyph(c, Icon::Crosshair, cx, cy, 38.0f * k, c.accent);
    const char* cap = "Твой фокус. Твой стиль.";
    Text(c, cx - TextW(fonts::UI(), cap, 6, c.s) * 0.5f, y + h - 13 * k,
         cap, fonts::UI(), 6, Hex(0x64705C));
}
void PreviewSky(const Ctx& c, float x, float y, float w, float h) {
    StrokeR(c, x, y, w, h, Hex(0xC2A2CA), 5.0f, 1.0f, 0.08f);
    Ctx ci = c;
    ci.d->PushClipRect(c.P(x, y), c.P(x + w, y + h), true);
    FillGradV(ci, x, y, w, h * 0.6f, Hex(0x202132), Hex(0x4A3B58), 1.0f, 1.0f);
    FillGradV(ci, x, y + h * 0.6f, w, h * 0.4f, Hex(0x4A3B58), Hex(0xB17E77), 1.0f, 0.5f);
    const float k = h / 105.0f;
    // sun + glow
    const float sunx = x + w - 45 * k - 18 * k, suny = y + 24 * k + 18 * k;
    c.d->AddCircleFilled(ci.P(sunx, suny), ci.px(30 * k),
        ImColor(0xDF / 255.0f, 0x9D / 255.0f, 0x98 / 255.0f, ci.alpha * 0.25f), 24);
    c.d->AddCircleFilled(ci.P(sunx, suny), ci.px(18 * k),
        ImColor(0xE8 / 255.0f, 0xB2 / 255.0f, 0x9D / 255.0f, ci.alpha), 24);
    // orbit ellipse
    {
        const float ex = x + 7 * k + 70 * k, ey = y + 8 * k + 35 * k;
        const float rx = 70 * k, ry = 35 * k, rot = -25.0f * 3.14159265f / 180.0f;
        ImVec2 prev = ci.P(ex + (std::cos(0.0f) * rx) * std::cos(rot) - (std::sin(0.0f) * ry) * std::sin(rot),
                            ey + (std::cos(0.0f) * rx) * std::sin(rot) + (std::sin(0.0f) * ry) * std::cos(rot));
        for (int i = 1; i <= 40; i++) {
            const float a = i * 6.2831853f / 40.0f;
            const ImVec2 p = ci.P(ex + (std::cos(a) * rx) * std::cos(rot) - (std::sin(a) * ry) * std::sin(rot),
                                  ey + (std::cos(a) * rx) * std::sin(rot) + (std::sin(a) * ry) * std::cos(rot));
            ci.d->AddLine(prev, p, ImColor(0xCE, 0xBD, 0xD7, (int)(ci.alpha * 30)), ci.px(1.0f));
            prev = p;
        }
    }
    // mountains (back + front)
    {
        const float bh = 65 * k, fh = 47 * k;
        const float ry0 = y + h;
        const ImVec2 back[] = {
            ImVec2(x, ry0 - bh * 0.32f), ImVec2(x + w * 0.10f, ry0 - bh * 0.51f),
            ImVec2(x + w * 0.24f, ry0 - bh * 0.31f), ImVec2(x + w * 0.40f, ry0 - bh * 0.61f),
            ImVec2(x + w * 0.52f, ry0 - bh * 0.40f), ImVec2(x + w * 0.67f, ry0 - bh * 0.70f),
            ImVec2(x + w * 0.82f, ry0 - bh * 0.35f), ImVec2(x + w, ry0 - bh * 0.53f),
        };
        FillRidge(ci, back, 8, ry0, Hex(0x3D3348));
        const ImVec2 front[] = {
            ImVec2(x, ry0 - fh * 0.32f), ImVec2(x + w * 0.18f, ry0 - fh * 0.52f),
            ImVec2(x + w * 0.32f, ry0 - fh * 0.26f), ImVec2(x + w * 0.50f, ry0 - fh * 0.53f),
            ImVec2(x + w * 0.68f, ry0 - fh * 0.30f), ImVec2(x + w * 0.83f, ry0 - fh * 0.53f),
            ImVec2(x + w, ry0 - fh * 0.31f),
        };
        FillRidge(ci, front, 7, ry0, Hex(0x242530));
    }
    // stars: dots + tiny diamonds (no exotic glyphs needed)
    Text(ci, x + 20 * k, y + 10 * k, "·   ·   ·", fonts::UI(), 12, Hex(0xD3B9C9), 0.65f);
    const ImU32 su = ImColor(0xD3, 0xB9, 0xC9, (int)(ci.alpha * 200));
    const ImVec2 d0 = ci.P(x + 78 * k, y + 14 * k);
    ci.d->AddQuadFilled(ImVec2(d0.x - 3 * k, d0.y), ImVec2(d0.x, d0.y - 4 * k),
                        ImVec2(d0.x + 3 * k, d0.y), ImVec2(d0.x, d0.y + 4 * k), su);
    ci.d->PopClipRect();
}
void KeyMini(const Ctx& c, float x, float y, float sz, const char* label, bool pressed) {
    if (pressed) FillR(c, x, y, sz, sz, c.accent, 4.0f);
    else {
        FillR(c, x, y, sz, sz, Hex(0x26311F), 4.0f);
        StrokeR(c, x, y, sz, sz, Hex(0x485738), 4.0f, 1.0f);
    }
    const float tw = TextW(fonts::Title(), label, 12, c.s);
    Text(c, x + (sz - tw) * 0.5f, y + (sz - TextH(fonts::Title(), 12, c.s)) * 0.5f,
         label, fonts::Title(), 12, pressed ? Hex(0x182011) : c.accent);
}
void PreviewKeys(const Ctx& c, float x, float y, float w, float h) {
    const float sz = 27.0f, gap = 4.0f;
    const float cx = x + w * 0.5f, cy = y + h * 0.5f;
    KeyMini(c, cx - sz * 0.5f, cy - sz - gap * 0.5f, sz, "W", false);
    KeyMini(c, cx - sz * 1.5f - gap, cy + gap * 0.5f, sz, "A", false);
    KeyMini(c, cx - sz * 0.5f, cy + gap * 0.5f, sz, "S", true);
    KeyMini(c, cx + sz * 0.5f + gap, cy + gap * 0.5f, sz, "D", false);
}
void PreviewFps(const Ctx& c, float x, float y, float w, float h) {
    const float cx = x + w * 0.5f, cy = y + h * 0.5f - 8.0f;
    IconGlyph(c, Icon::Activity, cx - 62, cy, 24.0f, c.accent);
    Text(c, cx - 42, cy - TextH(fonts::Title(), 33, c.s) * 0.5f - 2,
         "144", fonts::Title(), 33, c.accent);
    const float fx = cx - 42 + TextW(fonts::Title(), "144", 33, c.s) + 6;
    Text(c, fx, cy - TextH(fonts::Title(), 15, c.s) * 0.5f + 4,
         "FPS", fonts::Title(), 15, c.accent, 0.8f);
    const char* cap = "Стабильно. Плавно. Быстро.";
    Text(c, cx - TextW(fonts::UI(), cap, 8, c.s) * 0.5f, cy + 30,
         cap, fonts::UI(), 8, Hex(0x7D8B72));
}
void PreviewTarget(const Ctx& c, float x, float y, float w, float h) {
    const float bw = 175.0f, bh = 62.0f;
    const float bx = x + (w - bw) * 0.5f, by = y + (h - bh) * 0.5f;
    FillR(c, bx, by, bw, bh, Hex(0x262D21), 6.0f);
    StrokeR(c, bx, by, bw, bh, Hex(0x4C573B), 6.0f, 1.0f);
    // pixel face
    const float fx = bx + 12, fy = by + 12, fs = 38.0f;
    FillR(c, fx, fy, fs, fs, Hex(0x716648), 0.0f);
    FillR(c, fx + 8, fy + 10, 8, 8, Hex(0x3A3428), 0.0f);
    FillR(c, fx + 22, fy + 10, 8, 8, Hex(0x3A3428), 0.0f);
    FillR(c, fx + 8, fy + 24, 22, 4, Hex(0xBB9974), 0.0f);
    Text(c, fx + fs + 10, by + 12, "Steve", fonts::UISemi(), 10, kText);
    FillR(c, fx + fs + 10, by + 30, 95, 4, c.accent, 2.0f);
    Text(c, fx + fs + 10, by + 40, "20 / 20 HP", fonts::UI(), 7, Hex(0x8C9981));
}
void PreviewZoom(const Ctx& c, float x, float y, float w, float h) {
    IconGlyph(c, Icon::Maximize, x + w * 0.5f, y + h * 0.5f, 40.0f, c.accent);
}
void PreviewHotbar(const Ctx& c, float x, float y, float w, float h) {
    const float sz = 26.0f, gap = 4.0f;
    float sx = x + (w - (sz * 7 + gap * 6)) * 0.5f;
    const float sy = y + (h - sz) * 0.5f;
    for (int i = 0; i < 7; i++) {
        char b[4];
        snprintf(b, sizeof(b), "%d", i + 1);
        const bool sel = i == 2;
        if (sel) {
            FillR(c, sx + i * (sz + gap), sy, sz, sz, Hex(0x3C492F), 3.0f);
            StrokeR(c, sx + i * (sz + gap), sy, sz, sz, c.accent, 3.0f, 1.0f);
        } else {
            FillR(c, sx + i * (sz + gap), sy, sz, sz, Hex(0x282D23), 3.0f);
            StrokeR(c, sx + i * (sz + gap), sy, sz, sz, Hex(0x3F4736), 3.0f, 1.0f);
        }
        const float tw = TextW(fonts::UI(), b, 10, c.s);
        Text(c, sx + i * (sz + gap) + (sz - tw) * 0.5f,
             sy + (sz - TextH(fonts::UI(), 10, c.s)) * 0.5f,
             b, fonts::UI(), 10, sel ? c.accent : Hex(0x6F7F64));
    }
}
void ModulePreview(const Ctx& c, float x, float y, float w, float h, int kind) {
    if (kind != 2) {
        FillR(c, x, y, w, h, Hex(0x25331B), 5.0f, 0.22f);
        // soft radial feel: lighter center band
        FillR(c, x + w * 0.2f, y, w * 0.6f, h, Hex(0x2E3B22), 5.0f, 0.25f);
    }
    switch (kind) {
        case 0: PreviewHud(c, x, y, w, h); break;
        case 1: PreviewCrosshair(c, x, y, w, h); break;
        case 2: PreviewSky(c, x, y, w, h); break;
        case 3: PreviewKeys(c, x, y, w, h); break;
        case 4: PreviewFps(c, x, y, w, h); break;
        case 5: PreviewTarget(c, x, y, w, h); break;
        case 6: PreviewZoom(c, x, y, w, h); break;
        case 7: PreviewHotbar(c, x, y, w, h); break;
        default: break;
    }
}

// ============================ module card ============================
void ModuleCard(Ctx& c, Module* m, float x, float y, float w, float previewH,
                bool large, float& outH) {
    const float topPad = large ? 17.0f : 13.0f;
    const float sidePad = large ? 17.0f : 12.0f;
    const float infoPad = large ? 17.0f : 15.0f;
    const float namePt = large ? 16.0f : 12.0f;
    const float descPt = large ? 10.0f : 7.0f;
    const float h = topPad + 16.0f + 9.0f + previewH + 12.0f +
                    TextH(fonts::Title(), namePt, c.s) + 4.0f +
                    TextH(fonts::UI(), descPt, c.s) * 1.8f + infoPad;
    outH = h;
    const bool hov = c.Hover(x, y, w, h);
    const float ha = HoverAnim(HashStr(m->name(), 0xCAu), hov, c.dt);
    FillR(c, x, y - ha * 2.0f, w, h, gui::Accent(), 8.0f);
    StrokeR(c, x, y - ha * 2.0f, w, h, gui::LerpColor(Hex(0x2B2D30), Hex(0x48513E), ha),
            8.0f, 1.0f);
    Ctx cc = c;
    // top row: type + toggle
    IconGlyph(cc, ModuleIcon(m->name()), x + sidePad + 7, y + topPad + 8, 14.0f, Hex(0x979A9F));
    Text(cc, x + sidePad + 19, y + topPad + 8 - TextH(fonts::UI(), large ? 10.0f : 8.0f, cc.s) * 0.5f,
         m->category(), fonts::UI(), large ? 10.0f : 8.0f, Hex(0x979A9F));
    m->toggleAnim = gui::Animate(m->enabled() ? 1.0f : 0.0f, m->toggleAnim, AF(c.dt, 12.0f));
    if (Toggle(cc, x + w - sidePad - 29, y + topPad, m->enabled(), m->toggleAnim))
        ApplyModuleState(m, !m->enabled());
    // preview (click -> module modal)
    const float px = x + (large ? 10.0f : 8.0f), py = y + topPad + 16.0f + 9.0f;
    const float pw = w - (large ? 20.0f : 16.0f);
    ModulePreview(cc, px, py, pw, previewH, ModulePreview(m->name()));
    if (cc.Hover(px, py, pw, previewH) && cc.Clicked()) {
        g_selMod = m;
        g_moduleScroll = g_moduleScrollTo = 0.0f;
        g_modal = M_Module;
        g_modalAnim = 0.0f;
    }
    // info + gear
    const float iy = py + previewH + 12.0f;
    Text(cc, x + sidePad, iy, m->name(), fonts::Title(), namePt, kText);
    {
        // description: single line, ellipsis when overflowing
        const float dw = pw - sidePad - 4.0f - 24.0f;
        std::string desc = m->description();
        while (desc.size() > 8 && TextW(fonts::UI(), (desc + "...").c_str(), descPt, cc.s) > dw)
            desc.erase(desc.size() - 1);
        if (desc != m->description()) desc += "...";
        Text(cc, x + sidePad, iy + TextH(fonts::Title(), namePt, cc.s) + 4.0f,
             desc.c_str(), fonts::UI(), descPt, Hex(0x7F838A));
    }
    if (IconButton(cc, x + w - sidePad - 24, iy - 1, 24, Icon::Settings2, 15.0f)) {
        g_selMod = m;
        g_moduleScroll = g_moduleScrollTo = 0.0f;
        g_modal = M_Module;
        g_modalAnim = 0.0f;
    }
}

// ============================ sidebar ============================
void NavItem(Ctx& c, float y, unsigned icon, const char* label, bool active,
             const char* badge, unsigned rightIcon, bool dot, bool& outClicked) {
    const float x = 17.0f, w = kSideW - 34.0f, h = 40.0f;
    const bool hov = c.Hover(x, y, w, h);
    const float ha = HoverAnim(HashStr(label, active ? 0x4Bu : 0x4Au), hov, c.dt);
    if (active) FillR(c, x, y, w, h, gui::Accent(), 7.0f);
    else if (ha > 0.01f) FillR(c, x, y, w, h, Hex(0x202222), 7.0f, ha);
    if (active) FillR(c, 0, y + 10, 3, h - 20, c.accent, 0.0f);
    const ImColor fg = active ? c.accent : gui::LerpColor(Hex(0x91949B), Hex(0xE8ECE3), active ? 0 : ha);
    IconGlyph(c, icon, x + 13 + 9, y + h * 0.5f, 19.0f, fg);
    Text(c, x + 13 + 12 + 19, y + h * 0.5f - TextH(fonts::UISemi(), 11, c.s) * 0.5f,
         label, fonts::UISemi(), 11, fg);
    const float rx = x + w - 13.0f;
    if (badge) {
        const float bw = TextW(fonts::Title(), badge, 9, c.s) + 12.0f;
        FillR(c, rx - bw, y + (h - 18) * 0.5f, bw, 18,
              active ? Hex(0x37432A) : Hex(0x282A2C), 4.0f);
        Text(c, rx - bw + (bw - TextW(fonts::Title(), badge, 9, c.s)) * 0.5f,
             y + (h - TextH(fonts::Title(), 9, c.s)) * 0.5f,
             badge, fonts::Title(), 9, active ? c.accent : Hex(0xA3A6AA));
    } else if (rightIcon) {
        IconGlyph(c, rightIcon, rx - 7, y + h * 0.5f, 14.0f, fg, 0.9f);
    } else if (dot) {
        c.d->AddCircleFilled(c.P(rx - 7, y + h * 0.5f), c.px(2.5f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 10);
    }
    outClicked = hov && c.Clicked();
}

void PaintSidebar(Ctx& c) {
    {
        const ImVec2 a = c.P(0, 0), b = c.P(kSideW, kMainH);
        gui::FillRect(ImVec4(a.x, a.y, b.x, b.y), gui::Accent(), c.alpha * 0.20f,
                      c.px(kMainR), c.d, ImDrawFlags_RoundCornersLeft);
        c.d->AddLine(c.P(kSideW, 0), c.P(kSideW, kMainH),
                     ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
    }
    // brand
    Logo(c, 24, 22, 26, c.accent);
    Text(c, 58, 20, "nightfull", fonts::Title(), 22, kText);
    Text(c, 59, 47, "BEDROCK CLIENT", fonts::UISemi(), 7, Hex(0x91948E));
    // workspace card
    {
        const float y = 70.0f;
        FillR(c, 17, y, kSideW - 34, 50, Hex(0x1B1D1E), 8.0f);
        StrokeR(c, 17, y, kSideW - 34, 50, Hex(0x2A2C2C), 8.0f, 1.0f);
        FillR(c, 26, y + 11, 29, 28, Hex(0x282D24), 6.0f);
        IconGlyph(c, Icon::Box, 26 + 14.5f, y + 25, 17.0f, c.accent);
        Text(c, 65, y + 10, "Личное пространство", fonts::UISemi(), 10, kText);
        Text(c, 65, y + 28, "Настройка модулей", fonts::UI(), 9, kMuted);
        IconGlyph(c, Icon::ChevronDown, kSideW - 30, y + 25, 14.0f, Hex(0x969990));
    }
    // nav
    Text(c, 31, 130, "ПРОСТРАНСТВО", fonts::UISemi(), 9, Hex(0x676A70));
    bool clicked = false;
    float y = 144.0f;
    NavItem(c, y, Icon::Dashboard, "Обзор", g_page == P_Overview, nullptr, 0, false, clicked);
    if (clicked) NavTo(P_Overview);
    y += 42.0f;
    {
        char badge[8];
        snprintf(badge, sizeof(badge), "%d", VisibleCount());
        // NavItem copies nothing: badge must outlive the call only.
        NavItem(c, y, Icon::Box, "Модули", g_page == P_Modules, badge, 0, false, clicked);
        if (clicked) NavTo(P_Modules);
    }
    y += 42.0f;
    NavItem(c, y, Icon::Monitor, "Редактор HUD", g_page == P_Hud, nullptr, 0, false, clicked);
    if (clicked) NavTo(P_Hud);
    y += 42.0f;
    NavItem(c, y, Icon::Palette, "Внешний вид", g_page == P_Themes, nullptr, 0, false, clicked);
    if (clicked) NavTo(P_Themes);
    y += 42.0f;
    NavItem(c, y, Icon::FolderHeart, "Конфигурации", g_page == P_Profiles, nullptr, 0, false, clicked);
    if (clicked) NavTo(P_Profiles);
    y += 42.0f;
    Text(c, 31, y + 2, "ПРОЕКТ", fonts::UISemi(), 9, Hex(0x676A70));
    y += 22.0f;
    NavItem(c, y, Icon::GitFork, "Репозитории", g_page == P_Sources, nullptr, Icon::ArrowUpRight,
            false, clicked);
    if (clicked) NavTo(P_Sources);
    y += 42.0f;
    NavItem(c, y, Icon::BookOpen, "Что нового", false, nullptr, 0, true, clicked);
    if (clicked) { g_modal = M_Update; g_modalAnim = 0.0f; }
    y += 42.0f;
    NavItem(c, y, Icon::Settings2, "Настройки", g_page == P_Settings, nullptr, 0, false, clicked);
    if (clicked) NavTo(P_Settings);
    // community card
    {
        const float cy = 508.0f;
        FillR(c, 17, cy, kSideW - 34, 112, Hex(0x1E231A), 9.0f);
        StrokeR(c, 17, cy, kSideW - 34, 112, Hex(0x2B3026), 9.0f, 1.0f);
        IconGlyph(c, Icon::Gamepad, 38, cy + 16, 20.0f, c.accent);
        IconGlyph(c, Icon::Sparkles, 54, cy + 10, 12.0f, c.accent);
        Text(c, 70, cy + 8, "Лучше вместе.", fonts::Bold(), 13, kText);
        Text(c, 31, cy + 34, "Идеи, обновления и люди,", fonts::UI(), 10, Hex(0x899081));
        Text(c, 31, cy + 50, "которые любят Minecraft.", fonts::UI(), 10, Hex(0x899081));
        if (TextLink(c, 31, cy + 72, "Сообщество", Icon::ArrowUpRight, 10.0f)) {
            ImGui::SetClipboardText("https://github.com/paramrrr23-maker/hamambanan/issues");
            Toast("Ссылка скопирована");
        }
    }
    // user profile
    {
        const float py = 630.0f;
        c.d->AddLine(c.P(17, py), c.P(kSideW - 17, py),
                     ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
        const bool hov = c.Hover(17, py + 6, kSideW - 34, 60);
        // avatar: minecraft-ish gradient + pixel eyes
        const float ax = 24, ay = py + 18;
        FillGradV(c, ax, ay, 33, 12, Hex(0x6B5040), Hex(0x6B5040), 1.0f, 1.0f);
        FillR(c, ax, ay + 10, 33, 16, Hex(0xBA9471), 0.0f);
        FillR(c, ax, ay + 22, 33, 12, Hex(0x536344), 0.0f);
        StrokeR(c, ax, ay, 33, 34, Hex(0x292B25), 7.0f, 3.0f);
        FillR(c, ax + 7, ay + 14, 6, 6, Hex(0x423D2B), 0.0f);
        FillR(c, ax + 20, ay + 14, 6, 6, Hex(0x423D2B), 0.0f);
        Text(c, 67, py + 22, "Player", fonts::UISemi(), 11, hov ? c.accent : kText);
        Text(c, 67, py + 40, "Локальный профиль", fonts::UI(), 9, kMuted);
        IconGlyph(c, Icon::Ellipsis, kSideW - 32, py + 36, 17.0f, Hex(0x8B8D93));
        if (hov && c.Clicked()) NavTo(P_Profiles);
    }
}

// ============================ topbar ============================
void PaintTopbar(Ctx& c, bool& fieldClaimed) {
    {
        const ImVec2 a = c.P(kSideW, 0), b = c.P(kMainW, kTopH);
        gui::FillRect(ImVec4(a.x, a.y, b.x, b.y), gui::Accent(), c.alpha * 0.20f,
                      c.px(kMainR), c.d, ImDrawFlags_RoundCornersTopRight);
        c.d->AddLine(c.P(kSideW, kTopH), c.P(kMainW, kTopH),
                     ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
    }
    // Compact local shell marker from the attached reference.
    {
        const char* shell = "NIGHTFULL  /  LOCAL";
        const float sw = TextW(fonts::UI(), shell, 8, c.s);
        Text(c, kSideW + (kMainW - kSideW - sw) * 0.5f, 10, shell,
             fonts::UI(), 8, Hex(0x69736C));
    }
    // breadcrumb
    Text(c, kContX, 30, "Пространство", fonts::UI(), 10, Hex(0x757881));
    const float bw = TextW(fonts::UI(), "Пространство", 10, c.s);
    IconGlyph(c, Icon::ChevronRight, kContX + bw + 14, 37, 13.0f, Hex(0x555960));
    Text(c, kContX + bw + 26, 30, kPageTitles[g_page], fonts::UISemi(), 10, Hex(0xC7C9CE));
    // search
    const float sw = 236.0f, sx = kMainW - 35 - 30 - 20 - 30 - 20 - sw;
    TextField(c, sx, 20, sw, 34, Field::Search, g_search, sizeof(g_search),
              "Найти модуль...", true);
    if (c.interact && c.Hover(sx, 20, sw, 34) && ImGui::IsMouseClicked(0)) fieldClaimed = true;
    // divider
    FillR(c, sx + sw + 10, 25, 1, 23, kBorder, 0.0f);
    // bell
    const float bellX = sx + sw + 21;
    if (IconButton(c, bellX, 22, 30, Icon::Bell, 19.0f)) {
        g_notif = !g_notif;
        g_notifRead = true;
        g_notifFrame = ImGui::GetFrameCount();
    }
    if (!g_notifRead)
        c.d->AddCircleFilled(c.P(bellX + 25, 25), c.px(2.5f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 10);
    // avatar
    const float avX = bellX + 30 + 19;
    c.d->AddCircleFilled(c.P(avX + 15, 37), c.px(15.0f),
        ImColor(0x15, 0x19, 0x17, (int)(c.alpha * 255)), 20);
    c.d->AddCircle(c.P(avX + 15, 37), c.px(15.0f),
        ImColor(0x2A, 0x32, 0x2C, (int)(c.alpha * 255)), 20, c.px(1.0f));
    {
        const char* p = "P";
        Text(c, avX + 15 - TextW(fonts::UISemi(), p, 11, c.s) * 0.5f,
             37 - TextH(fonts::UISemi(), 11, c.s) * 0.5f, p, fonts::UISemi(), 11, Hex(0xC1CEAF));
    }
    if (c.Hover(avX, 22, 30, 30) && c.Clicked()) NavTo(P_Profiles);
}
void PaintNotifPanel(Ctx& c) {
    if (!g_notif) return;
    const float w = 310.0f, h = 210.0f;
    const float x = kMainW - 354.0f, y = kTopH + 6.0f;
    Ctx o = c;
    o.offsetY = 0;
    FillR(o, x, y, w, h, Hex(0x1B1D1F), 10.0f);
    StrokeR(o, x, y, w, h, Hex(0x34373A), 10.0f, 1.0f);
    Text(o, x + 20, y + 20, "Уведомления", fonts::Bold(), 16, kText);
    Text(o, x + 20, y + 56, "Добро пожаловать в Nightfull", fonts::UISemi(), 12, kText);
    WrapText(o, x + 20, y + 78, w - 40, "Nightfull готов к настройке. Изменения сохраняются на этом устройстве.",
             fonts::UI(), 11, kMuted, 3);
    if (TextLink(o, x + 20, y + h - 32, "Посмотреть обновление", Icon::ArrowRight, 9.0f)) {
        g_modal = M_Update;
        g_modalAnim = 0.0f;
        g_notif = false;
    }
    if (o.interact && ImGui::GetFrameCount() != g_notifFrame &&
        ImGui::IsMouseClicked(0) && !o.Hover(x, y, w, h)) g_notif = false;
}

// ============================ page heading ============================
float PageHeading(Ctx& c, float y, bool overview, bool profiles) {
    Text(c, kContX, y, "ТВОЁ ПРОСТРАНСТВО. ТВОЙ NIGHTFULL.", fonts::UISemi(), 8, Hex(0x747B73));
    const char* title = overview ? "Всё начинается здесь" : kPageTitles[g_page];
    const float tw = TextW(fonts::Bold(), title, 27, c.s);
    Text(c, kContX, y + 16, title, fonts::Bold(), 27, kText);
    Text(c, kContX + tw + 2, y + 16, ".", fonts::Bold(), 27, c.accent);
    Text(c, kContX, y + 56, kPageSubs[g_page], fonts::UI(), 11, Hex(0x83868D));
    if (overview) {
        // build badge
        const char* b = "Nightfull  /  v0.1.0";
        const float bw = TextW(fonts::UI(), b, 9, c.s) + 34.0f;
        const float bx = kContX + kContW - bw, by = y + 18;
        FillR(c, bx, by, bw, 30, Hex(0x191D17), 6.0f);
        StrokeR(c, bx, by, bw, 30, Hex(0x30362A), 6.0f, 1.0f);
        c.d->AddCircleFilled(c.P(bx + 14, by + 15), c.px(2.5f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 10);
        Text(c, bx + 22, by + 15 - TextH(fonts::UI(), 9, c.s) * 0.5f, b, fonts::UI(), 9, Hex(0xA4AB9D));
    } else if (profiles) {
        if (Button(c, kContX + kContW - 200, y + 16, 200, 38, "Новая конфигурация",
                   true, Icon::Plus, 16.0f)) {
            g_modal = M_Save;
            g_modalAnim = 0.0f;
            g_profileName[0] = 0;
        }
    } else {
        if (Button(c, kContX + kContW - 150, y + 16, 150, 38, "Сохранить",
                   false, Icon::FolderHeart, 15.0f)) {
            g_modal = M_Save;
            g_modalAnim = 0.0f;
            g_profileName[0] = 0;
        }
    }
    return y + 100.0f;
}

// ============================ quick settings / tip ============================
float QuickSettings(Ctx& c, float x, float y, float w, bool showLink, bool tall) {
    GeneralModule* gm = GeneralModule::instance();
    const float h = tall ? 296.0f : (showLink ? 252.0f : 208.0f);
    FillR(c, x, y, w, h, gui::Accent(), 8.0f);
    StrokeR(c, x, y, w, h, Hex(0x2A2C2F), 8.0f, 1.0f);
    Text(c, x + 18, y + 18, "Быстрые настройки", fonts::Bold(), 12, kText);
    IconGlyph(c, Icon::Sliders, x + w - 30, y + 28, 16.0f, Hex(0x757B83));
    const float step = tall ? 44.0f : 36.0f;
    float ry = y + (tall ? 60.0f : 52.0f);
    // menu key row
    IconGlyph(c, Icon::Keyboard, x + 26, ry + 12, 16.0f, Hex(0x6E757C));
    Text(c, x + 42, ry + 12 - TextH(fonts::UI(), 9, c.s) * 0.5f,
         "Открыть ClickGUI", fonts::UI(), 9, Hex(0xA3A6AC));
    {
        const char* kn = g_listening ? "Нажмите…" : keys::Name((unsigned)overlay::g_menuKey);
        const float kw = KeycapW(c, kn);
        Keycap(c, x + w - 18 - kw, ry, kn, g_listening);
        if (c.Hover(x + w - 18 - kw, ry, kw, 24) && c.Clicked())
            g_listening = !g_listening;
    }
    ry += step;
    // animations row
    static float animA = 1.0f, blurA = 1.0f;
    IconGlyph(c, Icon::Sparkles, x + 26, ry + 12, 16.0f, Hex(0x6E757C));
    Text(c, x + 42, ry + 12 - TextH(fonts::UI(), 9, c.s) * 0.5f,
         "Анимации интерфейса", fonts::UI(), 9, Hex(0xA3A6AC));
    if (gm && gm->m_animations) {
        if (Toggle(c, x + w - 18 - 29, ry + 4, gm->m_animations->mValue, animA))
            gm->m_animations->mValue = !gm->m_animations->mValue;
    }
    ry += step;
    // blur row
    IconGlyph(c, Icon::Layers, x + 26, ry + 12, 16.0f, Hex(0x6E757C));
    Text(c, x + 42, ry + 12 - TextH(fonts::UI(), 9, c.s) * 0.5f,
         "Размытие фона", fonts::UI(), 9, Hex(0xA3A6AC));
    if (gm && gm->m_blur) {
        if (Toggle(c, x + w - 18 - 29, ry + 4, gm->m_blur->mValue, blurA))
            gm->m_blur->mValue = !gm->m_blur->mValue;
    }
    ry += step;
    if (tall && gm && gm->m_toasts) {
        static float toastA = 1.0f;
        IconGlyph(c, Icon::Bell, x + 26, ry + 12, 16.0f, Hex(0x6E757C));
        Text(c, x + 42, ry + 12 - TextH(fonts::UI(), 9, c.s) * 0.5f,
             "Уведомления", fonts::UI(), 9, Hex(0xA3A6AC));
        if (Toggle(c, x + w - 18 - 29, ry + 4, gm->m_toasts->mValue, toastA))
            gm->m_toasts->mValue = !gm->m_toasts->mValue;
        ry += step;
    }
    // accent row
    c.d->AddLine(c.P(x + 18, ry - 2), c.P(x + w - 18, ry - 2),
                 ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
    ry += 10.0f;
    IconGlyph(c, Icon::Palette, x + 26, ry + 8, 16.0f, Hex(0x747981));
    Text(c, x + 42, ry + 8 - TextH(fonts::UI(), 9, c.s) * 0.5f,
         "Акцентный цвет", fonts::UI(), 9, Hex(0xA3A6AC));
    {
        float dx = x + w - 18 - 13.0f;
        for (int i = 4; i >= 0; i--) {
            if (ColorDot(c, dx, ry + 1, 13.0f, Hex(kAccents[i].hex), IsAccent(kAccents[i].hex)))
                SetAccent(kAccents[i].hex);
            dx -= 19.0f;
        }
    }
    if (showLink) {
        c.d->AddLine(c.P(x + 18, y + h - 40), c.P(x + w - 18, y + h - 40),
                     ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
        // full-width link: label left, arrow right
        const bool hov = c.Hover(x + 18, y + h - 32, w - 36, 22);
        const float ha = HoverAnim(HashStr("allsettings", 3), hov, c.dt);
        const ImColor col = gui::LerpColor(Hex(0xA1A5A7), c.accent, ha);
        Text(c, x + 18, y + h - 30, "Все настройки", fonts::UISemi(), 9, col);
        IconGlyph(c, Icon::ArrowRight, x + w - 26, y + h - 21, 14.0f, col);
        if (hov && c.Clicked()) NavTo(P_Settings);
    }
    return h;
}
float TipCard(Ctx& c, float x, float y, float w) {
    const float h = 172.0f;
    FillR(c, x, y, w, h, Hex(0x171B15), 8.0f);
    StrokeDashed(c, x, y, w, h, Hex(0x2E332A));
    IconGlyph(c, Icon::Sparkles, x + 24, y + 28, 13.0f, c.accent);
    Text(c, x + 36, y + 28 - TextH(fonts::UISemi(), 7, c.s) * 0.5f,
         "МАЛЕНЬКИЙ СОВЕТ", fonts::UISemi(), 7, Hex(0x949E87));
    Text(c, x + 17, y + 48, "Хороший интерфейс не отвлекает.", fonts::UI(), 11, Hex(0xA9AEA3));
    Text(c, x + 17, y + 68, "Настрой модули", fonts::UI(), 11, Hex(0xA9AEA3));
    {
        const float tw = TextW(fonts::UI(), "Настрой модули ", 11, c.s);
        Text(c, x + 17 + tw, y + 68, "под себя.", fonts::UI(), 11, c.accent);
    }
    if (TextLink(c, x + 17, y + h - 32, "Попробовать редактор HUD", Icon::ArrowUpRight, 8.0f))
        NavTo(P_Hud);
    return h;
}

// ============================ overview page ============================
void HeroArt(const Ctx& c, float x, float y, float w, float h) {
    // Procedural world art: blue-black glass, a restrained grid and
    // accent-tinted glow orbs clipped to the card.
    Ctx ci = c;
    const ImVec2 a = ci.P(x, y), b = ci.P(x + w, y + h);
    ci.d->PushClipRect(a, b, true);
    FillGradV(ci, x, y, w, h, gui::Accent(), gui::Accent(), 0.22f, 0.16f);
    FillGradV(ci, x, y + h * 0.45f, w, h * 0.55f, gui::Accent(), gui::Accent(), 0.2f, 0.16f);
    // grid
    for (float gx = x + 34; gx < x + w; gx += 34)
        ci.d->AddLine(ci.P(gx, y), ci.P(gx, y + h),
                      ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z,
                              ci.alpha * 0.045f), ci.px(1.0f));
    for (float gy = y + 30; gy < y + h; gy += 30)
        ci.d->AddLine(ci.P(x, gy), ci.P(x + w, gy),
                      ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z,
                              ci.alpha * 0.035f), ci.px(1.0f));
    // glow orbs (accent-tinted, right side like the sunset)
    ci.d->AddCircleFilled(ci.P(x + w * 0.78f, y + h * 0.34f), ci.px(90),
        ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z, ci.alpha * 0.10f), 28);
    ci.d->AddCircleFilled(ci.P(x + w * 0.66f, y + h * 0.66f), ci.px(55),
        ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z, ci.alpha * 0.07f), 24);
    ci.d->AddCircleFilled(ci.P(x + w * 0.90f, y + h * 0.70f), ci.px(40),
        ImColor(0xE8 / 255.0f, 0xB2 / 255.0f, 0x9D / 255.0f, ci.alpha * 0.10f), 20);
    // dots
    for (int i = 0; i < 26; i++) {
        const float dx = x + (float)((i * 197) % 100) / 100.0f * w;
        const float dy = y + (float)((i * 331) % 100) / 100.0f * h;
        ci.d->AddCircleFilled(ci.P(dx, dy), ci.px(1.4f),
            ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z,
                    ci.alpha * (0.08f + (i % 4) * 0.025f)), 6);
    }
    // left dark gradient so the text reads (like the CSS overlay)
    FillGradV(ci, x, y, w * 0.35f, h, gui::Accent(), gui::Accent(), 0.2f, 0.15f);
    ci.d->PopClipRect();
}
float OverviewHero(Ctx& c, float y) {
    const float x = kContX, w = kContW, h = 310.0f;
    FillR(c, x, y, w, h, gui::Accent(), 11.0f);
    HeroArt(c, x, y, w, h);
    StrokeR(c, x, y, w, h, kBorder, 11.0f, 1.0f);
    const float cx = x + 33.0f;
    float ty = y + 31.0f;
    c.d->AddCircleFilled(c.P(cx + 2, ty + 5), c.px(2.5f),
        ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 10);
    Text(c, cx + 12, ty, "MINECRAFT BEDROCK, ПЕРЕОСМЫСЛЕННЫЙ", fonts::UISemi(), 8, kSecText);
    Text(c, cx, ty + 24, "Nightfull", fonts::Bold(), 44, kText);
    Text(c, cx, ty + 24 + 50, "ClickGUI.", fonts::Bold(), 44, c.accent);
    Text(c, cx, ty + 24 + 50 + 54, "Управляй модулями и их параметрами.", fonts::UI(), 11,
         kSecText);
    Text(c, cx, ty + 24 + 50 + 54 + 19, "Настраивай интерфейс, HUD и профиль прямо в игре.", fonts::UI(), 11,
         kMuted);
    const float ay = ty + 24 + 50 + 54 + 19 + 26;
    // Primary action stays inside the ClickGUI: open the module roster.
    {
        const float bw = 218.0f, bh = 40.0f;
        const bool hov = c.Hover(cx, ay, bw, bh);
        const float ha = HoverAnim(HashStr("modules", 1), hov, c.dt);
        FillR(c, cx, ay - ha, bw, bh,
              gui::LerpColor(c.accent, ImColor(255, 255, 255), ha * 0.09f), 6.0f);
        IconGlyph(c, Icon::Sliders, cx + 24, ay - ha + bh * 0.5f, 16.0f, kBtnText);
        Text(c, cx + 38, ay - ha + bh * 0.5f - TextH(fonts::UISemi(), 10, c.s) * 0.5f,
             "Открыть модули", fonts::UISemi(), 10, kBtnText);
        IconGlyph(c, Icon::ArrowRight, cx + bw - 22, ay - ha + bh * 0.5f, 16.0f, kBtnText);
        if (hov && c.Clicked()) NavTo(P_Modules);
    }
    if (TextLink(c, cx + 218 + 23, ay + 11, "Редактор HUD", Icon::ChevronRight, 10.0f, 16.0f))
        NavTo(P_Hud);
    const float py = ay + 40 + 19;
    IconGlyph(c, Icon::Monitor, cx + 6, py + 5, 12.0f, kMuted);
    Text(c, cx + 16, py, "Windows 10 / 11", fonts::UI(), 8, kMuted);
    {
        const float tw = TextW(fonts::UI(), "Windows 10 / 11", 8, c.s);
        c.d->AddCircleFilled(c.P(cx + 16 + tw + 10, py + 5), c.px(1.5f),
            ImColor(0x69, 0x73, 0x6C, (int)(c.alpha * 255)), 8);
        Text(c, cx + 16 + tw + 18, py, "Bedrock Edition", fonts::UI(), 8, kMuted);
    }
    // tag bottom-right
    {
        const char* t = "CLICKGUI / LOCAL";
        const float tw = TextW(fonts::UI(), t, 7, c.s) + 30.0f;
        const float tx = x + w - tw - 24, tyy = y + h - 21 - 26;
        FillR(c, tx, tyy, tw, 26, kField, 4.0f, g_animsOff ? 0.95f : 0.6f);
        StrokeR(c, tx, tyy, tw, 26, kSecText, 4.0f, 1.0f, 0.16f);
        c.d->AddCircleFilled(c.P(tx + 13, tyy + 13), c.px(2.0f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 8);
        Text(c, tx + 21, tyy + 13 - TextH(fonts::UI(), 7, c.s) * 0.5f, t, fonts::UI(), 7,
             kSecText);
    }
    return h;
}
void StatCard(Ctx& c, float x, float y, float w, int kind) {
    const float h = 82.0f;
    FillR(c, x, y, w, h, gui::Accent(), 8.0f);
    StrokeR(c, x, y, w, h, kBorder, 8.0f, 1.0f);
    ImColor tile, fg;
    unsigned icon = Icon::Box;
    if (kind == 0) { tile = Hex(0x242C1D); fg = Hex(0xB8DD88); icon = Icon::Box; }
    else if (kind == 1) { tile = Hex(0x282236); fg = Hex(0xB6A0E9); icon = Icon::FolderHeart; }
    else if (kind == 2) { tile = Hex(0x1E2934); fg = Hex(0x89AFDD); icon = Icon::Gamepad; }
    else { tile = Hex(0x30261C); fg = Hex(0xD8B48B); icon = Icon::Shield; }
    FillR(c, x + 14, y + 21, 39, 39, tile, 9.0f);
    IconGlyph(c, icon, x + 14 + 19.5f, y + 21 + 19.5f, 21.0f, fg);
    const float tx = x + 14 + 39 + 12;
    if (kind == 0) {
        Text(c, tx, y + 17, "Активные модули", fonts::UI(), 9, Hex(0x82868D));
        char b[16];
        snprintf(b, sizeof(b), "%d", EnabledCount());
        Text(c, tx, y + 32, b, fonts::Title(), 23, kText);
        char b2[16];
        snprintf(b2, sizeof(b2), "/ %d", VisibleCount());
        Text(c, tx + TextW(fonts::Title(), b, 23, c.s) + 5, y + 39, b2, fonts::Title(), 12,
             Hex(0x777C82));
        const char* pill = "Включены";
        const float pw = TextW(fonts::UI(), pill, 7, c.s) + 12.0f;
        FillR(c, x + w - pw - 10, y + h - 24, pw, 18, Hex(0x20291B), 4.0f);
        StrokeR(c, x + w - pw - 10, y + h - 24, pw, 18, Hex(0x34402B), 4.0f, 1.0f);
        Text(c, x + w - pw - 10 + 6, y + h - 24 + 4, pill, fonts::UI(), 7, Hex(0x94B878));
    } else if (kind == 1) {
        Text(c, tx, y + 17, "Конфигурация", fonts::UI(), 9, Hex(0x82868D));
        {
            std::string ap = g_activeProfile;
            const float maxW = x + w - 40 - tx;
            while (ap.size() > 4 &&
                   TextW(fonts::Title(), (ap + "...").c_str(), 15, c.s) > maxW)
                ap.erase(ap.size() - 1);
            if (ap != g_activeProfile) ap += "...";
            Text(c, tx, y + 34, ap.c_str(), fonts::Title(), 15, kText);
        }
        if (IconButton(c, x + w - 32, y + 28, 26, Icon::ChevronDown, 15.0f))
            NavTo(P_Profiles);
    } else if (kind == 2) {
        Text(c, tx, y + 17, "Версия Minecraft", fonts::UI(), 9, Hex(0x82868D));
        Text(c, tx, y + 34, "Bedrock", fonts::Title(), 15, kText);
        Text(c, tx + TextW(fonts::Title(), "Bedrock ", 15, c.s), y + 38, "1.21",
             fonts::Title(), 12, Hex(0x777C82));
    } else {
        Text(c, tx, y + 17, "Статус клиента", fonts::UI(), 9, Hex(0x82868D));
        c.d->AddCircleFilled(c.P(tx + 3, y + 50), c.px(2.5f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha), 10);
        Text(c, tx + 10, y + 42, "Рабочий интерфейс", fonts::UISemi(), 11, Hex(0xC5D5B6));
    }
}
void PaintOverview(Ctx& c, float y0) {
    float y = PageHeading(c, y0, true, false);
    y += OverviewHero(c, y) + 17.0f;
    {
        const float gap = 13.0f, cw = (kContW - gap * 3) / 4.0f;
        for (int i = 0; i < 4; i++) StatCard(c, kContX + i * (cw + gap), y, cw, i);
        y += 82.0f + 29.0f;
    }
    // The overview is intentionally a single full-width workspace. Quick
    // controls and HUD tools live on their dedicated pages instead of a
    // permanently mounted inspector column.
    const float leftW = kContW;
    float ly = y;
    // section heading
    Text(c, kContX, ly, "Функции ClickGUI", fonts::Bold(), 14, kText);
    {
        const float tw = TextW(fonts::Bold(), "Функции ClickGUI ", 14, c.s);
        const char* pill = "ИЗБРАННОЕ";
        const float pw = TextW(fonts::UI(), pill, 6, c.s) + 10.0f;
        FillR(c, kContX + tw + 7, ly + 2, pw, 16, Hex(0x21271B), 3.0f);
        StrokeR(c, kContX + tw + 7, ly + 2, pw, 16, Hex(0x303827), 3.0f, 1.0f);
        Text(c, kContX + tw + 12, ly + 5, pill, fonts::UISemi(), 6, Hex(0x8B9D78));
    }
    Text(c, kContX, ly + 22, "Модули и настройки доступны прямо в ClickGUI.", fonts::UI(), 9,
         kMuted);
    {
        // right-aligned link
        const char* t = "Все модули";
        const float lw = TextW(fonts::UISemi(), t, 9, c.s) + 5 + 15;
        if (TextLink(c, kContX + leftW - lw, ly + 8, t, Icon::ArrowRight, 9.0f))
            NavTo(P_Modules);
    }
    ly += 52.0f;
    // featured modules (first 3 visible)
    {
        std::vector<Module*> mods;
        for (const auto& m : modules().modules()) {
            if (m && !m->hiddenFromLists) mods.push_back(m.get());
            if ((int)mods.size() >= 3) break;
        }
        const float mg = 12.0f, mw = (leftW - mg * 2) / 3.0f;
        float mh = 0;
        for (int i = 0; i < (int)mods.size(); i++) {
            float ch = 0;
            ModuleCard(c, mods[i], kContX + i * (mw + mg), ly, mw, 105.0f, false, ch);
            mh = std::max(mh, ch);
        }
        ly += mh + 17.0f;
    }
    // config banner
    {
        const float bh = 72.0f;
        FillR(c, kContX, ly, leftW, bh, Hex(0x1C2119), 8.0f);
        StrokeR(c, kContX, ly, leftW, bh, Hex(0x30342A), 8.0f, 1.0f);
        FillR(c, kContX + 16, ly + 17, 37, 37, Hex(0x262E1F), 8.0f);
        StrokeR(c, kContX + 16, ly + 17, 37, 37, Hex(0x36412B), 8.0f, 1.0f);
        IconGlyph(c, Icon::FolderHeart, kContX + 16 + 18.5f, ly + 17 + 18.5f, 21.0f, c.accent);
        Text(c, kContX + 65, ly + 17, "Сохранение настроек ClickGUI", fonts::UISemi(), 10, kText);
        Text(c, kContX + 65, ly + 34, "Сохрани параметры модулей в локальный профиль.", fonts::UI(),
             8, Hex(0x858D7E));
        if (ButtonTrail(c, kContX + leftW - 16 - 168, ly + 19, 168, 34, "Сохранить конфиг",
                        false, Icon::ArrowUpRight, 14.0f)) {
            g_modal = M_Save;
            g_modalAnim = 0.0f;
            g_profileName[0] = 0;
        }
        ly += bh;
    }
    // update strip
    {
        ly += 20.0f;
        FillR(c, kContX, ly, 30, 30, Hex(0x24221B), 7.0f);
        StrokeR(c, kContX, ly, 30, 30, Hex(0x343024), 7.0f, 1.0f);
        IconGlyph(c, Icon::Zap, kContX + 15, ly + 15, 18.0f, Hex(0xD4C28B));
        Text(c, kContX + 41, ly + 2, "Маленькое обновление. Большая разница.", fonts::UISemi(), 9, kText);
        {
            const float tw = TextW(fonts::UISemi(), "Маленькое обновление. Большая разница. ", 9, c.s);
            const char* pill = "NEW";
            const float pw = TextW(fonts::UI(), pill, 6, c.s) + 10.0f;
            FillR(c, kContX + 41 + tw, ly + 2, pw, 14, Hex(0x252C1F), 3.0f);
            Text(c, kContX + 41 + tw + 5, ly + 4, pill, fonts::UISemi(), 6, c.accent);
        }
        Text(c, kContX + 41, ly + 19, "Новый интерфейс, гибкие темы и больше свободы для твоего HUD.",
             fonts::UI(), 8, Hex(0x71767D));
        if (IconButton(c, kContX + leftW - 30, ly, 30, Icon::ArrowUpRight, 19.0f)) {
            g_modal = M_Update;
            g_modalAnim = 0.0f;
        }
        ly += 34.0f;
    }
    g_contentH[P_Overview] = ly - y0 + 70.0f;   // + footer space
}

// ============================ modules page ============================
bool ModuleVisible(Module* m) {
    if (!m || m->hiddenFromLists) return false;
    if (g_category == 1 && std::strcmp(m->category(), "Visual")) return false;
    if (g_category == 2 && std::strcmp(m->category(), "Client")) return false;
    if (g_category == 3 && std::strcmp(m->category(), "Movement") &&
        std::strcmp(m->category(), "Combat") && std::strcmp(m->category(), "World")) return false;
    if (g_category == 4 && std::strcmp(m->category(), "HUD")) return false;
    if (g_category == 5 && !m->enabled()) return false;
    if (g_search[0]) {
        char needle[64], nm[96], ds[256];
        AsciiLower(needle, sizeof(needle), g_search);
        AsciiLower(nm, sizeof(nm), m->name());
        AsciiLower(ds, sizeof(ds), m->description());
        if (!std::strstr(nm, needle) && !std::strstr(ds, needle)) return false;
    }
    return true;
}
void PaintModules(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, false);
    // filter bar
    {
        float tx = kContX + 5.0f;
        const float ty = y;
        float totalW = 10.0f;
        float tabW[6];
        for (int i = 0; i < 6; i++) {
            tabW[i] = TextW(fonts::UI(), kCategories[i], 11, c.s) + 28.0f;
            totalW += tabW[i] + 4.0f;
        }
        FillR(c, kContX, ty, totalW, 40, Hex(0x151719), 8.0f);
        StrokeR(c, kContX, ty, totalW, 40, Hex(0x282B2C), 8.0f, 1.0f);
        for (int i = 0; i < 6; i++) {
            const bool hov = c.Hover(tx, ty + 5, tabW[i], 30);
            const float ha = HoverAnim(0xF0u + i, hov || g_category == i, c.dt);
            if (g_category == i) FillR(c, tx, ty + 5, tabW[i], 30, Hex(0x293321), 5.0f);
            else if (ha > 0.01f) FillR(c, tx, ty + 5, tabW[i], 30, Hex(0x202222), 5.0f, ha);
            const ImColor col = g_category == i ? c.accent
                              : gui::LerpColor(Hex(0x8E949B), c.accent, g_category == i ? 0 : ha * 0.6f);
            const float tw = TextW(fonts::UI(), kCategories[i], 11, c.s);
            Text(c, tx + (tabW[i] - tw) * 0.5f, ty + 20 - TextH(fonts::UI(), 11, c.s) * 0.5f,
                 kCategories[i], fonts::UI(), 11, col);
            if (hov && c.Clicked()) g_category = i;
            tx += tabW[i] + 4.0f;
        }
        char b[32];
        snprintf(b, sizeof(b), "%d включено", EnabledCount());
        TextRight(c, kContX + kContW, ty + 20 - TextH(fonts::UI(), 10, c.s) * 0.5f,
                  b, fonts::UI(), 10, Hex(0x7D8775));
        y += 40.0f + 24.0f;
    }
    // grid
    std::vector<Module*> mods;
    for (const auto& m : modules().modules())
        if (ModuleVisible(m.get())) mods.push_back(m.get());
    if (!mods.empty()) {
        const int cols = 3;
        const float gap = 20.0f, cw = (kContW - gap * (cols - 1)) / cols;
        float colY[3] = { 0, 0, 0 };
        float bottom = 0;
        for (Module* m : mods) {
            int col = 0;
            for (int k = 1; k < cols; k++)
                if (colY[k] < colY[col]) col = k;
            float ch = 0;
            ModuleCard(c, m, kContX + col * (cw + gap), y + colY[col], cw, 155.0f, true, ch);
            colY[col] += ch + gap;
            bottom = std::max(bottom, colY[col]);
        }
        y += bottom;
    } else {
        // empty state
        IconGlyph(c, Icon::Search, kContX + kContW * 0.5f, y + 60, 35.0f, Hex(0x808C75));
        Text(c, kContX + kContW * 0.5f - TextW(fonts::Bold(), "Ничего не найдено", 21, c.s) * 0.5f,
             y + 90, "Ничего не найдено", fonts::Bold(), 21, Hex(0xE1E7DB));
        const char* p = "Попробуй другое название или категорию.";
        Text(c, kContX + kContW * 0.5f - TextW(fonts::UI(), p, 12, c.s) * 0.5f,
             y + 124, p, fonts::UI(), 12, Hex(0x808C75));
        if (Button(c, kContX + kContW * 0.5f - 90, y + 152, 180, 36, "Сбросить фильтры", false)) {
            g_search[0] = 0;
            g_category = 0;
        }
        y += 230.0f;
    }
    IconGlyph(c, Icon::Help, kContX + 7, y + 25, 14.0f, Hex(0x81878A));
    Text(c, kContX + 20, y + 25 - TextH(fonts::UI(), 10, c.s) * 0.5f,
         "Модули управляют рабочим HUD и локальными настройками Nightfull.",
         fonts::UI(), 10, Hex(0x81878A));
    y += 60.0f;
    g_contentH[P_Modules] = y - y0 + 70.0f;
}

// ============================ HUD editor page ============================
void HudCanvasArt(const Ctx& c, float x, float y, float w, float h) {
    Ctx ci = c;
    ci.d->PushClipRect(ci.P(x, y), ci.P(x + w, y + h), true);
    FillGradV(ci, x, y, w, h, gui::Accent(), gui::Accent(), 0.22f, 0.16f);
    FillGradV(ci, x, y + h * 0.5f, w, h * 0.5f, gui::Accent(), gui::Accent(), 0.16f, 0.2f);
    ci.d->AddCircleFilled(ci.P(x + w * 0.72f, y + h * 0.30f), ci.px(70),
        ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z, ci.alpha * 0.08f), 26);
    ci.d->AddCircleFilled(ci.P(x + w * 0.30f, y + h * 0.72f), ci.px(46),
        ImColor(0xE8 / 255.0f, 0xB2 / 255.0f, 0x9D / 255.0f, ci.alpha * 0.08f), 20);
    for (int i = 0; i < 20; i++) {
        const float dx = x + (float)((i * 211) % 100) / 100.0f * w;
        const float dy = y + (float)((i * 307) % 100) / 100.0f * h;
        ci.d->AddCircleFilled(ci.P(dx, dy), ci.px(1.3f),
            ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z,
                    ci.alpha * (0.07f + (i % 4) * 0.02f)), 6);
    }
    // mountains silhouette
    const ImVec2 mtn[] = {
        ImVec2(x, y + h * 0.72f), ImVec2(x + w * 0.14f, y + h * 0.52f),
        ImVec2(x + w * 0.30f, y + h * 0.70f), ImVec2(x + w * 0.48f, y + h * 0.46f),
        ImVec2(x + w * 0.64f, y + h * 0.68f), ImVec2(x + w * 0.80f, y + h * 0.55f),
        ImVec2(x + w, y + h * 0.70f),
    };
    FillRidge(ci, mtn, 7, y + h, gui::Accent());
    FillGradV(ci, x, y, w, h, gui::Accent(), gui::Accent(), 0.15f, 0.25f);
    ci.d->PopClipRect();
}
void PaintHud(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, false);
    // HUD is a first-class page: the canvas and its controls share one
    // responsive workspace, with no permanent right-hand inspector.
    const float cw = kContW;
    const float ch = 330.0f;
    HudCanvasArt(c, kContX, y, cw, ch);
    StrokeR(c, kContX, y, cw, ch, kBorder, 9.0f, 1.0f);
    {
        const char* t = "ЖИВОЙ HUD";
        const float tw = TextW(fonts::UI(), t, 7, c.s) + 20.0f;
        FillR(c, kContX + cw - tw - 15, y + 15, tw, 24, kField, 4.0f, 0.82f);
        Text(c, kContX + cw - tw - 15 + 10,
             y + 15 + 12 - TextH(fonts::UI(), 7, c.s) * 0.5f,
             t, fonts::UI(), 7, kSecText);
    }
    // draggable widget
    {
        const float wx = kContX + g_hudX / 100.0f * cw;
        const float wy = y + g_hudY / 100.0f * ch;
        const float sc = g_hudScale / 100.0f;
        const float bw = 190.0f * sc, bh = 38.0f * sc;
        Ctx ci = c;
        ci.d->PushClipRect(ci.P(kContX, y), ci.P(kContX + cw, y + ch), true);
        FillR(ci, wx, wy, bw, bh, gui::Accent(), 5.0f, 0.92f);
        StrokeDashed(ci, wx, wy, bw, bh, ci.accent);
        Logo(ci, wx + 10 * sc, wy + (bh - 18 * sc) * 0.5f, 16 * sc, ci.accent);
        Text(ci, wx + 32 * sc,
             wy + (bh - TextH(fonts::Title(), 14, ci.s) * sc) * 0.5f,
             "nightfull", fonts::Title(), 14 * sc, ci.accent);
        {
            const float sx = wx + 32 * sc + TextW(fonts::Title(), "nightfull", 14 * sc, ci.s) + 8 * sc;
            ci.d->AddLine(ci.P(sx, wy + 9 * sc), ci.P(sx, wy + bh - 9 * sc),
                ImColor(0x9B, 0xA1, 0xAD, (int)(ci.alpha * 90)), ci.px(1.0f));
            Text(ci, sx + 8 * sc,
                 wy + (bh - TextH(fonts::UI(), 9, ci.s) * sc) * 0.5f,
                 "144 FPS", fonts::UI(), 9 * sc, kMuted);
        }
        ci.d->PopClipRect();
        const bool hov = c.Hover(wx, wy, bw, bh);
        if (hov && c.Clicked()) {
            const ImVec2 m = c.Mouse();
            g_hudGrabX = m.x - wx;
            g_hudGrabY = m.y - wy;
            g_hudDrag = true;
        }
        if (g_hudDrag) {
            if (!overlay::g_guiMouseDown[0] && !ImGui::GetIO().MouseDown[0]) {
                g_hudDrag = false;
            } else {
                const ImVec2 m = c.Mouse();
                g_hudX = gui::Clamp((m.x - g_hudGrabX - kContX) / cw * 100.0f, 0.0f, 60.0f);
                g_hudY = gui::Clamp((m.y - g_hudGrabY - y) / ch * 100.0f, 0.0f, 85.0f);
            }
        }
    }
    // crosshair overlay (follows the real module)
    {
        Module* chm = FindModule("Crosshair");
        if (chm && chm->enabled())
            IconGlyph(c, Icon::Crosshair, kContX + cw * 0.5f, y + ch * 0.5f, 30.0f, c.accent);
    }
    // canvas footer
    FillR(c, kContX + 1, y + ch - 38, cw - 2, 37, kField, 0.0f, 0.74f);
    {
        const char* t = "HUD canvas · Перетаскивай виджет мышью";
        Text(c, kContX + (cw - TextW(fonts::UI(), t, 9, c.s)) * 0.5f,
             y + ch - 38 + (37 - TextH(fonts::UI(), 9, c.s)) * 0.5f,
             t, fonts::UI(), 9, kSecText);
    }
    const float canvasB = y + ch;
    IconGlyph(c, Icon::Monitor, kContX + 7, canvasB + 26, 15.0f, kMuted);
    Text(c, kContX + 20, canvasB + 26 - TextH(fonts::UI(), 10, c.s) * 0.5f,
         "HUD layout", fonts::UI(), 10, kMuted);
    {
        const char* t = "Сбросить положение";
        const float lw = TextW(fonts::UISemi(), t, 9, c.s) + 5;
        if (TextLink(c, kContX + cw - lw, canvasB + 20, t, 0, 9.0f)) {
            g_hudX = 5.0f; g_hudY = 8.0f; g_hudScale = 100.0f;
            Toast("Положение HUD сброшено");
        }
    }
    // Settings are kept beside the canvas in the page flow, not in a
    // permanently visible side panel. Every existing control remains active.
    y = canvasB + 58.0f;
    {
        const float oh = 184.0f;
        FillR(c, kContX, y, cw, oh, gui::Accent(), 9.0f);
        StrokeR(c, kContX, y, cw, oh, kBorder, 9.0f, 1.0f);
        Text(c, kContX + 20, y + 18, "Настройки HUD", fonts::Bold(), 14, kText);
        Text(c, kContX + 20, y + 41, "Nightfull Watermark", fonts::UI(), 10, kMuted);
        char b[16];
        snprintf(b, sizeof(b), "%.0f%%", g_hudScale);
        Text(c, kContX + 270, y + 22, "Масштаб", fonts::UI(), 10, kMuted);
        TextRight(c, kContX + 525, y + 22, b, fonts::UISemi(), 10, c.accent);
        SliderF(c, kContX + 270, y + 43, 255, &g_hudScale, 70.0f, 150.0f);
        Text(c, kContX + 575, y + 22, "Прицел", fonts::UI(), 10, kMuted);
        {
            Module* chm = FindModule("Crosshair");
            static float chA = 1.0f;
            if (chm && Toggle(c, kContX + cw - 51, y + 15, chm->enabled(), chA))
                ApplyModuleState(chm, !chm->enabled());
        }
        c.d->AddLine(c.P(kContX + 20, y + 83), c.P(kContX + cw - 20, y + 83),
                     ImColor(0x44, 0x4B, 0x58, (int)(c.alpha * 200)), c.px(1.0f));
        IconGlyph(c, Icon::Help, kContX + 28, y + 111, 17.0f, kMuted);
        WrapText(c, kContX + 47, y + 101, cw - 250,
                 "Положение и масштаб сохраняются автоматически.",
                 fonts::UI(), 10, kMuted, 3);
        if (Button(c, kContX + cw - 194, y + oh - 52, 174, 36, "Экспортировать", false,
                   Icon::Download, 15.0f))
            Toast("Конфигурация экспортирована");
    }
    g_contentH[P_Hud] = y - y0 + 184.0f + 70.0f;
}

// ============================ themes page ============================
void PaintThemes(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, false);
    // showcase
    {
        const float sh = 220.0f;
        FillR(c, kContX, y, kContW, sh, gui::Accent(), 12.0f);
        StrokeR(c, kContX, y, kContW, sh, kBorder, 12.0f, 1.0f);
        Ctx ci = c;
        ci.d->PushClipRect(ci.P(kContX, y), ci.P(kContX + kContW, y + sh), true);
        ci.d->AddCircleFilled(ci.P(kContX + kContW * 0.7f, y + sh * 0.7f), ci.px(150),
            ImColor(ci.accent.Value.x, ci.accent.Value.y, ci.accent.Value.z, ci.alpha * 0.09f), 30);
        ci.d->PopClipRect();
        Text(c, kContX + 65, y + 45, "МЕНЬШЕ ШУМА. БОЛЬШЕ ТЕБЯ.", fonts::UISemi(), 8, kMuted);
        Text(c, kContX + 65, y + 66, "Ночь — наш холст.", fonts::Bold(), 34, kText);
        Text(c, kContX + 65, y + 112, "Цвет — твой выбор.", fonts::Bold(), 34, c.accent);
        Text(c, kContX + 65, y + 162, "Выбери акцент. Всё остальное подстроится.", fonts::UI(), 11,
             kMuted);
        // tilted mockup card
        {
            const float mw = 230.0f, mh = 168.0f;
            const float mx = kContX + kContW - mw - 80.0f, my = y + 26.0f;
            FillR(c, mx, my, mw, mh, gui::Accent(), 10.0f);
            StrokeR(c, mx, my, mw, mh, kBorder, 10.0f, 1.0f);
            Logo(c, mx + 22, my + 20, 17, c.accent);
            Text(c, mx + 45, my + 19, "nightfull", fonts::Title(), 19, c.accent);
            IconGlyph(c, Icon::Ellipsis, mx + mw - 32, my + 30, 18.0f, kMuted);
            FillR(c, mx + 22, my + 56, mw - 44, 1, kBorder, 0.0f);
            IconGlyph(c, Icon::Crosshair, mx + 34, my + 78, 20.0f, kSecText);
            Text(c, mx + 50, my + 78 - TextH(fonts::UI(), 12, c.s) * 0.5f,
                 "Crosshair", fonts::UI(), 12, kSecText);
            FillR(c, mx + mw - 22 - 26, my + 78 - 7, 26, 14, c.accent, 7.0f);
            c.d->AddCircleFilled(c.P(mx + mw - 22 - 7.5f, my + 78), c.px(4.5f),
                ImColor(gui::Accent().Value.x, gui::Accent().Value.y, gui::Accent().Value.z, c.alpha), 12);
            IconGlyph(c, Icon::Monitor, mx + 34, my + 104, 20.0f, kSecText);
            Text(c, mx + 50, my + 104 - TextH(fonts::UI(), 12, c.s) * 0.5f,
                 "Interface", fonts::UI(), 12, kSecText);
            FillR(c, mx + mw - 22 - 26, my + 104 - 7, 26, 14, c.accent, 7.0f);
            c.d->AddCircleFilled(c.P(mx + mw - 22 - 7.5f, my + 104), c.px(4.5f),
                ImColor(gui::Accent().Value.x, gui::Accent().Value.y, gui::Accent().Value.z, c.alpha), 12);
            if (Button(c, mx + 22, my + mh - 48, mw - 44, 32, "Твой стиль", true, 0, 15.0f))
                NavTo(P_Modules);
        }
        y += sh + 32.0f;
    }
    Text(c, kContX, y, "Акцентная палитра", fonts::UISemi(), 16, kText);
    y += 36.0f;
    {
        const int n = 5;
        const float gap = 15.0f, cw = (kContW - gap * (n - 1)) / n;
        for (int i = 0; i < n; i++) {
            const float x = kContX + i * (cw + gap);
            const bool sel = IsAccent(kAccents[i].hex);
            const bool hov = c.Hover(x, y, cw, 190);
            FillR(c, x, y, cw, 190, Hex(0x171A15), 8.0f);
            StrokeR(c, x, y, cw, 190, sel ? c.accent : Hex(0x2B2F29), 8.0f, sel ? 1.4f : 1.0f);
            const ImColor ac = Hex(kAccents[i].hex);
            FillR(c, x + 12, y + 12, cw - 24, 85, ac, 5.0f, 0.10f);
            const float cy = y + 12 + 42.5f, cxm = x + cw * 0.5f;
            c.d->AddCircleFilled(c.P(cxm - 34, cy), c.px(13),
                ImColor(ac.Value.x, ac.Value.y, ac.Value.z, c.alpha), 18);
            c.d->AddCircleFilled(c.P(cxm, cy), c.px(13),
                ImColor(ac.Value.x, ac.Value.y, ac.Value.z, c.alpha * 0.6f), 18);
            c.d->AddCircleFilled(c.P(cxm + 34, cy), c.px(13),
                ImColor(ac.Value.x, ac.Value.y, ac.Value.z, c.alpha * 0.25f), 18);
            Text(c, x + 12, y + 112, kAccents[i].name, fonts::Title(), 14, kText);
            if (sel) IconGlyph(c, Icon::Check, x + cw - 22, y + 120, 16.0f, c.accent);
            Text(c, x + 12, y + 134, kAccents[i].desc, fonts::UI(), 8, Hex(0x808B77));
            if (hov && c.Clicked()) SetAccent(kAccents[i].hex);
            (void)hov;
        }
        y += 190.0f + 20.0f;
    }
    // Theme engine controls stay on the dedicated Themes page. This keeps
    // preset selection, naming, cycle speed and custom-color behavior visible
    // without bringing back an always-mounted inspector.
    {
        ThemesModule* tm = ThemesModule::instance();
        const float sh = 222.0f;
        FillR(c, kContX, y, kContW, sh, gui::Accent(), 9.0f);
        StrokeR(c, kContX, y, kContW, sh, kBorder, 9.0f, 1.0f);
        Text(c, kContX + 20, y + 18, "Theme engine", fonts::Bold(), 13, kText);
        Text(c, kContX + 20, y + 40,
             "Палитра управляет акцентами, переключателями и HUD.",
             fonts::UI(), 9, kMuted);
        Text(c, kContX + 20, y + 72, "Пресеты", fonts::UI(), 10, kSecText);
        float dx = kContX + 102.0f;
        if (tm && tm->m_theme) {
            for (int i = 0; i < gui::ThemeCount(); i++) {
                const bool selected = tm->m_theme->mValue == i;
                if (ColorDot(c, dx, y + 61, 23.0f, gui::ThemeSwatch(i), selected)) {
                    tm->m_theme->setValue(i);
                    Toast("Тема: %s", gui::ThemeName(i));
                }
                dx += 34.0f;
            }
        }
        Text(c, kContX + 20, y + 116, "Название модулей", fonts::UI(), 10, kMuted);
        const char* naming = "Normal";
        if (tm && tm->m_naming) {
            switch (tm->m_naming->mValue) {
                case ThemesModule::NamingLower: naming = "lowercase"; break;
                case ThemesModule::NamingLowerSpaced: naming = "lower spaced"; break;
                case ThemesModule::NamingSpaced: naming = "Spaced"; break;
                default: break;
            }
        }
        if (Button(c, kContX + 145, y + 102, 140, 30, naming, false, Icon::ChevronDown, 13.0f) &&
            tm && tm->m_naming) {
            tm->m_naming->setValue((tm->m_naming->mValue + 1) % 4);
        }
        if (tm && tm->m_colorSlots && tm->m_colorSpeed && tm->m_saturation) {
            char slots[24], speed[24], sat[24];
            snprintf(slots, sizeof(slots), "%.0f", tm->m_colorSlots->mValue);
            snprintf(speed, sizeof(speed), "%.2f", tm->m_colorSpeed->mValue);
            snprintf(sat, sizeof(sat), "%.0f%%", tm->m_saturation->mValue * 100.0f);
            Text(c, kContX + 330, y + 116, "Слоты", fonts::UI(), 10, kMuted);
            TextRight(c, kContX + 520, y + 116, slots, fonts::UISemi(), 10, c.accent);
            SliderF(c, kContX + 330, y + 136, 190, &tm->m_colorSlots->mValue, 1.0f, 6.0f);
            Text(c, kContX + 550, y + 116, "Цикл", fonts::UI(), 10, kMuted);
            TextRight(c, kContX + 705, y + 116, speed, fonts::UISemi(), 10, c.accent);
            SliderF(c, kContX + 550, y + 136, 155, &tm->m_colorSpeed->mValue, 0.25f, 20.0f);
            Text(c, kContX + 735, y + 116, "Насыщенность", fonts::UI(), 10, kMuted);
            TextRight(c, kContX + kContW - 20, y + 116, sat, fonts::UISemi(), 10, c.accent);
            SliderF(c, kContX + 735, y + 136, 103, &tm->m_saturation->mValue, 0.0f, 1.0f);
        }
        c.d->AddLine(c.P(kContX + 20, y + 178), c.P(kContX + kContW - 20, y + 178),
                     ImColor(0x44, 0x4B, 0x58, (int)(c.alpha * 200)), c.px(1.0f));
        Text(c, kContX + 20, y + 193,
             "Выбор цвета и стиль именования применяются сразу.",
             fonts::UI(), 9, kMuted);
    }
    y += 242.0f;
    g_contentH[P_Themes] = y - y0 + 70.0f;
}

// ============================ profiles page ============================
void PaintProfiles(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, true);
    if (g_profilesDirty) { g_profiles = config::listProfiles(); g_profilesDirty = false; }
    // notice
    {
        const float nh = 76.0f;
        FillR(c, kContX, y, kContW, nh, Hex(0x1B2117), 9.0f);
        StrokeR(c, kContX, y, kContW, nh, Hex(0x343D2B), 9.0f, 1.0f);
        IconGlyph(c, Icon::Shield, kContX + 34, y + nh * 0.5f, 20.0f, c.accent);
        Text(c, kContX + 54, y + 16, "Твои настройки остаются у тебя", fonts::UISemi(), 12, kText);
        Text(c, kContX + 54, y + 36, "Конфигурации хранятся локально. Экспортируй их, чтобы сохранить копию.",
             fonts::UI(), 10, Hex(0x8D9783));
        if (Button(c, kContX + kContW - 16 - 130, y + 19, 130, 38, "Экспорт", false,
                   Icon::Download, 15.0f))
            Toast("Конфигурация экспортирована");
        y += nh + 24.0f;
    }
    // grid: Default + saved + new
    {
        const int cols = 3;
        const float gap = 20.0f, cw = (kContW - gap * (cols - 1)) / cols;
        const float ch = 258.0f;
        struct Card { bool isDefault; bool isNew; std::wstring name; };
        std::vector<Card> cards;
        cards.push_back({ true, false, L"" });
        for (const std::wstring& p : g_profiles) cards.push_back({ false, false, p });
        cards.push_back({ false, true, L"" });
        int idx = 0;
        for (const Card& card : cards) {
            const int col = idx % cols, row = idx / cols;
            const float x = kContX + col * (cw + gap);
            const float yy = y + row * (ch + gap);
            if (card.isNew) {
                const bool hov = c.Hover(x, yy, cw, ch);
                const float ha = HoverAnim(HashStr("newprofile", 9), hov, c.dt);
                FillR(c, x, yy, cw, ch, gui::LerpColor(Hex(0x141812), Hex(0x1E2818), ha), 10.0f);
                StrokeDashed(c, x, yy, cw, ch, gui::LerpColor(Hex(0x3A4431), c.accent, ha));
                IconGlyph(c, Icon::Plus, x + cw * 0.5f, yy + 100, 28.0f,
                          gui::LerpColor(Hex(0x748964), c.accent, ha));
                Text(c, x + (cw - TextW(fonts::UISemi(), "Новый сетап", 14, c.s)) * 0.5f, yy + 130,
                     "Новый сетап", fonts::UISemi(), 14,
                     gui::LerpColor(Hex(0x748964), c.accent, ha));
                const char* p = "Сохрани текущие настройки";
                Text(c, x + (cw - TextW(fonts::UI(), p, 10, c.s)) * 0.5f, yy + 154, p,
                     fonts::UI(), 10, Hex(0x7E8975));
                if (hov && c.Clicked()) {
                    g_modal = M_Save;
                    g_modalAnim = 0.0f;
                    g_profileName[0] = 0;
                }
            } else {
                char narrow[64] = {};
                if (!card.isDefault)
                    WideCharToMultiByte(CP_UTF8, 0, card.name.c_str(), -1,
                                        narrow, sizeof(narrow), nullptr, nullptr);
                const char* title = card.isDefault ? "Default" : narrow;
                const bool active = g_activeProfile == title;
                FillR(c, x, yy, cw, ch, gui::Accent(), 10.0f);
                StrokeR(c, x, yy, cw, ch, Hex(0x2E3429), 10.0f, 1.0f);
                FillR(c, x + 25, yy + 25, 47, 47, Hex(0x242D1D), 10.0f);
                StrokeR(c, x + 25, yy + 25, 47, 47, Hex(0x3E4A31), 10.0f, 1.0f);
                IconGlyph(c, Icon::FolderHeart, x + 25 + 23.5f, yy + 25 + 23.5f, 26.0f, c.accent);
                if (!card.isDefault &&
                    IconButton(c, x + cw - 25 - 26, yy + 25, 26, Icon::Trash, 16.0f)) {
                    if (config::deleteProfile(card.name)) {
                        g_profilesDirty = true;
                        if (g_activeProfile == title) g_activeProfile = "Default";
                        Toast("Конфигурация удалена");
                    } else Toast("Не удалось удалить");
                }
                {
                    std::string pt = title;
                    while (pt.size() > 4 &&
                           TextW(fonts::UISemi(), (pt + "...").c_str(), 21, c.s) > cw - 50)
                        pt.erase(pt.size() - 1);
                    if (pt != title) pt += "...";
                    Text(c, x + 25, yy + 92, pt.c_str(), fonts::UISemi(), 21, kText);
                }
                Text(c, x + 25, yy + 122,
                     card.isDefault ? "Базовый сетап Nightfull" : "Твой персональный сетап",
                     fonts::UI(), 11, Hex(0x848E7B));
                // meta
                int count = 0;
                if (card.isDefault) {
                    for (const auto& kv : g_factory) {
                        Module* m = FindModule(kv.first.c_str());
                        if (m && !m->hiddenFromLists && kv.second) count++;
                    }
                } else {
                    // count from the profile file is overkill: show live count
                    count = EnabledCount();
                }
                char mb[32];
                snprintf(mb, sizeof(mb), "%d модулей", count);
                Text(c, x + 25, yy + 162, mb, fonts::UI(), 9, Hex(0xA5B19A));
                TextRight(c, x + cw - 25, yy + 162,
                          card.isDefault ? "Встроенный профиль" : "", fonts::UI(), 9, Hex(0x686F63));
                if (active) {
                    if (Button(c, x + 25, yy + ch - 25 - 38, cw - 50, 38,
                               "Активная конфигурация", false, Icon::Check, 15.0f)) {
                    }
                } else {
                    if (Button(c, x + 25, yy + ch - 25 - 38, cw - 50, 38,
                               card.isDefault ? "Применить" : "Применить конфигурацию", false)) {
                        if (card.isDefault) {
                            for (const auto& kv : g_factory) {
                                Module* m = FindModule(kv.first.c_str());
                                if (m) ApplyModuleState(m, kv.second);
                            }
                            SetAccent(0xD97757);
                            g_activeProfile = "Default";
                            Toast("Применена конфигурация Default");
                        } else if (config::loadProfile(card.name)) {
                            char nb[80];
                            snprintf(nb, sizeof(nb), "Применена конфигурация «%s»", narrow);
                            g_activeProfile = narrow;
                            Toast("%s", nb);
                        } else Toast("Не удалось применить");
                    }
                }
            }
            idx++;
        }
        const int rows = (idx + cols - 1) / cols;
        y += rows * (ch + gap);
    }
    g_contentH[P_Profiles] = y - y0 + 70.0f;
}

// ============================ sources page ============================
struct SourceDef {
    const char* name; const char* owner; const char* type; const char* desc;
    const char* url; bool reviewed;
};
const SourceDef kSources[8] = {
    { "hamambanan", "paramrrr23-maker", "Основа проекта",
      "Nightfull: менеджер модулей, ImGui DX11/DX12, ClickGUI и HUD.",
      "https://github.com/paramrrr23-maker/hamambanan", true },
    { "FlarialClient", "oAnshull", "Bedrock · C++",
      "Bedrock-клиент и standalone DLL. Идеи визуальных модулей.",
      "https://github.com/oAnshull/FlarialClient", true },
    { "DeltaClient", "CollapseLoader", "Java · Дизайн",
      "Очищенный проект для IntelliJ. Визуальный референс интерфейса.",
      "https://github.com/CollapseLoader/DeltaClient", true },
    { "SystemDLC", "CollapseLoader", "Java · Дизайн",
      "Референс интерфейса: Target HUD и частицы в похожей стилистике.",
      "https://github.com/CollapseLoader/SystemDLC", false },
    { "Solstice-Source", "AzOxStOz", "Bedrock · C++",
      "Панельный ModernGui — источник идей для структуры меню.",
      "https://github.com/AzOxStOz/Solstice-Source", false },
    { "expensive-3.1-src", "Enderman202020", "Java · Дизайн",
      "Визуальный референс. Требует отдельного изучения лицензии.",
      "https://github.com/Enderman202020/expensive-3.1-src", false },
    { "Borion Releases", "Borion-Updated", "Bedrock · Релизы",
      "Источник релизов. Совместимость здесь не проверяется.",
      "https://github.com/Borion-Updated/Releases/releases", false },
    { "OderSo Versions", "OderSoClient", "Bedrock · Релизы",
      "Источник версий. Бинарные файлы этот интерфейс не трогает.",
      "https://github.com/OderSoClient/Versions/releases", false },
};
void PaintSources(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, false);
    // summary
    {
        const float nh = 96.0f;
        FillR(c, kContX, y, kContW, nh, Hex(0x1B2117), 9.0f);
        StrokeR(c, kContX, y, kContW, nh, Hex(0x343D2B), 9.0f, 1.0f);
        IconGlyph(c, Icon::GitFork, kContX + 35, y + 34, 26.0f, c.accent);
        Text(c, kContX + 58, y + 18, "От исходников — к своему интерфейсу", fonts::UISemi(), 15, kText);
        WrapText(c, kContX + 58, y + 42, kContW - 58 - 130,
                 "Ниже указано, что действительно просмотрено. Это обзор доступных файлов, а не полный аудит.",
                 fonts::UI(), 10, Hex(0x8D9783), 2);
        const char* b = "8 источников";
        const float bw = TextW(fonts::UI(), b, 9, c.s) + 20.0f;
        FillR(c, kContX + kContW - bw - 22, y + 33, bw, 30, Hex(0x191D17), 6.0f);
        StrokeR(c, kContX + kContW - bw - 22, y + 33, bw, 30, Hex(0x30362A), 6.0f, 1.0f);
        Text(c, kContX + kContW - bw - 22 + 10, y + 33 + 15 - TextH(fonts::UI(), 9, c.s) * 0.5f,
             b, fonts::UI(), 9, Hex(0xA4AB9D));
        y += nh + 24.0f;
    }
    // grid
    {
        const int cols = 3;
        const float gap = 18.0f, cw = (kContW - gap * (cols - 1)) / cols;
        const float ch = 268.0f;
        for (int i = 0; i < 8; i++) {
            const int col = i % cols, row = i / cols;
            const float x = kContX + col * (cw + gap);
            const float yy = y + row * (ch + gap);
            const SourceDef& s = kSources[i];
            FillR(c, x, yy, cw, ch, gui::Accent(), 9.0f);
            StrokeR(c, x, yy, cw, ch, Hex(0x2B3028), 9.0f, 1.0f);
            IconGlyph(c, Icon::GitFork, x + 34, yy + 36, 22.0f, Hex(0xA5B797));
            {
                const char* st = s.reviewed ? "Частично просмотрен" : "К изучению";
                const float sw = TextW(fonts::UI(), st, 7, c.s) + 12.0f;
                FillR(c, x + cw - sw - 23, yy + 24, sw, 22,
                      s.reviewed ? Hex(0x252F1E) : Hex(0x2E281D), 4.0f);
                StrokeR(c, x + cw - sw - 23, yy + 24, sw, 22,
                        s.reviewed ? Hex(0x3E4C32) : Hex(0x4A4130), 4.0f, 1.0f);
                Text(c, x + cw - sw - 23 + 6, yy + 24 + 11 - TextH(fonts::UI(), 7, c.s) * 0.5f,
                     st, fonts::UI(), 7, s.reviewed ? Hex(0xA6C58C) : Hex(0xB6A278));
            }
            char owner[96];
            snprintf(owner, sizeof(owner), "%s /", s.owner);
            Text(c, x + 23, yy + 62, owner, fonts::UI(), 9, Hex(0x788370));
            Text(c, x + 23, yy + 80, s.name, fonts::Title(), 20, kText);
            Text(c, x + 23, yy + 108, s.type, fonts::UI(), 8, c.accent);
            WrapText(c, x + 23, yy + 128, cw - 46, s.desc, fonts::UI(), 11, Hex(0x92998B), 3);
            if (TextLink(c, x + 23, yy + ch - 38, "Открыть репозиторий", Icon::ArrowUpRight, 9.0f)) {
                ImGui::SetClipboardText(s.url);
                Toast("Ссылка скопирована");
            }
        }
        y += 3 * (ch + gap);
    }
    g_contentH[P_Sources] = y - y0 + 70.0f;
}

// ============================ settings page ============================
void PaintSettings(Ctx& c, float y0) {
    float y = PageHeading(c, y0, false, false);
    // The former overview inspector now lives here as a normal page section.
    // It is full-width so the workspace never reserves a permanent right rail.
    const float cw = kContW;
    const float qh = QuickSettings(c, kContX, y, cw, true, true);
    y += qh + 20.0f;

    // About, storage and reset actions remain available below the controls.
    const float ah = 244.0f;
    FillR(c, kContX, y, cw, ah, gui::Accent(), 9.0f);
    StrokeR(c, kContX, y, cw, ah, kBorder, 9.0f, 1.0f);
    Text(c, kContX + 25, y + 20, "О Nightfull", fonts::Bold(), 16, kText);
    Logo(c, kContX + cw - 25 - 17, y + 20, 17, c.accent);
    WrapText(c, kContX + 25, y + 48, cw - 50,
             "Персональное пространство для настройки визуального опыта Minecraft Bedrock.",
             fonts::UI(), 11, kMuted, 2);
    const float rowX = kContX + 25;
    const float rowW = cw - 50;
    float ry = y + 108.0f;
    auto row = [&](const char* k, const char* v) {
        c.d->AddLine(c.P(rowX, ry), c.P(rowX + rowW, ry),
                     ImColor(0x44, 0x4B, 0x58, (int)(c.alpha * 200)), c.px(1.0f));
        Text(c, rowX, ry + 12, k, fonts::UI(), 11, kMuted);
        TextRight(c, rowX + rowW, ry + 12, v, fonts::UISemi(), 10, kSecText);
        ry += 34.0f;
    };
    row("Версия Nightfull", "0.1.0 Night build");
    row("Хранение настроек", "Локальное");
    row("Подключение к игре", "Рабочие модули");
    if (Button(c, rowX, y + ah - 48, 190, 34, "Экспорт настроек", false,
               Icon::Download, 15.0f))
        Toast("Конфигурация экспортирована");
    {
        const char* t = "Восстановить настройки по умолчанию";
        const float tw = TextW(fonts::UI(), t, 9, c.s);
        const bool hov = c.Hover(kContX + (cw - tw) * 0.5f, y + ah - 43, tw, 18);
        const float ha = HoverAnim(HashStr("resetall", 5), hov, c.dt);
        Text(c, kContX + (cw - tw) * 0.5f, y + ah - 43, t, fonts::UI(), 9,
             gui::LerpColor(kMuted, c.accent, ha));
        if (hov && c.Clicked()) {
            for (const auto& kv : g_factory) {
                Module* m = FindModule(kv.first.c_str());
                if (m) ApplyModuleState(m, kv.second);
            }
            SetAccent(0xD97757);
            GeneralModule* gm = GeneralModule::instance();
            if (gm) {
                if (gm->m_animations) gm->m_animations->mValue = true;
                if (gm->m_blur) gm->m_blur->mValue = true;
            }
            overlay::g_menuKey = VK_INSERT;
            g_activeProfile = "Default";
            Toast("Настройки восстановлены. Сохранённые профили не изменены.");
        }
    }
    y += ah + 20.0f;
    const float tipH = TipCard(c, kContX, y, cw);
    y += tipH;
    g_contentH[P_Settings] = y - y0 + 70.0f;
}

// ============================ footer ============================
void PaintFooter(Ctx& c, float y) {
    c.d->AddLine(c.P(kContX, y), c.P(kContX + kContW, y),
                 ImColor(0x20, 0x27, 0x22, (int)(c.alpha * 255)), c.px(1.0f));
    Logo(c, kContX, y + 19, 14, Hex(0x7B8374));
    {
        const float tw = TextW(fonts::UI(), "nightfull  /  ", 8, c.s);
        Text(c, kContX + 21, y + 21, "nightfull", fonts::UI(), 8, Hex(0x636970));
        Text(c, kContX + 21 + tw, y + 21, "Локальный ClickGUI.", fonts::UI(), 8, Hex(0x636970));
    }
    {
        const char* t = "Локальные настройки сохранены";
        const float tw = TextW(fonts::UI(), t, 7, c.s) + 9.0f;
        const float fx = kContX + (kContW - tw) * 0.5f;
        c.d->AddCircleFilled(c.P(fx + 2, y + 26), c.px(2.0f),
            ImColor(0x72, 0x88, 0x5F, (int)(c.alpha * 255)), 8);
        Text(c, fx + 9, y + 21, t, fonts::UI(), 7, Hex(0x737B6B));
    }
    {
        const char* t = "Нужна помощь?";
        const float lw = TextW(fonts::UI(), t, 8, c.s) + 5 + 13;
        if (TextLink(c, kContX + kContW - lw, y + 21, t, Icon::ArrowUpRight, 8.0f)) {
            g_modal = M_Help;
            g_modalAnim = 0.0f;
        }
    }
}

// ============================ page dispatch + scroll ============================
// Prefer the wheel delta captured by the in-world bridge. ImGui's MouseWheel
// field remains a fallback for normal windowed input, but custom background
// painting must not depend on backend consumption order.
float MenuWheelY() {
    return std::fabs(overlay::g_guiMouseWheel) > 0.0001f
        ? overlay::g_guiMouseWheel
        : ImGui::GetIO().MouseWheel;
}

void PaintPage(Ctx& c) {
    const int tab = (int)g_page;
    const float viewH = kViewB - kContY;
    const float maxScroll = std::max(0.0f, g_contentH[tab] - viewH);
    if (c.interact && maxScroll > 0.0f && c.Hover(kContX, kContY, kContW, viewH) &&
        g_modal == M_None && !g_notif) {
        const float wheel = MenuWheelY();
        if (wheel != 0.0f) g_scrollTo[tab] -= wheel * 44.0f;
    }
    g_scrollTo[tab] = gui::Clamp(g_scrollTo[tab], 0.0f, maxScroll);
    g_scroll[tab] = gui::Animate(g_scrollTo[tab], g_scroll[tab], AF(c.dt, 14.0f));

    c.d->PushClipRect(c.P(kContX, kContY - 6), c.P(kContX + kContW, kViewB), true);
    const float savedOff = c.offsetY;
    c.offsetY = -g_scroll[tab];
    switch (g_page) {
        case P_Overview: PaintOverview(c, kContY); break;
        case P_Modules: PaintModules(c, kContY); break;
        case P_Hud: PaintHud(c, kContY); break;
        case P_Themes: PaintThemes(c, kContY); break;
        case P_Profiles: PaintProfiles(c, kContY); break;
        case P_Sources: PaintSources(c, kContY); break;
        case P_Settings: PaintSettings(c, kContY); break;
    }
    PaintFooter(c, kContY + g_contentH[tab] - 64.0f);
    c.offsetY = savedOff;
    c.d->PopClipRect();

    const float maxS = std::max(0.0f, g_contentH[tab] - viewH);
    if (maxS > 0.0f) {
        const float th = std::max(28.0f, viewH * viewH / std::max(1.0f, g_contentH[tab]));
        const float ty = kContY + (viewH - th) * (g_scroll[tab] / maxS);
        Ctx sc = c;
        sc.offsetY = 0;
        FillR(sc, kContX + kContW - 3, ty, 3, th, kMuted, 1.5f, 0.5f);
    }
}

// ============================ toasts ============================
void PaintToasts() {
    GeneralModule* gm = GeneralModule::instance();
    if (gm && gm->m_toasts && !gm->m_toasts->mValue) { g_toasts.clear(); return; }
    const unsigned long long now = GetTickCount64();
    while (!g_toasts.empty() && now >= g_toasts.front().until)
        g_toasts.erase(g_toasts.begin());
    while (g_toasts.size() > 2) g_toasts.erase(g_toasts.begin());
    const ImVec2 screen = gui::GetScreenSize();
    float y = screen.y - 26.0f;
    ImFont* f = fonts::UI();
    ImFont* fi = fonts::Icon();
    for (int i = (int)g_toasts.size() - 1; i >= 0; i--) {
        const ToastItem& t = g_toasts[i];
        const float remain = (float)(t.until - now) / 1000.0f;
        const float a = gui::Clamp(std::min(remain / 0.4f, 1.0f), 0.0f, 1.0f);
        const float slide = g_animsOff ? 0.0f : (1.0f - gui::Clamp(remain / 0.25f, 0.0f, 1.0f)) * 9.0f;
        const float tw = f->CalcTextSizeA(12.0f * gui::GetTextScale(), FLT_MAX, 0.0f, t.text.c_str()).x;
        const float w = tw + 24.0f + 17.0f + 12.0f + 14.0f + 18.0f, h = 46.0f;
        const float x = (screen.x - w) * 0.5f;
        y -= h;
        const float yy = y - slide;
        gui::FillRect(ImVec4(x, yy, x + w, yy + h), ImColor(0x15, 0x19, 0x17), 0.94f * a, 9.0f);
        gui::StrokeRect(ImVec4(x, yy, x + w, yy + h), ImColor(0x2A, 0x32, 0x2C), 9.0f, 1.0f, a);
        if (fi) {
            const char chk[4] = { (char)0xEE, (char)0x81, (char)0xAC, 0 };  // U+E06C check
            gui::DrawString(ImVec2(x + 18, yy + (h - 17.0f) * 0.5f), chk, gui::Accent(),
                          17.0f / gui::kFontUnit, a, false, nullptr, fi);
        }
        gui::DrawString(ImVec2(x + 18 + 17 + 12, yy + (h - 15.0f) * 0.5f), t.text.c_str(),
                      ImColor(0xD6, 0xE8, 0xDB), 12.0f / gui::kFontUnit, a, false, nullptr, f);
        y -= 10.0f;
    }
}

ImColor SystemSurface();

// ============================ modals ============================
// Modal frame: backdrop + centered box. Returns box origin via out params.
bool ModalBegin(Ctx& c, float w, float h, float& outX, float& outY) {
    Ctx o = c;
    o.offsetY = 0;
    GeneralModule* gm = GeneralModule::instance();
    const bool blur = !gm || !gm->m_blur || gm->m_blur->mValue;
    gui::FillRect(ImVec4(o.origin.x, o.origin.y, o.origin.x + kRefMainW * o.s,
                         o.origin.y + kRefMainH * o.s),
                  ImColor(0x05, 0x08, 0x06), o.alpha * (blur ? 0.74f : 0.92f), 12.0f * o.s, o.d);
    g_modalAnim = gui::Animate(1.0f, g_modalAnim, AF(o.dt, 14.0f));
    const float rise = (1.0f - g_modalAnim) * 12.0f;
    const float x = (kRefMainW - w) * 0.5f, y = (kRefMainH - h) * 0.5f + rise;
    outX = x; outY = y;
    Ctx m = o;
    m.alpha *= (0.4f + 0.6f * g_modalAnim);
    FillR(m, x, y, w, h, SystemSurface(), 15.0f);
    StrokeR(m, x, y, w, h, kBorder, 15.0f, 1.0f);
    // close X
    if (IconButton(m, x + w - 14 - 28, y + 14, 28, Icon::X, 20.0f)) {
        g_modal = M_None;
        g_selMod = nullptr;
        g_moduleScroll = g_moduleScrollTo = 0.0f;
        return false;
    }
    // backdrop click closes
    if (o.interact && g_modalAnim > 0.6f && ImGui::IsMouseClicked(0) && !o.Hover(x, y, w, h)) {
        g_modal = M_None;
        g_selMod = nullptr;
        g_moduleScroll = g_moduleScrollTo = 0.0f;
        return false;
    }
    return true;
}
void ModalSymbol(Ctx& c, unsigned icon, float x, float y) {
    FillR(c, x, y, 53, 53, Hex(0x29351F), 12.0f);
    StrokeR(c, x, y, 53, 53, Hex(0x435435), 12.0f, 1.0f);
    IconGlyph(c, icon, x + 26.5f, y + 26.5f, 27.0f, c.accent);
}
void CloseModal() {
    g_modal = M_None;
    g_selMod = nullptr;
    g_moduleScroll = g_moduleScrollTo = 0.0f;
}
void PaintSaveModal(Ctx& c) {
    const float w = 460, h = 360;
    float x, y;
    if (!ModalBegin(c,w,h,x,y)) return;
    Ctx m = c; m.offsetY = 0;
    Text(m,x+28,y+30,"Сохранить конфигурацию",fonts::UISemi(),22,kText);
    WrapText(m,x+28,y+76,w-56,"Профиль сохранит состояния модулей, бинды, цвета и настройки интерфейса.",fonts::UI(),13,kMuted,2);
    Text(m,x+28,y+134,"Название профиля",fonts::UISemi(),13,kText);
    TextField(m,x+28,y+162,w-56,42,Field::Profile,g_profileName,sizeof(g_profileName),"Например, PvP или Recording",false);
    if (g_profilesDirty) { g_profiles=config::listProfiles(); g_profilesDirty=false; }
    wchar_t wide[64] = {};
    MultiByteToWideChar(CP_UTF8,0,g_profileName,-1,wide,64);
    bool duplicate=false;
    for(const auto& p:g_profiles) if(p==wide) duplicate=true;
    if(duplicate) Text(m,x+28,y+221,"Существующий профиль будет перезаписан.",fonts::UI(),12,kMuted);
    const bool submit=Button(m,x+28,y+h-68,w-56,40,"Сохранить профиль",true,Icon::Check,16,g_profileName[0]!=0);
    if(submit || (EnterPressed() && g_profileName[0])) {
        if (!config::validProfileName(wide)) Toast("Недопустимое имя профиля");
        else if(config::saveProfile(wide)) {
            g_profilesDirty=true;g_activeProfile=g_profileName;
            Toast("Профиль сохранён: %s",g_profileName);
            g_profileName[0]=0;CloseModal();g_field.kind=Field::None;
        } else Toast("Не удалось сохранить профиль");
    }
}

void PaintUpdateModal(Ctx& c) {
    const float w = 460.0f, h = 520.0f;
    float x, y;
    if (!ModalBegin(c, w, h, x, y)) return;
    Ctx m = c;
    m.offsetY = 0;
    m.alpha *= (0.4f + 0.6f * g_modalAnim);
    ModalSymbol(m, Icon::Zap, x + 32, y + 30);
    Text(m, x + 32, y + 100, "NIGHTFULL · 0.1.0 NIGHT BUILD", fonts::UISemi(), 8, Hex(0x747B73));
    Text(m, x + 32, y + 118, "Знакомься с новым пространством.", fonts::Bold(), 23, kText);
    Text(m, x + 32, y + 152, "Обновлённая визуальная панель Nightfull.", fonts::UI(), 12,
         Hex(0x929C88));
    float ry = y + 200.0f;
    auto row = [&](unsigned icon, const char* t, const char* d) {
        IconGlyph(m, icon, x + 42, ry + 12, 20.0f, m.accent);
        Text(m, x + 64, ry, t, fonts::UISemi(), 12, kText);
        Text(m, x + 64, ry + 20, d, fonts::UI(), 10, Hex(0x8B9880));
        ry += 62.0f;
    };
    row(Icon::Palette, "Пять акцентных палитр", "Один цвет объединяет весь интерфейс.");
    row(Icon::Monitor, "Интерактивный редактор HUD", "Перетаскивание, масштаб и живая визуализация.");
    row(Icon::FolderHeart, "Твои конфигурации", "Локальное сохранение и экспорт в JSON.");
    if (ButtonTrail(m, x + 32, y + h - 32 - 40, w - 64, 40, "Отлично, попробуем", true,
                    Icon::ArrowRight, 16.0f))
        CloseModal();
}
void PaintHelpModal(Ctx& c) {
    const float w = 460.0f, h = 540.0f;
    float x, y;
    if (!ModalBegin(c, w, h, x, y)) return;
    Ctx m = c;
    m.offsetY = 0;
    m.alpha *= (0.4f + 0.6f * g_modalAnim);
    ModalSymbol(m, Icon::Help, x + 32, y + 30);
    Text(m, x + 32, y + 100, "Немного о пространстве", fonts::Bold(), 23, kText);
    float ry = y + 150.0f;
    auto qa = [&](const char* q, const char* a) {
        Text(m, x + 32, ry, q, fonts::UISemi(), 12, Hex(0xC4D4B7));
        ry += 22.0f;
        ry += WrapText(m, x + 32, ry, w - 64, a, fonts::UI(), 11, Hex(0x8D9B81), 3) * 20.0f;
        ry += 14.0f;
    };
    qa("Как включить модуль?",
       "Открой «Модули» и нажми переключатель в карточке. Кнопка настроек открывает параметры модуля.");
    qa("Где хранятся настройки?",
       "В локальной папке Nightfull рядом с DLL. Имена профилей резервируют отдельные файлы.");
    qa("Что доступно в Nightfull?",
        "Модули, темы, конфигурации и HUD-виджеты управляются из ClickGUI и сохраняются вместе с профилем.");
}
bool ModuleSettingVisible(const Setting* s) {
    return s && (!s->mIsVisible || s->mIsVisible());
}

float ModuleSettingHeight(const Setting* s) {
    if (!ModuleSettingVisible(s)) return 0.0f;
    switch (s->mType) {
        case SettingType::Number: return 68.0f;
        case SettingType::String: return 64.0f;
        default: return 48.0f;
    }
}

float ModuleModalHeight(Module* m) {
    float h = 600.0f;
    if (m) {
        for (const auto& s : m->settings()) h += ModuleSettingHeight(s.get());
    }
    // Keep the dialog inside the existing 700px design canvas. The settings
    // viewport below becomes scrollable when a module has more controls than
    // can fit between the preview header and the fixed footer.
    return std::min(700.0f, h);
}

// Forward declarations: the SystemDLC-style card renderer lives further down;
// the Modules page and the settings modal share it as one layout source.
float RefSettingHeight(const Setting* s);
float RefModuleSettingsHeight(Module* m);
float RefDrawModuleSettings(Ctx& c, Module* m, float x, float y, float w);

float ModuleSettingsContentHeight(Module* m) {
    if (!m) return 0.0f;
    // Same card rows as the Modules page: one layout source for both views.
    return RefModuleSettingsHeight(m);
}

bool PaintModuleSettings(Ctx& c, Module* m, float x, float y, float w, float& outY) {
    outY = y;
    if (!m) return false;
    bool any = false;
    for (const auto& holder : m->settings()) {
        if (ModuleSettingVisible(holder.get())) { any = true; break; }
    }
    if (!any) return false;
    // SystemDLC-style setting cards, shared with the Modules page renderer so
    // the modal and the inline expansion always look identical.
    outY = RefDrawModuleSettings(c, m, x, y, w);
    return true;
}

void PaintModuleModal(Ctx& c) {
    Module* m = g_selMod;
    if (!m) { g_modal = M_None; return; }
    const float w = 460.0f, h = ModuleModalHeight(m);
    float x, y;
    if (!ModalBegin(c, w, h, x, y)) return;
    Ctx md = c;
    md.offsetY = 0;
    md.alpha *= (0.4f + 0.6f * g_modalAnim);
    auto& vis = g_modVis[m->name()];
    if (vis.first <= 0.0f) { vis.first = 100.0f; vis.second = 100.0f; }
    FillR(md, x + 32, y + 30, 53, 53, Hex(0x29351F), 12.0f);
    StrokeR(md, x + 32, y + 30, 53, 53, Hex(0x435435), 12.0f, 1.0f);
    IconGlyph(md, ModuleIcon(m->name()), x + 32 + 26.5f, y + 30 + 26.5f, 27.0f, md.accent);
    // eyebrow + title (right of the symbol)
    Text(md, x + 100, y + 32, m->category(), fonts::UISemi(), 8, Hex(0x747B73));
    Text(md, x + 100, y + 48, m->name(), fonts::Bold(), 23, kText);
    Text(md, x + 32, y + 100, m->description(), fonts::UI(), 12, Hex(0x929C88));
    // preview (scaled + faded)
    {
        Ctx pv = md;
        pv.alpha *= vis.second / 100.0f;
        const float sc = vis.first / 100.0f;
        const float pw = w - 64, ph = 150.0f;
        const float sw = pw * sc, sh = ph * sc;
        const float sx = x + 32 + (pw - sw) * 0.5f, sy = y + 132 + (ph - sh) * 0.5f;
        FillR(pv, sx, sy, sw, sh, Hex(0x141812), 5.0f);
        ModulePreview(pv, sx, sy, sw, sh, ModulePreview(m->name()));
        StrokeR(pv, sx, sy, sw, sh, Hex(0x35402B), 5.0f, 1.0f);
    }
    // enable row
    Text(md, x + 32, y + 304, "Включить модуль", fonts::UI(), 12, Hex(0xA3A6AC));
    if (Toggle(md, x + w - 32 - 29, y + 302, m->enabled(), m->toggleAnim))
        ApplyModuleState(m, !m->enabled());
    md.d->AddLine(md.P(x + 32, y + 330), md.P(x + w - 32, y + 330),
                  ImColor(0x20, 0x27, 0x22, (int)(md.alpha * 255)), md.px(1.0f));
    // Real module settings (not just the enable switch). Keep the modal
    // shell and preview controls fixed, but put the typed settings in their
    // own clipped, wheel-scrollable viewport. This prevents long modules
    // (HUD, Crosshair and future modules) from drawing their lower settings
    // underneath the footer button.
    const float settingsX = x + 32.0f;
    const float settingsW = w - 64.0f;
    const float settingsTop = 346.0f;
    const float settingsBottom = h - 190.0f;
    const float settingsViewH = std::max(0.0f, settingsBottom - settingsTop);
    const float settingsContentH = ModuleSettingsContentHeight(m);
    const float maxModuleScroll = std::max(0.0f, settingsContentH - settingsViewH);
    if (md.interact && settingsViewH > 0.0f &&
        md.Hover(settingsX, y + settingsTop, settingsW, settingsViewH)) {
        const float wheel = MenuWheelY();
        if (wheel != 0.0f) g_moduleScrollTo -= wheel * 44.0f;
    }
    g_moduleScrollTo = gui::Clamp(g_moduleScrollTo, 0.0f, maxModuleScroll);
    g_moduleScroll = gui::Animate(g_moduleScrollTo, g_moduleScroll, AF(md.dt, 14.0f));

    Ctx settingsCtx = md;
    settingsCtx.offsetY = -g_moduleScroll;
    settingsCtx.interact = md.interact && settingsViewH > 0.0f &&
                           md.Hover(settingsX, y + settingsTop, settingsW, settingsViewH);
    md.d->PushClipRect(md.P(settingsX, y + settingsTop),
                       md.P(settingsX + settingsW, y + settingsBottom), true);
    float controlsY = y + settingsTop;
    PaintModuleSettings(settingsCtx, m, settingsX, controlsY, settingsW, controlsY);
    md.d->PopClipRect();

    if (maxModuleScroll > 0.0f) {
        const float trackX = x + w - 18.0f;
        const float thumbH = std::max(24.0f,
            settingsViewH * settingsViewH / std::max(1.0f, settingsContentH));
        const float thumbY = y + settingsTop +
            (settingsViewH - thumbH) * (g_moduleScroll / maxModuleScroll);
        FillR(md, trackX, y + settingsTop, 3.0f, settingsViewH, Hex(0x293128), 1.5f, 0.8f);
        FillR(md, trackX, thumbY, 3.0f, thumbH, md.accent, 1.5f, 0.9f);
    }

    // Preview scale and opacity remain separate local ClickGUI preferences and
    // stay visible at the bottom while the module's own settings scroll.
    const float auxY = h - 175.0f;
    {
        char b[16];
        snprintf(b, sizeof(b), "%.0f%%", vis.first);
        Text(md, x + 32, y + auxY, "Масштаб сцены", fonts::UI(), 10, Hex(0xA2A89D));
        TextRight(md, x + w - 32, y + auxY, b, fonts::UISemi(), 10, md.accent);
        SliderF(md, x + 32, y + auxY + 22, w - 64, &vis.first, 70.0f, 100.0f);
    }
    {
        char b[16];
        snprintf(b, sizeof(b), "%.0f%%", vis.second);
        Text(md, x + 32, y + auxY + 60, "Непрозрачность", fonts::UI(), 10, Hex(0xA2A89D));
        TextRight(md, x + w - 32, y + auxY + 60, b, fonts::UISemi(), 10, md.accent);
        SliderF(md, x + 32, y + auxY + 82, w - 64, &vis.second, 20.0f, 100.0f);
    }
    if (Button(md, x + 32, y + h - 32 - 40, w - 64, 40, "Готово", true, Icon::Check, 16.0f)) {
        CloseModal();
        Toast("Настройки модуля сохранены");
    }
}
void PaintModal(Ctx& c) {
    if (g_modal == M_None) { g_modalAnim = 0.0f; return; }
    switch (g_modal) {
        case M_Save: PaintSaveModal(c); break;
        case M_Update: PaintUpdateModal(c); break;
        case M_Help: PaintHelpModal(c); break;
        case M_Module: PaintModuleModal(c); break;
        default: break;
    }
}


// ============================ reference shell renderer ============================
// This is the mounted ClickGUI. It mirrors the attached HTML composition
// rather than the former page-based menu: the top command strip, profile
// sidebar, three-column module board and the right inspector tabs are all
// native ImGui draw-list surfaces. Module callbacks and setting storage stay
// on the original objects.
// Category = the module's own category string (set in its constructor).
// Rail order: Combat, Movement, Visual, HUD, World, Client, GUI (6 = theme
// gallery, never a module list). Unknown strings fall back to Client.
int RefCategoryFor(Module* m) {
    if (!m || m->hiddenFromLists) return -1;
    static const char* const kCats[] = { "Combat", "Movement", "Visual", "HUD", "World", "Client" };
    const char* cat = m->category();
    for (int i = 0; i < (int)(sizeof(kCats) / sizeof(kCats[0])); i++)
        if (!std::strcmp(cat, kCats[i])) return i;
    return 5;
}

bool RefMatches(Module* m);

void RefCollect(int category, std::vector<Module*>& out) {
    out.clear();
    for (const auto& holder : modules().modules()) {
        Module* m = holder.get();
        if ((category == -1 || RefCategoryFor(m) == category) && RefMatches(m)) out.push_back(m);
    }
    std::sort(out.begin(), out.end(), [](Module* a, Module* b) {
        return _stricmp(a->name(), b->name()) < 0;
    });
}

bool SystemFavorite(Module* m) {
    GeneralModule* gm = GeneralModule::instance();
    return m && gm && gm->m_guiFavorites &&
        gm->m_guiFavorites->mValue.find(std::string("\n") + m->name() + "\n") != std::string::npos;
}
void SystemToggleFavorite(Module* m) {
    GeneralModule* gm = GeneralModule::instance();
    if (!m || !gm || !gm->m_guiFavorites) return;
    std::string token = std::string("\n") + m->name() + "\n";
    std::string& v = gm->m_guiFavorites->mValue;
    const size_t at = v.find(token);
    if (at == std::string::npos) v += token; else v.erase(at, token.size());
}
bool RefMatches(Module* m) {
    if (!m || m->hiddenFromLists) return false;
    if (g_systemFavoritesOnly && !SystemFavorite(m)) return false;
    if (!g_search[0]) return true;
    char needle[96], name[128], desc[320];
    AsciiLower(needle, sizeof(needle), g_search);
    AsciiLower(name, sizeof(name), m->name());
    AsciiLower(desc, sizeof(desc), m->description());
    return std::strstr(name, needle) || std::strstr(desc, needle);
}

Module* RefFirstModule() {
    for (const auto& holder : modules().modules()) {
        Module* m = holder.get();
        if (m && !m->hiddenFromLists) return m;
    }
    return nullptr;
}

void RefEnsureSelection() {
    if (g_refSelected && !g_refSelected->hiddenFromLists) return;
    g_refSelected = RefFirstModule();
}

float RefRadius(float base) {
    return g_refCompact ? std::max(16.0f, base - 4.0f) : (g_refRadius > 0.0f ? g_refRadius : base);
}

bool SystemDark() {
    GeneralModule* gm = GeneralModule::instance();
    return gm && gm->m_guiAppearance && gm->m_guiAppearance->mValue == 1;
}
ImColor SystemSurface() { return SystemDark() ? ImColor(28, 30, 36) : ImColor(250, 250, 250); }
void SystemPalette() {
    const bool dark = SystemDark();
    kField = dark ? ImColor(36, 39, 46) : ImColor(255, 255, 255);
    kModuleBg = SystemSurface();
    kBorder = dark ? ImColor(65, 68, 78) : ImColor(222, 223, 227);
    kText = dark ? ImColor(242, 243, 247) : ImColor(24, 25, 28);
    kMuted = dark ? ImColor(165, 168, 179) : ImColor(98, 100, 107);
    kFaint = dark ? ImColor(143, 146, 158) : ImColor(114, 116, 125);
    kTrack = dark ? ImColor(51, 54, 65) : ImColor(233, 234, 238);
    kSecText = kText; kKnobOff = dark ? ImColor(162, 166, 177) : ImColor(120, 122, 132);
}
void RefPanelSurface(const Ctx& c, float x, float y, float w, float h,
                     const ImColor& fill = gui::Accent(), float alpha = 1.0f) {
    (void)fill; (void)alpha;
    FillR(c, x, y, w, h, SystemSurface(), 18.0f);
    StrokeR(c, x, y, w, h, kBorder, 18.0f, 1.0f, 0.8f);
}

bool RefPill(Ctx& c, float x, float y, float w, float h, const char* label,
             bool primary = false) {
    const bool hov = c.Hover(x, y, w, h);
    const ImColor fill = primary ? gui::LerpColor(c.accent, kField, 0.72f) : kField;
    FillR(c, x, y, w, h, fill, 8.0f, 1.0f);
    StrokeR(c, x, y, w, h, primary ? gui::LerpColor(c.accent, kText, 0.16f) : kBorder,
            8.0f, 1.0f, hov ? 1.0f : 0.72f);
    const ImColor fg = primary ? kText : (hov ? kText : kSecText);
    Text(c, x + (w - TextW(fonts::UISemi(), label, 13.0f, c.s)) * 0.5f,
         y + (h - TextH(fonts::UISemi(), 13.0f, c.s)) * 0.5f,
         label, fonts::UISemi(), 13.0f, fg);
    return hov && c.Clicked();
}

bool RefSwitch(Ctx& c, float x, float y, bool on, float& anim) {
    // Obsidian pill toggle: 31x18 track, 14px knob gliding 13px, theme
    // accent on-state with the same springy knob as before.
    const float w = 31.0f, h = 18.0f;
    anim = g_animsOff ? (on ? 1.0f : 0.0f) : gui::Animate(on ? 1.0f : 0.0f, anim, AF(c.dt, 10.0f));
    const float t = gui::Clamp(anim, 0.0f, 1.0f);
    // easeOutBack: fast attack, soft overshoot, settle. Clamped so the knob
    // never leaves the track even mid-spring.
    const float c1 = 1.70158f, c3 = c1 + 1.0f, u = t - 1.0f;
    const float e = gui::Clamp(1.0f + c3 * u * u * u + c1 * u * u, -0.05f, 1.12f);
    FillR(c, x, y, w, h, on ? c.accent : kTrack, h * 0.5f, on ? 0.95f : 0.8f);
    StrokeR(c, x, y, w, h, on ? c.accent : kBorder, h * 0.5f, 1.0f, on ? 0.9f : 0.5f);
    const float knobCX = x + 2.0f + 7.0f + e * 13.0f;
    const float knobCY = y + h * 0.5f;
    if (t > 0.01f)
        c.d->AddCircleFilled(c.P(knobCX, knobCY), c.px(10.0f),
            ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, 0.22f * t * c.alpha), 18);
    c.d->AddCircleFilled(c.P(knobCX, knobCY), c.px(7.0f),
        on || t > 0.5f ? kKnobOn : kKnobOff, 18);
    // Gloss dot: static highlight giving the knob volume through the glide.
    c.d->AddCircleFilled(c.P(knobCX - 2.0f, knobCY - 2.0f), c.px(2.2f),
        ImColor(255, 255, 255, (int)(110 * c.alpha)), 10);
    // r24: the switch is a real on/off button now: hover ring + click edge.
    const bool hov = c.Hover(x - 3.0f, y - 3.0f, w + 6.0f, h + 6.0f);
    if (hov)
        StrokeR(c, x - 2.0f, y - 2.0f, w + 4.0f, h + 4.0f, c.accent,
                (h + 4.0f) * 0.5f, 1.2f, 0.6f);
    return hov && c.Clicked();
}

void RefThemeSwatch(const Ctx& c, float x, float y, float w, float h,
                   const ImColor& a, const ImColor& b, bool selected) {
    // Two-tone fill (left half a, right half b) instead of FillGradientV:
    // the vertical gradient primitive ignores radii and left sharp corners
    // sticking out of the rounded stroke. Same effective radius as the
    // stroke so the fill respects it.
    const float r = c.px(StyleRadius(11.0f));
    c.d->AddRectFilled(c.P(x, y), c.P(x + w, y + h),
                       ImColor(a.Value.x, a.Value.y, a.Value.z,
                               a.Value.w * 0.96f * c.alpha), r);
    c.d->AddRectFilled(c.P(x + w * 0.5f, y), c.P(x + w, y + h),
                       ImColor(b.Value.x, b.Value.y, b.Value.z,
                               b.Value.w * 0.96f * c.alpha), r,
                       ImDrawFlags_RoundCornersRight);
    StrokeR(c, x, y, w, h, selected ? kText : kBorder, 11.0f,
            selected ? 1.5f : 1.0f, selected ? 0.95f : 0.8f);
    if (selected)
        c.d->AddCircleFilled(c.P(x + w - 13.0f, y + 13.0f), c.px(3.0f), kText, 12);
}

const char* RefThemeLabel(int i) {
    static const char* names[] = {
        "Ember Dusk", "Mint Glass", "Moon Rose", "Arctic Slate",
        "Amethyst Fog", "Mono Bone"
    };
    return (i >= 0 && i < 6) ? names[i] : "Custom";
}

float RefSettingHeight(const Setting* s) {
    if (!ModuleSettingVisible(s)) return 0.0f;
    switch (s->mType) {
        case SettingType::Number: return 90.0f;
        case SettingType::Bool: return 64.0f;
        case SettingType::Enum: return 94.0f;
        case SettingType::Color: return g_colorEditSetting == s ? 224.0f : 78.0f;
        case SettingType::String: return 102.0f;
    }
    return 64.0f;
}

float RefModuleSettingsHeight(Module* m) {
    if (!m) return 78.0f;
    float h = 0.0f;
    for (const auto& holder : m->settings())
        if (ModuleSettingVisible(holder.get())) h += RefSettingHeight(holder.get()) + 10.0f;
    return h > 0.0f ? h : 78.0f;
}

float RefDrawModuleSettings(Ctx& c, Module* m, float x, float y, float w) {
    if (!m || m->settings().empty()) {
        FillR(c, x, y, w, 70.0f, kField, 0.0f, 1.0f);
        StrokeR(c, x, y, w, 70.0f, kBorder, 0.0f, 1.0f, 0.8f);
        Text(c, x + 14, y + 14, "Module settings", fonts::UISemi(), 12, kText);
        Text(c, x + 14, y + 37, "No extra controls for this module.", fonts::UI(), 10, kMuted);
        return 70.0f;
    }
    for (const auto& holder : m->settings()) {
        Setting* s = holder.get();
        if (!ModuleSettingVisible(s)) continue;
        const float h = RefSettingHeight(s);
        FillR(c, x, y, w, h, SystemSurface(), 8.0f, 1.0f);
        // Each setting is a quiet section, not a nested boxed card.
        const float labelW = w - ((s->mType == SettingType::Bool) ? 80.0f : 28.0f);
        c.d->PushClipRect(c.P(x + 14, y + 8), c.P(x + 14 + labelW, y + 33), true);
        Text(c, x + 14, y + 11, s->mName.c_str(), fonts::UISemi(), 14, kText);
        c.d->PopClipRect();
        if (!s->mDescription.empty()) {
            std::string desc = s->mDescription;
            while (desc.size() > 8 && TextW(fonts::UI(), desc.c_str(), 11, c.s) > w - 28.0f)
                { size_t at = desc.size() - 1;
                  while (at > 0 && ((unsigned char)desc[at] & 0xC0) == 0x80) --at;
                  desc.resize(at); }
            if (desc.size() < s->mDescription.size()) desc += "…";
            Text(c, x + 14, y + 33, desc.c_str(), fonts::UI(), 11, kMuted);
        }
        if (s->mType == SettingType::Bool) {
            BoolSetting* bs = static_cast<BoolSetting*>(s);
            RefSwitch(c, x + w - 58, y + 16, bs->mValue, bs->mAnim);
            if (c.Hover(x + w - 66, y + 9, 58, 42) && c.Clicked()) bs->mValue = !bs->mValue;
        } else if (s->mType == SettingType::Number && s->mIsKeybind) {
            // r34: key-capture button instead of a 0..255 slider.
            NumberSetting* ns = static_cast<NumberSetting*>(s);
            const bool listening = g_keyEditSetting == ns;
            const char* label = listening ? "Нажми клавишу…"
                : (ns->mValue > 0.0f ? keys::Name((unsigned)ns->mValue) : "Не назначено");
            const float kw = w - 28.0f;
            const float kx = x + 14.0f, ky = y + 52.0f, kh = 30.0f;
            const float pulse = listening ? 0.6f + 0.4f * std::sin((float)ImGui::GetTime() * 6.0f) : 1.0f;
            const bool hov = c.Hover(kx, ky, kw, kh);
            FillR(c, kx, ky, kw, kh, listening ? gui::LerpColor(c.accent, kField, 0.6f) : kTrack, 8.0f, 0.95f);
            StrokeR(c, kx, ky, kw, kh, (listening || hov) ? c.accent : kBorder, 8.0f,
                    listening ? 1.6f : 1.0f, pulse);
            const float tw = TextW(fonts::UISemi(), label, 11, c.s);
            Text(c, kx + (kw - tw) * 0.5f, ky + (kh - TextH(fonts::UISemi(), 11, c.s)) * 0.5f,
                 label, fonts::UISemi(), 11,
                 listening ? kText : (ns->mValue > 0.0f ? c.accent : kMuted), pulse);
            if (hov && c.Clicked()) {
                EndStringEdit(true);
                g_field.kind = Field::None;
                g_keyEditSetting = listening ? nullptr : ns;
            }
            if (hov && c.RightClicked()) { ns->setValue(0.0f); g_keyEditSetting = nullptr; }
        } else if (s->mType == SettingType::Number) {
            NumberSetting* ns = static_cast<NumberSetting*>(s);
            char value[32];
            snprintf(value, sizeof(value), "%.2f", ns->mValue);
            TextRight(c, x + w - 14, y + 53, value, fonts::UISemi(), 12, kText);
            SliderF(c, x + 14, y + h - 23, w - 28, &ns->mValue, ns->mMin, ns->mMax);
            SliderBubble(c, x + 14, y + h - 23, w - 28, &ns->mValue, ns->mMin, ns->mMax, ns->mStep);
            ns->setValue(ns->mValue);
        } else if (s->mType == SettingType::Enum) {
            EnumSetting* es = static_cast<EnumSetting*>(s);
            const float ex = x + 14.0f, ey = y + 54.0f, ew = w - 28.0f;
            std::string cur = es->current();
            while (cur.size() > 4 && TextW(fonts::UISemi(), cur.c_str(), 12, c.s) > ew - 38.0f) {
                size_t at = cur.size() - 1;
                while (at > 0 && ((unsigned char)cur[at] & 0xC0) == 0x80) --at;
                cur.resize(at);
            }
            if (cur.size() < es->current().size()) cur += "…";
            FillR(c, ex, ey, ew, 30.0f, kField, 8.0f);
            StrokeR(c, ex, ey, ew, 30.0f, c.Hover(ex, ey, ew, 30) ? c.accent : kBorder, 8.0f, 1.0f);
            Text(c, ex + 10, ey + 7, cur.c_str(), fonts::UISemi(), 12, kText);
            IconGlyph(c, Icon::ChevronDown, ex + ew - 15, ey + 15, 12, kMuted);
            if (c.Hover(ex, ey, ew, 30) && c.Clicked()) {
                EndStringEdit(true); g_field.kind = Field::None;
                g_systemEnum = es;
                const ImVec2 a = c.P(ex, ey), b = c.P(ex + ew, ey + 30);
                g_systemEnumRect = ImVec4(a.x, a.y, b.x, b.y);
                g_systemEnumFrame = ImGui::GetFrameCount();
            }
        } else if (s->mType == SettingType::Color) {
            ColorSetting* cs = static_cast<ColorSetting*>(s);
            const bool open = g_colorEditSetting == cs;
            const bool dotHov = c.Hover(x + w - 46, y + 8, 46, 46);
            ColorDot(c, x + w - 36, y + 18, 18.0f, cs->getAsImColor(), open);
            if (dotHov && c.Clicked()) {
                if (open) {
                    g_colorEditSetting = nullptr;
                    g_colorDrag = nullptr;
                } else {
                    g_colorEditSetting = cs;
                    g_colorDrag = nullptr;
                    float h, s2, v;
                    ColorRgbToHsvF(cs->mValue[0], cs->mValue[1], cs->mValue[2], &h, &s2, &v);
                    g_colorHue = h;
                }
            }
            if (open) {
                // r25: inline HSV editor - SV square, hue strip, alpha bar and
                // the hex value. Works for every color setting in the client.
                const float sq = 92.0f;
                const float sqx = x + 14.0f, sqy = y + 56.0f;
                const float hx = sqx + sq + 10.0f, hw = 14.0f;
                const float ax = sqx, ay = sqy + sq + 12.0f, aw = sq + 10.0f + hw, ah = 14.0f;
                float h = 0.0f, sat = 0.0f, val = 0.0f;
                ColorRgbToHsvF(cs->mValue[0], cs->mValue[1], cs->mValue[2], &h, &sat, &val);
                const ImColor hueCol = ImColor::HSV(g_colorHue, 1.0f, 1.0f, 1.0f);
                const ImU32 white = ImGui::GetColorU32(ImVec4(1.0f, 1.0f, 1.0f, c.alpha));
                const ImU32 hueU32 = ImGui::GetColorU32(ImVec4(hueCol.Value.x, hueCol.Value.y,
                                                               hueCol.Value.z, c.alpha));
                c.d->AddRectFilledMultiColor(c.P(sqx, sqy), c.P(sqx + sq, sqy + sq),
                                             white, hueU32, hueU32, white);
                const ImU32 clearB = ImGui::GetColorU32(ImVec4(0, 0, 0, 0));
                const ImU32 blackB = ImGui::GetColorU32(ImVec4(0, 0, 0, 0.98f * c.alpha));
                c.d->AddRectFilledMultiColor(c.P(sqx, sqy), c.P(sqx + sq, sqy + sq),
                                             clearB, clearB, blackB, blackB);
                StrokeR(c, sqx, sqy, sq, sq, kBorder, 0.0f, 1.0f, 0.9f);
                const float cvx = sqx + sat * sq, cvy = sqy + (1.0f - val) * sq;
                c.d->AddCircle(c.P(cvx, cvy), c.px(5.5f), ImGui::GetColorU32(ImVec4(1, 1, 1, c.alpha)),
                               16, c.px(1.6f));
                c.d->AddCircle(c.P(cvx, cvy), c.px(6.5f), ImGui::GetColorU32(ImVec4(0, 0, 0, 0.55f * c.alpha)),
                               16, c.px(1.0f));
                for (int k = 0; k < 6; ++k) {
                    const ImColor c0 = ImColor::HSV((float)k / 6.0f, 1.0f, 1.0f, c.alpha);
                    const ImColor c1 = ImColor::HSV((float)(k + 1) / 6.0f, 1.0f, 1.0f, c.alpha);
                    const ImU32 u0 = ImGui::GetColorU32(ImVec4(c0.Value.x, c0.Value.y, c0.Value.z, c0.Value.w));
                    const ImU32 u1 = ImGui::GetColorU32(ImVec4(c1.Value.x, c1.Value.y, c1.Value.z, c1.Value.w));
                    c.d->AddRectFilledMultiColor(c.P(hx, sqy + sq * (float)k / 6.0f),
                                                 c.P(hx + hw, sqy + sq * (float)(k + 1) / 6.0f),
                                                 u0, u0, u1, u1);
                }
                const float hy = sqy + g_colorHue * sq;
                c.d->AddLine(c.P(hx - 2.0f, hy), c.P(hx + hw + 2.0f, hy),
                             ImGui::GetColorU32(ImVec4(1, 1, 1, c.alpha)), c.px(2.0f));
                const ImU32 a0 = ImGui::GetColorU32(ImVec4(cs->mValue[0], cs->mValue[1], cs->mValue[2], 0.0f));
                const ImU32 a1 = ImGui::GetColorU32(ImVec4(cs->mValue[0], cs->mValue[1], cs->mValue[2], c.alpha));
                c.d->AddRectFilledMultiColor(c.P(ax, ay), c.P(ax + aw, ay + ah), a0, a1, a1, a0);
                StrokeR(c, ax, ay, aw, ah, kBorder, 0.0f, 1.0f, 0.9f);
                const float akx = ax + cs->mValue[3] * aw;
                c.d->AddCircleFilled(c.P(akx, ay + ah * 0.5f), c.px(5.0f),
                                     ImGui::GetColorU32(ImVec4(1, 1, 1, c.alpha)), 16);
                char hex[16];
                snprintf(hex, sizeof(hex), "#%02X%02X%02X",
                         (int)(cs->mValue[0] * 255.0f + 0.5f),
                         (int)(cs->mValue[1] * 255.0f + 0.5f),
                         (int)(cs->mValue[2] * 255.0f + 0.5f));
                Text(c, hx + hw + 12.0f, sqy + 1.0f, hex, fonts::UISemi(), 9, kText);
                FillR(c, hx + hw + 12.0f, sqy + 20.0f, 44.0f, 20.0f,
                      cs->getAsImColor(), 5.0f, 0.95f);
                StrokeR(c, hx + hw + 12.0f, sqy + 20.0f, 44.0f, 20.0f, kBorder, 5.0f, 1.0f, 0.8f);
                if (c.Clicked() && !g_colorDrag) {
                    if (c.Hover(sqx, sqy, sq, sq)) {
                        g_colorDrag = cs;
                        g_colorDragArea = 0;
                        g_colorDragRect = ImVec4(sqx, sqy, sqx + sq, sqy + sq);
                    } else if (c.Hover(hx - 4.0f, sqy, hw + 8.0f, sq)) {
                        g_colorDrag = cs;
                        g_colorDragArea = 1;
                        g_colorDragRect = ImVec4(hx, sqy, hx + hw, sqy + sq);
                    } else if (c.Hover(ax, ay - 5.0f, aw, ah + 10.0f)) {
                        g_colorDrag = cs;
                        g_colorDragArea = 2;
                        g_colorDragRect = ImVec4(ax, ay, ax + aw, ay + ah);
                    }
                    if (g_colorDrag == cs) {
                        g_colorDragCtx = c;
                        ApplyColorDrag(cs);
                    }
                }
                if (g_colorDrag == cs) {
                    // Keep the captured geometry fresh like SliderF does.
                    g_colorDragCtx = c;
                    const int area = g_colorDragArea;
                    if (area == 0) g_colorDragRect = ImVec4(sqx, sqy, sqx + sq, sqy + sq);
                    else if (area == 1) g_colorDragRect = ImVec4(hx, sqy, hx + hw, sqy + sq);
                    else g_colorDragRect = ImVec4(ax, ay, ax + aw, ay + ah);
                }
            }
        } else if (s->mType == SettingType::String) {
            // r34: a real, visible input box (it used to be read-only text).
            StringSetting* ss = static_cast<StringSetting*>(s);
            const bool active = g_stringEditSetting == ss;
            const float fx = x + 14.0f, fy = y + 50.0f, fw = w - 28.0f, fh = 32.0f;
            const bool hov = c.Hover(fx, fy, fw, fh);
            if (active && hov) g_stringFieldHovered = true;
            FillR(c, fx, fy, fw, fh, active ? gui::LerpColor(c.accent, kTrack, 0.85f) : kTrack, 8.0f, 0.95f);
            StrokeR(c, fx, fy, fw, fh, active ? c.accent : (hov ? kSecBorder : kBorder), 8.0f,
                    active ? 1.6f : 1.0f);
            const char* shown = active ? g_stringEditBuf : ss->mValue.c_str();
            const float th = TextH(fonts::UI(), 11, c.s);
            const float ty = fy + (fh - th) * 0.5f;
            const float innerW = fw - 22.0f;
            const float textW = TextW(fonts::UI(), shown, 11, c.s);
            // Long text scrolls so the end (and the caret) stays visible.
            const float shift = (active && textW > innerW) ? textW - innerW : 0.0f;
            const ImVec2 ca = c.P(fx + 8.0f, fy), cb = c.P(fx + fw - 8.0f, fy + fh);
            c.d->PushClipRect(ca, cb, true);
            if (shown[0])
                Text(c, fx + 11.0f - shift, ty, shown, fonts::UI(), 11, kText);
            else
                Text(c, fx + 11.0f, ty, active ? "Печатай…  (Enter - готово, Esc - отмена)"
                                               : "Нажми, чтобы ввести текст",
                     fonts::UI(), 10, kFaint);
            if (active && ((int)(ImGui::GetTime() * 2.0) % 2 == 0))
                FillR(c, fx + 11.0f - shift + textW + 1.0f, ty, 1.5f, th, c.accent, 0.0f, 0.95f);
            c.d->PopClipRect();
            if (!active && ss->mValue.size())
                TextRight(c, x + w - 14, y + 86, "изменить", fonts::UI(), 8, kMuted);
            if (hov && c.Clicked()) { BeginStringEdit(ss); g_stringFieldHovered = true; }
        }
        y += h + 10.0f;
    }
    return y;
}


// Mini icon of a cursor style, drawn in a button/preview box.
void CursorStyleIcon(ImDrawList* d, int style, const ImVec2& c0, float s, ImU32 col) {
    const ImU32 dark = IM_COL32(15, 18, 22, 220);
    if (style == 1) {            // ring
        d->AddCircle(c0, 6.0f * s, col, 24, 1.4f * s);
        d->AddCircleFilled(c0, 1.4f * s, col, 10);
    } else if (style == 2) {     // cross
        const float g = 2.4f * s, l = 6.0f * s, th = 1.4f * s;
        d->AddLine(ImVec2(c0.x, c0.y - g - l), ImVec2(c0.x, c0.y - g), col, th);
        d->AddLine(ImVec2(c0.x, c0.y + g), ImVec2(c0.x, c0.y + g + l), col, th);
        d->AddLine(ImVec2(c0.x - g - l, c0.y), ImVec2(c0.x - g, c0.y), col, th);
        d->AddLine(ImVec2(c0.x + g, c0.y), ImVec2(c0.x + g + l, c0.y), col, th);
    } else if (style == 3) {     // dot
        d->AddCircleFilled(c0, 3.2f * s, col, 18);
        d->AddCircle(c0, 3.2f * s, dark, 18, 0.7f * s);
    } else if (style == 4) {     // diamond
        const float r = 5.5f * s;
        const ImVec2 v[4] = { ImVec2(c0.x, c0.y - r), ImVec2(c0.x + r, c0.y),
                              ImVec2(c0.x, c0.y + r), ImVec2(c0.x - r, c0.y) };
        d->AddConvexPolyFilled(v, 4, col);
        d->AddPolyline(v, 4, dark, ImDrawFlags_Closed, 0.9f * s);
    } else if (style == 5) {     // orbit
        d->AddCircle(c0, 5.5f * s, col, 24, 1.2f * s);
        d->AddCircleFilled(ImVec2(c0.x + 5.5f * s, c0.y), 1.8f * s, col, 10);
        d->AddCircleFilled(c0, 1.3f * s, col, 8);
    } else if (style == 6) {     // blade
        const ImVec2 v[4] = { ImVec2(c0.x - 4.5f*s, c0.y - 4.5f*s), ImVec2(c0.x - 2.0f*s, c0.y - 2.0f*s),
                              ImVec2(c0.x + 5.5f*s, c0.y - 1.0f*s), ImVec2(c0.x - 0.5f*s, c0.y + 5.0f*s) };
        d->AddConvexPolyFilled(v, 4, col);
        d->AddPolyline(v, 4, dark, ImDrawFlags_Closed, 0.9f * s);
    } else if (style == 7) {     // brackets
        const float arm = 3.2f * s, out = 6.0f * s, th = 1.3f * s;
        d->AddLine(ImVec2(c0.x - out, c0.y - out + arm), ImVec2(c0.x - out, c0.y - out), col, th);
        d->AddLine(ImVec2(c0.x - out, c0.y - out), ImVec2(c0.x - out + arm, c0.y - out), col, th);
        d->AddLine(ImVec2(c0.x + out - arm, c0.y - out), ImVec2(c0.x + out, c0.y - out), col, th);
        d->AddLine(ImVec2(c0.x + out, c0.y - out), ImVec2(c0.x + out, c0.y - out + arm), col, th);
        d->AddLine(ImVec2(c0.x - out, c0.y + out - arm), ImVec2(c0.x - out, c0.y + out), col, th);
        d->AddLine(ImVec2(c0.x - out, c0.y + out), ImVec2(c0.x - out + arm, c0.y + out), col, th);
        d->AddLine(ImVec2(c0.x + out - arm, c0.y + out), ImVec2(c0.x + out, c0.y + out), col, th);
        d->AddLine(ImVec2(c0.x + out, c0.y + out), ImVec2(c0.x + out, c0.y + out - arm), col, th);
    } else {                     // arrow
        const ImVec2 v[7] = {
            ImVec2(c0.x - 3.0f*s, c0.y - 6.0f*s), ImVec2(c0.x - 1.8f*s, c0.y + 5.0f*s),
            ImVec2(c0.x + 0.4f*s, c0.y + 2.2f*s), ImVec2(c0.x + 2.6f*s, c0.y + 6.4f*s),
            ImVec2(c0.x + 4.4f*s, c0.y + 5.2f*s), ImVec2(c0.x + 2.6f*s, c0.y + 0.6f*s),
            ImVec2(c0.x + 6.2f*s, c0.y + 0.6f*s)
        };
        d->AddConvexPolyFilled(v, 7, col);
        d->AddPolyline(v, 7, dark, ImDrawFlags_Closed, 0.9f * s);
    }
}

// Cursor customization card. Storage lives in ThemesModule settings; the
// overlay pulls them every frame in ApplyClientModules(). Visible in the GUI
// category gallery and in the (legacy) Themes inspector tab.
float PaintCursorCard(Ctx& c, float x, float y, float w) {
    ThemesModule* tm = ThemesModule::instance();
    const float h = 214.0f;
    FillR(c, x, y, w, h, kField, 18.0f, 0.68f);
    StrokeR(c, x, y, w, h, kBorder, 18.0f, 1.0f, 0.7f);
    Text(c, x + 14, y + 13, "Cursor", fonts::UISemi(), 11, kText);
    Text(c, x + 14, y + 34, "Вид указателя внутри GUI", fonts::UI(), 8, kMuted);
    static const char* names[8] = { "Arrow", "Ring", "Cross", "Dot",
                                    "Diamond", "Orbit", "Blade", "Brackets" };
    if (!tm || !tm->m_cursorStyle || !tm->m_cursorScale || !tm->m_cursorGlow ||
        !tm->m_cursorTheme || !tm->m_cursorColor) return h;
    // Live preview of the selected style, top-right corner of the header.
    {
        const ImVec2 pv = c.P(x + w - 44.0f, y + 27.0f);
        c.d->AddCircleFilled(pv, c.px(15.0f), ImColor(0, 0, 0, (int)(90 * c.alpha)), 20);
        const ImColor pc = tm->m_cursorTheme->mValue ? c.accent : tm->m_cursorColor->getAsImColor();
        CursorStyleIcon(c.d, tm->m_cursorStyle->mValue, pv, c.px(1.0f),
                        ImGui::GetColorU32(ImVec4(pc.Value.x, pc.Value.y, pc.Value.z, pc.Value.w * c.alpha)));
    }
    for (int i = 0; i < 8; ++i) {
        const float bw = 78.0f;
        const float by = y + 57.0f + (i / 4) * 47.0f;
        const float bx = x + 14.0f + (i % 4) * (bw + 7.0f);
        const bool selected = tm->m_cursorStyle->mValue == i;
        const bool hov = c.Hover(bx, by, bw, 40.0f);
        FillR(c, bx, by, bw, 40.0f,
              selected ? gui::LerpColor(c.accent, kField, 0.38f) : kTrack,
              10.0f, selected ? 0.95f : (hov ? 0.88f : 0.62f));
        StrokeR(c, bx, by, bw, 40.0f, selected || hov ? c.accent : kBorder,
                10.0f, selected ? 1.4f : 1.0f, selected ? 0.95f : 0.55f);
        const ImColor ic = selected ? c.accent : kMuted;
        CursorStyleIcon(c.d, i, c.P(bx + 15.0f, by + 20.0f), c.px(1.0f),
                        ImGui::GetColorU32(ImVec4(ic.Value.x, ic.Value.y, ic.Value.z, ic.Value.w * c.alpha)));
        Text(c, bx + 28.0f, by + 13.0f, names[i], fonts::UISemi(), 8,
             selected ? c.accent : kText);
        if (hov && c.Clicked()) tm->m_cursorStyle->setValue(i);
    }
    Text(c, x + 14, y + 147, "Scale", fonts::UI(), 8, kMuted);
    char scaleText[16];
    snprintf(scaleText, sizeof(scaleText), "%.0f%%", tm->m_cursorScale->mValue * 100.0f);
    TextRight(c, x + w * 0.5f, y + 147, scaleText, fonts::UI(), 8, c.accent);
    SliderF(c, x + 14, y + 166, w * 0.5f - 20.0f, &tm->m_cursorScale->mValue, 0.50f, 2.00f);
    tm->m_cursorScale->setValue(tm->m_cursorScale->mValue);
    const float gx = x + w * 0.53f;
    Text(c, gx, y + 147, "Glow", fonts::UI(), 8, kMuted);
    char glowText[16];
    snprintf(glowText, sizeof(glowText), "%.0f%%", tm->m_cursorGlow->mValue * 100.0f);
    TextRight(c, x + w - 14, y + 147, glowText, fonts::UI(), 8, c.accent);
    SliderF(c, gx, y + 166, w * 0.43f, &tm->m_cursorGlow->mValue, 0.0f, 1.0f);
    tm->m_cursorGlow->setValue(tm->m_cursorGlow->mValue);
    const bool theme = tm->m_cursorTheme->mValue;
    const float tx = x + 14.0f, ty = y + 189.0f;
    Text(c, tx, ty + 2.0f, theme ? "Theme color" : "Custom color 1",
         fonts::UI(), 8, theme ? c.accent : kMuted);
    if (c.Hover(tx, ty - 4.0f, 120.0f, 24.0f) && c.Clicked())
        tm->m_cursorTheme->mValue = !tm->m_cursorTheme->mValue;
    if (!theme) {
        const float px = x + 138.0f;
        FillR(c, px, ty - 3.0f, 46.0f, 22.0f, tm->m_cursorColor->getAsImColor(), 8.0f, 0.95f);
        StrokeR(c, px, ty - 3.0f, 46.0f, 22.0f, c.accent, 8.0f, 1.0f, 0.6f);
    }
    return h;
}

float RefThemeTab(Ctx& c, float x, float y, float w) {
    ThemesModule* tm = ThemesModule::instance();
    const float cardW = w;
    // Only the real custom accent editor remains in this tab. It writes into
    // ThemesModule::m_color1, switches the engine to Custom and feeds the
    // same live accent used by panels, toggles and HUD modules.
    {
        const float h = 248.0f;
        FillR(c, x, y, cardW, h, kField, 18.0f, 0.72f);
        StrokeR(c, x, y, cardW, h, kBorder, 18.0f, 1.0f, 0.72f);
        Text(c, x + 14, y + 14, "Custom accent", fonts::UISemi(), 12, kText);
        Text(c, x + 14, y + 35, "Настрой цвет вручную — изменения применяются сразу.",
             fonts::UI(), 8, kMuted);
        ImColor current = tm && tm->m_color1 ? tm->m_color1->getAsImColor() : c.accent;
        FillR(c, x + 14, y + 62, 74, 74, current, 18.0f, 0.96f);
        StrokeR(c, x + 14, y + 62, 74, 74, kText, 18.0f, 1.0f, 0.42f);
        char hex[16];
        snprintf(hex, sizeof(hex), "#%02X%02X%02X",
                 (int)(current.Value.x * 255.0f + 0.5f),
                 (int)(current.Value.y * 255.0f + 0.5f),
                 (int)(current.Value.z * 255.0f + 0.5f));
        Text(c, x + 14, y + 146, hex, fonts::UISemi(), 9, c.accent);
        if (tm && tm->m_color1) {
            const float sx = x + 106.0f, sw = cardW - 120.0f;
            const char* labels[] = { "Red", "Green", "Blue" };
            float* channels[] = { &tm->m_color1->mValue[0], &tm->m_color1->mValue[1],
                                  &tm->m_color1->mValue[2] };
            for (int i = 0; i < 3; i++) {
                const float sy = y + 59.0f + i * 54.0f;
                Text(c, sx, sy, labels[i], fonts::UI(), 9, kMuted);
                char value[16];
                snprintf(value, sizeof(value), "%d", (int)(*channels[i] * 255.0f + 0.5f));
                TextRight(c, x + cardW - 14, sy, value, fonts::UISemi(), 9, c.accent);
                const bool touching = c.Hover(sx - 6, sy + 17, sw + 12, 24) && c.Clicked();
                SliderF(c, sx, sy + 18, sw, channels[i], 0.0f, 1.0f);
                if (touching && tm->m_theme) tm->m_theme->setValue(ThemesModule::ThemeCustom);
            }
        }
        Text(c, x + 106, y + 222,
             "RGB values are live and are saved in the local theme profile.",
             fonts::UI(), 8, kMuted);
        y += h + 10.0f;
    }
    y += PaintCursorCard(c, x, y, cardW) + 10.0f;
    {
        const float h = 72.0f;
        FillR(c, x, y, cardW, h, kField, 18.0f, 0.68f);
        StrokeR(c, x, y, cardW, h, kBorder, 18.0f, 1.0f, 0.7f);
        Text(c, x + 14, y + 13, "Panel roundness", fonts::UISemi(), 11, kText);
        char value[16]; snprintf(value, sizeof(value), "%.0fpx", g_refRadius);
        TextRight(c, x + cardW - 14, y + 13, value, fonts::UI(), 9, c.accent);
        SliderF(c, x + 14, y + 39, cardW - 28, &g_refRadius, 18.0f, 38.0f);
        y += h + 10.0f;
    }
    {
        const float h = 72.0f;
        FillR(c, x, y, cardW, h, kField, 18.0f, 0.68f);
        StrokeR(c, x, y, cardW, h, kBorder, 18.0f, 1.0f, 0.7f);
        Text(c, x + 14, y + 13, "Noise texture", fonts::UISemi(), 11, kText);
        char value[16]; snprintf(value, sizeof(value), "%.0f%%", g_refGrain * 100.0f);
        TextRight(c, x + cardW - 14, y + 13, value, fonts::UI(), 9, c.accent);
        SliderF(c, x + 14, y + 39, cardW - 28, &g_refGrain, 0.0f, 0.30f);
        y += h + 10.0f;
    }
    {
        const float h = 72.0f;
        FillR(c, x, y, cardW, h, kField, 18.0f, 0.68f);
        StrokeR(c, x, y, cardW, h, kBorder, 18.0f, 1.0f, 0.7f);
        // Bound through the persisted General "GUI Size" setting (falls back
        // to the static when the module is somehow missing).
        GeneralModule* gs = GeneralModule::instance();
        NumberSetting* guiSize = gs ? gs->m_guiSize : nullptr;
        float* const guiSizeV = guiSize ? &guiSize->mValue : &g_refUiScale;
        Text(c, x + 14, y + 13, "GUI size", fonts::UISemi(), 11, kText);
        char value[16]; snprintf(value, sizeof(value), "%.0f%%", *guiSizeV * 100.0f);
        TextRight(c, x + cardW - 14, y + 13, value, fonts::UI(), 9, c.accent);
        SliderF(c, x + 14, y + 39, cardW - 28, guiSizeV, 0.80f, 1.30f);
        // Snap to the setting's 0.01 step (same pattern as the inspector
        // number sliders) and re-clamp to its declared range.
        if (guiSize) guiSize->setValue(guiSize->mValue);
        y += h;
    }
    return y;
}

float RefHudTab(Ctx& c, float x, float y, float w) {
    // "Edit HUD on screen": closes the ClickGUI and lands in the free-form
    // HUD editor (the setting is the editor's source of truth, so flipping
    // it here arms edit mode for the next frame's reconciliation).
    {
        const float h = 64.0f;
        const bool hov = c.Hover(x, y, w, h);
        FillR(c, x, y, w, h, hov ? gui::LerpColor(c.accent, kField, 0.55f) : kField,
              18.0f, 0.72f);
        StrokeR(c, x, y, w, h, hov ? c.accent : kBorder, 18.0f, 1.0f, hov ? 0.95f : 0.7f);
        Text(c, x + 14, y + 13, "Edit HUD on screen", fonts::UISemi(), 11, kText);
        Text(c, x + 14, y + 35, "Перетаскивай где угодно, колесо — размер", fonts::UI(), 8, kMuted);
        if (hov && c.Clicked()) {
            GeneralModule* g = GeneralModule::instance();
            if (g && g->m_hudEdit) g->m_hudEdit->mValue = true;
            overlay::g_showMenu = false;
            overlay::HudEditSet(true);
            Toast("HUD editor on");
        }
        y += h + 10.0f;
    }
    const float previewH = 196.0f;
    HudCanvasArt(c, x, y, w, previewH);
    StrokeR(c, x, y, w, previewH, kBorder, 18.0f, 1.0f, 0.8f);
    Ctx clip = c;
    clip.d->PushClipRect(clip.P(x, y), clip.P(x + w, y + previewH), true);
    // Watermark widget preserved from the former HUD editor, restyled as the
    // reference HUD preview and still draggable inside the canvas.
    const float sc = g_hudScale / 100.0f;
    const float bw = 136.0f * sc, bh = 30.0f * sc;
    const float wx = x + g_hudX / 100.0f * w;
    const float wy = y + g_hudY / 100.0f * previewH;
    FillR(clip, wx, wy, bw, bh, kField, 13.0f, 0.9f);
    StrokeR(clip, wx, wy, bw, bh, c.accent, 13.0f, 1.0f, 0.92f);
    Text(clip, wx + 10.0f * sc, wy + 8.0f * sc, "Nightfull", fonts::UISemi(), 10.0f * sc, kText);
    Text(clip, wx + 70.0f * sc, wy + 8.0f * sc, "1.21.111", fonts::UI(), 8.0f * sc, c.accent);
    // Array list uses actual enabled modules, not mock data.
    float ay = y + 14.0f;
    int shown = 0;
    for (const auto& holder : modules().modules()) {
        Module* m = holder.get();
        if (!m || m->hiddenFromLists || !m->enabled() || shown >= 4) continue;
        const float tw = TextW(fonts::UI(), m->name(), 8, c.s) + 16.0f;
        FillR(clip, x + w - tw - 12, ay, tw, 18, gui::LerpColor(c.accent, kField, 0.68f), 9.0f, 0.76f);
        TextRight(clip, x + w - 20, ay + 4, m->name(), fonts::UI(), 8, kText);
        ay += 22.0f;
        shown++;
    }
    Module* cross = FindModule("Crosshair");
    if (cross && cross->enabled()) {
        const float cx = x + w * 0.5f, cy = y + previewH * 0.53f;
        clip.d->AddLine(clip.P(cx - 10, cy), clip.P(cx + 10, cy), c.accent, clip.px(1.0f));
        clip.d->AddLine(clip.P(cx, cy - 10), clip.P(cx, cy + 10), c.accent, clip.px(1.0f));
    }
    Text(clip, x + 12, y + previewH - 24, "XYZ 128, 64, -340  |  Ping 38ms", fonts::UI(), 8, kMuted);
    clip.d->PopClipRect();
    const bool widgetHover = c.Hover(wx, wy, bw, bh);
    if (widgetHover && c.Clicked()) {
        const ImVec2 m = c.Mouse();
        g_hudGrabX = m.x - wx;
        g_hudGrabY = m.y - wy;
        g_hudDrag = true;
    }
    if (g_hudDrag) {
        if (!overlay::g_guiMouseDown[0] && !ImGui::GetIO().MouseDown[0]) {
            g_hudDrag = false;
        } else {
            const ImVec2 m = c.Mouse();
            g_hudX = gui::Clamp((m.x - g_hudGrabX - x) / w * 100.0f, 0.0f, 64.0f);
            g_hudY = gui::Clamp((m.y - g_hudGrabY - y) / previewH * 100.0f, 0.0f, 82.0f);
        }
    }
    y += previewH + 10.0f;
    {
        const float h = 78.0f;
        FillR(c, x, y, w, h, kField, 18.0f, 0.7f);
        StrokeR(c, x, y, w, h, kBorder, 18.0f, 1.0f, 0.7f);
        Text(c, x + 14, y + 13, "HUD scale", fonts::UISemi(), 11, kText);
        char value[16]; snprintf(value, sizeof(value), "%.0f%%", g_hudScale);
        TextRight(c, x + w - 14, y + 13, value, fonts::UI(), 9, c.accent);
        SliderF(c, x + 14, y + 42, w - 28, &g_hudScale, 70.0f, 150.0f);
        y += h + 10.0f;
    }
    {
        const float h = 62.0f;
        FillR(c, x, y, w, h, kField, 18.0f, 0.7f);
        StrokeR(c, x, y, w, h, kBorder, 18.0f, 1.0f, 0.7f);
        Text(c, x + 14, y + 14, "Crosshair", fonts::UISemi(), 11, kText);
        Text(c, x + 14, y + 35, "Показывать центр в HUD canvas", fonts::UI(), 8, kMuted);
        Module* chm = FindModule("Crosshair");
        static float crossAnim = 0.0f;
        RefSwitch(c, x + w - 58, y + 18, chm && chm->enabled(), crossAnim);
        if (chm && c.Hover(x + w - 70, y + 10, 66, 44) && c.Clicked())
            ApplyModuleState(chm, !chm->enabled());
        y += h + 10.0f;
    }
    if (RefPill(c, x, y, (w - 10.0f) * 0.5f, 38.0f, "Reset position", false)) {
        g_hudX = 5.0f; g_hudY = 8.0f; g_hudScale = 100.0f;
        Toast("HUD position reset");
    }
    if (RefPill(c, x + (w + 10.0f) * 0.5f, y, (w - 10.0f) * 0.5f, 38.0f,
               "Export HUD", true))
        Toast("HUD configuration exported");
    return y + 38.0f;
}

void PaintReferenceTopbar(Ctx& c, bool& fieldClaimed) {
    RefPanelSurface(c, kRefCenterX, 16, kRefCenterW, 48);
    IconGlyph(c, Icon::Box, kRefCenterX + 24, 40, 18, kText);
    const char* title = g_systemConfigs ? "Configs" : g_showGeneral ? "Settings" :
        g_systemFavoritesOnly ? "Favorites" : g_refCategory < 0 ? "All modules" : kRefCategoryNames[g_refCategory];
    Text(c, kRefCenterX + 44, 31, title, fonts::UISemi(), 14, kText);
    const float sx = kRefCenterX + 222, sw = kRefCenterW - 222 - 210;
    TextField(c, sx, 22, sw, 36, Field::Search, g_search, sizeof(g_search), "Search modules…", true);
    if (c.Hover(sx, 22, sw, 36) && c.Clicked()) fieldClaimed = true;

    const unsigned icons[] = { Icon::Sparkles, SystemDark() ? Icon::Sun : Icon::Moon, Icon::Monitor, Icon::X };
    for (int i = 0; i < 4; ++i) {
        const float bx = kRefMainW - 196 + i * 44.0f;
        const bool hov = c.Hover(bx, 22, 36, 36);
        FillR(c, bx, 22, 36, 36, hov ? kTrack : kField, 10);
        StrokeR(c, bx, 22, 36, 36, kBorder, 10, 1);
        IconGlyph(c, icons[i], bx + 18, 40, 16, i == 0 && g_systemFavoritesOnly ? c.accent : kText);
        if (!hov || !c.Clicked()) continue;
        if (i == 0) { g_systemFavoritesOnly = !g_systemFavoritesOnly; g_showGeneral = false; g_systemConfigs = false; }
        if (i == 1) {
            GeneralModule* gm = GeneralModule::instance();
            if (gm && gm->m_guiAppearance) gm->m_guiAppearance->setValue(SystemDark() ? 0 : 1);
        }
        if (i == 2) {
            GeneralModule* gm = GeneralModule::instance();
            if (gm && gm->m_hudEdit) gm->m_hudEdit->mValue = true;
            overlay::g_showMenu = false; overlay::HudEditSet(true); Toast("HUD editor on");
        }
        if (i == 3) overlay::g_showMenu = false;
    }
}


// Obsidian prototype glyphs, vector-drawn (zero font-coverage risk -
// system fonts may lack these codepoints, so paths instead of text).
// cat: 0 Combat (crossed blades), 1 Movement (wave), 2 Visual (eye),
// 3 Player (diamond), 4 World (globe), 5 Client (filled diamond),
// 6 GUI (2x2 grid). c0 = screen center, u = screen px per design px.
void ObsCatIcon(ImDrawList* d, const ImVec2& c0, float u, int cat, ImU32 col) {
    const float th = 1.8f * u;
    switch (cat) {
        case 0: { // crossed blades + guards
            d->AddLine(ImVec2(c0.x - 5 * u, c0.y + 5 * u), ImVec2(c0.x + 5 * u, c0.y - 5 * u), col, th);
            d->AddLine(ImVec2(c0.x + 5 * u, c0.y + 5 * u), ImVec2(c0.x - 5 * u, c0.y - 5 * u), col, th);
            d->AddLine(ImVec2(c0.x - 6.5f * u, c0.y + 2.5f * u), ImVec2(c0.x - 2.5f * u, c0.y + 6.5f * u), col, th);
            d->AddLine(ImVec2(c0.x + 6.5f * u, c0.y + 2.5f * u), ImVec2(c0.x + 2.5f * u, c0.y + 6.5f * u), col, th);
            break;
        }
        case 1: { // wave (HTML movement glyph)
            const ImVec2 p[4] = { ImVec2(c0.x - 6 * u, c0.y + 1 * u), ImVec2(c0.x - 2 * u, c0.y - 3 * u),
                                  ImVec2(c0.x + 2 * u, c0.y + 3 * u), ImVec2(c0.x + 6 * u, c0.y - 1 * u) };
            d->AddPolyline(p, 4, col, false, th);
            break;
        }
        case 2: { // eye (HTML render glyph)
            d->AddCircle(c0, 5.0f * u, col, 20, th);
            d->AddCircleFilled(c0, 2.0f * u, col, 10);
            break;
        }
        case 3: { // outline diamond (HTML player glyph)
            d->AddQuad(ImVec2(c0.x, c0.y - 5.5f * u), ImVec2(c0.x + 5.5f * u, c0.y),
                       ImVec2(c0.x, c0.y + 5.5f * u), ImVec2(c0.x - 5.5f * u, c0.y), col, th);
            break;
        }
        case 4: { // globe
            d->AddCircle(c0, 5.5f * u, col, 22, th);
            d->AddLine(ImVec2(c0.x - 5.5f * u, c0.y), ImVec2(c0.x + 5.5f * u, c0.y), col, 1.2f * u);
            d->AddLine(ImVec2(c0.x, c0.y - 5.5f * u), ImVec2(c0.x, c0.y + 5.5f * u), col, 1.2f * u);
            break;
        }
        case 5: { // filled diamond (HTML all-modules glyph)
            d->AddQuadFilled(ImVec2(c0.x, c0.y - 5.5f * u), ImVec2(c0.x + 5.5f * u, c0.y),
                             ImVec2(c0.x, c0.y + 5.5f * u), ImVec2(c0.x - 5.5f * u, c0.y), col);
            break;
        }
        default: { // 2x2 grid (HTML misc/GUI glyph)
            const float q = 3.4f * u, g = 1.4f * u;
            d->AddRectFilled(ImVec2(c0.x - 2 * q - g, c0.y - 2 * q - g), ImVec2(c0.x - g, c0.y - g), col, 1.0f * u);
            d->AddRectFilled(ImVec2(c0.x + g, c0.y - 2 * q - g), ImVec2(c0.x + 2 * q + g, c0.y - g), col, 1.0f * u);
            d->AddRectFilled(ImVec2(c0.x - 2 * q - g, c0.y + g), ImVec2(c0.x - g, c0.y + 2 * q + g), col, 1.0f * u);
            d->AddRectFilled(ImVec2(c0.x + g, c0.y + g), ImVec2(c0.x + 2 * q + g, c0.y + 2 * q + g), col, 1.0f * u);
            break;
        }
    }
}

// Half-moon avatar (HTML profile glyph): dim disc + lit half.
void ObsAvatar(ImDrawList* d, const ImVec2& c0, float r, ImU32 dim, ImU32 lit) {
    d->AddCircleFilled(c0, r, dim, 22);
    d->PathArcTo(c0, r * 0.999f, -1.5707963f, 1.5707963f, 22);
    d->PathFillConvex(lit);
    d->AddCircle(c0, r, lit, 22, 1.2f);
}

void PaintReferenceSidebar(Ctx& c) {
    RefPanelSurface(c, 12, 16, kRefSideW - 12, kRefMainH - 32);
    Logo(c, 38, 42, 18, kText);
    Text(c, 58, 32, "Nightfull", fonts::UISemi(), 17, kText);
    Text(c, 30, 82, "Client categories", fonts::UI(), 12, kMuted);
    float ny = 106;
    for (int i = -1; i < kRefCategoryCount; ++i) {
        const bool active = !g_showGeneral && !g_systemConfigs && g_refCategory == i;
        const bool hov = c.Hover(22, ny, kRefSideW - 34, 36);
        const float a = HoverAnim(HashStr(i < 0 ? "All" : kRefCategoryNames[i], 704), active || hov, c.dt);
        if (a > 0.001f) FillR(c, 22, ny, kRefSideW - 34, 36, kTrack, 9, a * 0.8f);
        if (active) FillR(c, 22, ny + 10, 3, 16, c.accent, 2);
        if (i < 0) IconGlyph(c, Icon::Grid, 39, ny + 18, 17, kText);
        else ObsCatIcon(c.d, c.P(39, ny + 18), c.px(1.05f), i,
            ImGui::ColorConvertFloat4ToU32(ImVec4(kText.Value.x,kText.Value.y,kText.Value.z,c.alpha)));
        Text(c, 58, ny + 10, i < 0 ? "All" : i == 6 ? "Themes / GUI" : kRefCategoryNames[i], fonts::UISemi(), 14, kText);
        std::vector<Module*> list;
        // Sidebar counts describe the category, independent of the search/favorites filter.
        int total = 0;
        for (const auto& h : modules().modules()) if (!h->hiddenFromLists && (i < 0 || RefCategoryFor(h.get()) == i)) ++total;
        char count[12]; snprintf(count, sizeof(count), "%d", i == 6 ? kThemePresetCount : total);
        TextRight(c, kRefSideW - 18, ny + 11, count, fonts::UISemi(), 12, active ? kText : kMuted);
        if (hov && c.Clicked()) {
            g_refCategory = i; g_showGeneral = false; g_systemConfigs = false;
            g_refScroll = g_refScrollTo = 0;
            for (int col = 0; col < 3; ++col) g_systemColumnScroll[col] = g_systemColumnTarget[col] = 0;
        }
        ny += 39;
    }
    Text(c, 30, ny + 24, "Settings", fonts::UI(), 12, kMuted);
    ny += 48;
    const char* labels[] = { "Configs", "HUD editor", "Client settings" };
    const unsigned icons[] = { Icon::FolderHeart, Icon::Monitor, Icon::Settings2 };
    for (int i = 0; i < 3; ++i) {
        const bool hov = c.Hover(22, ny, kRefSideW - 34, 36);
        if (hov || (i == 0 && g_systemConfigs) || (i == 2 && g_showGeneral)) FillR(c, 22, ny, kRefSideW - 34, 36, kTrack, 9);
        IconGlyph(c, icons[i], 39, ny + 18, 17, kText);
        Text(c, 58, ny + 10, labels[i], fonts::UISemi(), 14, kText);
        if (hov && c.Clicked()) {
            if (i == 0) { g_systemConfigs = !g_systemConfigs; g_showGeneral = false; g_profilesDirty = true; }
            if (i == 1) {
                GeneralModule* gm = GeneralModule::instance();
                if (gm && gm->m_hudEdit) gm->m_hudEdit->mValue = true;
                overlay::HudEditSet(true); overlay::g_showMenu = false;
            }
            if (i == 2) { g_showGeneral = !g_showGeneral; g_systemConfigs = false; }
            for (int col = 0; col < 3; ++col) g_systemColumnScroll[col] = g_systemColumnTarget[col] = 0;
        }
        ny += 40;
    }
    const float fy = kRefMainH - 90;
    FillR(c, 22, fy, kRefSideW - 34, 64, kField, 12);
    FillR(c, 32, fy + 15, 34, 34, kTrack, 10);
    Text(c, 42, fy + 22, "N", fonts::UISemi(), 16, kText);
    Text(c, 76, fy + 14, "Nightfull Client", fonts::UISemi(), 13, kText);
    Text(c, 76, fy + 34, "R26 • local profile", fonts::UI(), 11, kMuted);
}


float RefPanelHeight(int category, float w) {
    std::vector<Module*> list;
    RefCollect(category, list);
    if (category == 6) {
        // GUI: the theme gallery. 3 columns of 74px cards + header. Height
        // computed exactly from kThemePresetCount: header 54 + rows*card +
        // (rows-1)*gap + 14px bottom pad, so the full last row plus the pad
        // is always inside the panel (the old rows*(74+gap) shape added a
        // phantom trailing gap after the last row).
        constexpr int kCols = 3;
        constexpr float gap = 10.0f;
        const int rows = (kThemePresetCount + kCols - 1) / kCols;
        return 54.0f + rows * 74.0f + (rows - 1) * gap + 8.0f + 214.0f + 14.0f;
    }
    const float rowH = g_refCompact ? 64.0f : 74.0f;
    const float h = 54.0f + (list.empty() ? 72.0f : list.size() * (rowH + 8.0f)) + 12.0f;
    return std::max(360.0f, h);
}

void PaintReferenceModulePanel(Ctx& c, int category, float x, float y, float w, float h) {
    std::vector<Module*> list;
    RefCollect(category, list);
    RefPanelSurface(c, x, y, w, h, gui::Accent(), g_refDeepGlass ? 0.30f : 0.24f);
    const int activeCount = [&]() {
        int n = 0; for (Module* m : list) if (m->enabled()) n++; return n;
    }();
    c.d->AddCircleFilled(c.P(x + 20, y + 27), c.px(5.0f), c.accent, 14);
    c.d->AddCircle(c.P(x + 20, y + 27), c.px(9.0f),
        ImColor(c.accent.Value.x, c.accent.Value.y, c.accent.Value.z, c.alpha * 0.18f), 18, c.px(1.0f));
    Text(c, x + 38, y + 19, kRefCategoryNames[category], fonts::Bold(), 15, kText);
    char stat[24]; if (category == 6) snprintf(stat, sizeof(stat), "%d themes", kThemePresetCount);
    else snprintf(stat, sizeof(stat), "%d/%d", activeCount, (int)list.size());
    TextRight(c, x + w - 16, y + 20, stat, fonts::UI(), 10, kMuted);

    // GUI category: the theme gallery instead of a module list. Selection
    // applies the preset into the custom color slots (the same path as the
    // Themes page gallery) and persists through the config like any colors.
    if (category == 6) {
        ThemesModule* tm = ThemesModule::instance();
        const int total = kThemePresetCount;
        constexpr int kCols = 3;
        const float gap = 10.0f;
        const float cw = (w - 24.0f - gap * (kCols - 1)) / kCols;
        const float ch = 74.0f;
        auto applyPreset = [&](int i) {
            if (!tm) return;
            const ThemePreset& p = kThemePresets[i];
            const float r1 = ((p.c1 >> 16) & 0xFF) / 255.0f;
            const float g1 = ((p.c1 >> 8) & 0xFF) / 255.0f;
            const float b1 = (p.c1 & 0xFF) / 255.0f;
            const float r2 = ((p.c2 >> 16) & 0xFF) / 255.0f;
            const float g2 = ((p.c2 >> 8) & 0xFF) / 255.0f;
            const float b2 = (p.c2 & 0xFF) / 255.0f;
            tm->m_theme->setValue(ThemesModule::ThemeCustom);
            float* d1 = tm->m_color1->mValue;
            d1[0] = r1; d1[1] = g1; d1[2] = b1; d1[3] = 1.0f;
            float* d2c = tm->m_color2->mValue;
            d2c[0] = r2; d2c[1] = g2; d2c[2] = b2; d2c[3] = 1.0f;
            tm->m_colorSlots->setValue(2);
            tm->m_presetIdx->setValue((float)i);
            Toast("Тема: %s", p.name);
        };
        // The panel scrolls with the reference board (wc.offsetY), so clip
        // cards to the panel body and lay them out in a tall grid.
        const float top = y + 54.0f;
        const int rows = (total + kCols - 1) / kCols;
        c.d->PushClipRect(c.P(x + 4, top), c.P(x + w - 4, y + h - 6), true);
        for (int i = 0; i < total; i++) {
            const int col = i % kCols, row = i / kCols;
            const float cx = x + 12.0f + col * (cw + gap);
            const float cy = top + row * (ch + gap);
            if (cy > y + h + ch) break;
            const ThemePreset& p = kThemePresets[i];
            const bool sel = tm && tm->m_presetIdx &&
                             tm->m_presetIdx->mValue == (float)i;
            const bool hov = c.Hover(cx, cy, cw, ch);
            if (hov) FillR(c, cx, cy, cw, ch, kField, 12.0f, 0.7f);
            StrokeR(c, cx, cy, cw, ch, sel ? c.accent : kBorder, 12.0f,
                    sel ? 1.6f : 1.0f, sel ? 0.95f : 0.6f);
            const ImColor c1((float)((p.c1 >> 16) & 0xFF) / 255.0f,
                             (float)((p.c1 >> 8) & 0xFF) / 255.0f,
                             (float)(p.c1 & 0xFF) / 255.0f, 1.0f);
            const ImColor c2((float)((p.c2 >> 16) & 0xFF) / 255.0f,
                             (float)((p.c2 >> 8) & 0xFF) / 255.0f,
                             (float)(p.c2 & 0xFF) / 255.0f, 1.0f);
            // Two-tone swatch preview: color 1 base + color 2 right half.
            // Both halves are drawn as rounded rects (right corners only on
            // the overlay) so the fill stays inside the rounded swatch - the
            // old triangle wedge overhung the rounded top-right corner.
            const float swH = 34.0f;
            const float swR = c.px(StyleRadius(6.0f));
            c.d->AddRectFilled(c.P(cx + 9, cy + 9),
                               c.P(cx + cw - 9, cy + 9 + swH),
                               ImColor(c1.Value.x, c1.Value.y, c1.Value.z,
                                       c1.Value.w * c.alpha),
                               swR);
            c.d->AddRectFilled(c.P(cx + 9 + (cw - 18) * 0.5f, cy + 9),
                               c.P(cx + cw - 9, cy + 9 + swH),
                               ImColor(c2.Value.x, c2.Value.y, c2.Value.z,
                                       c2.Value.w * c.alpha),
                               swR, ImDrawFlags_RoundCornersRight);
            StrokeR(c, cx + 9, cy + 9, cw - 18, swH, Hex(0x000000), 6.0f, 1.0f, 0.35f);
            Text(c, cx + 9, cy + 9 + swH + 6, p.name, fonts::UISemi(), 12,
                 sel ? c.accent : kText);
            if (sel) IconGlyph(c, Icon::Check, cx + cw - 16, cy + 9 + swH + 11,
                               11.0f, c.accent);
            if (hov && c.Clicked()) applyPreset(i);
        }
        c.d->PopClipRect();
        // Cursor customization lives here too: the Themes inspector tab is
        // not part of the current shell, so GUI is the only reachable spot.
        const float cursorY = top + (float)rows * (ch + gap) + 8.0f;
        c.d->PushClipRect(c.P(x + 4, top), c.P(x + w - 4, y + h - 6), true);
        PaintCursorCard(c, x + 12.0f, cursorY, w - 24.0f);
        c.d->PopClipRect();
        return;
    }
    float rowY = y + 54.0f;
    const float rowH = g_refCompact ? 64.0f : 74.0f;
    if (list.empty()) {
        FillR(c, x + 10, rowY, w - 20, 64.0f, kField, 20.0f, 0.48f);
        Text(c, x + 24, rowY + 16, "No modules in this category", fonts::UISemi(), 10, kMuted);
        Text(c, x + 24, rowY + 37, "Настройка появится вместе с модулем.", fonts::UI(), 8, kMuted);
        return;
    }
    for (Module* m : list) {
        const bool selected = m == g_refSelected;
        const bool hov = c.Hover(x + 10, rowY, w - 20, rowH);
        m->toggleAnim = gui::Animate(m->enabled() ? 1.0f : 0.0f, m->toggleAnim, AF(c.dt, 12.0f));
        const float ta = gui::Clamp(m->toggleAnim, 0.0f, 1.0f);
        FillR(c, x + 10, rowY, w - 20, rowH, kModuleBg, 18.0f, 0.92f);
        if (ta > 0.01f) FillR(c, x + 10, rowY, w - 20, rowH, c.accent, 18.0f, 0.18f * ta);
        const float en = std::max(ta, selected ? 1.0f : 0.0f);
        StrokeR(c, x + 10, rowY, w - 20, rowH,
                selected ? gui::LerpColor(c.accent, kText, 0.12f)
                         : (ta > 0.01f ? c.accent : ImColor(255, 255, 255)),
                18.0f, 1.0f + 0.3f * en,
                selected ? 0.9f : (hov ? 0.9f : (0.12f + 0.62f * ta)));
        Text(c, x + 24, rowY + 14, gui::ApplyNaming(m->name()), fonts::UISemi(), 12, kText);
        std::string desc = m->description();
        const float maxW = w - 112.0f;
        while (desc.size() > 8 && TextW(fonts::UI(), desc.c_str(), 8, c.s) > maxW)
            desc.erase(desc.size() - 1);
        if (desc.size() < std::strlen(m->description())) desc += "…";
        Text(c, x + 24, rowY + 36, desc.c_str(), fonts::UI(), 8, kMuted);
        const bool swHit = RefSwitch(c, x + w - 68, rowY + (rowH - 22.0f) * 0.5f,
                                     m->enabled(), m->toggleAnim);
        if (swHit) {
            g_refSelected = m;
            ApplyModuleState(m, !m->enabled());
            Toast("%s %s", m->name(), m->enabled() ? "enabled" : "disabled");
        } else if (hov && c.RightClicked()) {
            g_refSelected = m;
            g_refTab = 0;
            g_refInspectorScroll = g_refInspectorScrollTo = 0.0f;
            Toast("Settings: %s", m->name());
        } else if (hov && c.Clicked()) {
            g_refSelected = m;
            g_refCategory = category;
            ApplyModuleState(m, !m->enabled());
            Toast("%s %s", m->name(), m->enabled() ? "enabled" : "disabled");
        }
        rowY += rowH + 8.0f;
    }
}

void RefCollectAll(std::vector<Module*>& out) {
    out.clear();
    for (const auto& holder : modules().modules()) {
        Module* m = holder.get();
        if (m && !m->hiddenFromLists && RefMatches(m)) out.push_back(m);
    }
    std::sort(out.begin(), out.end(), [](Module* a, Module* b) {
        return _stricmp(a->name(), b->name()) < 0;
    });
}

float RefFunctionBoardHeight(const std::vector<Module*>& list, float w) {
    const float rowH = g_refCompact ? 64.0f : 74.0f;
    const int cols = 3;
    const int rows = std::max(1, ((int)list.size() + cols - 1) / cols);
    (void)w;
    return 58.0f + rows * (rowH + 10.0f) + 16.0f;
}

void PaintReferenceFunctionCard(Ctx& c, Module* m, float x, float y, float w, float h) {
    const bool selected = m == g_refSelected;
    const bool hov = c.Hover(x, y, w, h);
    m->toggleAnim = gui::Animate(m->enabled() ? 1.0f : 0.0f, m->toggleAnim, AF(c.dt, 12.0f));
    const float ta = gui::Clamp(m->toggleAnim, 0.0f, 1.0f);
    FillR(c, x, y, w, h, kModuleBg, 18.0f, 0.92f);
    if (ta > 0.01f) FillR(c, x, y, w, h, c.accent, 18.0f, 0.18f * ta);
    const float en = std::max(ta, selected ? 1.0f : 0.0f);
    StrokeR(c, x, y, w, h,
            selected ? gui::LerpColor(c.accent, kText, 0.12f)
                     : (ta > 0.01f ? c.accent : ImColor(255, 255, 255)),
            18.0f, 1.0f + 0.3f * en,
            selected ? 0.9f : (hov ? 0.9f : (0.12f + 0.62f * ta)));
    Text(c, x + 14, y + 13, gui::ApplyNaming(m->name()), fonts::UISemi(), 12, kText);
    std::string desc = m->description();
    const float maxW = w - 112.0f;
    while (desc.size() > 8 && TextW(fonts::UI(), desc.c_str(), 8, c.s) > maxW)
        desc.erase(desc.size() - 1);
    if (desc.size() < std::strlen(m->description())) desc += "…";
    Text(c, x + 14, y + 36, desc.c_str(), fonts::UI(), 8, kMuted);
    const bool swHit = RefSwitch(c, x + w - 58, y + (h - 22.0f) * 0.5f,
                                 m->enabled(), m->toggleAnim);
    if (swHit) {
        g_refSelected = m;
        ApplyModuleState(m, !m->enabled());
        Toast("%s %s", m->name(), m->enabled() ? "enabled" : "disabled");
    } else if (hov && c.RightClicked()) {
        g_refSelected = m;
        g_refTab = 0;
        g_refInspectorScroll = g_refInspectorScrollTo = 0.0f;
        Toast("Settings: %s", m->name());
    } else if (hov && c.Clicked()) {
        g_refSelected = m;
        ApplyModuleState(m, !m->enabled());
        Toast("%s %s", m->name(), m->enabled() ? "enabled" : "disabled");
    }
}

// UTF-8-safe labels. Never cut a Cyrillic continuation byte.
std::string SystemFit(const char* text, float width, float pt, const Ctx& c) {
    std::string v = text ? text : "";
    if (TextW(fonts::UISemi(), v.c_str(), pt, c.s) <= width) return v;
    while (!v.empty() && TextW(fonts::UISemi(), (v + "…").c_str(), pt, c.s) > width) {
        size_t at = v.size() - 1;
        while (at > 0 && ((unsigned char)v[at] & 0xC0) == 0x80) --at;
        v.resize(at);
    }
    return v + "…";
}
void SystemStar(const Ctx& c, float x, float y, bool favorite) {
    ImVec2 p[10];
    for (int i = 0; i < 10; ++i) {
        const float a = -1.5707963f + i * 0.6283185f, r = i % 2 ? 3.5f : 7.5f;
        p[i] = c.P(x + std::cos(a) * r, y + std::sin(a) * r);
    }
    const ImColor col = favorite ? c.accent : kMuted;
    c.d->AddPolyline(p, 10, ImGui::ColorConvertFloat4ToU32(ImVec4(col.Value.x,col.Value.y,col.Value.z,c.alpha)), ImDrawFlags_Closed, c.px(favorite ? 2.2f : 1.2f));
}
void SystemModuleCard(Ctx& c, Module* m, float x, float y, float w, float h) {
    const bool hidden = m->hiddenFromLists;
    const bool hov = c.Hover(x, y, w, h);
    float& ha = m->hoverLift;
    ha = g_animsOff ? (hov ? 1.0f : 0.0f) : gui::Animate(hov ? 1.0f : 0.0f, ha, AF(c.dt, 12));
    RefPanelSurface(c, x, y, w, h);
    if (ha > 0.01f || m == g_refSelected) StrokeR(c, x, y, w, h, c.accent, 18, 1.0f, std::max(ha * 0.35f, m == g_refSelected ? 0.45f : 0.0f));
    const std::string name = SystemFit(gui::ApplyNaming(m->name()), w - (hidden ? 50 : 146), 15, c);
    Text(c, x + 16, y + 18, name.c_str(), fonts::UISemi(), 15, kText);
    if (!hidden) {
        const bool listening = g_refListeningKey && g_refSelected == m;
        std::string key = SystemFit(listening ? "…" : m->key() ? keys::Name((unsigned)m->key()) : "None", 51, 10, c);
        const float bx = x + w - 126;
        FillR(c, bx, y + 14, 57, 26, kTrack, 7, 0.75f);
        Text(c, bx + 5, y + 21, key.c_str(), fonts::UI(), 10, listening ? c.accent : kMuted);
        SystemStar(c, x + w - 53, y + 27, SystemFavorite(m));
        const bool sw = RefSwitch(c, x + w - 38, y + 18, m->enabled(), m->toggleAnim);
        if (sw) { g_refSelected = m; ApplyModuleState(m, !m->enabled()); Toast("%s %s", m->name(), m->enabled() ? "enabled" : "disabled"); }
        if (c.Hover(bx, y + 14, 57, 26) && c.Clicked()) { g_refSelected = m; g_refListeningKey = true; }
        if (c.Hover(x + w - 66, y + 12, 25, 30) && c.Clicked()) SystemToggleFavorite(m);
    }
    const std::string desc = SystemFit(m->description(), w - 55, 11, c);
    Text(c, x + 16, y + 45, desc.c_str(), fonts::UI(), 11, kMuted);
    IconGlyph(c, m->uiExpanded ? Icon::ChevronUp : Icon::ChevronDown, x + w - 22, y + 51, 12, kMuted);
    const bool headHit = c.Hover(x, y, w - (hidden ? 0 : 135), 41) || c.Hover(x, y + 41, w, 29);
    if ((headHit && c.Clicked()) || (c.Hover(x, y, w, 70) && c.RightClicked())) {
        m->uiExpanded = !m->uiExpanded; g_refSelected = m;
    }
    if (h > 80) {
        const float top = y + 72, bottom = y + h - 12;
        c.d->PushClipRect(c.P(x + 8, top), c.P(x + w - 8, bottom), true);
        Ctx sc = c;
        sc.interact = c.interact && c.Hover(x + 8, top, w - 16, std::max(0.0f, bottom - top));
        RefDrawModuleSettings(sc, m, x + 2, top, w - 4);
        c.d->PopClipRect();
    }
}
void SystemConfigs(Ctx& c) {
    const float x = kRefCenterX, y = kRefBodyY, w = kRefCenterW;
    RefPanelSurface(c, x, y, w, kRefBodyH - 16);
    Text(c, x + 24, y + 24, "Local configurations", fonts::UISemi(), 20, kText);
    Text(c, x + 24, y + 58, "Сохранение, загрузка и удаление настоящих профилей Nightfull.", fonts::UI(), 13, kMuted);
    if (RefPill(c, x + 24, y + 96, 220, 36, "Save current as…", true)) {
        g_modal = M_Save; g_modalAnim = 0; g_profileName[0] = 0;
    }
    if (RefPill(c, x + 254, y + 96, 170, 36, "Save active config")) Toast(config::Save() ? "Configuration saved" : "Save failed");
    if (g_profilesDirty) { g_profiles = config::listProfiles(); g_profilesDirty = false; }
    const float top = y + 150, vh = kRefBodyH - 186;
    const float maxScroll = std::max(0.0f, (float)g_profiles.size() * 62 - vh);
    if (c.interact && c.Hover(x, top, w, vh)) g_refScrollTo -= MenuWheelY() * 48;
    g_refScrollTo = gui::Clamp(g_refScrollTo, 0, maxScroll);
    g_refScroll = g_animsOff ? g_refScrollTo : gui::Animate(g_refScrollTo, g_refScroll, AF(c.dt, 14));
    c.d->PushClipRect(c.P(x + 16, top), c.P(x + w - 16, top + vh), true);
    Ctx pc = c; pc.offsetY = -g_refScroll; pc.interact = c.interact && c.Hover(x,top,w,vh);
    for (size_t i = 0; i < g_profiles.size(); ++i) {
        const float py = top + i * 62.0f;
        char name[256] = {}; WideCharToMultiByte(CP_UTF8,0,g_profiles[i].c_str(),-1,name,sizeof(name),nullptr,nullptr);
        FillR(pc, x + 24, py, w - 48, 52, kField, 10);
        std::string fit = SystemFit(name, w - 320, 14, pc);
        Text(pc, x + 40, py + 18, fit.c_str(), fonts::UISemi(), 14, kText);
        if (RefPill(pc, x + w - 246, py + 8, 120, 36, "Load")) {
            if (config::loadProfile(g_profiles[i])) { g_activeProfile = name; Toast("Profile loaded: %s", name); } else Toast("Load failed");
        }
        if (RefPill(pc, x + w - 116, py + 8, 90, 36, "Delete")) {
            if (config::deleteProfile(g_profiles[i])) { g_profilesDirty = true; Toast("Profile deleted"); } else Toast("Delete failed");
        }
    }
    if (g_profiles.empty()) Text(pc, x + 24, top + 12, "Пока нет профилей. Сохрани текущие настройки кнопкой выше.", fonts::UI(), 14, kMuted);
    c.d->PopClipRect();
}
void PaintReferenceWorkspace(Ctx& c, bool& fieldClaimed) {
    (void)fieldClaimed;
    if (g_systemConfigs) { SystemConfigs(c); return; }
    const float x = kRefCenterX, w = kRefCenterW, top = kRefBodyY;
    const float viewH = kRefBodyH - 16;
    if (g_refCategory == 6 && !g_showGeneral) {
        const float ph = RefPanelHeight(6, w);
        const float maxScroll = std::max(0.0f, ph - viewH);
        if (c.interact && c.Hover(x,top,w,viewH)) g_refScrollTo -= MenuWheelY() * 48;
        g_refScrollTo = gui::Clamp(g_refScrollTo,0,maxScroll);
        g_refScroll = g_animsOff ? g_refScrollTo : gui::Animate(g_refScrollTo,g_refScroll,AF(c.dt,14));
        Ctx tc = c; tc.offsetY = -g_refScroll; tc.interact = c.interact && c.Hover(x,top,w,viewH);
        c.d->PushClipRect(c.P(x,top),c.P(x+w,top+viewH),true);
        PaintReferenceModulePanel(tc,6,x,top,w,ph);
        c.d->PopClipRect(); return;
    }
    std::vector<Module*> list;
    if (g_showGeneral) {
        if (Module* m = modules().find("General")) list.push_back(m);
        if (Module* m = modules().find("Themes")) list.push_back(m);
    } else RefCollect(g_refCategory, list);
    if (list.empty()) {
        RefPanelSurface(c,x,top,w,160);
        Text(c,x+24,top+32,g_systemFavoritesOnly ? "No favorite modules yet" : "No matching modules",fonts::UISemi(),20,kText);
        Text(c,x+24,top+76,g_systemFavoritesOnly ? "Нажми звезду рядом с названием модуля." : "Измени поиск или выбери другую категорию.",fonts::UI(),14,kMuted);
        return;
    }
    constexpr float gap = 8, header = 78;
    const float cw = (w - 2 * gap) / 3;
    std::vector<float> heights(list.size(),header);
    static std::string lastFilter;
    const std::string filter = std::to_string(g_refCategory) + "/" + g_search + "/" +
        (g_systemFavoritesOnly ? "F" : "A") + (g_showGeneral ? "G" : "M");
    if (lastFilter != filter) {
        lastFilter = filter;
        for (int col = 0; col < 3; ++col) g_systemColumnScroll[col] = g_systemColumnTarget[col] = 0;
        for (size_t i = 0; i < list.size(); ++i) list[i]->cardAnim = -std::min((float)i * 0.035f, 0.25f);
    }
    float content[3] = {};
    for (size_t i = 0; i < list.size(); ++i) {
        Module* m = list[i];
        if (g_animsOff) m->uiExpandT = m->uiExpanded ? 1 : 0;
        else gui::Spring(m->uiExpandT,m->uiExpandVel,m->uiExpanded ? 1.0f : 0.0f,std::min(c.dt,0.033f),190,22);
        const float t = gui::Clamp(m->uiExpandT,0,1);
        heights[i] = header + (RefModuleSettingsHeight(m) + 10) * t;
        content[i % 3] += heights[i] + gap;
    }
    if (g_systemFocus) {
        for (size_t i = 0; i < list.size(); ++i) if (list[i] == g_systemFocus) {
            float before = 0;
            for (size_t j = i % 3; j < i; j += 3) before += heights[j] + gap;
            g_systemColumnTarget[i % 3] = before;
            g_systemColumnScroll[i % 3] = before;
            break;
        }
        g_systemFocus = nullptr;
    }
    if (g_showGeneral) {
        const float hx = x + 2 * (cw + gap);
        RefPanelSurface(c,hx,top,cw,396);
        Text(c,hx+20,top+22,"Nightfull controls",fonts::UISemi(),18,kText);
        WrapText(c,hx+20,top+64,cw-40,"Настройки сохраняются автоматически. Профили доступны во вкладке Configs.",fonts::UI(),13,kMuted,3);
        Text(c,hx+20,top+148,"CTRL K — поиск модулей",fonts::UISemi(),14,kText);
        Text(c,hx+20,top+184,"Звезда — добавить в избранное",fonts::UISemi(),14,kText);
        Text(c,hx+20,top+220,"ПКМ по шапке — свернуть настройки",fonts::UISemi(),13,kText);
        WrapText(c,hx+20,top+266,cw-40,"HUD editor: перетаскивание элементов, колесо для масштаба, ПКМ для параметров.",fonts::UI(),13,kMuted,3);
        if(RefPill(c,hx+20,top+336,cw-40,36,"Save active config",true)) Toast(config::Save() ? "Configuration saved" : "Save failed");
    }
    for (int col = 0; col < 3; ++col) {
        const float cx = x + col * (cw + gap);
        const float maxScroll = std::max(0.0f, content[col] - viewH);
        if (c.interact && c.Hover(cx,top,cw,viewH)) g_systemColumnTarget[col] -= MenuWheelY() * 52;
        g_systemColumnTarget[col] = gui::Clamp(g_systemColumnTarget[col],0,maxScroll);
        g_systemColumnScroll[col] = g_animsOff ? g_systemColumnTarget[col] : gui::Animate(g_systemColumnTarget[col],g_systemColumnScroll[col],AF(c.dt,14));
        c.d->PushClipRect(c.P(cx,top),c.P(cx+cw,top+viewH),true);
        Ctx cc = c; cc.offsetY = -g_systemColumnScroll[col];
        cc.interact = c.interact && c.Hover(cx,top,cw,viewH);
        float cy = top;
        for (size_t i = (size_t)col; i < list.size(); i += 3) {
            Module* m = list[i];
            m->cardAnim = g_animsOff ? 1 : std::min(1.0f,m->cardAnim+c.dt*5);
            const float t = gui::Clamp(m->cardAnim,0,1), e = 1-std::pow(1-t,3.0f);
            Ctx ac = cc; ac.alpha *= e; ac.interact = cc.interact && t > 0.75f;
            if (cy + heights[i] >= top + g_systemColumnScroll[col] && cy <= top + viewH + g_systemColumnScroll[col])
                SystemModuleCard(ac,m,cx,cy+(1-e)*12,cw,heights[i]);
            cy += heights[i] + gap;
        }
        c.d->PopClipRect();
        if (maxScroll > 0) {
            const float sh = std::max(24.0f,viewH*viewH/content[col]);
            const float sy = top + (viewH-sh)*g_systemColumnScroll[col]/maxScroll;
            FillR(c,cx+cw-4,sy,3,sh,kMuted,2,0.45f);
        }
    }
}


void PaintReferenceInspector(Ctx& c) {
    const float x = kRefRightX, w = kRefRightW;
    RefPanelSurface(c, x, kRefBodyY, w, kRefBodyH, gui::Accent(), g_refDeepGlass ? 0.30f : 0.26f);
    const float ix = x + 14.0f, iw = w - 28.0f;
    const float headerY = kRefBodyY + 14.0f, headerH = 148.0f;
    // Aurora phead: category icon box + name + sub + description + meta
    // tags. Tabs and settings below keep their logic untouched.
    {
        const int cat = g_refSelected ? RefCategoryFor(g_refSelected) : -1;
        FillR(c, ix, headerY, 34, 34, kField, 0.0f, 0.85f);
        StrokeR(c, ix, headerY, 34, 34, kBorder, 0.0f, 1.0f, 0.8f);
        if (cat >= 0 && cat < kRefCategoryCount) {
            const ImColor gc = kMint;
            ObsCatIcon(c.d, c.P(ix + 17, headerY + 17), c.px(1.0f), cat,
                       ImColor(gc.Value.x, gc.Value.y, gc.Value.z, gc.Value.w * c.alpha));
        }
        const char* nm = g_refSelected ? gui::ApplyNaming(g_refSelected->name()) : "None";
        Text(c, ix + 44, headerY + 2, nm, fonts::UISemi(), 15, kText);
        char sub[64];
        if (g_refSelected && cat >= 0)
            snprintf(sub, sizeof(sub), "%s · %s", g_refSelected->description(), kRefCategoryNames[cat]);
        else snprintf(sub, sizeof(sub), "Select a module");
        Text(c, ix + 44, headerY + 22, sub, fonts::UI(), 9, kMuted);
    }
    if (g_refSelected) {
        std::string desc = g_refSelected->description();
        while (desc.size() > 8 && TextW(fonts::UI(), desc.c_str(), 10, c.s) > iw - 20.0f)
            desc.erase(desc.size() - 1);
        if (desc.size() < std::strlen(g_refSelected->description())) desc += "…";
        Text(c, ix + 2, headerY + 56, desc.c_str(), fonts::UI(), 10, kMuted);
        // Meta tags: state, settings count, bind.
        float mx = ix + 2;
        const float my = headerY + 78;
        auto metaTag = [&](const char* t, const ImColor& col) {
            const float twd = TextW(fonts::UISemi(), t, 8.0f, c.s) + 12.0f;
            FillR(c, mx, my, twd, 17.0f, kField, 0.0f, 0.85f);
            StrokeR(c, mx, my, twd, 17.0f, kBorder, 0.0f, 1.0f, 0.6f);
            Text(c, mx + 6, my + 3, t, fonts::UISemi(), 8, col);
            mx += twd + 6.0f;
        };
        char nset[24]; snprintf(nset, sizeof(nset), "%d SETTINGS", (int)g_refSelected->settings().size());
        metaTag(g_refSelected->enabled() ? "ON" : "OFF", g_refSelected->enabled() ? kMint : kMuted);
        metaTag(nset, kMuted);
        const char* key = g_refListeningKey ? "Press..." :
            (g_refSelected->key() ? keys::Name((unsigned)g_refSelected->key()) : "Unbound");
        metaTag(key, kMint);
    }
    const char* key = g_refListeningKey ? "Press..." :
        (g_refSelected && g_refSelected->key() ? keys::Name((unsigned)g_refSelected->key()) : "Unbound");
    if (RefPill(c, ix + iw - 92, headerY + 108, 78, 31, key, false))
        g_refListeningKey = true;

    const float tabsY = headerY + headerH + 12.0f;
    const float tabW = (iw - 14.0f) / 3.0f;
    const char* tabNames[] = { "Settings", "Themes", "HUD" };
    for (int i = 0; i < 3; i++) {
        if (RefPill(c, ix + i * (tabW + 7.0f), tabsY, tabW, 40.0f, tabNames[i], g_refTab == i)) {
            g_refTab = i;
            g_refInspectorScroll = g_refInspectorScrollTo = 0.0f;
        }
    }
    const float areaY = tabsY + 52.0f;
    const float footH = 52.0f;
    const float footY = kRefBodyY + kRefBodyH - footH - 14.0f;
    const float areaH = footY - areaY - 12.0f;
    float contentH = 0.0f;
    if (g_refTab == 0) contentH = RefModuleSettingsHeight(g_refSelected);
    else if (g_refTab == 1) contentH = 248.0f + 10.0f + 214.0f + 10.0f + 72.0f + 10.0f + 72.0f + 10.0f + 72.0f;
    else contentH = 64.0f + 10.0f + 196.0f + 10.0f + 78.0f + 10.0f + 62.0f + 10.0f + 38.0f;
    g_refInspectorContentH = contentH;
    const float maxScroll = std::max(0.0f, contentH - areaH);
    if (c.interact && c.Hover(ix, areaY, iw, areaH) && MenuWheelY() != 0.0f)
        g_refInspectorScrollTo -= MenuWheelY() * 42.0f;
    g_refInspectorScrollTo = gui::Clamp(g_refInspectorScrollTo, 0.0f, maxScroll);
    g_refInspectorScroll = gui::Animate(g_refInspectorScrollTo, g_refInspectorScroll, AF(c.dt, 14.0f));
    Ctx ic = c;
    ic.offsetY = -g_refInspectorScroll;
    c.d->PushClipRect(c.P(ix, areaY), c.P(ix + iw, footY), true);
    float drawY = areaY;
    if (g_refTab == 0) drawY = RefDrawModuleSettings(ic, g_refSelected, ix, drawY, iw);
    else if (g_refTab == 1) drawY = RefThemeTab(ic, ix, drawY, iw);
    else drawY = RefHudTab(ic, ix, drawY, iw);
    c.d->PopClipRect();
    if (maxScroll > 0.0f) {
        const float thumbH = std::max(24.0f, areaH * areaH / std::max(1.0f, contentH));
        const float thumbY = areaY + (areaH - thumbH) * (g_refInspectorScroll / maxScroll);
        FillR(c, x + w - 8, areaY, 3, areaH, kTrack, 2.0f, 0.65f);
        FillR(c, x + w - 8, thumbY, 3, thumbH, c.accent, 2.0f, 0.85f);
    }
    // Footer: primary Enable/Disable action for the selected module.
    if (g_refSelected) {
        const bool on = g_refSelected->enabled();
        const bool hov = c.Hover(ix, footY, iw, footH);
        FillR(c, ix, footY, iw, footH, on ? ImColor(61, 220, 132, 255) : kField, 0.0f,
              on ? 0.95f : (hov ? 0.85f : 0.65f));
        if (on) StrokeR(c, ix, footY, iw, footH, kMintHi, 0.0f, 1.0f, 0.6f);
        else StrokeR(c, ix, footY, iw, footH, kBorder, 0.0f, 1.0f, 0.6f);
        const char* label = on ? "Disable" : "Enable";
        Text(c, ix + (iw - TextW(fonts::UISemi(), label, 12, c.s)) * 0.5f, footY + 17,
             label, fonts::UISemi(), 12, on ? ImColor(4, 18, 10) : kText);
        if (hov && c.Clicked()) {
            ApplyModuleState(g_refSelected, !on);
            Toast("%s %s", g_refSelected->name(), g_refSelected->enabled() ? "enabled" : "disabled");
        }
    }
}

void SystemEnumPopup(Ctx& c) {
    if (!g_systemEnum) return;
    const float rowH = 34, maxH = std::min(240.0f, (float)g_systemEnum->mValues.size() * rowH + 8);
    const float ew = (g_systemEnumRect.z - g_systemEnumRect.x) / c.s;
    const float ex = (g_systemEnumRect.x - c.origin.x) / c.s;
    float ey = (g_systemEnumRect.w - c.origin.y) / c.s + 4;
    if (ey + maxH > kRefMainH - 16) ey = (g_systemEnumRect.y - c.origin.y) / c.s - maxH - 4;
    ey = std::max(16.0f, ey);
    static float scroll = 0; static EnumSetting* previous = nullptr;
    if (previous != g_systemEnum) { previous = g_systemEnum; scroll = 0; }
    const float maxScroll = std::max(0.0f, (float)g_systemEnum->mValues.size()*rowH + 8 - maxH);
    if (c.interact && c.Hover(ex,ey,ew,maxH)) scroll = gui::Clamp(scroll-MenuWheelY()*rowH,0,maxScroll);
    RefPanelSurface(c,ex,ey,ew,maxH);
    c.d->PushClipRect(c.P(ex+4,ey+4),c.P(ex+ew-4,ey+maxH-4),true);
    bool picked = false;
    for (size_t i = 0; i < g_systemEnum->mValues.size(); ++i) {
        const float ry = ey+4+i*rowH-scroll;
        const bool hov = c.Hover(ex+4,ry,ew-8,rowH) && c.Hover(ex,ey+4,ew,maxH-8);
        if (hov || g_systemEnum->mValue == (int)i) FillR(c,ex+4,ry,ew-8,rowH,kTrack,6);
        const std::string label = SystemFit(g_systemEnum->mValues[i].c_str(),ew-35,12,c);
        Text(c,ex+12,ry+9,label.c_str(),fonts::UISemi(),12,kText);
        if (hov && c.Clicked() && g_systemEnumFrame != ImGui::GetFrameCount()) { g_systemEnum->setValue((int)i); picked = true; }
    }
    c.d->PopClipRect();
    if (picked || (c.Clicked() && !c.Hover(ex,ey,ew,maxH) && g_systemEnumFrame != ImGui::GetFrameCount())) g_systemEnum = nullptr;
}
void PaintReferenceShell(Ctx& c, bool& fieldClaimed) {
    RefEnsureSelection(); SystemPalette();
    FillR(c,0,0,kRefMainW,kRefMainH,SystemDark() ? ImColor(17,19,24) : ImColor(207,208,211),28);
    StrokeR(c,0,0,kRefMainW,kRefMainH,kBorder,28,1);
    Ctx controls = c;
    controls.interact = c.interact && !g_systemEnum;
    PaintReferenceTopbar(controls,fieldClaimed);
    PaintReferenceSidebar(controls);
    PaintReferenceWorkspace(controls,fieldClaimed);
    SystemEnumPopup(c);
}


// ============================ per-frame services ============================
void ApplyClientModules() {
    ThemesModule* tm = ThemesModule::instance();
    if (tm && tm->m_theme && tm->m_naming && tm->m_colorSlots && tm->m_colorSpeed && tm->m_saturation) {
        gui::SetTheme(tm->m_theme->mValue);
        gui::SetNamingStyle(tm->m_naming->mValue);
        gui::SetCustomColorCount((int)tm->m_colorSlots->mValue);
        ColorSetting* slots[] = { tm->m_color1, tm->m_color2, tm->m_color3,
                                  tm->m_color4, tm->m_color5, tm->m_color6 };
        for (int i = 0; i < 6; i++)
            if (slots[i]) gui::SetCustomColor(i, slots[i]->getAsImColor());
        gui::SetColorSpeed(tm->m_colorSpeed->mValue);
        gui::SetSaturation(tm->m_saturation->mValue);
    }
    if (tm && tm->m_cursorStyle && tm->m_cursorScale && tm->m_cursorGlow &&
        tm->m_cursorTheme && tm->m_cursorColor) {
        unsigned cursorColor = 0xFFFFFFFFu;
        if (!tm->m_cursorTheme->mValue && tm->m_color1) {
            const ImColor c1 = tm->m_color1->getAsImColor();
            cursorColor = ((unsigned)(c1.Value.w * 255.0f) << 24) |
                          ((unsigned)(c1.Value.x * 255.0f) << 16) |
                          ((unsigned)(c1.Value.y * 255.0f) << 8) |
                          (unsigned)(c1.Value.z * 255.0f);
        }
        overlay::SetGuiCursorStyle(tm->m_cursorStyle->mValue,
                                   tm->m_cursorScale->mValue,
                                   tm->m_cursorGlow->mValue,
                                   tm->m_cursorTheme->mValue,
                                   cursorColor);
    }

    // HUD editor <-> "HUD Editor" setting reconciliation. This runs every
    // frame (even with the menu fully closed) before any early return, so a
    // change on either side settles within one frame. Edge-triggered in both
    // directions: whichever of overlay's g_hudEdit / the setting changed
    // since last frame wins, which cleanly separates the overlay-owned
    // forced exits (ESC, menu opening) from setting-side changes (binds,
    // inspector button) that would otherwise be indistinguishable.
    GeneralModule* gm = GeneralModule::instance();
    if (gm && gm->m_hudEdit) {
        static bool prevActive = false, prevValue = false;
        const bool active = overlay::HudEditActive();
        const bool value = gm->m_hudEdit->mValue;
        if (active != prevActive) {
            // overlay-side change (HudEditSet / ESC / menu opened): the
            // setting follows the state.
            gm->m_hudEdit->mValue = active;
            prevValue = active;
        } else if (value != prevValue && !overlay::g_showMenu) {
            // setting-side change (bind via DispatchBinds / inspector): the
            // state follows the setting. Deferred while the menu is open
            // (prevValue not advanced), so a toggle made in the menu applies
            // right after the menu closes.
            overlay::HudEditSet(value);
            prevValue = value;
        }
        prevActive = active;
    }

    // GUI Size is a persisted General setting now; the static below is just a
    // per-frame copy the shell reads. Synced here (before any early return)
    // so a slider drag, a loaded profile or a hand-edited config takes effect
    // on the very next frame.
    if (gm && gm->m_guiSize) g_refUiScale = gm->m_guiSize->mValue;

    // The backdrop blur is gated on the "UI Blur" setting here; the overlay
    // additionally requires the menu/HUD editor to actually own input and a
    // non-zero open-animation strength before it spends a single GPU cycle.
    overlay::SetUiBlurEnabled(gm && gm->m_blur && gm->m_blur->mValue);
    const ImColor _ac = gui::Accent();
    overlay::SetUiBlurTint(_ac.Value.x, _ac.Value.y, _ac.Value.z);

    // Global text multiplier (menu + HUD draw through gui:: text helpers).
    if (gm && gm->m_textScale)
        gui::SetTextScale(gm->m_textScale->mValue);
}

void DispatchBinds() {
    for (const auto& m : modules().modules()) {
        // Menu key + END (unload) are engine-reserved: even a hand-edited
        // config must never steal them.
        const int k = m->key();
        if (k > 0 && k != overlay::g_menuKey && k != VK_END) {
            if (m->mHoldToUse) {
                // r22: hold modules (Zoom / Freelook) follow the physical key
                // state instead of toggling on the press edge. Silent on
                // purpose: a held key must not spam toasts every frame.
                const bool down = keys::Down((unsigned)k);
                if (down != m->enabled()) ApplyModuleState(m.get(), down);
            } else if (keys::PressedThisFrame((unsigned)k)) {
                ApplyModuleState(m.get(), !m->enabled());
                Toast("%s -> %s", m->name(), m->enabled() ? "ON" : "OFF");
            }
        }
        for (const auto& s : m->settings()) {
            if (s->mType != SettingType::Bool || s->mKey <= 0) continue;
            if (s->mKey == overlay::g_menuKey || s->mKey == VK_END) continue;
            if (keys::PressedThisFrame((unsigned)s->mKey)) {
                BoolSetting* bs = static_cast<BoolSetting*>(s.get());
                bs->mValue = !bs->mValue;
                LOG_INFO("bind: setting %s -> %s", s->mName.c_str(), bs->mValue ? "ON" : "OFF");
            }
        }
    }
    if (Module* base = modules().find("TextHotkeys"); base && base->enabled()) {
        static_cast<TextHotkeysModule*>(base)->dispatchPressedBinds();
    }
}

void HashCombine(unsigned& h, unsigned v) { h ^= v; h *= 16777619u; }
void HashFloat(unsigned& h, float f) {
    if (f == 0.0f) f = 0.0f;
    unsigned b = 0;
    std::memcpy(&b, &f, 4);
    HashCombine(h, b);
}

unsigned StateHash() {
    unsigned h = 2166136261u;
    for (const auto& m : modules().modules()) {
        for (const char* p = m->name(); *p; p++) HashCombine(h, (unsigned char)*p);
        HashCombine(h, m->enabled() ? 1u : 0u);
        HashCombine(h, (unsigned)m->key());
        for (const auto& s : m->settings()) {
            HashCombine(h, (unsigned)s->mType);
            HashCombine(h, (unsigned)s->mKey);
            switch (s->mType) {
                case SettingType::Bool:
                    HashCombine(h, static_cast<BoolSetting*>(s.get())->mValue ? 1u : 0u); break;
                case SettingType::Number:
                    HashFloat(h, static_cast<NumberSetting*>(s.get())->mValue); break;
                case SettingType::Enum:
                    HashCombine(h, (unsigned)static_cast<EnumSetting*>(s.get())->mValue); break;
                case SettingType::Color:
                    for (int i = 0; i < 4; i++)
                        HashFloat(h, static_cast<ColorSetting*>(s.get())->mValue[i]);
                    break;
                case SettingType::String: {
                    const std::string& v = static_cast<StringSetting*>(s.get())->mValue;
                    for (char ch : v) HashCombine(h, (unsigned char)ch);
                    break;
                }
            }
        }
    }
    return h;
}

void AutosaveTick() {
    // StateHash walks every module and every setting; doing that every frame
    // is wasted work. Recomputing at most every 150 ms keeps the semantics -
    // "save 1.5 s after the last change" - within a 150 ms tolerance, with
    // g_lastHash acting as the shadow copy that detects the change.
    static ULONGLONG s_lastHashAt = 0;
    const ULONGLONG now = GetTickCount64();
    if (s_lastHashAt != 0 && now - s_lastHashAt < 150) return;
    s_lastHashAt = now;
    g_hash = StateHash();
    if (g_hash != g_lastHash) {
        if (g_lastHash != 0) {
            g_savePending = true;
            g_changedAt = now;
        }
        g_lastHash = g_hash;
    } else if (g_savePending && now - g_changedAt > 1500) {
        g_savePending = false;
        config::Save();
    }
}

} // namespace

// ============================ public API ============================
bool Init() {
    RegisterAllModules();
    g_factory.clear();
    for (const auto& m : modules().modules())
        if (m) g_factory[m->name()] = m->enabled();
    config::Load();
    // config::Load restores the enabled bit directly for compatibility with
    // the existing roster, but nothing runs the Enable phase at startup: the
    // callbacks that arm overlay state (SetXxxEnabled + setting reads) only
    // fire later, when the user first toggles the module or its Tick begins.
    // A module enabled from config BEFORE the first Present installs its
    // hooks would stay silently inert until the next OFF->ON - the "needs two
    // toggles" symptom. Replay the Enable phase once for every module the
    // config (or its ctor) left enabled. Every onEnable in the roster is an
    // idempotent stateless setter (audit in the delivery report): a replay
    // re-applies the same overlay flag or resets a local animation value, it
    // never double-arms anything.
    for (const auto& holder : modules().modules()) {
        if (holder && holder->enabled())
            ModulePhaseGuard::run(holder.get(), ModulePhaseGuard::Phase::Enable);
    }
    g_modVis.clear();
    g_ease.reset();
    g_loaded = true;
    LOG_INFO("menu: init ok (%d modules)", (int)modules().modules().size());
    return true;
}

void Shutdown() {
    if (!g_loaded) return;
    config::Save();
    LOG_INFO("menu: shutdown (config flushed)");
}

bool KeyboardCaptured() {
    return g_systemEnum || g_field.kind != Field::None || g_stringEditSetting != nullptr ||
           g_keyEditSetting != nullptr || g_listening || g_refListeningKey;
}

bool DismissTopmost() {
    // r34: ESC inside a settings text field reverts it, inside a key capture
    // cancels it - the menu itself stays open.
    if (g_systemEnum) { g_systemEnum = nullptr; return true; }
    if (g_colorEditSetting) { g_colorEditSetting = nullptr; g_colorDrag = nullptr; return true; }
    if (g_stringEditSetting) { EndStringEdit(false); return true; }
    if (g_keyEditSetting) { g_keyEditSetting = nullptr; return true; }
    // Bind capture goes first: ESC here must unbind the module (clear the
    // key) while the menu stays open. Handling it later misses the edge -
    // the Present path resets the key snapshot right after this returns.
    if (g_refListeningKey) {
        if (g_refSelected) {
            g_refSelected->setKey(0);
            Toast("%s unbound", g_refSelected->name());
        }
        g_refListeningKey = false;
        return true;
    }
    if (g_modal != M_None) { CloseModal(); return true; }
    if (g_notif) { g_notif = false; return true; }
    if (g_listening) { g_listening = false; return true; }
    if (g_field.kind != Field::None) { g_field.kind = Field::None; return true; }
    if (g_hudDrag) { g_hudDrag = false; return true; }
    return false;
}

void Toast(const char* fmt, ...) {
    char b[192];
    va_list a; va_start(a, fmt); vsnprintf(b, sizeof(b), fmt, a); va_end(a);
    b[sizeof(b) - 1] = 0;
    g_toasts.push_back({ b, GetTickCount64() + 3500 });
    while (g_toasts.size() > 3) g_toasts.erase(g_toasts.begin());
}

void OpenModuleSettings(Module* m) {
    if (!m) return;
    // Same selection state the module panels' right-click handler uses, plus
    // raising the menu itself (HUD editor right-click parity).
    g_refSelected = m;
    g_systemFocus = m;
    g_showGeneral = m->hiddenFromLists;
    g_systemConfigs = false; g_systemFavoritesOnly = false;
    g_refCategory = RefCategoryFor(m);
    g_search[0] = 0; g_systemEnum = nullptr;
    m->uiExpanded = true;
    g_refTab = 0;
    g_refInspectorScroll = g_refInspectorScrollTo = 0.0f;
    overlay::g_showMenu = true;
    Toast("Settings: %s", m->name());
}

void Frame() {
    static int uifno = 0;
    const bool utrace = ++uifno <= 3;
    if (utrace) LOG_INFO("trace: ui::Frame %d begin", uifno);
    const float dt = gui::GetDeltaTime();
    static bool previousMenuOpen = false;
    if (previousMenuOpen != overlay::g_showMenu) {
        // A slider capture belongs to one GUI session. Do not carry a stale
        // pointer/geometry through the close animation into the next session.
        g_dragV = nullptr;
        g_systemEnum = nullptr;
        g_hudDrag = false;
        g_keyEditSetting = nullptr;
        g_colorEditSetting = nullptr;
        g_colorDrag = nullptr;
        EndStringEdit(true);
        previousMenuOpen = overlay::g_showMenu;
    }
    ApplyClientModules();
    {
        // r34 perf gate: tell the overlay which heavy subsystems are needed.
        auto on = [](const char* n) { Module* m = modules().find(n); return m && m->enabled(); };
        const bool actors = on("Hitboxes") || on("Target HUD");
        overlay::SetFeatureDemand(actors, on("World Particles") ||
                                  (on("Crosshair Strokes") && !overlay::g_showMenu &&
                                   !overlay::HudEditActive() &&
                                   overlay::IsWorldHudScreen()),
                                  on("AutoSprint") || on("Null Movement"), on("Cooldowns"));
    }
    if (utrace) LOG_INFO("trace: ui apply done");

    // Keybinds fire only in plain gameplay: never with the ClickGUI or HUD
    // editor open, and never on a game screen (chat, pause/Esc, inventory,
    // containers, settings...). Presses made there are simply dropped.
    if (!overlay::g_showMenu && !overlay::HudEditActive() && overlay::IsGameplayScreen())
        DispatchBinds();
    if (utrace) LOG_INFO("trace: ui binds done");

    // HUD editor scrim (Flarial editmenu): dim the world but keep every HUD
    // element visible above it - modules render after this on the same list.
    // Drawn whether or not the menu animation has fully closed.
    const bool hudEdit = overlay::HudEditActive() && !overlay::g_showMenu;
    if (hudEdit) {
        const ImVec2 es = gui::GetScreenSize();
        if (es.x > 0.0f && es.y > 0.0f)
            gui::FillRect(ImVec4(0.0f, 0.0f, es.x, es.y), ImColor(0, 0, 0), 0.55f);
    }

    // r25: the whole client HUD/ESP draws only on the gameplay HUD layers.
    // Over inventory, pause, chat, chest or any other screen nothing from
    // Nightfull renders (the ClickGUI itself is not a module and keeps
    // working; the HUD editor only exists in gameplay).
    const bool drawWorldUi = overlay::IsWorldHudScreen() || overlay::g_showMenu ||
                             overlay::HudEditActive();
    for (const auto& m : modules().modules()) {
        if (!m->enabled()) continue;
        ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Tick);
        if (m->enabled() && drawWorldUi)
            ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Render);
    }
    if (utrace) LOG_INFO("trace: ui modules done");

    // HUD editor hints at the top, above everything (foreground list). Placed
    // before the menu-ease early return so they render with the menu closed.
    if (hudEdit) {
        const ImVec2 es = gui::GetScreenSize();
        if (es.x > 0.0f && es.y > 0.0f) {
            ImDrawList* fd = ImGui::GetForegroundDrawList();
            const char* line1 = "HUD-редактор: тяни элементы, колесо — размер, ПКМ — настройки";
            const char* line2 = "ESC — выход";
            const float u1 = 0.56f, u2 = 0.52f;
            const float y1 = 14.0f;
            const float w1 = gui::GetTextWidth(line1, u1);
            gui::DrawString(ImVec2((es.x - w1) * 0.5f, y1), line1,
                            ImColor(214, 217, 224), u1, 0.85f, true, fd);
            const float w2 = gui::GetTextWidth(line2, u2);
            gui::DrawString(ImVec2((es.x - w2) * 0.5f, y1 + gui::GetTextHeight(u1) + 4.0f),
                            line2, ImColor(214, 217, 224), u2, 0.85f, true, fd);
        }
    }

    // Reconcile AutoSprint after module toggles and GUI/menu transitions. The
    // actual synthetic key remains paired at overlay's Keyboard::feed hook.
    overlay::ServiceAutoSprint();
    AutosaveTick();
    if (utrace) LOG_INFO("trace: ui autosave done");
    PaintToasts();
    if (utrace) LOG_INFO("trace: ui toasts done");

    GeneralModule* gm = GeneralModule::instance();
    const float easeSpeed = gm && gm->m_easeSpeed ? gm->m_easeSpeed->mValue : 14.0f;
    const int animStyle = gm && gm->m_animation ? gm->m_animation->mValue : 1;
    const float scrimMax = gm && gm->m_scrim ? gm->m_scrim->mValue : 0.45f;
    g_animsOff = gm && gm->m_animations && !gm->m_animations->mValue;

    if (overlay::g_showMenu) g_ease.incrementPercentage(dt * easeSpeed / 10.0f);
    else g_ease.decrementPercentage(dt * 2.0f * easeSpeed / 10.0f);

    gui::EasingUtil e = g_ease;
    const float anim = g_animsOff ? (overlay::g_showMenu ? 1.0f : 0.0f)
                                  : gui::Lerp(0.0f, 1.0f, (float)e.easeOutExpo());
    // Backdrop blur strength tracks the open animation so the frosted glass
    // fades with the menu; the HUD editor uses full strength. Must be pushed
    // before the closed early return so the close animation also fades it out.
    overlay::SetUiBlurStrength(hudEdit ? 1.0f
                              : (overlay::g_showMenu ? anim : 0.0f));
    if (anim < 0.001f) {
        // Fully closed: drop transient interaction state.
        g_systemEnum = nullptr;
        g_modal = M_None; g_selMod = nullptr; g_notif = false;
        g_listening = false; g_refListeningKey = false; g_field.kind = Field::None;
        g_dragV = nullptr; g_hudDrag = false;
        g_colorEditSetting = nullptr; g_colorDrag = nullptr;
        return;
    }

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;

    // Ctrl+K focuses search.
    if (overlay::g_showMenu && keys::Down(VK_CONTROL) && keys::PressedThisFrame('K')) {
        EndStringEdit(true);
        g_keyEditSetting = nullptr;
        keys::TextInput(nullptr, 0, false);
        g_field.kind = Field::Search;
    }

    UpdateTextField();
    UpdateStringField();
    UpdateKeyField();
    // Typing in search jumps to the Modules page (current behavior).
    if (g_field.kind == Field::Search && g_search[0] && g_page != P_Modules)
        g_page = P_Modules;
    bool fieldClaimed = false;

    float sBase = std::min(screen.x * 0.94f / kRefMainW, screen.y * 0.94f / kRefMainH);

    if (sBase <= 0.05f) return;

    const float openE = gui::Clamp(anim, 0.0f, 1.0f);
    float sEff = sBase;
    float risePx = 0.0f;
    if (animStyle == GeneralModule::AnimZoom) {
        const float z = 0.94f + 0.06f * (1.0f - (1.0f - openE) * (1.0f - openE));
        sEff = sBase * z;
    } else if (animStyle == GeneralModule::AnimRise) {
        risePx = (1.0f - openE) * (1.0f - openE) * 18.0f * sBase;
    }
    // The Themes > GUI size slider scales the complete native shell, not
    // merely a label or a preview. Clamp again (now to the setting's full
    // 0.80..1.30 range) so corrupted config values cannot push the window
    // outside the screen.
    sEff *= gui::Clamp(g_refUiScale, 0.80f, 1.30f);
    sEff = std::min(sEff, std::min(screen.x * 0.97f / kRefMainW, screen.y * 0.94f / kRefMainH));

    const float blockW = kRefMainW * sEff, blockH = kRefMainH * sEff;
    ImVec2 origin((screen.x - blockW) * 0.5f, (screen.y - blockH) * 0.5f + risePx);
    const ImVec2 mouse = gui::GetMousePos();
    // Draggable shell: LMB grab on the title bar background moves the whole
    // window (buttons on the right keep their clicks). Offset persists while
    // the menu lives and is clamped so the window cannot leave the screen.
    {
        static bool dragWin = false;
        static float grabDX = 0.0f, grabDY = 0.0f;
        static float winOX = 0.0f, winOY = 0.0f;
        const bool lDown = overlay::g_guiMouseDown[0] || ImGui::IsMouseDown(0);
        const bool lPressed = overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0);
        const float titleH = kRefTopH * sEff;
        const float dragX = origin.x + winOX, dragY = origin.y + winOY;
        const bool inTitle = mouse.x >= dragX + kRefCenterX * sEff &&
                             mouse.x < dragX + (kRefCenterX + 180.0f) * sEff &&
                             mouse.y >= dragY && mouse.y < dragY + titleH;
        if (!dragWin && lPressed && overlay::g_showMenu && inTitle && g_modal == M_None) {
            dragWin = true;
            grabDX = mouse.x - dragX;
            grabDY = mouse.y - dragY;
        }
        if (dragWin && !lDown) dragWin = false;
        if (dragWin) {
            winOX = mouse.x - grabDX - (screen.x - blockW) * 0.5f;
            winOY = mouse.y - grabDY - ((screen.y - blockH) * 0.5f + risePx);
        }
        if (!overlay::g_showMenu) { dragWin = false; }
        origin.x += winOX;
        origin.y += winOY;
        origin.x = gui::Clamp(origin.x, 0.0f, std::max(0.0f, screen.x - blockW));
        origin.y = gui::Clamp(origin.y, 0.0f, std::max(0.0f, screen.y - blockH));
        winOX = origin.x - (screen.x - blockW) * 0.5f;
        winOY = origin.y - ((screen.y - blockH) * 0.5f + risePx);
    }
    // This custom ClickGUI is drawn directly on the background draw list, so
    // ImGui has no native window hit-test for it. Compute the exact rendered
    // rectangle here and make it the single input gate: clicks outside this
    // rectangle must not activate any GUI control (or dismiss a popup).
    const bool pointerInsideWindow =
        mouse.x >= origin.x && mouse.x < origin.x + blockW &&
        mouse.y >= origin.y && mouse.y < origin.y + blockH;

    // Scrim.
    gui::FillRect(ImVec4(0, 0, screen.x, screen.y), ImColor(0, 0, 0),
                  anim * scrimMax, 0.0f);

    Ctx c;
    c.d = ImGui::GetBackgroundDrawList();
    c.s = sEff;
    c.alpha = anim;
    c.origin = origin;
    c.interact = overlay::g_showMenu && pointerInsideWindow && g_modal == M_None;
    c.dt = dt;
    c.accent = gui::Accent();

    // Window shadow + Aurora night backdrop: faint green/blue auras, a
    // static grid lattice and scanlines (prototype world feel). Layouts are
    // precomputed per screen size; only ambient state is read per frame.
    auto radialGlow = [&](const ImVec2& c0, float r, const ImColor& col, float a) {
        constexpr int kLayers = 22;
        for (int i = kLayers; i >= 1; --i) {
            const float t = (float)i / (float)kLayers;
            const float fall = (1.0f - t) * (1.0f - t);
            c.d->AddCircleFilled(c0, r * t,
                ImColor(col.Value.x, col.Value.y, col.Value.z, a * fall * anim), 48);
        }
    };
    // Obsidian backdrop (prototype body): purple aura top-left, mint aura
    // right side over the dimmed game. First aura follows the client theme
    // accent; mint stays fixed like the prototype. No lattice, no grain.
    radialGlow(ImVec2(screen.x * 0.15f, screen.y * 0.0f),
               560.0f * sBase, c.accent, 0.13f);
    radialGlow(ImVec2(screen.x * 0.90f, screen.y * 0.20f),
               460.0f * sBase, ImColor(32, 217, 164), 0.07f);
    gui::FillShadowRect(ImVec4(origin.x, origin.y, origin.x + kRefMainW * sEff,
                               origin.y + kRefMainH * sEff),
                        ImColor(0, 0, 0), anim * 0.34f, 20.0f * sEff, c.d);

    g_stringFieldHovered = false;
    PaintReferenceShell(c, fieldClaimed);
    // Apply the captured slider against the geometry rendered this frame. This
    // is important for in-world relative mouse input and for controls that
    // change the shell scale/scroll while they are being dragged.
    UpdateFloatDrag();
    UpdateColorDrag();   // r25: color picker drag capture

    // Modals get their own interacting ctx.
    {
        Ctx mc = c;
        mc.interact = overlay::g_showMenu && pointerInsideWindow;
        PaintModal(mc);
    }
    // Both settings renderers must get a chance to claim the click first.
    if (g_stringEditSetting && !g_stringFieldHovered &&
        (overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0)))
        EndStringEdit(true);

    // Menu-key capture.
    if (g_listening) {
        for (int vk = 8; vk <= 0xFE && g_listening; vk++) {
            if (keys::PressedThisFrame(vk)) {
                if (vk == VK_ESCAPE) { g_listening = false; break; }
                if (vk == VK_END) { Toast("END зарезервирована для выгрузки"); g_listening = false; break; }
                overlay::g_menuKey = vk;
                LOG_INFO("menu: menu key -> %s", keys::Name(vk));
                g_listening = false;
            }
        }
    }

    // Reference inspector module-key capture. ESC unbinds the module
    // entirely (clears the key) instead of just cancelling the capture.
    if (g_refListeningKey) {
        for (int vk = 8; vk <= 0xFE && g_refListeningKey; vk++) {
            if (!keys::PressedThisFrame(vk)) continue;
            if (vk == VK_ESCAPE) {
                if (g_refSelected) {
                    g_refSelected->setKey(0);
                    Toast("%s unbound", g_refSelected->name());
                }
                g_refListeningKey = false;
                break;
            }
            if (vk == VK_END) { Toast("END reserved for unload"); g_refListeningKey = false; break; }
            if (g_refSelected) {
                g_refSelected->setKey(vk);
                Toast("%s keybind -> %s", g_refSelected->name(), keys::Name(vk));
            }
            g_refListeningKey = false;
        }
    }

    // Click-away deactivates the text field (fields claim their own clicks).
    if (!fieldClaimed && c.interact && ImGui::IsMouseClicked(0) &&
        g_field.kind != Field::None)
        g_field.kind = Field::None;
}

} // namespace ui
} // namespace nf
