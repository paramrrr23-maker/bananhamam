# Устройство Nightfull и границы переработки R26

## 1. Что это за проект
Нативная Windows x64 DLL на C++20. Рисует ImGui поверх Minecraft Bedrock через
DirectX 11/12; часть игровых функций связывается с внутренними API/хуками игры.
Это не Electron, не React-клиент и не веб-сервер. HTML в приложенном архиве —
визуальный образец, а не часть игрового runtime.

## 2. Запуск и жизненный цикл
`src/dllmain.cpp` минимален: при attach отключает лишние thread notifications,
создаёт рабочий поток и вызывает `overlay::MainThread`. Тяжёлый DirectX/ImGui-код
не выполняется под loader lock. Detach вызывает best-effort teardown.

`src/overlay/overlay.cpp` — большой общий движок (~18 тысяч строк):
перехват Present/ResizeBuffers и DX12 command queue, подготовка render targets,
ImGui Win32/DX11/DX12, ввод и курсор, игровые хуки, sampler/snapshots и teardown.
Здесь находятся платформенные и версионно-зависимые части. R26 этот файл не изменяет.

После подготовки ImGui вызывается `ui::Init`: регистрация модулей и загрузка конфига.
Покадрово `ui::Frame` применяет настройки клиента, ограничивает dispatch биндов
обычным игровым экраном, вызывает tick/render модулей через guard, обновляет автосохранение,
рисует HUD/редактор и ClickGUI. Menu остаётся отдельным draw-list UI, не игровым модулем.

## 3. Модули и настройки
`core/module.h`: Module содержит категорию, имя, описание, enabled/key,
список типизированных Setting и callbacks onEnable/onDisable/onTick/onRender.
`core/module_manager.*` владеет объектами; `modules/registry.cpp` собирает roster.
Текущий registry содержит 44 регистрации, включая скрытые служебные модули.

`core/setting.h` содержит Bool, Number со snap-to-step, Enum с mValues,
Color RGBA и String с ограничением длины. Есть optional mIsVisible и mIsKeybind.
Имена настроек являются идентификаторами хранения; R26 не переименовывает старые поля.
Общий рендерер меню обходит этот список. Поэтому новый модуль/новая настройка
автоматически появляются без вручную написанной карточки.

`core/module_guard.*` вызывает callbacks с SEH-изоляцией и диагностикой долгих вызовов.
Включение через GUI по-прежнему использует ApplyModuleState + ModulePhaseGuard,
а не простую отрисовочную переменную. Меню учитывает ситуацию, когда onEnable
сам выключает неподдерживаемую функцию.

## 4. Где живут функции
- `modules/game_modules.*`: AutoSprint, FullBright, Hitboxes/TargetESP, NoHurtCam,
  Saturation, MotionBlur, WorldParticles, JavaInventoryHotkeys, VSyncDisabler,
  NullMovement, CPS limiter, GuiScale, ViewModel, ItemPhysics, JumpCircles,
  Freelook, Glint, очистка чата/скорборда.
- `modules/hud_modules.*`: Watermark/Arraylist, Cooldowns, Potions, FPS/CPS,
  Keybinds, Reach Display, Target HUD, Time, Memory, Mouse/Crosshair Strokes,
  Keystrokes, Crosshair, Armor HUD. Фактические game-data snapshots берутся через overlay.
- `modules/text_hotkeys.*`: слоты названия/клавиши/текста/включения;
  рендер строки/кейбинда сохраняет NotifyTextHotkeysEdited.
- `modules/client_modules.*`: скрытые always-applied General и Themes;
  настройки меню, темы, цвета, naming, курсор, HUD editor.
- `modules/stub_modules.*`: не следует считать всё завершёнными функциями.
  HUD/Skybox/Hotbar/Time Changer преимущественно являются holders настроек.
  Zoom, несмотря на расположение в этом файле, имеет реальные callbacks
  prepare/write/restore FOV и hold-to-use. R26 не обещает доделать отсутствующий runtime.

Многие игровые функции отключаются, если нужная сигнатура/offset не подтверждены.
Наличие карточки не означает гарантированную поддержку произвольной версии Bedrock.

## 5. Ввод, курсор, редактор HUD
Overlay публикует g_guiMouseDown/Pressed/Released и колесо перед ImGui::NewFrame.
Menu работает и с этими snapshot-данными, и с ImGui backend. Это важно для относительной
мыши в игровом мире. Ctx преобразует screen/design координаты, масштаб и scroll offset.

R26 не заменяет WndProc, Keyboard::feed/MouseDevice::feed или arbitration курсора.
Новый список/цветовой editor закрывается через DismissTopmost; текст/key capture
через KeyboardCaptured не даёт открыть/закрыть меню случайным пользовательским вводом.
Настройки внутри карточек получают hit gate по текущему clipped viewport,
а popup рисуется после колонок и временно блокирует остальные controls.

HUD editor живёт в исходном overlay/HUD коде. Меню лишь передаёт ему управление.
OpenModuleSettings теперь дополнительно выбирает категорию и фокусирует карточку.

## 6. Конфигурации и темы
`utils/config.*`: свой JSON serializer/parser, активный config.json и именованные
profiles. Базовая папка обычно RoamingState/Nightfull, есть fallback-пути.
Неизвестные модули/параметры игнорируются. Запись включает состояния, бинды и все Setting,
включая скрытые; поэтому новое избранное хранится без второго формата конфигурации.

R26 добавляет только GUI Appearance (Light/Dark) и скрытую строку GUI Favorites в General.
Строка избранного содержит разделённые переводами строк имена модулей; JSON escaping
обрабатывается существующим writer. Save/load API и автосохранение не переписаны.

`utils/gui_theme.*` управляет циклическим акцентом и naming, `theme_presets.h` содержит
80 пресетов. R26 использует тот же Accent и настройки цвета. GUI Light/Dark меняет
локальную нейтральную палитру меню, не заменяет тему HUD.
`utils/fonts.*` загружает Segoe UI с fallback на bundled JetBrains/Arial; Lucide — иконки.
Расширены диапазоны punctuation и исправлен код chevron-up в атласе.

## 7. Новый layout
База 1440×900 design units; боковая колонка 238, верхняя панель 48 снаружи отступов.
Рабочая область разбита на три колонки с 8-unit gap. Карточки измеряются по
видимым настройкам, состоянию раскрытия и открытому HSV редактору.
Каждая колонка имеет свой target/current scroll и отрисовывается с clipping.
При фильтрации список сортируется по существующему имени модуля и layout перестраивается.

Spring reveal не меняет игровые данные. Модуль переключает только отдельный switch;
заголовок раскрывает настройки, звезда меняет избранное, поле key включает bind capture.
Пустой поиск/избранное имеют отдельные информативные состояния.
Configs и Client settings — рабочие страницы, без фиктивных Friends/Waypoints из макета.

## 8. Граница изменений
Изменены меню/его заголовок, UI state default в Module, General settings,
glyph ranges в fonts.cpp и имя выходного файла build.bat.
Игровые модули (кроме General/Theme holders), overlay, key bridge, persistence engine,
third-party библиотеки и HUD rendering оставлены побайтно прежними.
Проверку выполняет MANIFEST_R26.json: перечислены изменённые файлы и SHA-256.

Код нативного меню проверяется на headless стенде с реальным bundled ImGui.
Платформенные/игровые API в этом стенде — mocks: это проверка UI, не сертификация игры.
