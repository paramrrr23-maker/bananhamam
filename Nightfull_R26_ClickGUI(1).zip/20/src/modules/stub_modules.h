// stub_modules.h - menu-driven module holders.
//
// These keep the ClickGUI roster aligned with the Nightfull reference. Each
// class is a plain Module with identity and default state; the registry keeps
// rendering independent from the module implementation.

#pragma once

#include "core/module.h"

namespace nf {

class HudModule : public Module {
public:
    HudModule();
    NumberSetting* m_scale = nullptr;
};

class SkyboxModule : public Module {
public:
    SkyboxModule();
    NumberSetting* m_scale = nullptr;
};

class ZoomModule : public Module {
public:
    ZoomModule();
    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    NumberSetting* m_zoomFov = nullptr;
    BoolSetting* m_smooth = nullptr;
    float m_cur = 0.0f;
    unsigned long long m_lastMs = 0;
    bool m_prepared = false;
};

class HotbarModule : public Module {
public:
    HotbarModule();
    NumberSetting* m_scale = nullptr;
};

class TimeChangerModule : public Module {
public:
    TimeChangerModule();
    NumberSetting* m_scale = nullptr;
};

} // namespace nf
