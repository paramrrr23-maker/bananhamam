// Flarial-inspired visual modules that are safe for the Bedrock overlay.
//
// These modules only draw into our ImGui overlay or read local Windows/input
// state. World/entity modules from Flarial are intentionally absent until a
// verified Minecraft Bedrock 1.21.111 SDK symbol is available.

#pragma once

#include "modules/module.h"

#include <array>

namespace modules {

class FlarialFPS : public Module {
public:
    FlarialFPS();
    void on_render() override;

private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    EnumSetting* m_color = nullptr;
};

class FlarialCPS : public Module {
public:
    FlarialCPS();
    void on_tick() override;
    void on_render() override;

private:
    static constexpr int kMaxClicks = 64;
    std::array<unsigned long long, kMaxClicks> m_lmb{};
    std::array<unsigned long long, kMaxClicks> m_rmb{};
    int m_lmbHead = 0;
    int m_rmbHead = 0;
    int m_lmbCount = 0;
    int m_rmbCount = 0;
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_showButtons = nullptr;
    EnumSetting* m_color = nullptr;

    void record(std::array<unsigned long long, kMaxClicks>& buffer,
                int& head, int& count, unsigned long long now);
    int recent(const std::array<unsigned long long, kMaxClicks>& buffer,
               int head, int count, unsigned long long now) const;
};

class CPSLimiter : public Module {
public:
    CPSLimiter();
    NumberSetting* m_left = nullptr;
    NumberSetting* m_right = nullptr;
};

class FlarialKeystrokes : public Module {
public:
    FlarialKeystrokes();
    void on_render() override;

private:
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_spacing = nullptr;
    NumberSetting* m_rounding = nullptr;
    BoolSetting* m_showMouse = nullptr;
    ColorSetting* m_enabledColor = nullptr;
    ColorSetting* m_disabledColor = nullptr;
};

class FlarialCrosshair : public Module {
public:
    FlarialCrosshair();
    void on_render() override;

private:
    BoolSetting* m_dynamic = nullptr;
    NumberSetting* m_gap = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    ColorSetting* m_color = nullptr;
};

class FlarialMouseStrokes : public Module {
public:
    FlarialMouseStrokes();
    void on_enable() override;
    void on_disable() override;
    void on_tick() override;
    void on_render() override;

private:
    struct TrailPoint {
        ImVec2 position{};
        unsigned long long timestamp = 0;
    };
    static constexpr int kMaxPoints = 64;
    static constexpr unsigned long long kPointLifetimeMs = 260ull;
    std::array<TrailPoint, kMaxPoints> m_points{};
    int m_pointCount = 0;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    ColorSetting* m_color = nullptr;
};

class FlarialDirectionHUD : public Module {
public:
    FlarialDirectionHUD();
    void on_render() override;

private:
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_degrees = nullptr;
    ColorSetting* m_color = nullptr;
};

class FlarialClock : public Module {
public:
    FlarialClock();
    void on_render() override;

private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_seconds = nullptr;
    BoolSetting* m_24Hour = nullptr;
    ColorSetting* m_color = nullptr;
};

class FlarialMemory : public Module {
public:
    FlarialMemory();
    void on_render() override;

private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    ColorSetting* m_color = nullptr;
};

// Flarial Animations port: lerps the selected-hotbar-slot highlight square
// when slots are switched. The actual work happens in the overlay's
// TextureGroup::getTexture + MinecraftUIRenderContext::drawImage hooks; this
// module only holds the speed setting and the enabled switch.
class Animations : public Module {
public:
    Animations();

    NumberSetting* m_speed = nullptr;
};

// Flarial ReachCounter port: shows the distance of the last attack. The value
// comes from the GameMode::attack hook (overlay.cpp) reading the level hit
// result, exactly like Flarial's AttackEvent.
class ReachDisplay : public Module {
public:
    ReachDisplay();
    void on_render() override;

private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    EnumSetting* m_color = nullptr;
};

// Pulse-style "Potions" plate: header with icon, rows of the local player's
// active effects with the remaining time (m:ss), like the Pulse videos.
// Data comes from the MobEffectsComponent entt read (overlay.cpp).
// The plate stays visible with no effects but hides on any menu/chat screen.
class PotionsHud : public Module {
public:
    PotionsHud();
    void on_render() override;

private:
    EnumSetting*   m_position = nullptr;
    NumberSetting* m_scale    = nullptr;
    BoolSetting*   m_useTheme = nullptr;   // follow the interface theme accent
    BoolSetting*   m_outline  = nullptr;   // accent stroke around the plate
    NumberSetting* m_opacity  = nullptr;   // plate opacity
    ColorSetting*  m_color    = nullptr;   // accent when "Theme color" is off
};

// Pulse-style "Keybinds" plate: header with icon, one row per module with a
// keybind - neon green dot while the module is enabled, red when disabled.
class KeybindsHud : public Module {
public:
    KeybindsHud();
    void on_render() override;

private:
    EnumSetting*   m_position = nullptr;
    NumberSetting* m_scale    = nullptr;
    BoolSetting*   m_useTheme = nullptr;   // follow the interface theme accent
    BoolSetting*   m_outline  = nullptr;   // accent stroke around the plate
    NumberSetting* m_opacity  = nullptr;   // plate opacity
    ColorSetting*  m_color    = nullptr;   // accent when "Theme color" is off
};

// Pulse-style "Monitoring" plate: FPS / BPS / server TPS / joined server IP /
// left CPS / local time - same plate look as Potions / Keybinds.
class MonitoringHud : public Module {
public:
    MonitoringHud();
    void on_render() override;

private:
    EnumSetting*   m_position = nullptr;
    NumberSetting* m_scale    = nullptr;
    BoolSetting*   m_useTheme = nullptr;   // follow the interface theme accent
    BoolSetting*   m_outline  = nullptr;   // accent stroke around the plate
    NumberSetting* m_opacity  = nullptr;   // plate opacity
    ColorSetting*  m_color    = nullptr;   // accent when "Theme color" is off
};

// SystemDLC "TargetHud" port: a 235x54 plate for the last attacked entity -
// avatar block with the initial, the (display) name and a health chip whose
// color follows the hp ratio (red -> yellow -> green). Fades in on attack,
// fades out ~2.5 s after the last hit.
class TargetHud : public Module {
public:
    TargetHud();
    void on_render() override;

private:
    EnumSetting*   m_position = nullptr;
    NumberSetting* m_scale    = nullptr;
    BoolSetting*   m_useTheme = nullptr;
    BoolSetting*   m_outline  = nullptr;
    NumberSetting* m_opacity  = nullptr;
    ColorSetting*  m_color    = nullptr;
};

// Entity hitbox ESP: projects every actor's AABB (entt component) through the
// view matrix and draws either the outline perimeter or a fully filled box;
// fill color always matches the perimeter color.
class Hitboxes : public Module {
public:
    Hitboxes();
    void on_render() override;

private:
    EnumSetting*   m_mode      = nullptr;   // Периметр / Заполненный
    NumberSetting* m_opacity   = nullptr;   // box transparency
    NumberSetting* m_thickness = nullptr;   // outline thickness (perimeter mode)
    BoolSetting*   m_useTheme  = nullptr;
    ColorSetting*  m_color     = nullptr;
};

// Crit Particles: SystemDLC TargetESP-style burst around the entity that
// took the hit. The attack hook in overlay.cpp only stamps a burst when the
// attacker is falling (a real crit) AND the target left its 500 ms damage
// immunity window; each burst carries the world-space hit point, rendered
// through the game's view matrix (overlay::ProjectWorldToScreen).
class CritParticles : public Module {
public:
    CritParticles();
    void on_render() override;

private:
    EnumSetting*   m_mode     = nullptr;   // Кольцо/Треугольник/Молнии/Спираль/Орбиты
    NumberSetting* m_radius   = nullptr;   // shape radius in blocks
    NumberSetting* m_density  = nullptr;   // point count
    NumberSetting* m_duration = nullptr;   // burst lifetime, ms
    NumberSetting* m_speed    = nullptr;   // animation speed
    NumberSetting* m_size     = nullptr;   // glow dot size in blocks
    BoolSetting*   m_useTheme = nullptr;   // follow the interface theme accent
    ColorSetting*  m_color    = nullptr;   // accent when "Theme color" is off
};

} // namespace modules
