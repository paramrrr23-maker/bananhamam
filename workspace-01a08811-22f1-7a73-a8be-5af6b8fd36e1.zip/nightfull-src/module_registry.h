// module_registry.h - declares the module registration entry point.
//
// NOTE: ASCII only in this file.

#pragma once

namespace modules {

// Adds every module of the project to the ModuleManager. Called once after
// ImGui context creation (from overlay.cpp init). To add a module: create
// files under modules/<category>/ and register it here.
void RegisterAllModules();

} // namespace modules