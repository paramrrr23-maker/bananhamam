# Проверка R26

## Успешно
- Проверка синтаксиса настоящих `menu.cpp` и `client_modules.cpp` через g++ C++20
  с отдельно подключёнными тестовыми Win32-заглушками.
- `tests/gui_r26_regression.py`: **43 assertions** в каждом запуске;
  все 9 состояний прошли. Лог: `tests/gui_r26_results.txt`.
- Проверены размеры по видимым Setting (скрытая настройка не оставляет phantom gap),
  enabled-switch, favorite toggle, раскрытие/сворачивание, enum selection,
  клавиатурный capture/ESC, независимая прокрутка, empty search, Light/Dark,
  bool без случайного переключения модуля, отмена строки, color editor,
  отключение анимаций, OpenModuleSettings из HUD, slider capture/update/release,
  UTF-8-safe ellipsis и наличие `…`, `—`, `•` в атласе шрифта.
- Отрисовка настоящих ImGui meshes и визуальный просмотр 9 кадров 1440×900:
  Light, Dark, Enum, Color, Settings, Themes, Configs, Empty, Save.
  Найденные oversized icons, неверный chevron-up и отсутствующая пунктуация исправлены.
- Сравнение с исходным ZIP: изменены только 7 source/build файлов;
  остальные исходники сохранены побайтно. SHA-256 приведены в MANIFEST_R26.json.
- Все прежние engine/game/HUD/text-hotkey implementations и third-party зависимости сохранены.

## Что этот тест НЕ проверяет
Headless harness включает реальный renderer меню и bundled ImGui, но создаёт
синтетические модули и заменяет game/Win32/config disk APIs на mocks.
Он не запускает Minecraft, не устанавливает хуки и не записывает реальные профили.
Файловая сохранность новых General settings основана на существующем неизменённом
serializer/parser; end-to-end запись в Bedrock RoamingState здесь не тестировалась.
Анимации прогонялись покадрово и проверялись по состоянию; PNG — неподвижные кадры,
не измерение плавности/FPS в игре.

**Windows/MSVC Release DLL, DirectX 11/12 runtime, mouse feed в игре,
конкретные Bedrock signatures и игровой FPS здесь не проверены.**
Нельзя считать headless g++ прогон заменой MSVC и in-game smoke test.

## Старые тесты из исходного архива
Были также попытки запуска прежних `targethud_r17_regression.py`,
`text_hotkeys_r15_regression.py`, `cooldowns_r16_regression.py`.
Они не дали зелёный результат в этой среде: первый требует отсутствующий shared
`libasan.so.6`; два других извлекают фрагменты обновлённого overlay без необходимых
Win32/SEH/Interlocked и актуальных вспомогательных символов.
Эти legacy harness не исправлялись в задаче редизайна; весь старый набор тестов
не объявляется пройденным. Исходники overlay/gameplay, которые они читают, не изменены.

## Что проверить на Windows
1. Выполнить build.bat, убедиться в создании Nightfull_R26.dll и копировании fonts.
2. Открыть меню в мире, в паузе и после изменения размера окна.
3. Проверить input capture, бинды/текст/цвет, dropdown вверх у нижнего края,
   wheel над каждой колонкой и переключение Light/Dark.
4. Сохранить профиль, изменить значения, загрузить и убедиться в восстановлении
   избранного, GUI Appearance, биндов и остальных настроек.
5. Проверить HUD editor → ПКМ → нужная раскрытая карточка; закрытие/повторное открытие.
6. Отдельно проверить игровой HUD, TargetHUD, Cooldowns и остальные функции
   на своей поддерживаемой версии Bedrock и выбранном DX11/DX12 backend.
