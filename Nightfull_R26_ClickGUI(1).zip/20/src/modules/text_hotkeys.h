#pragma once

#include "core/module.h"

namespace nf {

class TextHotkeysModule final : public Module {
public:
    static constexpr int kSlots = 6;

    TextHotkeysModule();
    void onTick() override;
    void dispatchPressedBinds();
    // Called by the settings UI after a slot's key or text was edited: a slot
    // that now has both a key and a text is switched on automatically, so the
    // user never has to hunt for a separate "Enabled" toggle.
    void onSlotEdited(const Setting* edited);

private:
    struct Slot {
        StringSetting* name = nullptr;
        NumberSetting* key = nullptr;
        StringSetting* text = nullptr;
        BoolSetting* enabled = nullptr;
    };

    Slot m_slots[kSlots] = {};
};

} // namespace nf
