
#include <algorithm>
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
#include "imgui.h"
using HWND=unsigned long long; using HCURSOR=void*; using UINT=unsigned; using LONG=long; using LPARAM=long long;
static bool owned=true; static bool SoftwareCursorOwned(){return owned;}
namespace gui { ImColor Accent(){return ImColor(80,220,150,255);} }

volatile LONG g_cursorVisibilityEpoch=0,g_cursorStyle=0,g_cursorScalePermille=1000,g_cursorGlowPermille=350,g_cursorTheme=1,g_cursorColor=0xFFD97757;
LONG InterlockedCompareExchange(volatile LONG* p,LONG,LONG){return *p;}
LONG InterlockedExchange(volatile LONG* p,LONG v){LONG old=*p;*p=v;return old;}
LONG InterlockedIncrement(volatile LONG* p){LONG old=*p;*p=old+1;return old+1;}
static ImU32 GuiCursorColor() {
    if (InterlockedCompareExchange(&g_cursorTheme, 0, 0)) {
        const ImColor accent = gui::Accent();
        return ImGui::GetColorU32(static_cast<const ImVec4&>(accent));
    }
    const unsigned c = (unsigned)InterlockedCompareExchange(&g_cursorColor, 0, 0);
    return IM_COL32((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF, (c >> 24) & 0xFF);
}
void DrawGuiCursor() {
    if (!SoftwareCursorOwned()) return;
    const ImGuiIO& io = ImGui::GetIO();
    const ImVec2 p = io.MousePos;
    if (!std::isfinite(p.x) || !std::isfinite(p.y) ||
        p.x < 0.0f || p.y < 0.0f || p.x >= io.DisplaySize.x || p.y >= io.DisplaySize.y)
        return;
    const float userScale = std::clamp(
        (float)InterlockedCompareExchange(&g_cursorScalePermille, 0, 0) / 1000.0f, 0.5f, 2.0f);
    const float glow = std::clamp(
        (float)InterlockedCompareExchange(&g_cursorGlowPermille, 0, 0) / 1000.0f, 0.0f, 1.0f);
    const int style = InterlockedCompareExchange(&g_cursorStyle, 0, 0);
    const float s = std::clamp(io.DisplaySize.y / 1080.0f, 0.9f, 1.8f) * userScale;
    const ImU32 col = GuiCursorColor();
    ImDrawList* d = ImGui::GetForegroundDrawList();
    d->PushClipRectFullScreen();
    const ImU32 glowCol = (col & ~IM_COL32_A_MASK) | ((unsigned)(90.0f * glow) << 24);
    if (style == 1) {             // ring: a clean aiming reticle, zero arrow silhouette
        if (glow > 0.0f) d->AddCircle(p, 11.0f * s, glowCol, 32, 5.5f * s);
        d->AddCircle(p, 8.0f * s, col, 32, 1.8f * s);
        d->AddCircleFilled(p, 1.8f * s, col, 12);
    } else if (style == 2) {      // cross: four short ticks around the exact point
        if (glow > 0.0f) d->AddCircle(p, 11.0f * s, glowCol, 28, 4.0f * s);
        const float gap = 4.0f * s, len = 10.0f * s, th = 1.8f * s;
        d->AddLine(ImVec2(p.x, p.y - gap - len), ImVec2(p.x, p.y - gap), col, th);
        d->AddLine(ImVec2(p.x, p.y + gap), ImVec2(p.x, p.y + gap + len), col, th);
        d->AddLine(ImVec2(p.x - gap - len, p.y), ImVec2(p.x - gap, p.y), col, th);
        d->AddLine(ImVec2(p.x + gap, p.y), ImVec2(p.x + gap + len, p.y), col, th);
        d->AddCircleFilled(p, 1.5f * s, col, 10);
    } else if (style == 3) {      // dot: the quietest possible pointer
        if (glow > 0.0f) d->AddCircleFilled(p, 7.0f * s, glowCol, 24);
        d->AddCircleFilled(p, 4.0f * s, col, 24);
        d->AddCircle(p, 4.0f * s, IM_COL32(15,18,22,180), 24, 0.8f * s);
    } else if (style == 4) {      // diamond: rotated square, sharp centerpiece
        const float r = 8.0f * s;
        const ImVec2 v[4] = { ImVec2(p.x, p.y - r), ImVec2(p.x + r, p.y),
                              ImVec2(p.x, p.y + r), ImVec2(p.x - r, p.y) };
        if (glow > 0.0f) d->AddConvexPolyFilled(v, 4, glowCol);
        d->AddConvexPolyFilled(v, 4, col);
        d->AddPolyline(v, 4, IM_COL32(15,18,22,220), ImDrawFlags_Closed, 1.2f * s);
        d->AddCircleFilled(p, 2.0f * s, IM_COL32(15,18,22,255), 10);
    } else if (style == 5) {      // orbit: ring + orbiting satellite dot
        if (glow > 0.0f) d->AddCircle(p, 11.0f * s, glowCol, 32, 5.5f * s);
        d->AddCircle(p, 7.5f * s, col, 32, 1.4f * s);
        const float t = (float)ImGui::GetTime() * 2.4f;
        const ImVec2 orb(p.x + cosf(t) * 7.5f * s, p.y + sinf(t) * 7.5f * s);
        d->AddCircleFilled(orb, 2.2f * s, col, 12);
        d->AddCircleFilled(p, 1.6f * s, col, 10);
    } else if (style == 6) {      // blade: thin diagonal pointer, sharper than arrow
        const ImVec2 v[4] = { p, ImVec2(p.x + 3.0f*s, p.y + 3.0f*s),
                              ImVec2(p.x + 14.0f*s, p.y + 6.0f*s), ImVec2(p.x + 5.0f*s, p.y + 13.0f*s) };
        if (glow > 0.0f) d->AddConvexPolyFilled(v, 4, glowCol);
        d->AddConvexPolyFilled(v, 4, col);
        d->AddPolyline(v, 4, IM_COL32(15,18,22,230), ImDrawFlags_Closed, 1.1f * s);
        d->AddLine(ImVec2(p.x + 4.5f*s, p.y + 4.5f*s), ImVec2(p.x + 4.5f*s, p.y + 12.0f*s),
                   IM_COL32(15,18,22,200), 1.0f * s);
    } else if (style == 7) {      // brackets: four corner brackets, no body
        const float arm = 5.0f * s, out = 9.0f * s, th = 1.6f * s;
        if (glow > 0.0f) d->AddCircle(p, 11.0f * s, glowCol, 28, 4.0f * s);
        const ImU32 c2 = col;
        d->AddLine(ImVec2(p.x - out, p.y - out + arm), ImVec2(p.x - out, p.y - out), c2, th);
        d->AddLine(ImVec2(p.x - out, p.y - out), ImVec2(p.x - out + arm, p.y - out), c2, th);
        d->AddLine(ImVec2(p.x + out - arm, p.y - out), ImVec2(p.x + out, p.y - out), c2, th);
        d->AddLine(ImVec2(p.x + out, p.y - out), ImVec2(p.x + out, p.y - out + arm), c2, th);
        d->AddLine(ImVec2(p.x - out, p.y + out - arm), ImVec2(p.x - out, p.y + out), c2, th);
        d->AddLine(ImVec2(p.x - out, p.y + out), ImVec2(p.x - out + arm, p.y + out), c2, th);
        d->AddLine(ImVec2(p.x + out - arm, p.y + out), ImVec2(p.x + out, p.y + out), c2, th);
        d->AddLine(ImVec2(p.x + out, p.y + out), ImVec2(p.x + out, p.y + out - arm), c2, th);
        d->AddCircleFilled(p, 1.4f * s, c2, 8);
    } else {                      // arrow: slim dark-edged pointer
        const ImVec2 arrow[] = {
            p, ImVec2(p.x + 2*s, p.y + 21*s), ImVec2(p.x + 7*s, p.y + 16*s),
            ImVec2(p.x + 11*s, p.y + 25*s), ImVec2(p.x + 15*s, p.y + 23*s),
            ImVec2(p.x + 11*s, p.y + 14*s), ImVec2(p.x + 19*s, p.y + 14*s)
        };
        if (glow > 0.0f) d->AddConvexPolyFilled(arrow, 7, glowCol);
        d->AddTriangleFilled(arrow[0], arrow[1], arrow[6], col);
        d->AddQuadFilled(arrow[2], arrow[3], arrow[4], arrow[5], col);
        d->AddPolyline(arrow, 7, IM_COL32(15,18,22,255), ImDrawFlags_Closed, 1.6f*s);
    }
    d->PopClipRect();
}
void SetGuiCursorStyle(int style, float scale, float glow, bool themeColor, unsigned color) {
    if (style < 0) style = 0;
    if (style > 7) style = 7;
    InterlockedExchange(&g_cursorStyle, style);
    InterlockedExchange(&g_cursorScalePermille,
                        (LONG)(std::clamp(scale, 0.5f, 2.0f) * 1000.0f));
    InterlockedExchange(&g_cursorGlowPermille,
                        (LONG)(std::clamp(glow, 0.0f, 1.0f) * 1000.0f));
    InterlockedExchange(&g_cursorTheme, themeColor ? 1 : 0);
    InterlockedExchange(&g_cursorColor, (LONG)(color ? color : 0xFFFFFFFFu));
}
int main(){
 ImGui::CreateContext(); auto& io=ImGui::GetIO(); io.DisplaySize=ImVec2(1920,1080); io.DeltaTime=1.0f/60.0f; io.IniFilename=nullptr; io.Fonts->AddFontDefault(); io.Fonts->Build(); io.AddMousePosEvent(500,400);
 for(int style=0;style<8;style++){
  for(int theme=0;theme<2;theme++){
   SetGuiCursorStyle(style,0.5f+style*0.2f,0.4f,theme==0,0xFF22AA66);
   ImGui::NewFrame(); DrawGuiCursor(); ImGui::Render();
   assert(ImGui::GetDrawData()->TotalVtxCount>0);
  }
 }
 SetGuiCursorStyle(99,99.f,99.f,false,0); assert(g_cursorStyle==7&&g_cursorScalePermille==2000&&g_cursorGlowPermille==1000);
 SetGuiCursorStyle(-3,-1.f,-1.f,true,0xFF00FF00); assert(g_cursorStyle==0&&g_cursorScalePermille==500&&g_cursorGlowPermille==0);
 owned=false; ImGui::NewFrame(); DrawGuiCursor(); ImGui::Render(); assert(ImGui::GetDrawData()->TotalVtxCount==0);
 ImGui::DestroyContext(); std::cout<<"PASS: 8 cursor styles x2 color modes, clamping, hidden when GUI closed\n";
}
