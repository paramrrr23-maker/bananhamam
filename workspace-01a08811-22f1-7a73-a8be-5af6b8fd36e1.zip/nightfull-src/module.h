// module.h - base class for every cheat-manager-style module.
//
// IMPORTANT design rule of this project: modules are UI DEMOS ONLY.
// on_tick()/on_render() are called every frame while the module is enabled,
// but the demo modules deliberately do NOT touch the game: no memory writes,
// no hooks, no gameplay effects. They exist to prove the module system and
// the ClickGUI wiring. To add a real effect you would override on_tick(),
// but this project intentionally ships none.
//
// Settings follow the Solstice model: a module declares them once (addSetting)
// and the ClickGUI renders them generically, so a module never writes UI code.
//
// NOTE: ASCII only in this file.

#pragma once

#include <memory>
#include <utility>
#include <vector>

#include "modules/setting.h"

namespace modules {

class Module {
public:
    Module(const char* category, const char* name, const char* description)
        : m_category(category), m_name(name), m_description(description), m_enabled(false) {}
    virtual ~Module() = default;

    // --- metadata ---
    const char* category()    const { return m_category; }
    const char* name()        const { return m_name; }
    const char* description() const { return m_description; }

    // --- state ---
    bool enabled() const { return m_enabled; }
    void set_enabled(bool v) { m_enabled = v; }
    void toggle() { m_enabled = !m_enabled; }

    // --- settings -------------------------------------------------------
    // Declare a setting owned by this module. Returns the raw pointer so the
    // module can keep a typed handle, e.g.
    //     m_range = addSetting<NumberSetting>("Range", "desc", 3.f, 1.f, 6.f, .1f);
    template <typename T, typename... Args>
    T* addSetting(Args&&... args) {
        auto owned = std::make_unique<T>(std::forward<Args>(args)...);
        T*   raw   = owned.get();
        mSettings.push_back(std::move(owned));
        return raw;
    }

    const std::vector<std::unique_ptr<Setting>>& settings() const { return mSettings; }

    // Erase a setting by name (used by modules with dynamic setting lists,
    // e.g. Text Hotkey's macro entries). Returns true when something was
    // removed. Protected settings (mIsVisible == false) are included.
    bool remove_setting(const std::string& name) {
        for (auto it = mSettings.begin(); it != mSettings.end(); ++it) {
            if ((*it)->mName == name) {
                mSettings.erase(it);
                return true;
            }
        }
        return false;
    }

    Setting* find_setting(const std::string& name) {
        for (auto& s : mSettings)
            if (s->mName == name) return s.get();
        return nullptr;
    }

    // --- keybind (virtual-key code, 0 = unbound) ------------------------
    int  key() const      { return mKey; }
    void setKey(int vk)   { mKey = vk; }

    // --- ClickGUI animation state ---------------------------------------
    // Owned by the GUI but stored on the module so the animation survives
    // across frames, exactly like Solstice's Module::mAnim / cScale.
    float cAnim        = 0.0f; // settings panel expand, 0..1
    float cScale       = 0.0f; // enable highlight, 0..1
    bool  showSettings = false;

    // --- lifecycle hooks ---
    virtual void on_enable()  {}   // called once when the module becomes enabled
    virtual void on_disable() {}   // called once when the module becomes disabled
    virtual void on_tick()    {}   // called every frame while enabled (demo: no-op)
    virtual void on_render()  {}   // called every frame while enabled (demo: no-op)

    // Keybind dispatch: return true to consume the bind press (no toggle).
    // Modules whose keybind TRIGGERS an action rather than switching them on
    // (e.g. Text Hotkey) override this; everything else keeps the default
    // enable/disable toggle.
    virtual bool on_key_trigger() { return false; }

    // Optional extra widgets below the declared settings. Most modules do not
    // need this - declare settings instead.
    virtual void render_settings() {}

protected:
    const char* m_category;
    const char* m_name;
    const char* m_description;
    bool        m_enabled;

    std::vector<std::unique_ptr<Setting>> mSettings;
    int                                   mKey = 0;

private:
    Module(const Module&) = delete;
    Module& operator=(const Module&) = delete;
};

} // namespace modules
