// interface_module.cpp - the Interface module (Solstice's Interface.hpp).
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/visual/interface_module.h"

#include <string>
#include <vector>

namespace modules {

InterfaceModule* InterfaceModule::s_instance = nullptr;

InterfaceModule::InterfaceModule()
    : Module("Settings", "Themes", "Tune Nightfull's accent and visual theme")
{
    s_instance = this;

    m_namingStyle = addSetting<EnumSetting>("Naming", "How module names are displayed.",
                                            NAMING_NORMAL_SPACED,
                                            std::vector<std::string>{
                                                "lowercase", "lower spaced", "Normal", "Spaced" });
    m_theme = addSetting<EnumSetting>("Theme", "Nightfull accent preset.", THEME_DEFAULT,
                                      std::vector<std::string>{
                                          "Default", "Purple", "Blue", "Cyan", "Red", "Green",
                                          "Orange", "Monochrome", "Custom" });
    m_colors = addSetting<NumberSetting>("Color Slots", "How many custom accent colors are used.",
                                         3.0f, 1.0f, 6.0f, 1.0f);

    m_color1 = addSetting<ColorSetting>("Color 1", "First custom accent color.",  0xFF8E5CFF);
    m_color2 = addSetting<ColorSetting>("Color 2", "Second custom accent color.", 0xFF4E7BFF);
    m_color3 = addSetting<ColorSetting>("Color 3", "Third custom accent color.",  0xFF36D0DC);
    m_color4 = addSetting<ColorSetting>("Color 4", "Fourth custom accent color.", 0xFF4ACD8F);
    m_color5 = addSetting<ColorSetting>("Color 5", "Fifth custom accent color.",  0xFFFF9746);
    m_color6 = addSetting<ColorSetting>("Color 6", "Sixth custom accent color.",  0xFFFF5D78);

    m_colorSpeed = addSetting<NumberSetting>("Accent Motion", "Speed of the accent gradient.",
                                             3.0f, 0.25f, 20.0f, 0.05f);
    m_saturation = addSetting<NumberSetting>("Saturation", "Saturation for custom colors.",
                                             1.0f, 0.0f, 1.0f, 0.01f);

    // Custom palette controls follow the selected preset. The GUI can still
    // show the colour cards while the user is choosing "Custom" because the
    // popup itself is not an ImGui-owned child window.
    const auto customSelected = [this]() { return m_theme->mValue == THEME_CUSTOM; };
    const auto needs = [this](int n) {
        return [this, n]() {
            return m_theme->mValue == THEME_CUSTOM && m_colors->mValue >= (float)n;
        };
    };

    m_colors->mIsVisible     = customSelected;
    m_color1->mIsVisible     = needs(1);
    m_color2->mIsVisible     = needs(2);
    m_color3->mIsVisible     = needs(3);
    m_color4->mIsVisible     = needs(4);
    m_color5->mIsVisible     = needs(5);
    m_color6->mIsVisible     = needs(6);
    m_saturation->mIsVisible = [this]() { return m_theme->mValue == THEME_CUSTOM; };
}

} // namespace modules
