// module_registry.cpp - registers the Nightfull module roster.
//
// Registration order is display order inside each category. The module list is
// local client-side UI/QoL state only; no module below touches game memory or
// installs a gameplay hook.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/module_manager.h"
#include "modules/misc/friends_module.h"
#include "modules/misc/misc_modules.h"
#include "modules/movement/movement_modules.h"
#include "modules/nightfull_modules.h"
#include "modules/player/player_modules.h"
#include "modules/settings/flarial_settings_module.h"
#include "modules/visual/clickgui_module.h"
#include "modules/visual/flarial_visual_modules.h"
#include "modules/visual/interface_module.h"
#include "modules/visual/visual_modules.h"

namespace modules {

void RegisterAllModules() {
    ModuleManager& mgr = ModuleManager::instance();

    std::vector<std::unique_ptr<Module>> roster = CreateNightfullModules();

    // Flarial-style modules are separate units so each can be enabled and
    // configured independently. Only self-contained overlay modules start on.
    roster.push_back(std::make_unique<Watermark>());
    roster.push_back(std::make_unique<Arraylist>());
    roster.push_back(std::make_unique<FlarialFPS>());
    roster.push_back(std::make_unique<FlarialCPS>());
    roster.push_back(std::make_unique<FlarialMouseStrokes>());
    roster.push_back(std::make_unique<CPSLimiter>());
    roster.push_back(std::make_unique<FullBright>());
    roster.push_back(std::make_unique<GuiScale>());
    roster.push_back(std::make_unique<VsyncDisabler>());
    roster.push_back(std::make_unique<Sprint>());
    roster.push_back(std::make_unique<NullMovement>());
    roster.push_back(std::make_unique<Freelook>());

    // The Friends manager and the Mid Click action (Solstice-based) - the
    // manager ships enabled (it must stay reachable); Mid Click starts OFF
    // so the middle button stays untouched until the user asks for it.
    roster.push_back(std::make_unique<FriendsModule>());
    roster.push_back(std::make_unique<MidClickModule>());

    // Flarial ports: hotbar slot animations and the attack reach readout.
    roster.push_back(std::make_unique<Animations>());
    roster.push_back(std::make_unique<ReachDisplay>());

    // Flarial's Text Hotkey: a keybind that types configured text into chat.
    roster.push_back(std::make_unique<TextHotkey>());

    // Flarial's Java Hotkeys: Java-style inventory slot swapping.
    roster.push_back(std::make_unique<JavaHotkeys>());

    // Flarial's No Hurt Cam: disables the camera tilt on damage.
    roster.push_back(std::make_unique<NoHurtCam>());

    // Pulse-style plates: active potions and active keybinds.
    roster.push_back(std::make_unique<PotionsHud>());
    roster.push_back(std::make_unique<KeybindsHud>());

    // Pulse-style monitoring plate: FPS / BPS / TPS / IP / CPS / time.
    roster.push_back(std::make_unique<MonitoringHud>());

    // SystemDLC-style Target HUD: last attacked entity with health.
    roster.push_back(std::make_unique<TargetHud>());

    // Entity hitbox ESP: perimeter outline or fully filled boxes.
    roster.push_back(std::make_unique<Hitboxes>());

    // SystemDLC-style crit particle burst at the crosshair on every hit.
    roster.push_back(std::make_unique<CritParticles>());

    // Flarial's client-side preferences live in their own Settings category.
    roster.push_back(std::make_unique<FlarialSettingsModule>());

    for (auto& module : roster)
        mgr.add(std::move(module));

    // Typed settings used by the ClickGUI itself. They live in the Settings
    // category so users can tune the menu without a hidden control surface.
    mgr.add(std::make_unique<ClickGuiModule>());
    mgr.add(std::make_unique<InterfaceModule>());
}

} // namespace modules
