// citron_gui.h - the Nightfull menu (SystemDLC-style ClickGUI port).
//
// Visual port of https://github.com/CollapseLoader/SystemDLC's ClickGuiScreen:
// 1188x700 pt design window (radius 12), collapsible 224/48 pt surface
// sidebar with category tabs and section labels, a 48 pt top bar with the
// page title and icon actions, and a 3-column masonry content grid of module
// cards (301 pt wide, radius 14) that expand in place to reveal their
// settings. Neutral dark palette (#0A0A0A background, #171717 surfaces,
// #404040 borders, #A1A1A1 muted text) with the client's cycling theme
// accent as the interactive color. Search modal, in-card dropdowns, friends
// page and config page follow the same design language.
//
// Unlike the reference app this renders inside the game as an overlay window:
// the design is clamped to fit the game screen and every pt metric scales by
// the same factor, so the layout keeps its proportions at any resolution.
//
// Run-on-the-render-thread rules (same as the other GUIs): no I/O per frame,
// no unbounded loops, bounded work per frame. All drawing goes through
// gui::* helpers and ImGui draw lists.
//
// NOTE: ASCII only in this file.

#pragma once

#include "imgui.h"

#include <array>
#include <string>
#include <vector>

namespace ui {

class CitronGui {
public:
    // animation: menu fade alpha; inScale: open/close zoom (0..1);
    // isEnabled: menu fully open (drives interaction).
    void render(float animation, float inScale, bool isEnabled);

private:
    struct Particle {
        float x;
        float y;
        float vx;
        float vy;
        float size;
        float phase;
    };

    bool m_built = false;
    int  m_tab   = 0;
    bool m_particlesReady = false;
    std::array<Particle, 30> m_particles{};

    // Per-module enable animation (0..1), registry-indexed.
    std::vector<float> m_modAnim;
    std::vector<float> m_modHover;
    // "Just opened" ring flash per module (decays to 0).
    std::vector<float> m_ringAnim;

    // Sidebar collapse (224 <-> 48 pt) driven from the top bar.
    bool  m_sideOpen = true;
    float m_sideAnim = 1.0f;

    // Top-bar title slide animation on page change (0..1) + direction.
    float m_titleT   = 1.0f;
    int   m_titleDir = 1;
    // Content slide-in on page change (1 = settled).
    float m_pageSlideT = 1.0f;

    // Bind capture state.
    void* m_bindMod     = nullptr;   // modules::Module*
    void* m_bindSetting = nullptr;   // modules::Setting*

    // Colour picker popup state.
    void* m_openColor    = nullptr;  // modules::ColorSetting*
    ImVec2 m_openColorPos = ImVec2(0, 0);

    // Open enum dropdown (drawn above the scrolled content).
    void*  m_ddSetting = nullptr;    // modules::EnumSetting*
    ImVec2 m_ddPos     = ImVec2(0, 0);  // panel top-left, design pt
    float  m_ddW       = 0.0f;
    int    m_ddFrame   = -1;         // frame it opened

    // Search modal (448x304, centred).
    bool m_searchOpen = false;
    int  m_searchFrame = -1;
    char m_searchBuf[64] = { 0 };
    int  m_searchSel    = -1;        // keyboard selection, -1 = none
    float m_searchScroll   = 0.0f;
    float m_searchScrollTo = 0.0f;
    std::vector<int>  m_searchIdx;   // registry module indices
    std::vector<char> m_searchKind;  // 0 = module hit, 1 = setting hit
    std::vector<std::string> m_searchText; // setting display name (kind 1)

    // Window drag offset (runtime only, not persisted).
    ImVec2 m_winOffset = ImVec2(0, 0);

    // --- Friends tab state -------------------------------------------------
    // Mid Click row.
    float m_midClickAnim  = 0.0f;   // toggle glide, 0..1

    // Friends list scrolling (design pt, smoothed towards m_friendScrollTo).
    float m_friendScroll   = 0.0f;
    float m_friendScrollTo = 0.0f;

    // Per-page content scrolling. Values are in design points so the same
    // wheel distance behaves consistently at every resolution.
    float m_pageScroll[10] = { 0.0f };
    float m_pageScrollTo[10] = { 0.0f };
    float m_pageContentHeight[10] = { 0.0f };

    // Friends form (inline card on the Friends page).
    bool  m_addFriendOpen  = false; // input focused
    int   m_addFriendFrame = -1;    // frame it gained focus
    bool  m_friendDup      = false; // "already in the list" hint
    char  m_friendBuf[64]  = { 0 }; // text field contents

    void OpenAddFriend();
    void CloseAddFriend();
    void CommitAddFriend();
    void InitParticles();
    void DrawParticles(const ImVec2& screen, const ImColor& accent,
                       float animation, float dt);
};

} // namespace ui
