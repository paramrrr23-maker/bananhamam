// clickgui.h - the ClickGUI menu (Solstice's ClickGui module).
//
// Owns the menu frame: the tab bar, the open/close easing, the background
// scrim, and the module list itself (ui/modern_gui.h).
//
// Only draws ImGui widgets and reads overlay/module state - it never touches
// the game. Module lifecycle (on_enable/on_disable) is triggered here when the
// user flips a toggle or presses a keybind, and on_tick/on_render are called
// for enabled modules once per frame.
//
// NOTE: ASCII only in this file.

#pragma once

namespace ui {

// Apply the Solstice-like theme and build the font atlas. Safe to call
// multiple times; must be called after ImGui::CreateContext() and before the
// first frame.
void ApplyStyle();

// Registers all modules (thin wrapper over modules::RegisterAllModules).
void RegisterModules();

// One ImGui menu frame. Must be called between ImGui::NewFrame() and
// ImGui::Render() (i.e. from the overlay render path).
void Render();

// Write the current state (modules + panel layout) to disk right now.
// Called on shutdown so nothing is lost when the game closes.
void SaveState();

} // namespace ui
