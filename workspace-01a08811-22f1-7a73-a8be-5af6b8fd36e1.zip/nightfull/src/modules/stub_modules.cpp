// stub_modules.cpp - menu-driven placeholder modules (no in-game effect yet).
//
// Identity strings (names, categories, descriptions) and default on/off
// states mirror the web prototype exactly. See stub_modules.h for the
// replacement contract.

#include "modules/stub_modules.h"

namespace nf {

HudModule::HudModule()
    : Module("Интерфейс", "HUD", "Всё важное — всегда перед глазами.") {
    setEnabled(true);
}

SkyboxModule::SkyboxModule()
    : Module("Визуал", "Skybox", "Новая атмосфера привычного мира.") {
}

TargetHudModule::TargetHudModule()
    : Module("Визуал", "Target HUD", "Компактная карточка выбранной цели.") {
}

ZoomModule::ZoomModule()
    : Module("Утилиты", "Zoom", "Рассмотри свой мир в деталях.") {
}

HotbarModule::HotbarModule()
    : Module("Интерфейс", "Hotbar", "Плавные анимации панели предметов.") {
    setEnabled(true);
}

TimeChangerModule::TimeChangerModule()
    : Module("Визуал", "Time Changer", "Любимое время суток в предпросмотре.") {
}

} // namespace nf
