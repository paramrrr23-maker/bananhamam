// clickgui.cpp - the ClickGUI menu (port of Solstice's ClickGui module).
//
// Solstice's menu is itself a module: it eases itself in with an EasingUtil,
// draws a tab bar across the top, and renders the module list. That is the
// shape here too, with the CitronGui renderer as the one and only style.
//
//   * animation  - EasingUtil percentage pushed by delta time, then shaped
//                  (easeOutExpo for the fade, easeOutElastic/easeOutBack for
//                  the zoom). This is what makes the menu feel like Solstice.
//   * tab bar    - ClickGui / HudEditor / Scripting, with the animated
//                  underline Solstice draws. HudEditor and Scripting show
//                  Solstice's own "Not implemented yet!" screen.
//   * scrim      - Solstice runs a D2D shader blur behind the menu; that needs
//                  a D2D device and a second render target inside the game
//                  process, so a flat translucent scrim is used and the
//                  ClickGui module's Blur Strength drives its intensity.
//   * keybinds   - modules and bool settings fire from the overlay's own key
//                  poll (ImGui never sees a key event inside the UWP sandbox).
//   * config     - every change is hashed; the state is written to disk ~1.5 s
//                  after the last change (Solstice's ConfigManager).
//
// Nothing here reads or writes the game.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "ui/clickgui.h"

#include "ui/citron_gui.h"

#include "modules/misc/friends_module.h"
#include "modules/module.h"
#include "modules/module_guard.h"
#include "modules/module_manager.h"
#include "modules/module_registry.h"
#include "modules/setting.h"
#include "modules/visual/clickgui_module.h"
#include "modules/visual/interface_module.h"
#include "utils/config.h"
#include "utils/easing.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"
#include "utils/logger.h"
#include "overlay.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>

namespace ui {

using modules::BoolSetting;
using modules::ClickGuiModule;
using modules::ColorSetting;
using modules::EnumSetting;
using modules::InterfaceModule;
using modules::Module;
using modules::ModulePhaseGuard;
using modules::NumberSetting;
using modules::Setting;
using modules::SettingType;

// File-local state. This MUST be an ANONYMOUS namespace: everything below
// (g_citronGui, g_inEase, StateHash, ...) is private to this file and
// is referenced by the public functions that follow the closing brace. Making
// it a named namespace (ui::ui) hides all of them from those functions and
// produces ~40 bogus "undeclared identifier" errors.
namespace {
CitronGui    g_citronGui;
gui::EasingUtil g_inEase;
bool        g_stateLoaded = false; // persisted state restored on the first frame

// --- config autosave -----------------------------------------------------
unsigned int g_stateHash     = 0;
unsigned int g_lastHash      = 0;
bool         g_savePending   = false;
unsigned long long g_changedAt = 0;

void HashCombine(unsigned int& h, unsigned int v) {
    h ^= v;
    h *= 16777619u;
}

void HashFloat(unsigned int& h, float f) {
    if (f == 0.0f) f = 0.0f;   // normalise -0.0
    unsigned int bits = 0;
    std::memcpy(&bits, &f, sizeof(bits));
    HashCombine(h, bits);
}

// Cheap digest of everything the config persists. Runs every frame, so it
// stays allocation-free and touches nothing but POD.
unsigned int StateHash() {
    unsigned int h = 2166136261u;

    for (const auto& m : modules::Modules().modules()) {
        for (const char* p = m->name(); *p; p++)     HashCombine(h, (unsigned char)*p);
        HashCombine(h, 0x9e3779b9u);
        for (const char* p = m->category(); *p; p++) HashCombine(h, (unsigned char)*p);
        HashCombine(h, m->enabled() ? 1u : 0u);
        HashCombine(h, (unsigned int)m->key());

        for (const auto& s : m->settings()) {
            HashCombine(h, (unsigned int)s->mType);
            HashCombine(h, (unsigned int)s->mKey);
            switch (s->mType) {
                case SettingType::Bool:
                    HashCombine(h, static_cast<BoolSetting*>(s.get())->mValue ? 1u : 0u);
                    break;
                case SettingType::Number:
                    HashFloat(h, static_cast<NumberSetting*>(s.get())->mValue);
                    break;
                case SettingType::Enum:
                    HashCombine(h, (unsigned int)static_cast<EnumSetting*>(s.get())->mValue);
                    break;
                case SettingType::Color:
                    for (int i = 0; i < 4; i++)
                        HashFloat(h, static_cast<ColorSetting*>(s.get())->mValue[i]);
                    break;
                default:
                    break;
            }
        }
    }

    // The friends list is not a Setting, so it has to be hashed explicitly -
    // otherwise adding or removing a friend never changes the digest and the
    // debounced autosave below would never write it to disk.
    if (modules::FriendsModule* fm = modules::FriendsModule::instance()) {
        for (const std::string& n : fm->friends()) {
            for (const char* p = n.c_str(); *p; p++)
                HashCombine(h, (unsigned char)*p);
            HashCombine(h, 0x85ebca6bu);   // separator: "ab" != "a","b"
        }
    }
    return h;
}

// --- the ClickGui module's own settings ----------------------------------
float CgNumber(NumberSetting* s, float fallback) {
    return s ? s->mValue : fallback;
}

int CgEnum(EnumSetting* s, int fallback) {
    return s ? s->mValue : fallback;
}

struct CgSettings {
    int   animation = ClickGuiModule::ANIM_GLASS;
    float blur      = 7.0f;
    float easeSpeed = 18.0f;
    float midclick  = 1.0f;
    float opacity   = 0.94f;
    float border    = 0.42f;
    float radius    = 18.0f;
    bool  glass        = true;   // frosted glass material
    float transparency = 0.55f;  // glass see-through amount
};

CgSettings CurrentCgSettings() {
    CgSettings out;
    ClickGuiModule* cg = ClickGuiModule::instance();
    if (cg) {
        out.animation = CgEnum(cg->m_animation, ClickGuiModule::ANIM_GLASS);
        out.blur      = CgNumber(cg->m_blurStrength, 7.0f);
        out.easeSpeed = CgNumber(cg->m_easeSpeed, 18.0f);
        out.midclick  = CgNumber(cg->m_midclickRounding, 1.0f);
        out.opacity   = CgNumber(cg->m_panelOpacity, 0.94f);
        out.border    = CgNumber(cg->m_borderOpacity, 0.42f);
        out.radius    = CgNumber(cg->m_cornerRadius, 18.0f);
        out.glass        = cg->m_glass ? cg->m_glass->mValue : true;
        out.transparency = cg->m_transparency ? cg->m_transparency->mValue : 0.55f;
    }
    // A hand-edited config must not be able to wedge the animation or divide
    // by zero in the slider snapping.
    out.blur      = gui::Clamp(out.blur, 0.0f, 20.0f);
    out.easeSpeed = gui::Clamp(out.easeSpeed, 5.0f, 20.0f);
    if (out.midclick < 0.01f) out.midclick = 0.01f;
    out.opacity = gui::Clamp(out.opacity, 0.65f, 1.0f);
    out.border  = gui::Clamp(out.border, 0.1f, 1.0f);
    out.radius  = gui::Clamp(out.radius, 6.0f, 28.0f);
    if (out.animation < 0 || out.animation > ClickGuiModule::ANIM_BOUNCE)
        out.animation = ClickGuiModule::ANIM_ZOOM;
    return out;
}

// --- the Interface module drives the theme -------------------------------
void ApplyInterfaceSettings() {
    InterfaceModule* im = InterfaceModule::instance();
    if (!im) return;

    gui::SetTheme(im->m_theme->mValue);
    gui::SetNamingStyle(im->m_namingStyle->mValue);
    gui::SetCustomColorCount((int)im->m_colors->mValue);

    ColorSetting* slots[] = { im->m_color1, im->m_color2, im->m_color3,
                              im->m_color4, im->m_color5, im->m_color6 };
    for (int i = 0; i < 6; i++)
        gui::SetCustomColor(i, slots[i]->getAsImColor());

    gui::SetColorSpeed(im->m_colorSpeed->mValue);
    gui::SetSaturation(im->m_saturation->mValue);
}

// --- keybinds ------------------------------------------------------------
// Solstice cancels every key event while the menu is open, so keybinds only
// fire while it is closed.
void DispatchKeybinds() {
    // Module keybinds are an in-game concept: they fire only inside a
    // world/server (hud_screen). Minecraft's menus and text-input screens
    // (chat, sign, ...) own the keyboard - keybinds stay off there.
    if (!overlay::IsInWorld()) return;

    for (const auto& m : modules::Modules().modules()) {
        const int key = m->key();
        if (key > 0 && keys::PressedThisFrame(key)) {
            // Trigger-style modules (Text Hotkey) consume the press instead
            // of toggling; everything else keeps the enable/disable toggle.
            if (m->on_key_trigger()) {
                LOG_INFO("keybind: %s triggered", m->name());
                continue;
            }
            m->toggle();
            LOG_INFO("keybind: %s -> %s", m->name(), m->enabled() ? "ON" : "OFF");
            ModulePhaseGuard::run(m.get(), m->enabled() ? ModulePhaseGuard::ENABLE
                                                        : ModulePhaseGuard::DISABLE);
        }

        // Bool settings can be bound too (middle click one in the menu).
        for (const auto& s : m->settings()) {
            if (s->mType != SettingType::Bool) continue;
            if (s->mKey > 0 && keys::PressedThisFrame(s->mKey)) {
                BoolSetting* bs = static_cast<BoolSetting*>(s.get());
                bs->mValue = !bs->mValue;
                LOG_INFO("keybind: setting %s -> %s", s->mName.c_str(),
                         bs->mValue ? "ON" : "OFF");
            }
        }
    }
}

// --- tabs ----------------------------------------------------------------
// (The Solstice-style floating tab bar and its "Not implemented yet!" screen
// were removed: the Citron GUI carries its own tab bar and the only two
// renderers left both work.)

} // namespace

// ======================== public API ========================
void ApplyStyle() {
    gui::LoadFonts();

    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding   = 8.0f;
    s.FrameRounding    = 5.0f;
    s.GrabRounding     = 5.0f;
    s.WindowPadding    = ImVec2(8, 8);
    s.ItemSpacing      = ImVec2(8, 6);
    s.WindowBorderSize = 1.0f;
}

void RegisterModules() {
    modules::RegisterAllModules();
}

void SaveState() {
    config::Save();
    LOG_INFO("config: state written to %s", config::Path().c_str());
}

void Render() {
    // --- menu open/close transition ---------------------------------------
    // The key state comes from a DIFFERENT source depending on whether the
    // menu is open (the watcher's WH_KEYBOARD_LL mirror / the Keyboard::feed
    // hook) or closed (the in-process poll). Crossing that boundary must drop
    // all history, or every key that happened to be held at the moment of the
    // switch is reported as a brand-new press on the next frame - which typed
    // phantom characters into the search box (filtering every module out, so
    // only the empty category headers were left) and fired stray keybinds.
    static bool s_wasMenuOpen = false;
    if (overlay::g_ShowMenu != s_wasMenuOpen) {
        s_wasMenuOpen = overlay::g_ShowMenu;
        overlay::ResetKeyMirrors();
        keys::Reset();
    }

    // One key snapshot per frame - see utils/keys.h.
    keys::BeginFrame();

    // Restore the persisted state ONCE, on the first rendered frame. This runs
    // on the game's render thread, so it must not be repeated: a per-frame
    // config::Load() re-reads and re-parses the JSON file ~60x/s (a real stall
    // risk here) and, worse, it continuously reverts whatever the user just
    // changed before the debounced autosave ever gets a chance to record it -
    // toggles appeared to "undo themselves".
    // "Restored after DLL reinjection" is still satisfied: a re-injected DLL
    // starts with fresh globals, so its first frame loads the file again.
    if (!g_stateLoaded) {
        g_stateLoaded = true;
        config::Load();
        LOG_INFO("menu: state loaded");
    }

    ApplyInterfaceSettings();

    // Solstice cancels every key event while the menu is open, so keybinds
    // only fire once it is closed.
    if (!overlay::g_ShowMenu)
        DispatchKeybinds();

    // Enabled modules get their per-frame callbacks. Their implementations in
    // this project only draw into our overlay (watermark, arraylist) - they
    // never touch the game.
    for (const auto& m : modules::Modules().modules()) {
        if (!m->enabled()) continue;
        ModulePhaseGuard::run(m.get(), ModulePhaseGuard::TICK);
        // on_tick may have disabled the module (fault or time overrun).
        if (m->enabled())
            ModulePhaseGuard::run(m.get(), ModulePhaseGuard::RENDER);
    }

    const CgSettings cg  = CurrentCgSettings();
    const float      dt  = gui::GetDeltaTime();

    // --- open/close easing (Solstice's ClickGui::onRenderEvent) ----------
    if (overlay::g_ShowMenu) g_inEase.incrementPercentage(dt * cg.easeSpeed / 10.0f);
    else                     g_inEase.decrementPercentage(dt * 2.0f * cg.easeSpeed / 10.0f);

    float inScale = 0.0f;
    {
        // Solstice takes the easing by value, so shaping it here cannot
        // disturb the percentage it is still advancing.
        gui::EasingUtil ease = g_inEase;
        if (cg.animation == ClickGuiModule::ANIM_GLASS) {
            // Glass: a calm fade with a subtle settle-zoom (easeOutCubic).
            // The window never collapses - the alpha fade carries the close.
            inScale = 0.960f + 0.036f * (float)ease.easeOutCubic();
        } else if (cg.animation == ClickGuiModule::ANIM_ZOOM) {
            inScale = (float)ease.easeOutExpo();
        } else {
            inScale = overlay::g_ShowMenu ? (float)ease.easeOutElastic()
                                          : (float)ease.easeOutBack();
        }
    }
    if (g_inEase.isPercentageMax()) inScale = 0.996f;
    if (cg.animation == ClickGuiModule::ANIM_ZOOM)
        inScale = gui::Clamp(inScale, 0.0f, 0.996f);

    const float animation = gui::Lerp(0.0f, 1.0f, (float)g_inEase.easeOutExpo());

    // --- autosave --------------------------------------------------------
    g_stateHash = StateHash();
    if (g_stateHash != g_lastHash) {
        if (g_lastHash != 0) {
            g_savePending = true;
            g_changedAt   = (unsigned long long)GetTickCount64();
        }
        g_lastHash = g_stateHash;
    } else if (g_savePending &&
               (unsigned long long)GetTickCount64() - g_changedAt > 1500) {
        g_savePending = false;
        config::Save();
    }

    if (animation < 0.0001f)
        return;   // fully closed - nothing to draw

    const ImVec2 screen = gui::GetScreenSize();

    // Citron uses a flat dark backdrop. Its window has no bottom spotlight;
    // keeping only the full-screen scrim prevents the old Solstice glow from
    // showing as a colored strip under the menu. In the glass mode the scrim
    // is much lighter on purpose: the game shows through the frosted panels
    // (that is the whole glassmorphism point - refero tokens).
    const float scrim = cg.glass
        ? std::fminf(1.0f, 0.16f + cg.blur * 0.010f)
        : std::fminf(1.0f, 0.38f + cg.blur * 0.012f);
    ImGui::GetBackgroundDrawList()->AddRectFilled(
        ImVec2(0.0f, 0.0f), screen,
        IM_COL32(0, 0, 0, (int)(255.0f * animation * scrim)));

    // --- content ---------------------------------------------------------
    g_citronGui.render(animation, inScale, overlay::g_ShowMenu);
}

} // namespace ui
