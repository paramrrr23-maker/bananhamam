# Bedrock 1.21.111 — Исследование Rendering Pipeline. Часть 1: PRIORITY 1

Целевая версия: **Minecraft Bedrock 1.21.111 (Windows)**.
Легенда пометок (по ТЗ): **[CONFIRMED]** — факт из исходников, **[INFERENCE]** — вывод, **[PROPOSAL]** — предложение для нашего клиента.

---

## 0. Статус источников

| Источник | Статус | Что реально внутри |
|---|---|---|
| `Borion-Updated/Releases` | [CONFIRMED] только бинарники | `README.md` + `data.txt` со ссылками на `.dll`. Исходников нет |
| `Borion-Updated/Borion-OSS` | [CONFIRMED] **полные исходники** | Форк Horion (C++, MinHook, DirectX). Найден через страницу организации |
| `OderSoClient/Versions` | [CONFIRMED] только метаданные | `versions.json` — список поддерживаемых версий (1.21.111 есть: `"1.21.111"`). Исходников нет |
| `OderSoClient/*` (org) | [CONFIRMED] **исходников нет** | Всего 4 репозитория: `.github`, `client-data` (только `.dll` 1.20–1.26 + лаунчер), `Versions`, `VulkanMaterials` (только README). Клиент закрытый |
| `oAnshull/FlarialClient` | [CONFIRMED] **полные исходники** | C++, D2D + ImGui оверлей, DX11/DX12 хуки, собственный Tessellator-рендер |
| `AzOxStOz/Solstice-Source` | [CONFIRMED] **полные исходники** | C++, ImGui + Kiero, MinHook/libhat, ECS-компоненты актёров |

Локальные копии: `/home/user/research/` (shallow clone, `--depth 1`).

**Вывод для ТЗ:** техническими источниками де-факто являются **Borion-OSS, Flarial, Solstice**. OderSo изучить по коду невозможно (closed source) — его `versions.json` полезен лишь как подтверждение, что 1.21.111 — реально поддерживаемая клиентами версия.

---

## 1. Главная находка: три параллельных render path

Во всех трёх клиентах rendering идёт не одним способом, а **тремя независимыми путями**, каждый со своей точкой хука:

```
Path A — WORLD 3D (внутри мира, через Tessellator игры)
  LevelRenderer::renderLevel  →  Tessellator::begin/vertex  →  MeshHelpers::renderMeshImmediately  →  GPU
  └─ hitbox 3D, линии в мире, боксы блоков. Глубина/камера — от самой игры.

Path B — UI 2D (через MinecraftUIRenderContext игры)
  ScreenView::setupAndRender  →  MUIRenderContext::drawText/drawImage/drawQuad...  →  GPU
  └─ текст, прямоугольники, картинки, nametags. Работает в координатах UI.

Path C — OVERLAY (поверх всего, свой DX код)
  IDXGISwapChain::Present  →  D2D / ImGui DrawList  →  GPU
  └─ ESP-боксы (через W2S), HUD, ClickGUI, блюр. Не зависит от рендера игры.
```

Каждый путь разобран ниже с доказательствами.

---

## 2. Path A — World 3D через Tessellator [CONFIRMED]

### 2.1. Точка хука

| Клиент | Хук | Когда вызывается | Файл |
|---|---|---|---|
| Flarial | `LevelRenderer::renderLevel` (по сигнатуре) | До оригинального рендера уровня; модули получают событие `Render3DEvent(level, scn)` | `src/Client/Hook/Hooks/Render/RenderLevelHook.cpp` |
| Borion | `LevelRenderer::renderLevel` (по сигнатуре) | **После** оригинала: `ret = oFunc(...); setGameRenderContext(a2); onLevelRender();` | `Memory/Hooks.cpp:1205` |

Сигнатуры хуков — по паттернам байт (`FindSignature` / `GET_SIG_ADDRESS`), т.е. переживают мелкие обновления лучше, чем хардкод-оффсеты. [INFERENCE]

### 2.2. Цепочка рисования (Flarial `MCDrawUtil3D`)

Файл: `src/Utils/Render/DrawUtil3D.cpp`. Конструктор принимает `(LevelRender*, ScreenContext*, MaterialPtr*)`.

```
drawLine(p1, p2, color):
  scn->getTessellator()
  *scn->getColorHolder() = white
  tess->begin(LineStrip / LineList, 1)
  tess->color(r, g, b, a)
  p1 -= levelRenderer->getOrigin()   // world → render-local
  p2 -= levelRenderer->getOrigin()
  tess->vertex(...) x2
  [flush] → MeshHelpers::renderMeshImmediately(scn, tess, material)
```

Варианты примитивов: `drawLine`, `drawLineList`, `drawQuad` (4× LineStrip), `fillQuad` (QuadList, рисует обе стороны), `drawBox(AABB)` (4 вертикальных ребра + нижняя/верхняя грани), `TexturedQuad` (`vertexUV` + `renderMeshImmediately2` с текстурой).

### 2.3. Цепочка рисования (Borion `DrawUtils`, 3D-часть)

Файл: `Horion/DrawUtils.cpp`.

- `setGameRenderContext(a2)` — сохраняет `game3dContext` (= `a2` из `renderLevel`, т.е. ScreenContext) и обновляет `origin = levelRenderer->origin` + `lerpT`.
- `get3dTessellator()` = `*(game3dContext + 0xB0)`.
- `drawLine3d`: `tess__begin(myTess, 4, 2)` → `vertex` ×2 (со сдвигом на `-origin`) → `meshHelper_renderImm(game3dContext, tess, entityFlatStaticMaterial)`.
- `drawBox3d`: тот же путь, 12 рёбер бокса (24 вершины), формат `4` = line list.
- `drawLinestrip3d`: формат `5` = line strip. В комментариях к коду есть таблица форматов: `1: quads, 2: triangle list, 3: trianglestrip, 4: line list, 5: line strip`.
- Материал для 3D: `entityFlatStaticMaterial`, взятый из `itemInHandRenderer->entityLineMaterial` (т.е. переиспользуется игровой материал линий, глубина работает как у игры).

### 2.4. Материалы (Flarial `MaterialUtils`)

Файл: `src/Utils/Render/MaterialUtils.cpp`. Материалы создаются через `mce::RenderMaterialGroup::createUI(HashedString(name))`:

| Имя материала | Использование |
|---|---|
| `selection_box` | дефолт для `MCDrawUtil3D` (3D-боксы/линии) |
| `ui_fill_color` | заливки |
| `ui_textured` | текстурированные квады |
| `particles_alpha` | (в коде возвращает uiTextured — похоже на баг/заглушку) |
| `ui_crosshair` | прицел |
| `name_tag_depth_tested` | нametags с depth-test |

### 2.5. Важно для 1.21.111: сигнатура `renderMeshImmediately` менялась

Файл: `src/SDK/Client/Render/Tessellator/MeshHelpers.cpp`.

```cpp
if (VersionUtils::checkAboveOrEqual(21, 20))  // т.е. >= 1.21.20
    func(screenContext, tessellator, material, pad /* char[0x58] */);  // 4 аргумента
else
    func(screenContext, tessellator, material);                        // 3 аргумента
```

**1.21.111 > 1.21.20 → нужен 4-аргументный вариант.** [CONFIRMED факт ветвления; применимость к 1.21.111 — INFERENCE, но прямо следует из кода]

---

## 3. Path B — UI 2D через MinecraftUIRenderContext [CONFIRMED]

### 3.1. Точка хука: `ScreenView::setupAndRender`

**Flarial** (`SetupAndRenderHook.hpp`): хук по сигнатуре `ScreenView::setupAndRender`. В колбэке:
1. `SDK::screenView`, `SDK::clientInstance = muirc->getClientInstance()`, `SDK::scn = muirc->getScreenContext()`, `hasInstanced = true`.
2. Ленивый vtable-хук `MUIRenderContext`: `vtable[5]` = drawText, `vtable[7]` = drawImage, `vtable[8]` = drawNineSlice (сигнатуры drawImage различаются для версий: базовая / ≥1.21.20 / ≥1.21.50 — см. 3.3).
3. Читает имя слоя (`hud_screen`, `play_screen` и т.д.), триггерит `SetTopScreenNameEvent`.
4. Пушит `FrameTransform {viewMatrix, origin, fov}` в очередь для DX-потока (связь Path B → Path C).
5. Вызывает оригинал, затем триггерит `SetupAndRenderEvent(muirc)` для модулей (кроме `debug_screen`/`toast_screen`).

**Solstice** (`SetupAndRenderHook.cpp`): та же точка (`SigManager::ScreenView_setupAndRender`):
1. Пушит `{viewMatrix, cameraPos, playerPos, fov}` в `D3DHook::FrameTransforms`.
2. Лениво vtable-хукает `MinecraftUIRenderContext::drawImage` (`initVt`, индекс из `OffsetProvider::MinecraftUIRenderContext_drawImage`).

**Borion** (`Hooks.cpp`, три хука вместо одного):
- `UIScene_setupAndRender` / `UIScene_render` — выставляют флаг `shouldRender` только для `start_screen` / `hud_screen` (рендерят только на нужных экранах).
- `RenderText(a1, renderCtx)` — главная UI-точка:
  ```
  DrawUtils::setCtx(renderCtx, guiData)   // tessellator, colorHolder, refdef, fov, origin, материалы
  moduleMgr->onPreRender(renderCtx)       // ← модули (ESP!) рисуют здесь
  DrawUtils::flush()                      // renderCtx->flushText(0)
  retval = oText(a1, renderCtx)           // оригинал поверх
  ... HUD/ArrayList/TabGui/Watermark ...
  moduleMgr->onPostRender(renderCtx)
  DrawUtils::flush()
  ```

### 3.2. 2D-примитивы Borion (рисуются в `onPreRender`, до оригинального текста)

- `drawQuad/drawTriangle`: `tess__begin` → `tess_vertex` → `meshHelper_renderImm(screenContext2d, tess, uiMaterial)`. Линии рисуются как тонкие треугольники (6 вершин, формат 3).
- `drawText`: напрямую `renderCtx->drawText(font, rect, text, color, alpha, ...)` — игровой шрифт, `getFont()` возвращает `minecraftGame->getOldFont()`.
- `fillRectangle(pos, col, alpha)` = `setColor` + `drawQuad`; `drawRectangle` = 4 заливки.
- `drawImage(filePath, ...)` — есть декларация (реализацию смотреть в Части 2).
- `flush()` = `renderCtx->flushText(0)`.

### 3.3. Версионные различия drawImage (важно для 1.21.111)

Flarial держит **три** детура `vtable[7]` (файл `SetupAndRenderHook.hpp`):
- базовый: `(MUIRC, TexturePtr*, pos, dim, uv, uvSize)`
- ≥1.21.20: + `bool unk`
- ≥1.21.50: `(MUIRC, BedrockTextureData*, pos, dim, uv, uvSize, bool)` — `TexturePtr` заменён на `BedrockTextureData`

**Для 1.21.111 актуален вариант ≥1.21.50.** [INFERENCE из кода; сами детуры — CONFIRMED]

---

## 4. Path C — Overlay поверх Present (DX11/DX12) [CONFIRMED]

### 4.1. Графический API и точки хука

| Клиент | Способ хука Present | DX11 | DX12 |
|---|---|---|---|
| Solstice | **Kiero** (`kiero::init`, сначала D3D12, fallback D3D11) | Present idx **8**, ResizeBuffers idx **13** | Present idx **140**, ResizeBuffers idx **145** | 
| Flarial | Свои хуки: `SwapchainHook_DX11/DX12`, `CreateSwapchainForCoreWindowHook`, `ResizeHook`, `CommandListHook` | отдельный Present-хук DX11 | отдельный Present-хук DX12 + D3D11On12 + D2D поверх |

Файлы: `Solstice/.../RenderHooks/D3DHook.cpp` (`D3DHook::s_init`, строки ~554–572); `Flarial/.../Render/DirectX/...`.

[CONFIRMED] Bedrock на Windows рендерит через **DX11 или DX12** (оба поддерживаются, выбор зависит от настроек/драйвера). Поэтому оверлей обязанDetektить оба бэкенда. VSync-поведение Flarial меняет через `Present(..., DXGI_PRESENT_ALLOW_TEARING)`.

### 4.2. Синхронизация кадра между потоками (оба клиента — одинаковая схема!)

```
[Render thread: setupAndRender]                    [Present thread: overlay]
  FrameTransform{viewMatrix, origin, fov}  ──queue──▶  pop с задержкой transformDelay
  push под мьютексом                                 Transform = front()
                                                      W2S / ESP используют Transform
```

- Flarial: `SwapchainHook::FrameTransforms` + `frameTransformsMtx`, потребление в `RenderSync()` (`SwapchainHook.cpp:224`), хранение в `MC::Transform` (`D2D.hpp:28`).
- Solstice: `D3DHook::FrameTransforms`, потребление в `present()` (`D3DHook.cpp:359`), хранение в `RenderUtils::transform`.

[INFERENCE] Очередь с `transformDelay` компенсирует рассинхрон present-кадра и игрового кадра (present может идти чаще/реже).

### 4.3. Чем рисуют оверлей

- Flarial: **D2D** (`D2D::context`, собственный GUI-движок `FlarialGUI`: кнопки, слайдеры, блюр, эффекты) + **ImGui BackgroundDrawList** для ESP-примитивов (`DrawUtils::addLine` → `ImGui::GetBackgroundDrawList()->AddLine`).
- Solstice: **ImGui** поверх Kiero + собственный `D2D::init(swapChain, device)` (строка 423 `D3DHook.cpp` — детали в Части 2).
- Borion: оверлея через Present **нет** — весь рендер идёт путями A/B (Tessellator + MUIRC) + собственный `HImGui` (самописный immediate GUI на примитивах DrawUtils, рисуется в `RenderText`-хуке).

---

## 5. WorldToScreen — математика [CONFIRMED, две независимые реализации]

### 5.1. Flarial `Matrix::WorldToScreen` (`SDK/Client/Render/Matrix.cpp`)

```cpp
displaySize = clientInstance->getGuiData()->ScreenSize;
origin      = MC::Transform.origin;                    // из очереди кадров
pos         = pos.sub(origin);                         // world → camera-relative
matx        = getMatrixCorrection(MC::Transform.modelView);  // GLMatrix[16] → glm::mat4 (перестановка)
t           = matx * vec4(pos, 1);
if (t.z > 0) return false;                             // за камерой
screen.x = mX + (mX * t.x / -t.z * fov.x);
screen.y = mY - (mY * t.y / -t.z * fov.y);
```

`GLMatrix` — 16 float (`matrix[16]`), приходит из `ClientInstance->getViewMatrix()`. `fov` — `Vec2` из `ClientInstance->getFov()`.

### 5.2. Borion `glmatrixf::OWorldToScreen` (`Utils/HMath.h:403`)

```cpp
pos = pos.sub(origin);
x = transformx(pos); y = transformy(pos); z = transformz(pos);  // умножение на refdef-матрицу
if (z > 0) return false;
screen.x = mX + (mX * x / -z * fov.x);
screen.y = mY - (mY * y / -z * fov.y);
```

Идентичная формула. `refdef` = `ClientInstance->getRefDef()->correct()` (транспонированная), `fov` = `getFov()`, `origin` = `levelRenderer->origin`.

### 5.3. Вывод

```
World ──(minus origin)──▶ Camera-relative ──(× view/proj matrix)──▶ Clip ──(perspective divide + fov scale)──▶ Screen
```

- `origin` = позиция камеры/начала рендера (`LevelRenderer->origin` или `RendererPlayer->cameraPos`).
- Отсечение: `z > 0` → точка за камерой.
- [PROPOSAL] Наша `worldToScreen()` — та же формула; источник матрицы/origin/fov — очередь FrameTransform (как у Flarial/Solstice), чтобы работать из любого потока.

---

## 6. Entity: список, позиция, AABB [CONFIRMED]

### 6.1. Список сущностей

| Клиент | Способ | Файл |
|---|---|---|
| Flarial | `Level::getRuntimeActorList()` → `std::vector<Actor*>` (по сигнатуре; есть fallback «temp solution» в коде) | `SDK/Client/Level/Level.cpp:8` |
| Solstice | `Level::getRuntimeActorList()` → `std::vector<Actor*>` (сиг `SigManager::Level_getRuntimeActorList`) | `SDK/Minecraft/World/Level.cpp:29` |
| Borion | `GameData::forEachEntity(callback)` (обёртка; реализацию смотреть в `GameData.cpp` — в Части 2) | `Memory/GameData.h:245` |

### 6.2. Позиция и размеры (компонентная модель, Bedrock ≥ ~1.20)

- `Actor->getRenderPositionComponent()->renderPos` / `->mPosition` — рендер-позиция (сглаженная).
- `Actor->getAABBShapeComponent()->aabb` — `AABB {lower, upper}`.
- Borion (старый стиль): `ent->getPos()/getPosOld()` + `ent->width/height/aabb`, сглаживание через `lerp(..., lerpT)` (см. `drawEntityBox`, `DrawUtils.cpp:407`).
- ESP-фильтры (Borion `ESP.cpp`): пропуск себя, мёртвых (`timeSinceDeath > 0`), друзей, невидимых; толщина линии масштабируется от дистанции: `max(0.4, 1/max(1, dist*3))`.

### 6.3. Пример: Borion `drawEntityBox` → `drawBox(..., outline=true)`

8 вершин AABB → W2S каждой → обход внешнего контура (min-angle walk, тот же алгоритм скопирован во Flarial `DrawUtils::addBox` mode 2) → линии. Flarial `addEntityBox` дополнительно берёт `renderPos` и масштабирует толщину от дистанции.

---

## 7. Камера и FOV [CONFIRMED частично]

- `ClientInstance->getViewMatrix()` (Flarial/Solstice) / `getRefDef()->correct()` (Borion) — матрица вида.
- `ClientInstance->getFov()` → `vec2(x, y)` — используется прямо в формуле W2S.
- `LevelRenderer->getOrigin()` / `getLevelRendererPlayer()->cameraPos` — origin камеры.
- Borion хукает `LevelRendererPlayer::getFov` (зум-модули) и `LevelRendererPlayer::renderNameTags`, `bobView` (тряска камеры).
- [TODO Часть 2] Точная структура `LevelRendererPlayer`, матрицы проекции отдельно от вида, `CameraComponent` (есть в Solstice SDK: `Actor/Components/CameraComponent.hpp`).

---

## 8. Потоки (предварительно) [INFERENCE, уточнить в Части 2]

| Хук | Поток (предположительно) | Основание |
|---|---|---|
| `renderLevel` / `setupAndRender` | Render thread игры | Очередь FrameTransform с мьютексом + `transformDelay` была бы не нужна внутри одного потока |
| `Present` (overlay) | DX present thread | Стандартное поведение swapchain; ImGui рендерится там |
| Чтение entity/матриц | Безопасно в render-хуках | Все клиенты читают Actor/AABB/матрицы прямо в колбэках |

---

## 9. Что дальше

**Часть 2 (PRIORITY 1 — добить + PRIORITY 2):** `D3DHook.cpp` целиком (D2D init, RenderUtils/W2S Solstice), `GLMatrix`/viewMatrix источник, `forEachEntity` реализация, `LevelRendererPlayer`, текст/шрифты (`C_Font`, `getLineLength`), текстуры (`renderGuiItemNew`, `BedrockTextureData`), depth/blend/materials детали, ClickGUI-архитектуры для сравнения.

**Часть 3 (PRIORITY 3–4):** GUI-движки, input (Key/Mouse hooks), particles, module/event системы.

**Часть 4:** Анализ **вашего src** (нужен zip!) → карта «что добавить для rendering foundation» → предложение архитектуры `Renderer2D/Renderer3D/TextRenderer/...`.

---

## 10. Нужно от тебя

1. **Пришли zip с твоим src** (тем же способом — вложением в чат). Без него Часть 4 невозможна.
2. Подтверди: идём дальше по Частям 2–3, или сначала хочешь увидеть [PROPOSAL] архитектуры уже сейчас на базе Части 1?
