// visual_modules.h - Visual-category demo modules.
//
// UI DEMO ONLY - see combat_modules.h for the project-wide rule. Every module
// here either changes local settings or draws into OUR OWN ImGui overlay;
// none of them reads or writes the game.
//
// NOTE: ASCII only in this file.

#pragma once

#include "modules/module.h"

namespace modules {

class ESP : public Module {
public:
    ESP();

    EnumSetting*   m_mode       = nullptr;
    NumberSetting* m_thickness  = nullptr;
    BoolSetting*   m_health     = nullptr;
    BoolSetting*   m_distance   = nullptr;
    ColorSetting*  m_color      = nullptr;
};

class FullBright : public Module {
public:
    FullBright();
    void on_enable() override;
    void on_disable() override;
    void on_render() override;

    NumberSetting* m_strength = nullptr;
    BoolSetting*   m_gamma    = nullptr;
    float m_currentGamma = 1.0f;
};

class GuiScale : public Module {
public:
    GuiScale();
    NumberSetting* m_scale = nullptr;
};

class VsyncDisabler : public Module {
public:
    VsyncDisabler();
};

class Nametags : public Module {
public:
    Nametags();

    NumberSetting* m_scale    = nullptr;
    BoolSetting*   m_health   = nullptr;
    BoolSetting*   m_distance = nullptr;
    BoolSetting*   m_items    = nullptr;
};

class NoRender : public Module {
public:
    NoRender();

    BoolSetting* m_weather   = nullptr;
    BoolSetting* m_particles = nullptr;
    BoolSetting* m_entities  = nullptr;
    BoolSetting* m_hurtCam   = nullptr;
};

class Zoom : public Module {
public:
    Zoom();

    NumberSetting* m_fov    = nullptr;
    NumberSetting* m_smooth = nullptr;
    BoolSetting*   m_scroll = nullptr;
};

// Watermark, Pulse Visuals style: dark rounded pill with the pulse icon,
// the tag text, real ping and FPS segments. Background/Outline toggles
// control the pill.
class Watermark : public Module {
public:
    Watermark();

    void on_render() override;

    StringSetting* m_text        = nullptr;  // the tag text
    BoolSetting*   m_background  = nullptr;  // draw the dark pill
    BoolSetting*   m_outline     = nullptr;  // accent stroke around the pill
    BoolSetting*   m_fps         = nullptr;  // FPS segment
    BoolSetting*   m_ping        = nullptr;  // ping segment (real RakNet ping)
    NumberSetting* m_opacity     = nullptr;  // pill opacity
    NumberSetting* m_scale       = nullptr;  // make the tag bigger
};

// Arraylist, Packet V3 style: translucent dark plate per row (flush to the
// right screen edge), white module name + gray mode, and an accent pill bar
// inset near the right edge, with the Solstice-style per-module lerp
// animation. Purely our own drawing.
class Arraylist : public Module {
public:
    Arraylist();

    void on_render() override;

    BoolSetting*   m_renderMode   = nullptr;  // mode text next to the module name
    NumberSetting* m_fontSize     = nullptr;  // text size in px (V3 ~15px)
    NumberSetting* m_opacity      = nullptr;  // plate opacity
    EnumSetting*   m_visibility   = nullptr;  // All / Bound
    NumberSetting* m_scale        = nullptr;

    // per-module lerp animation, indexed by the global registry order.
    std::vector<float> m_anim;
};

class Freelook : public Module {
public:
    Freelook();
    void on_enable() override;
    void on_disable() override;

    EnumSetting* m_mode = nullptr;

    // Packet-Source state: camera angles are redirected while the player's
    // own rotation stays untouched. The update-from-camera hook consumes this
    // state even during the short restoration window after disable.
    bool redirectMouse = false;
    int resetViewTick = -1;
    ImVec2 initialViewAngles{};
    ImVec2 lastCameraAngle{};
    bool isThirdPerson = false;
    bool cameraFacesFront = false;
    bool initialCaptured = false;
};

} // namespace modules
