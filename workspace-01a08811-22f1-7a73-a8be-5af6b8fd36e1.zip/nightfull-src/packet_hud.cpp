// packet_hud.cpp - shared Packet V2 HUD drawing engine. See packet_hud.h.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/visual/packet_hud.h"

#include "utils/gui_render.h"

#include <cstring>

namespace {

// Direct port of the shared HUD colour machinery from Packet-Source /
// PacketV2 (_ref_packet/Memory/Hooks.cpp lines 448-480 and
// _ref_packetv2/Client/Memory/Hooks.cpp) plus Utils::ApplyRainbow. In Packet
// these live in function-level statics shared by every HUD draw call.
struct PacketHud {
    float rcolors[4]  = { 1.f, 0.6f, 0.6f, 1.f };  // ApplyRainbow's seed
    float dynamic     = 0.f;  bool dynamicUp = true;   // dynamicColor wave
    float currColor[4] = { 1.f, 1.f, 1.f, 1.f };   // the shared wheel colour
    int   lastFrame   = -1;

    void AdvanceFrame() {
        const int frame = ImGui::GetFrameCount();
        if (frame == lastFrame) return;
        lastFrame = frame;

        // Utils::ApplyRainbow(rcolors, 0.0005f)
        if (rcolors[3] < 1.f) {
            rcolors[0] = 1.f; rcolors[1] = 0.6f; rcolors[2] = 0.6f; rcolors[3] = 1.f;
        }
        ImGui::ColorConvertRGBtoHSV(rcolors[0], rcolors[1], rcolors[2],
                                    rcolors[0], rcolors[1], rcolors[2]);
        rcolors[0] += 0.0005f;
        if (rcolors[0] >= 1.f) rcolors[0] = 0.f;
        ImGui::ColorConvertHSVtoRGB(rcolors[0], rcolors[1], rcolors[2],
                                    rcolors[0], rcolors[1], rcolors[2]);

        // dynamicColor: step 0.007/frame inside 0.2..1.0 (Hooks.cpp 470-480)
        dynamic += (dynamicUp ? 0.007f : -0.007f);
        if (dynamic < 0.2f) { dynamic = 0.2f; dynamicUp = true; }
        if (dynamic > 1.f)  { dynamic = 1.f;  dynamicUp = false; }

        currColor[0] = rcolors[0];
        currColor[1] = rcolors[1];
        currColor[2] = rcolors[2];
        currColor[3] = 1.f;
    }
};
PacketHud g_hud;

// Packet's enum values skip 10 (Weather was removed in V2).
constexpr int kPacketSel[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12 };

// Static palette from Hooks.cpp (White/Red/Orange/Yellow/Green/Blue/Purple/Pink).
bool StaticColor(int sel, float* out) {
    float r, g, b;
    switch (sel) {
    case 4:  r = 255.f; g = 255.f; b = 255.f; break;
    case 5:  r = 255.f; g = 0.f;   b = 0.f;   break;
    case 6:  r = 255.f; g = 127.f; b = 0.f;   break;
    case 7:  r = 255.f; g = 255.f; b = 0.f;   break;
    case 8:  r = 0.f;   g = 255.f; b = 0.f;   break;
    case 9:  r = 0.f;   g = 170.f; b = 255.f; break;
    case 11: r = 148.f; g = 0.f;   b = 211.f; break;
    case 12: r = 255.f; g = 192.f; b = 203.f; break;
    default: return false;
    }
    out[0] = r / 255.f; out[1] = g / 255.f; out[2] = b / 255.f; out[3] = 1.f;
    return true;
}

} // anonymous namespace

namespace packethud {

int Sel(int enumIndex) {
    if (enumIndex < 0 || enumIndex >= (int)(sizeof(kPacketSel) / sizeof(kPacketSel[0])))
        return 0;
    return kPacketSel[enumIndex];
}

const std::vector<std::string>& ColorNames() {
    static const std::vector<std::string> kNames = {
        "Rainbow", "Dynamic", "Horion", "Fadeaway", "White", "Red",
        "Orange", "Yellow", "Green", "Blue", "Purple", "Pink"
    };
    return kNames;
}

void Frame() { g_hud.AdvanceFrame(); }

ImVec4 Color(int packetSel) {
    if (packetSel == 1)
        return ImVec4(g_hud.dynamic, g_hud.dynamic, g_hud.dynamic, 1.f);
    float st[4];
    if (StaticColor(packetSel, st))
        return ImVec4(st[0], st[1], st[2], 1.f);
    // Rainbow / Horion / Fadeaway all resolve to the shared wheel colour.
    return ImVec4(g_hud.currColor[0], g_hud.currColor[1], g_hud.currColor[2], 1.f);
}

float Unit() { return gui::kFontUnit * 0.1f; }  // 1.8 px per MC UI unit

ImVec2 P(float x, float y) { return ImVec2(x * Unit(), y * Unit()); }

ImVec4 R(float x, float y, float z, float w) {
    const float u = Unit();
    return ImVec4(x * u, y * u, z * u, w * u);
}

float TextWidthU(const std::string& text, float size) {
    return gui::GetTextWidth(text.c_str(), size) / Unit();
}

// Packet's DrawUtils::drawText: pos.y -= 1, shadow = colour/6 at +1*textSize.
void Text(ImVec2 posU, const std::string& text, const ImVec4& color,
          float size, float alpha, bool shadow) {
    if (!ImGui::GetCurrentContext() || text.empty()) return;
    ImDrawList* d    = ImGui::GetBackgroundDrawList();
    ImFont*     font = gui::CurrentFont();
    if (!font) return;
    const float px   = size * gui::kFontUnit;
    const float off  = 1.0f * size * Unit();
    const ImVec2 pos(posU.x * Unit(), posU.y * Unit() - Unit());
    if (shadow) {
        d->AddText(font, px, ImVec2(pos.x + off, pos.y + off),
                   ImGui::ColorConvertFloat4ToU32(ImVec4(color.x / 6.f, color.y / 6.f,
                                                         color.z / 6.f, alpha)),
                   text.c_str());
    }
    d->AddText(font, px, pos,
               ImGui::ColorConvertFloat4ToU32(ImVec4(color.x, color.y, color.z, alpha)),
               text.c_str());
}

void Fill(const ImVec4& rectU, const ImVec4& color, float alpha) {
    gui::FillRect(rectU, ImColor(color), alpha, 0.0f);
}

float HudRowWidthU(const std::string& text, float scale) {
    return TextWidthU(text, 1.0f * scale) + 6.5f * scale;
}

void HudRow(const std::string& text, float xU, float rowYU,
            int packetSel, float scale) {
    // Text only: the translucent black plate read as a drop shadow, so the
    // row is drawn without it by request.
    Text(P(xU + 2.f * scale, rowYU + 6.f * scale + 3.5f * scale),
         text, Color(packetSel), 1.f * scale, 1.f, false);
}

} // namespace packethud
