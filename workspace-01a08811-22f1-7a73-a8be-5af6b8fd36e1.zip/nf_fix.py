#!/usr/bin/env python3
"""Apply the remaining Nightfull compile fixes. Each replacement asserts
exactly one match, so a drifted anchor fails loudly instead of corrupting."""
import sys

BASE = "/home/user/nightfull/"

MENU = "src/ui/menu.cpp"
OVERLAY = "src/overlay/overlay.cpp"

menu_pairs = [
    ("struct Toast { std::string text; unsigned long long until; };",
     "struct ToastItem { std::string text; unsigned long long until; };"),
    ("std::vector<Toast> g_toasts;",
     "std::vector<ToastItem> g_toasts;"),
    ("const Toast& t = g_toasts[i];",
     "const ToastItem& t = g_toasts[i];"),
    ("ImColor(1, 1, 1, c.alpha * (0.75f + 0.25f * anim))",
     "ImColor(1.0f, 1.0f, 1.0f, c.alpha * (0.75f + 0.25f * anim))"),
    ("ImColor(1, 1, 1, c.alpha)",
     "ImColor(1.0f, 1.0f, 1.0f, c.alpha)"),
    ("tm->m_colors &&",
     "tm->m_colorSlots &&"),
    ("    c.anim = anim;",
     "    c.alpha = anim;"),
    ("const float h = 40 + rows.size() * 28 + 8;",
     "const float h = 40.0f + (float)rows.size() * 28.0f + 8.0f;"),
]

overlay_pairs = [
    ("#include <cstdio>\n#include <vector>",
     "#include <cstdio>\n#include <cstring>\n#include <vector>"),
    ('#include "imgui_impl_win32.h"\n',
     '#include "imgui_impl_win32.h"\n'
     '\n'
     '// Forward declaration: imgui_impl_win32.h intentionally keeps it in `#if 0`\n'
     '// and asks the caller to declare it (see the comment in that header).\n'
     'extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);\n'),
    ("using ResizeFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);",
     "using ResizeFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);\n"
     "\n"
     "void FinishUnload();  // defined below; called from the HkPresent tail"),
    ("""            } else {
                TeardownRender();
                LOG_ERROR("overlay: render init failed - retrying next frame");
            }""",
     """            } else {
                TeardownRender();
                static int fails = 0;
                if (++fails == 1 || fails % 600 == 0)
                    LOG_ERROR("overlay: render init failed (%d) - retrying", fails);
            }"""),
    ("""            } else if (keys::PressedThisFrame(VK_ESCAPE) && g_showMenu) {
                g_showMenu = false;
                keys::Reset();
                LOG_INFO("menu: ESC -> closed");
            }""",
     """            } else if (keys::PressedThisFrame(VK_ESCAPE) && g_showMenu) {
                // ESC first dismisses transient UI (field/dropdown/popup/bind),
                // and only closes the menu when nothing is open.
                if (!ui::DismissTopmost()) {
                    g_showMenu = false;
                    LOG_INFO("menu: ESC -> closed");
                }
                keys::Reset();
            }"""),
    ("""    TeardownRender();
    if (g_imgui) { ImGui::DestroyContext(); g_imgui = false; }""",
     """    TeardownRender();
    if (g_win32Init) { ImGui_ImplWin32_Shutdown(); g_win32Init = false; }
    if (g_imgui) { ImGui::DestroyContext(); g_imgui = false; }"""),
    ("""        // The worker's job is done; everything else runs on hooked threads.
        // This loop only exists to trigger the deferred unload off the hot path.
        for (;;) {
            Sleep(100);
            if (g_abort) return;
            if (g_unloadRequested && g_init) {
                EnterCriticalSection(&g_renderCs);
                const bool idle = (g_inRender == 0);
                LeaveCriticalSection(&g_renderCs);
                if (idle) { FinishUnload(); return; }
            }
        }""",
     """        // The worker's job is done; everything else runs on hooked threads
        // (unload is serialized in the HkPresent tail). Just park here so an
        // abort during startup can still be observed.
        while (!g_abort) Sleep(500);"""),
]


def apply(path, pairs):
    with open(BASE + path, encoding="utf-8") as f:
        content = f.read()
    for i, (old, new) in enumerate(pairs):
        n = content.count(old)
        if n != 1:
            print(f"FAIL {path} pair {i}: found {n} matches (expected 1)")
            print("--- old text ---")
            print(old)
            return False
        content = content.replace(old, new, 1)
        print(f"ok {path} pair {i}")
    with open(BASE + path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    return True


ok = apply(MENU, menu_pairs) and apply(OVERLAY, overlay_pairs)
print("ALL OK" if ok else "FAILED")
sys.exit(0 if ok else 1)
