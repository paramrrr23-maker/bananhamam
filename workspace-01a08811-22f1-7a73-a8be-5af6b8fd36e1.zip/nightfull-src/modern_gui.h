// modern_gui.h - Solstice's ClickGUI panel engine.
//
// Port of Solstice's src/Features/GUI/ModernDropdown.{hpp,cpp} (aka
// "ModernGui"). It owns the layout and every widget of the menu:
//
//   * one draggable panel per module category, laid out in a row;
//   * each panel is a stack of 30px rows: header + modules + their settings;
//   * opening a module's settings eases the rows apart (Module::cAnim);
//   * colours come from the cycling theme, so a column reads as a gradient;
//   * left click toggles, right click expands settings, middle click binds.
//
// This is a faithful port, not a re-implementation: geometry, colours, easing
// speeds and the per-widget draw order are Solstice's. Two known Solstice
// bugs are deliberately NOT ported (see modern_gui.cpp).
//
// Everything here is local UI state. No game memory is read or written.
//
// NOTE: ASCII only in this file.

#pragma once

#include <string>
#include <vector>

#include "imgui.h"
#include "utils/config.h"

namespace modules {
class Module;
class BoolSetting;
class ColorSetting;
} // namespace modules

namespace ui {

class ModernGui {
public:
    // Solstice's ModernGui::CategoryPosition.
    struct CategoryPosition {
        float x = 0.0f, y = 0.0f;
        bool  isDragging  = false;
        bool  isExtended  = true;
        bool  wasExtended = false;
        float yOffset     = 0.0f;
        float scrollEase  = 0.0f;
    };

    // Solstice's geometry constants.
    static constexpr float catWidth  = 200.0f;
    static constexpr float catHeight = 30.0f;
    static constexpr float catGap    = 40.0f;

    // Solstice's palette.
    static const ImColor textColor;
    static const ImColor darkBlack;
    static const ImColor mainColor;
    static const ImColor grayColor;
    static const ImColor enumBackGround;

    ModernGui();

    // One menu frame. Called from the ClickGui module between
    // ImGui::NewFrame() and ImGui::Render().
    //   animation        0..1 menu fade (drives every alpha)
    //   inScale          0..1 scale-from-centre (drives text size too)
    //   scrollDirection  -1/0/+1 wheel direction, consumed by the hovered panel
    //   blur             Solstice's Blur Strength (drives the scrim here)
    //   midclickRounding value a NumberSetting snaps to on middle-click drag
    void render(float animation, float inScale, int& scrollDirection,
                float midclickRounding, bool isPressingShift, bool isEnabled);

    // Window resized -> panels are re-centred (Solstice: resetPosition).
    void onWindowResizeEvent();

    // Panel layout to apply the next time the panels are laid out (used to
    // restore the saved positions on startup). Call before the first render.
    void restoreLayout(const std::vector<config::PanelPos>& layout);
    // Current layout, for saving.
    std::vector<config::PanelPos> currentLayout() const;

    // True while a keybind is being captured; the menu swallows keys then.
    bool isBinding() const { return m_isBinding || m_isBoolSettingBinding; }

    // True while the colour picker window is open.
    bool isColorPickerOpen() const { return m_displayColorPicker; }

    // Panel positions, exposed so the config can persist the layout.
    std::vector<CategoryPosition>& panels() { return m_catPositions; }

private:
    void drawSearchBox(const ImVec2& screen, float animation);
    void drawColorPicker(const ImVec2& screen, float animation);
    void drawTooltip(const std::string& tooltip, const ImVec2& screen,
                     float animation, float inScale);

    std::vector<CategoryPosition> m_catPositions;
    std::string                   m_searchText;
    char                          m_searchBuf[128];

    modules::Module*       m_lastMod             = nullptr;
    modules::BoolSetting*  m_lastBoolSetting     = nullptr;
    modules::ColorSetting* m_lastColorSetting    = nullptr;
    bool                   m_isBinding           = false;
    bool                   m_isBoolSettingBinding = false;
    bool                   m_displayColorPicker  = false;
    bool                   m_resetPosition       = false;
    bool                   m_searchFocused       = true;
    bool                   m_layoutApplied       = false;
    unsigned long long     m_lastReset           = 0;
    std::vector<config::PanelPos> m_pendingLayout;
};

} // namespace ui
