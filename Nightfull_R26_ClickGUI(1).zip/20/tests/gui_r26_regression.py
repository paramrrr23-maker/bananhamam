"""Linux/g++ headless test of the actual menu.cpp and bundled ImGui.
Platform, game and disk APIs are mocks, NOT a Windows DLL build or in-game test.
Optional --output DIR writes actual ImGui vertex meshes + font atlases for previews.
"""
from pathlib import Path
import os, subprocess, tempfile, argparse
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--output',type=Path);args=a.parse_args()
font=os.environ.get('NF_TEST_UI_FONT')
if not font:
    font=subprocess.check_output(['fc-match','-f','%{file}','Arial'],text=True).strip()
if not Path(font).is_file():raise SystemExit('Set NF_TEST_UI_FONT to a sans TTF with Cyrillic.')
env=dict(os.environ,NF_TEST_UI_FONT=font)
tp=root/'src/third_party/imgui'
files=[root/'tests/gui_r26_native.cpp',root/'src/core/module_manager.cpp',root/'src/modules/client_modules.cpp',root/'src/utils/gui_render.cpp',root/'src/utils/gui_theme.cpp']+[tp/(n+'.cpp') for n in ['imgui','imgui_draw','imgui_widgets','imgui_tables']]
with tempfile.TemporaryDirectory(prefix='nightfull-r26-') as d:
    exe=Path(d)/'native_gui'
    cmd=[os.environ.get('CXX','g++'),'-std=c++20','-O1','-ffunction-sections','-fdata-sections','-I'+str(root/'tests/gui_r26_stubs'),'-I'+str(root/'src'),'-I'+str(tp),*map(str,files),'-Wl,--gc-sections','-o',str(exe)]
    subprocess.run(cmd,cwd=root,check=True,env=env)
    if args.output:args.output.mkdir(parents=True,exist_ok=True)
    for state in ['light','dark','enum','color','settings','themes','configs','empty','save']:
        call=[str(exe),state]
        if args.output:call.append(str(args.output.resolve()/state))
        result=subprocess.run(call,cwd=root,check=True,env=env,capture_output=True,text=True)
        print(state+': '+result.stdout.strip())
