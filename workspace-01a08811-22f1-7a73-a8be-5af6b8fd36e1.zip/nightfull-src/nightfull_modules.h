// nightfull_modules.h - safe client-side QoL module roster for Nightfull.
//
// These modules are local UI/config concepts only. They do not read or write
// Minecraft memory, do not install gameplay hooks, and do not provide PvP or
// competitive advantages. The registry uses this file to populate the same
// Module/Setting system that the ClickGUI already renders.
//
// NOTE: ASCII only in this file.

#pragma once

#include <memory>
#include <vector>

#include "modules/module.h"

namespace modules {

class NightfullModule : public Module {
public:
    NightfullModule(const char* category, const char* name, const char* description)
        : Module(category, name, description) {}
};

// Builds the complete Nightfull roster in the order used by the UI.
std::vector<std::unique_ptr<Module>> CreateNightfullModules();

} // namespace modules
