"""R17: extracted production reader, worker, snapshot + real health-state header.

Linux C++20 ASan/UBSan with game/Win32 test doubles. NOT an MSVC build,
game ABI verification, network test, or proof of remote health synchronisation.
Run: python tests/targethud_r17_regression.py
"""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
src = (root / "src/overlay/overlay.cpp").read_text(encoding="utf-8")
hdr = (root / "src/overlay/overlay.h").read_text(encoding="utf-8")
hud = (root / "src/modules/hud_modules.cpp").read_text(encoding="utf-8")

def function(name):
    start = src.index(name)
    begin = src.index("{", start)
    depth = 1
    end = begin + 1
    while depth:
        depth += (src[end] == "{") - (src[end] == "}")
        end += 1
    return src[start:end]

prefix = r"""
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <limits>
#include <vector>
#include <cstdlib>
#include "overlay/target_health.hpp"
#define __fastcall
#define LOG_INFO(...) ((void)0)
using ULONGLONG = unsigned long long;
using LONG = long;
using LONG64 = long long;
using SRWLOCK = int;
#define SRWLOCK_INIT 0
int lockDepth=0;
void AcquireSRWLockShared(SRWLOCK*) { ++lockDepth; }
void ReleaseSRWLockShared(SRWLOCK*) { --lockDepth; }
void AcquireSRWLockExclusive(SRWLOCK*) { ++lockDepth; }
void ReleaseSRWLockExclusive(SRWLOCK*) { --lockDepth; }
LONG InterlockedCompareExchange(volatile LONG* p,LONG v,LONG c) { auto old=*p;if(old==c)*p=v;return old; }
LONG64 InterlockedCompareExchange64(volatile LONG64* p,LONG64 v,LONG64 c) { auto old=*p;if(old==c)*p=v;return old; }
int checks=0;
#define CHECK(x) do { ++checks; if(!(x)) { std::fprintf(stderr,"line %d: %s\n",__LINE__,#x);std::abort(); } } while(0)
ULONGLONG clockMs=10000;
ULONGLONG GetTickCount64() { return clockMs; }
void* GetModuleHandleW(const wchar_t*) { return nullptr; }
bool g_shuttingDown=false;
int patch=111, scans=0, matches=1, getterCalls=0, hurtTime=0;
bool contextOk=true, poolOk=true, containsOk=true, payloadOk=true;
char scoreText[256] = {};
char tabText[256] = {};
unsigned char payload[88]{}, instance[136]{}, attribute[64]{};
char actorA=0,actorB=0,actorC=0,localActor=0,worldObject=0;
void* world=&worldObject;
void* g_hitboxWorldLocal=&localActor;
SRWLOCK g_hitboxWorldContextLock=0;
using EntityId = std::uint32_t;
struct AttributesComponent {};
namespace entt {
template<class T> struct type_hash { static constexpr uint32_t value() {return 123;} };
struct Pool {
    bool contains(EntityId) const { return containsOk; }
    const void* value(EntityId) const {return payloadOk ? payload : nullptr;}
};
template<class T> struct basic_registry {
    const Pool* storage(uint32_t) const {static Pool p;return poolOk ? &p : nullptr;}
};
}
entt::basic_registry<EntityId> registry;
bool HitboxReadActorContextDirect(void*,void** obj,void** reg,uint32_t* ent) {
    *obj=&registry;*reg=&registry;*ent=1;return contextOk;
}
std::vector<std::pair<uintptr_t,size_t>> regions;
bool GuiRangeReadable(const void* p,size_t n) {
    auto v=reinterpret_cast<uintptr_t>(p);
    for(auto [base,size]:regions)
        if(v>=base && v-base<=size && n<=size-(v-base))return true;
    return false;
}
bool GuiPageReadable(const void* p) { return p && GuiRangeReadable(p,1); }
bool PotionReadBytes(const void* p,void* out,size_t n) {
    if(!GuiRangeReadable(p,n))return false;
    std::memcpy(out,p,n);return true;
}
void* fixtureGetter(const void* map,unsigned id) {
    ++getterCalls;CHECK(map==payload);CHECK(id==6);return instance;
}
bool JavaIsGameCodeAddress(uintptr_t p) { return p==reinterpret_cast<uintptr_t>(&fixtureGetter); }
int JavaGamePatch(){ return patch; }
int ScanSigMatches(void*,const char*,uintptr_t& out){
    ++scans;out=reinterpret_cast<uintptr_t>(&fixtureGetter);return matches;
}
void* HitboxGetWorldRegistry() {return world;}
void* HitboxLocalPlayer() {return &localActor;}
const unsigned kHitboxPlayerCategory=1;
bool HitboxReadActorCategories(void*,uint32_t* c) {*c=1;return true;}
bool HitboxCategoriesPlausible(uint32_t) {return true;}
int ThReadActorNames(void*,char (*names)[64],int) {std::strcpy(names[0],"Target");return 1;}
static bool ThReadSynchedName(void*,char* raw,size_t cap) {
    if (!raw || cap == 0 || !scoreText[0]) return false;
    std::snprintf(raw,cap,"%s",scoreText);
    return raw[0] != 0;
}
bool ThReadTabName(void*,void*,bool,int64_t,char(*)[64],int,char* out,size_t cap) {
    if (!tabText[0]) return false;
    std::snprintf(out,cap,"%s",tabText);
    return out[0] != 0;
}
void ThDumpSynchedData(void*) {}
void ThUpdateTargetRid(void*) {}
static volatile float g_tiPktHp = 0.0f, g_tiPktHpMax = 0.0f;
static volatile LONG64 g_tiPktHpAt = 0;
static volatile LONG64 g_tiPktHpRid = 0;
static volatile float g_tiPktAbs = 0.0f, g_tiPktAbsMax = 0.0f;
static volatile LONG64 g_tiPktAbsAt = 0;
static volatile float g_tiPktLastLoss = 0.0f, g_tiPktTotalLoss = 0.0f;
static volatile LONG g_tiPktLossGen = 0;
static volatile LONG64 g_tiPktLossAt = 0;
bool ThReadUniqueId(void* p,int64_t* id) {*id=p==&actorA?1:(p==&actorB?2:3);return true;}
int ThReadHurtTime(void*) {return hurtTime;}
bool ThReadHurtFlag(void*) {return false;}
bool ThReadRenderPos(void*,float* p) {p[0]=p[1]=p[2]=0;return true;}
bool ActorReadAabb(void*,float*,float*) {return false;}
bool ThFindSkinFace(void*,void*,bool,int64_t,char (*)[64],int,unsigned*,char*,size_t,int*) {return false;}
void ThStripName(const char* s,char* d,size_t n) {std::snprintf(d,n,"%s",s);}
unsigned kTiSteveFace[64]{};
constexpr uint32_t kHitboxSynchedDataHash = 0xDC1E21CEu;
int g_javaCs=0;
void JavaEnsureCs(){}
void EnterCriticalSection(int*){}
void LeaveCriticalSection(int*){}
void* volatile g_tiLookActor=nullptr;
volatile LONG64 g_tiLookAt=0;
volatile LONG g_tiHideMs=2000;
"""
globals1 = src[src.index("void* g_tiTarget = nullptr;"):src.index("static __int64 __fastcall HkGameModeAttack")]
globals2 = src[src.index("static SRWLOCK g_tiDataLock"):src.index("// Hurt flag from the SynchedActorData")]
reader = src[src.index("using ThAttributeGetter"):src.index("// ---- skin face (player list)")]
struct = hdr[hdr.index("struct TargetHudInfo {"):hdr.index("// Render thread, once per frame while the Target HUD")]
worker = function("static void ThPollTargetInfo() {")
synced_reader = function("static bool ThReadSynchedHealth(")
snapshot = function("bool GetTargetHudInfo(TargetHudInfo* out)")
tests = r"""
void hp(float value,float max=20.0f) {
    std::memcpy(instance+0x7C,&value,4);std::memcpy(instance+0x78,&max,4);
}
void tick(unsigned ms=8) {
    clockMs+=ms;g_tiLookAt=clockMs;ThPollTargetInfo();CHECK(lockDepth==0);
}
TargetHudInfo snap() {
    TargetHudInfo result{};CHECK(GetTargetHudInfo(&result));CHECK(lockDepth==0);return result;
}
int main() {
    regions={{reinterpret_cast<uintptr_t>(payload),sizeof(payload)},
             {reinterpret_cast<uintptr_t>(instance),sizeof(instance)},
             {reinterpret_cast<uintptr_t>(attribute),sizeof(attribute)}};
    const unsigned char* attr=attribute;
    unsigned id=6;
    std::memcpy(instance+8,&attr,8);std::memcpy(attribute+4,&id,4);hp(20);
    // Resolver refuses other versions and ambiguous signatures; retry bounded.
    patch=130;CHECK(!ThResolveHealthGetter());CHECK(scans==0);
    patch=111;clockMs+=5001;matches=2;CHECK(!ThResolveHealthGetter());CHECK(scans==1);
    CHECK(!ThResolveHealthGetter());CHECK(scans==1);
    clockMs+=5001;matches=1;CHECK(ThResolveHealthGetter());CHECK(scans==2);
    CHECK(ThResolveHealthGetter());CHECK(scans==2);
    float value=-1,max=-1;
    CHECK(ThReadHealth(&actorA,&value,&max));CHECK(value==20 && max==20);
    CHECK(!ThReadHealth(nullptr,&value,&max));CHECK(!ThReadHealth(&actorA,nullptr,&max));
    hp(21);CHECK(!ThReadHealth(&actorA,&value,&max));
    hp(10,0);CHECK(!ThReadHealth(&actorA,&value,&max));
    hp(-1);CHECK(!ThReadHealth(&actorA,&value,&max));
    hp(std::numeric_limits<float>::quiet_NaN());CHECK(!ThReadHealth(&actorA,&value,&max));
    hp(0);CHECK(ThReadHealth(&actorA,&value,&max));CHECK(value==0);
    hp(19);id=7;std::memcpy(attribute+4,&id,4);CHECK(!ThReadHealth(&actorA,&value,&max));
    id=6;std::memcpy(attribute+4,&id,4);
    attr=nullptr;std::memcpy(instance+8,&attr,8);CHECK(!ThReadHealth(&actorA,&value,&max));
    attr=attribute;std::memcpy(instance+8,&attr,8);
    poolOk=false;CHECK(!ThReadHealth(&actorA,&value,&max));poolOk=true;
    containsOk=false;CHECK(!ThReadHealth(&actorA,&value,&max));containsOk=true;
    payloadOk=false;CHECK(!ThReadHealth(&actorA,&value,&max));payloadOk=true;
    contextOk=false;CHECK(!ThReadHealth(&actorA,&value,&max));contextOk=true;
    // Actual worker/snapshot, not a reimplementation.
    hp(20);ThPollTargetInfo();g_tiLookActor=&actorA;tick();
    auto out=snap();CHECK(!out.healthValid && out.totalLoss==0); // unproven full HP
    for(int i=0;i<150;++i) {
        hurtTime=i%40==0?10:0;tick();out=snap();
        CHECK(!out.healthValid && out.totalLoss==0 && out.lossGen==0);
    }
    hurtTime=0;hp(18);tick();out=snap();
    CHECK(out.healthValid && out.health==18 && out.totalLoss==0); // no invented first loss
    hp(16);tick();out=snap();CHECK(out.lastDamage==2 && out.totalLoss==2 && out.lossGen==1);
    double seen=0;CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==2);
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==0);
    // Healing is not damage. Rapid losses aggregate between render frames.
    hp(19);tick();CHECK(snap().totalLoss==2);
    hp(18);tick();hp(16);tick();out=snap();
    CHECK(out.totalLoss==5 && out.lastDamage==2 && out.lossGen==3);
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==3);
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==0);
    // Invalid read clears HP immediately and breaks the damage baseline.
    hp(std::numeric_limits<float>::infinity());tick();CHECK(!snap().healthValid);
    hp(8);tick();out=snap();CHECK(out.healthValid && out.totalLoss==5);
    // A change in maximum can clamp HP without a hit.
    hp(6,6);tick();CHECK(snap().totalLoss==5);
    hp(5,6);tick();CHECK(snap().totalLoss==6);
    hp(0,6);tick();out=snap();CHECK(out.healthValid && out.health==0 && out.lastDamage==5);
    // Snapshot expiry despite the card still being visible.
    clockMs+=251;CHECK(!snap().healthValid);
    hp(4,6);tick();out=snap();CHECK(out.healthValid && out.totalLoss==11);
    // Hurt first, HP delayed: number published even inside hurt dedup window.
    hurtTime=10;tick();auto edgeGen=snap().damageGen;
    hurtTime=9;hp(2,6);tick(80);out=snap();
    CHECK(out.damageGen==edgeGen && out.lastDamage==2 && out.totalLoss==13);
    // Hurt without HP update: trust expires, repeated edges cannot extend it.
    hp(5,6);hurtTime=0;tick();hurtTime=10;tick();
    for(int i=0;i<100;++i){hurtTime=i%2?10:0;tick();}
    out=snap();CHECK(!out.healthValid && out.totalLoss==13);
    hp(3,6);tick();CHECK(snap().healthValid && snap().totalLoss==13);
    hp(2,6);tick();CHECK(snap().totalLoss==14);
    // Change actor: no carried loss/name/HP baseline.
    g_tiLookActor=&actorB;hp(10);hurtTime=0;tick();out=snap();
    CHECK(out.actor==&actorB && out.health==10 && out.totalLoss==0 && out.lossAt==0);
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==0);
    hp(8);tick();CHECK(snap().lastDamage==2);
    // Full HP becomes usable after a real change, unlike never-changing 20/20.
    hp(20);tick();out=snap();CHECK(out.healthValid && out.health==20);
    // SystemDLC-style score bridge: explicit server health text beats a
    // stale 20/20 AttributeInstance, but ordinary nick digits do not.
    std::strcpy(scoreText, "Target 13/20 HP");
    hp(20);tick();out=snap();
    CHECK(out.healthValid && out.health==13 && out.maxHealth==20 && out.healthScoreboard);
    std::strcpy(scoreText, "Target99");
    tick();out=snap();
    CHECK(out.healthValid && out.health==20 && !out.healthScoreboard);
    std::strcpy(scoreText, "Target 7 HP");
    tick();out=snap();
    CHECK(out.healthValid && out.health==7 && out.maxHealth==20 && out.healthScoreboard);
    std::strcpy(scoreText, "Target 20❤");
    tick();out=snap();
    CHECK(out.healthValid && out.health==20 && out.healthScoreboard);
    std::strcpy(scoreText, "Target");
    // TAB-list text is the Bedrock analogue of SystemDLC's LIST scoreboard
    // slot: it feeds the same parser and shows as server-derived HP.
    hp(20);std::strcpy(tabText,"Target 9❤");clockMs+=400;tick();out=snap();
    CHECK(out.healthValid && out.health==9 && out.maxHealth==20 && out.healthScoreboard);
    std::strcpy(tabText,"");clockMs+=400;tick();out=snap();
    CHECK(!out.healthScoreboard);
    // 64-bit uptime: no damage timestamp truncation past 49 days.
    clockMs=(1ULL<<32)+10000;hp(18);tick();hurtTime=10;hp(16);tick();
    out=snap();CHECK(out.damageAt>(1ULL<<32) && out.lossAt>(1ULL<<32));
    CHECK(out.lastDamage==2 && out.healthValid);
    // Stale events are consumed without redisplay.
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,false)==0);
    CHECK(nf::target_health::consumeLoss(out.totalLoss,seen,true)==0);
    // Same pointer after world reset must start from unknown.
    world=nullptr;tick();CHECK(g_tiTarget==nullptr && g_tiLookActor==nullptr);
    CHECK(!g_tiHealthValid && g_tiTotalLoss==0);
    world=&worldObject;tick();g_tiLookActor=&actorB;hp(20);tick();
    CHECK(!snap().healthValid && snap().totalLoss==0);
    // A finite but invalid maximum is never silently replaced by 20.
    hp(10,9);tick();CHECK(!snap().healthValid);
    CHECK(!nf::target_health::fresh(10,20));CHECK(!nf::target_health::fresh(0,0));
    // SystemDLC-style display: the estimate stays visible for the whole
    // tracking session while no exact source exists, and reacts to hits.
    g_tiLookActor=&actorC;hp(20);hurtTime=0;std::strcpy(scoreText,"Target");std::strcpy(tabText,"");
    clockMs+=400;tick();out=snap();
    CHECK(out.healthEstimated && !out.healthValid && out.estimatedHealth>19.5f && out.estimatedHealth<=20.0f);
    for(int i=0;i<400;++i)tick(16);
    out=snap();CHECK(out.healthEstimated && !out.healthValid); // no 1500 ms expiry
    g_tiPendingAttack=&actorC;g_tiPendingAttackAt=clockMs;
    hurtTime=10;tick();hurtTime=0;tick();out=snap();
    CHECK(out.estimatedHealth<19.5f && out.estimatedDamage==1.0f);
    // R21c: configurable step and a 1.0 floor (never a fake "dead" 0).
    g_tiEstStepPermille=0;
    g_tiPendingAttack=&actorC;g_tiPendingAttackAt=clockMs;
    hurtTime=10;tick();hurtTime=0;tick();out=snap();
    CHECK(out.estimatedHealth==19.0f); // step 0: no further decay
    g_tiEstStepPermille=3000;
    g_tiPendingAttack=&actorC;g_tiPendingAttackAt=clockMs;
    hurtTime=10;tick();hurtTime=0;tick();out=snap();
    CHECK(out.estimatedHealth==16.0f && out.estimatedDamage==3.0f);
    for(int i=0;i<10;++i){g_tiPendingAttack=&actorC;g_tiPendingAttackAt=clockMs;hurtTime=10;tick();hurtTime=0;tick();}
    out=snap();CHECK(out.estimatedHealth==1.0f); // floor: survives a long fight
    g_tiEstStepPermille=1000;
    // Bounded pure-state sweep across fractional HP, heals, invalid gaps.
    for(int i=1;i<=1000;++i) {
        nf::target_health::State s;
        float start=(i%100+1)/10.0f;
        s.sample(100,true,start,20,false);
        s.sample(108,true,start/2,20,false);
        CHECK(s.healthValid && std::fabs(s.lost-start/2)<0.0001f);
        auto total=s.totalLoss;
        s.sample(116,false,0,0,true);CHECK(!s.healthValid);
        s.sample(124,true,start/4,20,false);CHECK(s.totalLoss==total && s.lost==0);
        s.reset();CHECK(!s.have && s.totalLoss==0 && s.lossGen==0);
    }
    std::printf("Target HUD R17: %d assertions passed (mock game, ASan/UBSan).\n",checks);
}
"""

# Integration guards for the production render path.
assert 'm_lastHp' not in hud
assert 'nf::target_health::consumeLoss(info.totalLoss' in hud
assert 'std::max(bw * m_hpShown, bh)' not in hud
assert 'if (hpShownValid && m_hp > 0.0f && fw > 0.01f)' in hud
assert 'sizeof(hpText), "?"' in hud
assert 'InterlockedExchange(&g_tiDamageAt' not in src
assert 'g_tiHealthValid && nf::target_health::fresh(now, g_tiHealthAt)' in src
assert 'nf::target_health::validPair(cur, mx)' in reader
assert 'static bool ThReadSynchedHealth' in src
assert 'static bool ThReadTabName' in src
assert 'g_hitboxWorldRegistry != nullptr' in src
code = prefix + globals1 + globals2 + reader + synced_reader + struct + worker + snapshot + tests
with tempfile.TemporaryDirectory(prefix="nightfull_r17_") as temp:
    cpp=Path(temp)/"target.cpp"
    exe=Path(temp)/"target"
    cpp.write_text(code,encoding="utf-8")
    subprocess.run(["g++","-std=c++20","-O1","-g","-fno-omit-frame-pointer",
                    "-fsanitize=address,undefined","-fno-pie","-no-pie",
                    "-I",str(root/"src"),str(cpp),"-o",str(exe)],check=True)
    env=dict(os.environ,ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
             UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
    subprocess.run([str(exe)],check=True,env=env)
