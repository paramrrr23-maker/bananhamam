namespace nf {
namespace overlay {
static void CooldownSample();
namespace {
static int JavaGamePatch();
static int JavaGamePatch() { return 111; }
static int JavaPlaceAllSlot() { return JavaGamePatch(); }
void SetupCallRegression() { CooldownSample(); (void)JavaPlaceAllSlot(); }
}
static void CooldownSampleImpl() { (void)JavaGamePatch(); }
static void CooldownSample() { CooldownSampleImpl(); }
void RunNamespaceRegression() { SetupCallRegression(); }
}
}
int main() { nf::overlay::RunNamespaceRegression(); }
