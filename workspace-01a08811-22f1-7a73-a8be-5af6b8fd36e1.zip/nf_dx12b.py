#!/usr/bin/env python3
"""D3D12 diagnosis round 2: log swapchain format, create device objects
explicitly (capture the BOOL), bind the SRV heap (required, was missing),
check list-reset HRESULTs."""
import sys

PATH = "/home/user/nightfull/src/overlay/overlay.cpp"

pairs = [
    # (b) explicit device-object creation with result check
    ("""        if (!ImGui_ImplDX12_Init(&init_info)) {
            ReleaseD3D12(); return false;
        }
        g_backend12 = true;""",
     """        if (!ImGui_ImplDX12_Init(&init_info)) {
            ReleaseD3D12(); return false;
        }
        g_backend12 = true;
        // Create PSO/root-signature/font-texture NOW (not lazily on the first
        // NewFrame) so a failure is visible here instead of mid-frame.
        if (!ImGui_ImplDX12_CreateDeviceObjects()) {
            LOG_ERROR("overlay: DX12 CreateDeviceObjects failed - aborting D3D12 path");
            ReleaseD3D12(); return false;
        }
        LOG_INFO("overlay: DX12 device objects ready");"""),
    # (a) swapchain format details in the engage log
    ("""    LOG_INFO("overlay: D3D12 path engaged (%d buffers)", count);""",
     """    LOG_INFO("overlay: D3D12 path engaged (%d buffers, fmt=%d %ux%u sample=%u effect=%d)",
             count, (int)sd.BufferDesc.Format, sd.BufferDesc.Width, sd.BufferDesc.Height,
             sd.SampleDesc.Count, (int)sd.SwapEffect);"""),
    # (c) bind our SRV heap (backend requires app-side binding; fonts sample garbage without it)
    ("""    if (dtrace) LOG_INFO("trace: d3d12 imgui render done");
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12list);""",
     """    if (dtrace) LOG_INFO("trace: d3d12 imgui render done");
    ID3D12DescriptorHeap* heaps[] = { g_d12srvHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12list);"""),
    # (d) list/allocator reset result (log once)
    ("""    static int d12fno = 0;
    const bool dtrace = ++d12fno <= 3;
    g_d12alloc->Reset();
    g_d12list->Reset(g_d12alloc, nullptr);
    if (dtrace) LOG_INFO("trace: d3d12 list reset");""",
     """    static int d12fno = 0;
    const bool dtrace = ++d12fno <= 3;
    static bool resetErrLogged = false;
    const HRESULT hrAlloc = g_d12alloc->Reset();
    const HRESULT hrList = g_d12list->Reset(g_d12alloc, nullptr);
    if ((FAILED(hrAlloc) || FAILED(hrList)) && !resetErrLogged) {
        resetErrLogged = true;
        LOG_ERROR("overlay: D3D12 allocator/list reset failed (%08X/%08X)", hrAlloc, hrList);
    }
    if (dtrace) LOG_INFO("trace: d3d12 list reset");"""),
]

with open(PATH, encoding="utf-8") as f:
    content = f.read()
for i, (old, new) in enumerate(pairs):
    n = content.count(old)
    if n != 1:
        print(f"FAIL pair {i}: found {n} (expected 1)")
        print("--- old ---")
        print(old)
        sys.exit(1)
    content = content.replace(old, new, 1)
    print(f"ok pair {i}")
with open(PATH, "w", encoding="utf-8", newline="") as f:
    f.write(content)
print("ALL OK")
