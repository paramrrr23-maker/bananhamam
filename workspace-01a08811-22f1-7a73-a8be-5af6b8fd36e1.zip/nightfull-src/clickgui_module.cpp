// clickgui_module.cpp - the ClickGui module (Solstice's ClickGui.hpp).
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/visual/clickgui_module.h"

#include <string>
#include <vector>

namespace modules {

ClickGuiModule* ClickGuiModule::s_instance = nullptr;

ClickGuiModule::ClickGuiModule()
    : Module("Settings", "General", "Configure the Nightfull ClickGUI")
{
    s_instance = this;

    m_animation = addSetting<EnumSetting>("Animation", "The animation of the ClickGui.", ANIM_GLASS,
                                          std::vector<std::string>{ "Glass", "Zoom", "Bounce" });
    m_blurStrength = addSetting<NumberSetting>("Blur Strength", "Backdrop glass intensity.",
                                               7.0f, 0.0f, 20.0f, 0.1f);
    m_easeSpeed = addSetting<NumberSetting>("Ease Speed", "Speed of menu transitions.",
                                            18.0f, 5.0f, 20.0f, 0.1f);
    m_midclickRounding = addSetting<NumberSetting>("Midclick Rounding",
                                                   "Step used by middle-click slider snapping.",
                                                   1.0f, 0.01f, 1.0f, 0.01f);
    m_panelOpacity = addSetting<NumberSetting>("Panel Opacity", "Opacity of the main glass panel.",
                                               0.94f, 0.65f, 1.0f, 0.01f);
    m_borderOpacity = addSetting<NumberSetting>("Border Opacity", "Opacity of fine panel borders.",
                                                0.42f, 0.1f, 1.0f, 0.01f);
    m_cornerRadius = addSetting<NumberSetting>("Corner Radius", "Rounded corner size.",
                                               18.0f, 6.0f, 28.0f, 1.0f);
    m_glass = addSetting<BoolSetting>("Glass", "Frosted glass panels over the game.",
                                      true);
    m_transparency = addSetting<NumberSetting>("Transparency",
                                               "How see-through the glass panels are.",
                                               0.55f, 0.0f, 1.0f, 0.05f);
}

} // namespace modules
