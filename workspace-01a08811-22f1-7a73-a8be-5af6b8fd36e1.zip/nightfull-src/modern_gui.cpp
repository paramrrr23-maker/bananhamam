// modern_gui.cpp - Solstice's ClickGUI panel engine.
//
// Faithful port of Solstice's src/Features/GUI/ModernDropdown.cpp. Geometry,
// colours, easing speeds and draw order are Solstice's; only two things are
// different, both deliberate:
//
//   1. Solstice's colour picker REVERTS the colour when you press its Close
//      button (it snapshots the colour before the picker edits it and writes
//      that stale snapshot back on close). Here Close keeps what you picked.
//   2. Solstice draws its category icon from a bundled icon font
//      ("tenacity_icons_large"). No such font ships with this project, so a
//      themed dot is drawn in its place.
//
// Nothing here reads or writes the game; it only draws and edits local state.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "ui/modern_gui.h"

#include "modules/module.h"
#include "modules/module_guard.h"
#include "modules/module_manager.h"
#include "modules/setting.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"
#include "utils/logger.h"
#include "overlay.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace ui {

using modules::ModulePhaseGuard;
using modules::BoolSetting;
using modules::ColorSetting;
using modules::EnumSetting;
using modules::Module;
using modules::NumberSetting;
using modules::Setting;
using modules::SettingType;

const ImColor ModernGui::textColor      = ImColor(255, 255, 255);
const ImColor ModernGui::darkBlack      = ImColor(24, 24, 24);
const ImColor ModernGui::mainColor      = ImColor(22, 22, 22);
const ImColor ModernGui::grayColor      = ImColor(40, 40, 40);
const ImColor ModernGui::enumBackGround = ImColor(30, 30, 30);

namespace {

// Solstice's ModuleCategoryNames order.
const char* kSolsticeCategories[] = { "Combat", "Movement", "Player", "Visual", "Misc" };

std::vector<std::string>& Categories() {
    static std::vector<std::string> cats;
    static bool built = false;
    if (built) return cats;
    built = true;

    // Solstice's five, in Solstice's order, but only if a module uses them.
    for (const char* c : kSolsticeCategories) {
        for (const auto& m : modules::Modules().modules()) {
            if (std::strcmp(m->category(), c) == 0) {
                cats.push_back(c);
                break;
            }
        }
    }
    // Anything a custom module registers outside those five still shows up.
    for (const auto& m : modules::Modules().modules()) {
        bool known = false;
        for (const std::string& c : cats) {
            if (c == m->category()) { known = true; break; }
        }
        if (!known) cats.push_back(m->category());
    }
    return cats;
}

void CollectModules(const std::string& cat, std::vector<Module*>& out) {
    out.clear();
    for (const auto& m : modules::Modules().modules())
        if (cat == m->category())
            out.push_back(m.get());
}

std::string ToLower(std::string s) {
    for (size_t i = 0; i < s.size(); i++)
        s[i] = (char)tolower((unsigned char)s[i]);
    return s;
}

bool MatchesSearch(const Module* m, const std::string& needle) {
    if (needle.empty()) return true;
    const std::string name = ToLower(m->name());
    const std::string cat  = ToLower(m->category());
    return name.find(needle) != std::string::npos ||
           cat.find(needle)  != std::string::npos;
}

// Solstice's ImVec4::scaleToPoint around the screen centre (panel + rows).
ImVec4 ScaleScreen(const ImVec4& r, const ImVec2& screen, float amount) {
    return gui::ScaleToPoint(r, ImVec4(screen.x * 0.5f, screen.y * 0.5f,
                                       screen.x * 0.5f, screen.y * 0.5f), amount);
}

// Solstice scales SETTING rows on the Y axis only, toward the screen's middle
// while keeping the row's own X range - that is what keeps settings glued
// under their module while the whole panel zooms in from the centre.
ImVec4 ScaleRows(const ImVec4& r, float left, float right,
                 const ImVec2& screen, float amount) {
    return gui::ScaleToPoint(r, ImVec4(left, screen.y * 0.5f,
                                       right, screen.y * 0.5f), amount);
}

} // namespace

// ======================== construction ========================
ModernGui::ModernGui() {
    std::memset(m_searchBuf, 0, sizeof(m_searchBuf));
}

void ModernGui::onWindowResizeEvent() {
    m_resetPosition = true;
    m_lastReset     = (unsigned long long)GetTickCount64();
}

void ModernGui::restoreLayout(const std::vector<config::PanelPos>& layout) {
    m_pendingLayout = layout;
}

std::vector<config::PanelPos> ModernGui::currentLayout() const {
    std::vector<config::PanelPos> out;
    out.reserve(m_catPositions.size());
    for (const CategoryPosition& p : m_catPositions) {
        config::PanelPos pos;
        pos.x        = p.x;
        pos.y        = p.y;
        pos.extended = p.isExtended;
        out.push_back(pos);
    }
    return out;
}

// ======================== search box ========================
void ModernGui::drawSearchBox(const ImVec2& screen, float animation) {
    const float w = 300.0f;
    const float h = 30.0f;
    const ImVec4 r = ImVec4(screen.x * 0.5f - w * 0.5f, 24.0f,
                            screen.x * 0.5f + w * 0.5f, 24.0f + h);

    const bool capture = ImGui::GetIO().WantCaptureMouse;

    if (ImGui::IsMouseClicked(0) && !capture)
        m_searchFocused = gui::IsMouseOver(r);

    if (keys::TextInput(m_searchBuf, sizeof(m_searchBuf),
                        m_searchFocused && !m_isBinding && !m_isBoolSettingBinding)) {
        // Typing invalidates nothing - the filter is recomputed next frame.
    }

    gui::FillRect(r, ModernGui::darkBlack, animation, 10.0f);

    // Focused: a themed underline, so it is obvious where typing goes.
    if (m_searchFocused) {
        ImColor accent = gui::GetThemedColor(0);
        accent.Value.w = 1.0f;
        gui::FillRect(ImVec4(r.x, r.w - 2.0f, r.z, r.w),
                      accent, animation, 1.0f);
    }

    const bool  empty = (m_searchBuf[0] == 0);
    const char* shown = empty ? "Search modules..." : m_searchBuf;
    const float ts    = 0.85f;
    const float th    = gui::GetTextHeight(ts);
    const float ty    = r.y + (gui::RectH(r) - th) * 0.5f;

    gui::DrawText(ImVec2(r.x + 10.0f, ty), shown,
                  empty ? ImColor(120, 120, 120) : ModernGui::textColor,
                  ts, animation, true);

    // Caret: blinks at ~2 Hz while focused.
    if (m_searchFocused) {
        const bool blink = ((GetTickCount64() / 500) % 2) == 0;
        if (blink) {
            const float cw = gui::GetTextWidth(shown, ts);
            gui::FillRect(ImVec4(r.x + 12.0f + cw, ty + 2.0f,
                                 r.x + 13.0f + cw, ty + th - 2.0f),
                          ModernGui::textColor, animation * 0.8f);
        }
    }
}

// ======================== colour picker ========================
void ModernGui::drawColorPicker(const ImVec2& screen, float animation) {
    if (!m_displayColorPicker || !m_lastColorSetting) return;

    const float w = 400.0f, h = 400.0f;
    const ImVec2 pos(screen.x * 0.5f - w * 0.5f, screen.y * 0.5f - h * 0.5f);

    ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);

    ImGui::Begin("##cg_color", &m_displayColorPicker,
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoTitleBar);
    {
        ImGui::ColorPicker4("##picker", m_lastColorSetting->mValue,
                            ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoAlpha);
        if (ImGui::Button("Close", ImVec2(-1.0f, 0.0f)))
            m_displayColorPicker = false;   // keeps the picked colour (see file header)
    }
    ImGui::End();

    // Clicking outside the picker closes it (Solstice does this too).
    if (ImGui::IsMouseClicked(0) && !ImGui::GetIO().WantCaptureMouse &&
        !gui::IsMouseOver(ImVec4(pos.x, pos.y, pos.x + w, pos.y + h))) {
        m_displayColorPicker = false;
    }
}

// ======================== tooltip ========================
void ModernGui::drawTooltip(const std::string& tooltip, const ImVec2& screen,
                            float animation, float inScale) {
    if (tooltip.empty()) return;

    const float ts   = inScale * 0.8f;
    const float tw   = gui::GetTextWidth(tooltip.c_str(), ts);
    const float th   = gui::GetTextHeight(ts);
    const float pad  = 2.5f;
    const float off  = 8.0f;
    const ImVec2 mp  = gui::GetMousePos();

    ImVec4 r = ImVec4(mp.x + off - pad,
                      mp.y + th * 0.5f - th - pad,
                      mp.x + off + tw + pad * 2.0f,
                      mp.y + th * 0.5f + pad);

    // Solstice fades the tooltip out while a mouse button is held.
    static float alpha = 1.0f;
    if (ImGui::IsMouseDown(0) || ImGui::IsMouseDown(2))
        alpha = gui::Animate(0.0f, alpha, gui::GetDeltaTime() * 10.0f);
    else
        alpha = gui::Animate(1.0f, alpha, gui::GetDeltaTime() * 10.0f);

    if (alpha < 0.01f) return;

    // Keep it on screen instead of letting it run off the right/bottom edge.
    if (r.z > screen.x - 4.0f) { const float d = r.z - (screen.x - 4.0f); r.x -= d; r.z -= d; }
    if (r.w > screen.y - 4.0f) { const float d = r.w - (screen.y - 4.0f); r.y -= d; r.w -= d; }
    if (r.x < 4.0f)            { const float d = 4.0f - r.x;              r.x += d; r.z += d; }
    if (r.y < 4.0f)            { const float d = 4.0f - r.y;              r.y += d; r.w += d; }

    gui::FillRect(r, ImColor(20, 20, 20), animation * alpha, 0.0f,
                  ImGui::GetForegroundDrawList());
    gui::DrawText(ImVec2(r.x + pad, r.y + pad), tooltip.c_str(),
                  ModernGui::textColor, ts * alpha, animation * alpha, true,
                  ImGui::GetForegroundDrawList());
}

// ======================== main render ========================
void ModernGui::render(float animation, float inScale, int& scrollDirection,
                       float midclickRounding, bool isPressingShift,
                       bool isEnabled) {
    (void)isPressingShift; // Solstice passes it but never uses it either.

    const ImVec2 screen = gui::GetScreenSize();
    const float  dt     = gui::GetDeltaTime();
    ImDrawList*  draw   = ImGui::GetBackgroundDrawList();

    // --- search box (Solstice: an ImGui InputText at the top of the screen) -
    drawSearchBox(screen, animation);
    const std::string needle = ToLower(m_searchBuf);

    // --- re-centre after a window resize (Solstice: resetPosition) ---------
    if (m_resetPosition && (unsigned long long)GetTickCount64() - m_lastReset > 100) {
        m_catPositions.clear();
        m_resetPosition = false;
    }

    // --- panels -------------------------------------------------------------
    // The scrim and the bottom glow are drawn by the ClickGui module (they
    // belong to every tab, not just to the module list).
    std::vector<std::string>& categories = Categories();

    if (m_catPositions.empty() && isEnabled) {
        if (!m_layoutApplied) {
            m_layoutApplied = true;
            // Saved layout, but only if it still matches the category count.
            if (m_pendingLayout.size() == categories.size()) {
                for (size_t i = 0; i < categories.size(); i++) {
                    CategoryPosition p;
                    p.x          = m_pendingLayout[i].x;
                    p.y          = m_pendingLayout[i].y;
                    p.isExtended = m_pendingLayout[i].extended;
                    m_catPositions.push_back(p);
                }
            }
        }

        if (m_catPositions.empty()) {
            float x = screen.x * 0.5f -
                      (categories.size() * (ModernGui::catWidth + ModernGui::catGap)) * 0.5f;
            for (size_t i = 0; i < categories.size(); i++) {
                CategoryPosition p;
                p.x = std::round(x / 2.0f) * 2.0f;
                p.y = ModernGui::catGap * 2.0f;
                m_catPositions.push_back(p);
                x += ModernGui::catWidth + ModernGui::catGap;
            }
        }
    }

    // Menu closed (this still runs during the fade-out): drop every transient
    // interaction state. Without this, a search string that filtered every
    // module out, or a half-finished keybind capture, silently survived into
    // the next session and the menu reopened looking empty.
    if (!isEnabled) {
        m_displayColorPicker    = false;
        m_searchFocused         = false;
        m_isBinding             = false;
        m_isBoolSettingBinding  = false;
        m_lastMod               = nullptr;
        m_lastBoolSetting       = nullptr;
        if (m_searchBuf[0] != 0) {
            std::memset(m_searchBuf, 0, sizeof(m_searchBuf));
            m_catPositions.clear(); // re-layout with the full module list
        }
    }

    std::string tooltip;

    if (!m_catPositions.empty()) {
        std::vector<Module*> mods;

        for (size_t i = 0; i < categories.size() && i < m_catPositions.size(); i++) {
            CategoryPosition& cp = m_catPositions[i];

            CollectModules(categories[i], mods);

            // --- search filter (Solstice: filteredMods) ----------------------
            std::vector<Module*> shown;
            shown.reserve(mods.size());
            for (Module* m : mods)
                if (MatchesSearch(m, needle)) shown.push_back(m);

            const float modWidth  = ModernGui::catWidth;
            const float modHeight = ModernGui::catHeight;
            float       moduleY   = -cp.yOffset;

            // --- panel rects -------------------------------------------------
            ImVec4 catRect = ScaleScreen(
                ImVec4(cp.x, cp.y, cp.x + ModernGui::catWidth, cp.y + ModernGui::catHeight),
                screen, inScale);

            // Height of every settings row that is (partially) expanded.
            float settingsHeight = 0.0f;
            for (Module* m : shown) {
                for (const auto& s : m->settings()) {
                    if (!s->mIsVisible()) continue;
                    settingsHeight = gui::Lerp(settingsHeight, settingsHeight + modHeight, m->cAnim);
                    if (s->mType == SettingType::Enum && s->enumSlide > 0.01f) {
                        EnumSetting* es = static_cast<EnumSetting*>(s.get());
                        for (size_t j = 0; j < es->mValues.size(); j++)
                            settingsHeight = gui::Lerp(settingsHeight, settingsHeight + modHeight,
                                                       s->enumSlide);
                    }
                }
            }

            const float catWindowHeight = ModernGui::catHeight +
                                          modHeight * (float)shown.size() + settingsHeight;

            ImVec4 catWindow = ScaleScreen(
                ImVec4(cp.x, cp.y, cp.x + ModernGui::catWidth,
                       cp.y + moduleY + catWindowHeight),
                screen, inScale);

            ImColor rgb = gui::GetThemedColor((float)i * 20.0f);

            // --- scrolling (Solstice: wheel moves a whole row at a time) -----
            if (gui::IsMouseOver(catWindow) && cp.isExtended) {
                if (scrollDirection > 0) {
                    cp.scrollEase += (float)scrollDirection * ModernGui::catHeight;
                    const float maxScroll = catWindowHeight - modHeight * 2.0f;
                    if (cp.scrollEase > maxScroll) cp.scrollEase = maxScroll;
                } else if (scrollDirection < 0) {
                    cp.scrollEase += (float)scrollDirection * ModernGui::catHeight;
                    if (cp.scrollEase < 0.0f) cp.scrollEase = 0.0f;
                }
                scrollDirection = 0;
            }

            if (!cp.isExtended) {
                cp.scrollEase  = catWindowHeight - ModernGui::catHeight;
                cp.wasExtended = false;
            } else if (!cp.wasExtended) {
                cp.scrollEase  = 0.0f;
                cp.wasExtended = true;
            }

            cp.yOffset = gui::Animate(cp.scrollEase, cp.yOffset, dt * 10.5f);

            // Clip the rows so they cannot paint over the header or above it.
            const ImVec4 clipRect = ImVec4(catRect.x, catRect.w, catRect.z, screen.y);
            draw->PushClipRect(ImVec2(clipRect.x, clipRect.y), ImVec2(clipRect.z, clipRect.w), true);

            const bool interactive = isEnabled && !m_displayColorPicker &&
                                     !ImGui::GetIO().WantCaptureMouse;

            bool moduleToggled = false;

            for (size_t mi = 0; mi < shown.size(); mi++) {
                Module* m = shown[mi];

                ImDrawFlags flags = ImDrawFlags_RoundCornersBottom;
                float       radius = 0.0f;
                const bool  endMod = (mi + 1 == shown.size());
                if (endMod) radius = 15.0f * (1.0f - m->cAnim);

                rgb = gui::GetThemedColor(moduleY * 2.0f);

                ImVec4 modRect = ScaleScreen(
                    ImVec4(cp.x, cp.y + ModernGui::catHeight + moduleY,
                           cp.x + modWidth, cp.y + ModernGui::catHeight + moduleY + modHeight),
                    screen, inScale);
                modRect.y = std::floor(modRect.y);
                modRect.x = std::floor(modRect.x);

                // --- settings expand animation -------------------------------
                const float targetAnim = m->showSettings ? 1.0f : 0.0f;
                m->cAnim = gui::Animate(targetAnim, m->cAnim, dt * 12.5f);
                m->cAnim = gui::Clamp(m->cAnim, 0.0f, 1.0f);

                // --- settings rows -------------------------------------------
                if (m->cAnim > 0.001f) {
                    Setting* lastDragged = nullptr;
                    size_t   sIndex = 0;

                    for (const auto& sPtr : m->settings()) {
                        Setting* setting = sPtr.get();

                        if (!setting->mIsVisible()) {
                            setting->sliderEase = 0.0f;
                            setting->enumSlide  = 0.0f;
                            continue;
                        }

                        float sRadius = 0.0f;
                        if (endMod && sIndex + 1 == m->settings().size()) sRadius = 15.0f;
                        else if (endMod) sRadius = 15.0f * (1.0f - m->cAnim);

                        const bool  endSetting = (sIndex + 1 == m->settings().size());
                        const float setPadding = endSetting ? (-2.0f * animation) : 0.0f;

                        ImColor sRgb = gui::GetThemedColor(moduleY * 2.0f);
                        sRgb.Value.w = animation;

                        const std::string setName = gui::ApplyNaming(setting->mName.c_str());
                        const float       textH   = gui::GetTextHeight(inScale);

                        switch (setting->mType) {

                        // ---------------- Bool ----------------
                        case SettingType::Bool: {
                            BoolSetting* bs = static_cast<BoolSetting*>(setting);
                            moduleY = gui::Lerp(moduleY, moduleY + modHeight, m->cAnim);

                            ImVec4 rect = ScaleRows(
                                ImVec4(modRect.x, cp.y + ModernGui::catHeight + moduleY + setPadding,
                                       modRect.z, cp.y + ModernGui::catHeight + moduleY + modHeight),
                                modRect.x, modRect.z, screen, inScale);
                            rect.y = std::floor(rect.y);
                            if (rect.y < modRect.y) rect.y = modRect.y;

                            if (rect.y > catRect.y + 0.5f) {
                                gui::FillRect(rect, ModernGui::enumBackGround, animation, sRadius,
                                              draw, ImDrawFlags_RoundCornersBottom);

                                if (gui::IsMouseOver(rect) && interactive && cp.isExtended) {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseClicked(0) && m->showSettings)
                                        bs->mValue = !bs->mValue;
                                    if (ImGui::IsMouseClicked(2) && cp.isExtended) {
                                        m_lastBoolSetting     = bs;
                                        m_isBoolSettingBinding = true;
                                    }
                                }

                                setting->boolScale = gui::Animate(bs->mValue ? 1.0f : 0.0f,
                                                                  setting->boolScale, dt * 10.0f);

                                const float cY = rect.y + (gui::RectH(rect) - textH) * 0.5f;

                                // Solstice: shadow disc behind the toggle, tinted
                                // by the theme as it animates on.
                                const ImColor shadowCol =
                                    gui::LerpColor(ImColor(15, 15, 15), sRgb, setting->boolScale);
                                gui::FillShadowCircle(
                                    ImVec2(rect.z - 12.0f, cY + 7.5f), 5.0f, shadowCol,
                                    animation * m->cAnim, 12.0f, 12);

                                // Solstice: the check mark is revealed left to
                                // right by clipping it to boolScale.
                                const ImVec4 boolRect = ImVec4(rect.z - 23.5f, cY - 2.5f,
                                                               rect.z - 5.0f, cY + 17.5f);
                                const float  rectXDiff = gui::RectW(boolRect);

                                if (setting->boolScale > 0.01f) {
                                    ImVec4 br = boolRect;
                                    if (br.y < modRect.w) br.y = modRect.w;

                                    ImGui::GetForegroundDrawList()->PushClipRect(
                                        ImVec2(br.x, br.y),
                                        ImVec2(br.x + rectXDiff * setting->boolScale, br.w), true);
                                    gui::DrawCheckMark(ImVec2(gui::RectCenter(br).x - 4.0f * animation,
                                                              gui::RectCenter(br).y - 1.0f * animation),
                                                       1.3f * animation, sRgb, m->cAnim * animation);
                                    ImGui::GetForegroundDrawList()->PopClipRect();
                                }

                                gui::DrawText(ImVec2(rect.x + 5.0f, cY), setName.c_str(),
                                              ModernGui::textColor, inScale, animation, true);

                                // Bound key (Solstice has this commented out;
                                // shown here because keybinds actually fire).
                                if (setting->mKey > 0) {
                                    const char* kn = keys::Name(setting->mKey);
                                    const float kw = gui::GetTextWidth(kn, inScale * 0.7f);
                                    gui::DrawText(ImVec2(rect.z - 32.0f - kw, cY + 2.0f), kn,
                                                  ImColor(170, 170, 170), inScale * 0.7f,
                                                  animation, true);
                                }
                            }
                            break;
                        }

                        // ---------------- Enum ----------------
                        case SettingType::Enum: {
                            EnumSetting* es = static_cast<EnumSetting*>(setting);
                            const int    nVals = (int)es->mValues.size();

                            moduleY = gui::Lerp(moduleY, moduleY + modHeight, m->cAnim);

                            ImVec4 rect = ScaleRows(
                                ImVec4(modRect.x, cp.y + ModernGui::catHeight + moduleY + setPadding,
                                       modRect.z, cp.y + ModernGui::catHeight + moduleY + modHeight),
                                modRect.x, modRect.z, screen, inScale);
                            rect.y = std::floor(rect.y);
                            if (rect.y < modRect.y) rect.y = modRect.y;

                            const float slideTarget =
                                (setting->enumExtended && m->showSettings) ? 1.0f : 0.0f;
                            setting->enumSlide = gui::Animate(slideTarget, setting->enumSlide, dt * 10.0f);
                            setting->enumSlide = gui::Clamp(setting->enumSlide, 0.0f, 1.0f);

                            // --- expanded value list, below the header row ---
                            if (setting->enumSlide > 0.001f) {
                                for (int j = 0; j < nVals; j++) {
                                    moduleY = gui::Lerp(moduleY, moduleY + modHeight, setting->enumSlide);

                                    ImVec4 r2 = ScaleRows(
                                        ImVec4(modRect.x, cp.y + ModernGui::catHeight + moduleY + setPadding,
                                               modRect.z, cp.y + ModernGui::catHeight + moduleY + modHeight),
                                        modRect.x, modRect.z, screen, inScale);

                                    if (r2.y <= catRect.y + 0.5f) continue;

                                    const float cY  = r2.y + (gui::RectH(r2) - textH) * 0.5f;
                                    const char* val = es->mValues[j].c_str();

                                    gui::FillRect(r2, ImColor(20, 20, 20), animation, sRadius,
                                                  draw, ImDrawFlags_RoundCornersBottom);
                                    if (es->mValue == j)
                                        gui::FillRect(ImVec4(r2.x, r2.y, r2.x + 1.5f, r2.w),
                                                      sRgb, animation);

                                    if (gui::IsMouseOver(r2) && ImGui::IsMouseClicked(0) &&
                                        interactive && m->showSettings)
                                        es->setValue(j);

                                    gui::DrawText(ImVec2(r2.x + 5.0f, cY), val,
                                                  ModernGui::textColor, inScale, animation, true);
                                }
                            }

                            // --- header row: name left, current value right ---
                            if (rect.y > catRect.y + 0.5f) {
                                gui::FillRect(rect, ModernGui::enumBackGround, animation, sRadius,
                                              draw, ImDrawFlags_RoundCornersBottom);

                                if (gui::IsMouseOver(rect) && interactive && cp.isExtended) {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseClicked(0) && m->showSettings && nVals > 0)
                                        es->setValue(es->mValue + 1);
                                    else if (ImGui::IsMouseClicked(1) && m->showSettings)
                                        setting->enumExtended = !setting->enumExtended;
                                }

                                const float  cY  = rect.y + (gui::RectH(rect) - textH) * 0.5f;
                                const char*  val = es->current();
                                const float  vw  = gui::GetTextWidth(val, inScale);

                                gui::DrawText(ImVec2(rect.x + 5.0f, cY), setName.c_str(),
                                              ModernGui::textColor, inScale, animation, true);
                                gui::DrawText(ImVec2(rect.z - 5.0f - vw, cY), val,
                                              ImColor(170, 170, 170), inScale, animation, true);
                            }

                            // Soft shadow under the open dropdown.
                            if (rect.y > catRect.y - modHeight) {
                                gui::FillGradient(
                                    ImVec4(rect.x, rect.w, rect.z,
                                           rect.w + 10.0f * setting->enumSlide * animation),
                                    ImColor(0, 0, 0), ImColor(0, 0, 0),
                                    0.0f, 0.55f * animation);
                            }
                            break;
                        }

                        // ---------------- Number ----------------
                        case SettingType::Number: {
                            NumberSetting* ns = static_cast<NumberSetting*>(setting);
                            const float value = ns->mValue;
                            const float min   = ns->mMin;
                            const float max   = ns->mMax;

                            char        vbuf[16];
                            sprintf_s(vbuf, "%.2f", value);

                            moduleY = gui::Lerp(moduleY, moduleY + modHeight, m->cAnim);

                            ImVec4 bgRect = ScaleRows(
                                ImVec4(modRect.x, cp.y + ModernGui::catHeight + moduleY,
                                       modRect.z, cp.y + ModernGui::catHeight + moduleY + modHeight),
                                modRect.x, modRect.z, screen, inScale);
                            bgRect.y = std::floor(bgRect.y);
                            if (bgRect.y < modRect.y) bgRect.y = modRect.y;

                            ImVec4 rect = ScaleRows(
                                ImVec4(modRect.x + 7.0f,
                                       cp.y + ModernGui::catHeight + moduleY + setPadding,
                                       modRect.z - 7.0f,
                                       cp.y + ModernGui::catHeight + moduleY + modHeight),
                                modRect.x, modRect.z, screen, inScale);
                            rect.y = std::floor(rect.y);
                            if (rect.y < modRect.y) rect.y = modRect.y;

                            // Knob shrinks a touch while the slider is held.
                            static float clickAnimation = 1.0f;
                            if (ImGui::IsMouseDown(0) && gui::IsMouseOver(rect) &&
                                !ImGui::GetIO().WantCaptureMouse)
                                clickAnimation = gui::Animate(0.60f, clickAnimation, dt * 10.0f);
                            else
                                clickAnimation = gui::Animate(1.0f, clickAnimation, dt * 10.0f);

                            if (bgRect.y > catRect.y + 0.5f) {
                                gui::FillRect(bgRect, ModernGui::enumBackGround, animation, sRadius,
                                              draw, ImDrawFlags_RoundCornersBottom);

                                const float span = (max - min);
                                const float sliderPos = (span > 0.0f)
                                    ? (value - min) / span * gui::RectW(rect) : 0.0f;

                                setting->sliderEase = gui::Animate(sliderPos, setting->sliderEase,
                                                                   dt * 10.0f);
                                setting->sliderEase = gui::Clamp(setting->sliderEase, 0.0f,
                                                                 gui::RectW(rect));

                                // --- dragging: left = free, middle = snapped -
                                if (gui::IsMouseOver(rect) && interactive && cp.isExtended) {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseDown(0) || ImGui::IsMouseDown(2)) {
                                        setting->isDragging = true;
                                        lastDragged         = setting;
                                    }
                                }

                                if (ImGui::IsMouseDown(0) && setting->isDragging && isEnabled) {
                                    if (lastDragged != setting) {
                                        setting->isDragging = false;
                                    } else {
                                        const float t = (gui::GetMousePos().x - rect.x) /
                                                        gui::RectW(rect);
                                        ns->setValue(gui::Clamp(min + t * span, min, max));
                                    }
                                } else if (ImGui::IsMouseDown(2) && setting->isDragging && isEnabled) {
                                    if (lastDragged != setting) {
                                        setting->isDragging = false;
                                    } else {
                                        const float t = (gui::GetMousePos().x - rect.x) /
                                                        gui::RectW(rect);
                                        float nv = gui::Clamp(min + t * span, min, max);
                                        // Solstice: middle-click snaps to
                                        // Midclick Rounding.
                                        nv = std::round(nv / midclickRounding) * midclickRounding;
                                        ns->mValue = gui::Clamp(nv, min, max);
                                    }
                                } else {
                                    setting->isDragging = false;
                                }

                                // --- bar + knob -------------------------------
                                const float ySize = gui::RectH(rect);
                                ImVec2 barMin = ImVec2(rect.x, rect.w - ySize / 8.0f);
                                ImVec2 barMax = ImVec2(rect.x + setting->sliderEase * inScale, rect.w);
                                barMin.y = barMax.y - 4.0f * inScale;

                                const ImVec4 sliderRect = ImVec4(barMin.x, barMin.y - 4.5f,
                                                                 barMax.x, barMax.y - 6.5f);
                                gui::FillRect(sliderRect, sRgb, animation, 15.0f);

                                ImVec2 knob = ImVec2(sliderRect.z - 2.25f,
                                                     gui::RectCenter(sliderRect).y);
                                if (value <= min + 0.83f)
                                    knob.x = sliderRect.z + 2.25f;

                                gui::FillCircle(knob, 5.5f * clickAnimation * animation, sRgb,
                                                animation, 12);

                                draw->PushClipRect(ImVec2(sliderRect.x, sliderRect.y),
                                                   ImVec2(sliderRect.z, sliderRect.w), true);
                                gui::FillShadowRect(sliderRect, sRgb, animation * 0.75f, 15.0f,
                                                    0, 15.0f, draw);
                                draw->PopClipRect();

                                const float vw = gui::GetTextWidth(vbuf, inScale);
                                gui::DrawText(ImVec2(bgRect.z - 5.0f - vw, bgRect.y + 2.5f), vbuf,
                                              ImColor(170, 170, 170), inScale, animation, true);
                                gui::DrawText(ImVec2(bgRect.x + 5.0f, bgRect.y + 2.5f),
                                              setName.c_str(), ModernGui::textColor,
                                              inScale, animation, true);
                            }
                            break;
                        }

                        // ---------------- Color ----------------
                        case SettingType::Color: {
                            ColorSetting* cs = static_cast<ColorSetting*>(setting);

                            moduleY = gui::Lerp(moduleY, moduleY + modHeight, m->cAnim);

                            ImVec4 rect = ScaleRows(
                                ImVec4(modRect.x, cp.y + ModernGui::catHeight + moduleY + setPadding,
                                       modRect.z, cp.y + ModernGui::catHeight + moduleY + modHeight),
                                modRect.x, modRect.z, screen, inScale);
                            rect.y = std::floor(rect.y);
                            if (rect.y < modRect.y) rect.y = modRect.y;

                            if (rect.y > catRect.y + 0.5f) {
                                gui::FillRect(rect, ModernGui::enumBackGround, animation, sRadius,
                                              draw, ImDrawFlags_RoundCornersBottom);

                                if (gui::IsMouseOver(rect) && interactive && cp.isExtended) {
                                    tooltip = setting->mDescription;
                                    if (ImGui::IsMouseClicked(0) && m->showSettings) {
                                        m_displayColorPicker = !m_displayColorPicker;
                                        m_lastColorSetting   = cs;
                                    }
                                }

                                const float cY = rect.y + (gui::RectH(rect) - textH) * 0.5f;
                                gui::DrawText(ImVec2(rect.x + 5.0f, cY), setName.c_str(),
                                              ModernGui::textColor, inScale, animation, true);
                                gui::FillRect(ImVec4(rect.z - 20.0f, rect.y + 5.0f,
                                                     rect.z - 5.0f, rect.w - 5.0f),
                                              cs->getAsImColor(), animation, 3.0f);
                            }
                            break;
                        }

                        default:
                            break;
                        }

                        sIndex++;
                    }
                }

                // --- module row ------------------------------------------------
                if (modRect.y > catRect.y + 0.5f) {
                    // Solstice paints the enabled colour first, then the flat
                    // grey row over it; the theme shows through via the
                    // gradient pass below, which is what actually reads as
                    // "enabled".
                    if (m->cScale <= 1.0f) {
                        gui::FillRect(modRect, m->enabled() ? rgb : ImColor(30, 30, 30),
                                      animation, radius, draw, flags);
                        gui::FillRect(modRect, ModernGui::grayColor, animation, radius,
                                      draw, flags);
                    }

                    m->cScale = gui::Animate(m->enabled() ? 1.0f : 0.0f, m->cScale, dt * 10.0f);

                    if (m->cScale > 0.0f) {
                        const ImColor rgb2 = gui::GetThemedColor(modRect.y + gui::RectW(modRect));
                        gui::FillRoundedGradient(modRect, rgb, rgb2, radius,
                                                 animation * m->cScale,
                                                 animation * m->cScale, flags);
                    }

                    const std::string modName = gui::ApplyNaming(m->name());
                    const float textH = gui::GetTextHeight(inScale);
                    const float nw    = gui::GetTextWidth(modName.c_str(), inScale);
                    const float nx    = modRect.x + (gui::RectW(modRect) - nw) * 0.5f;
                    const float ny    = modRect.y + (gui::RectH(modRect) - textH) * 0.5f;

                    gui::DrawText(ImVec2(nx, ny), modName.c_str(),
                                  m->enabled() ? ImColor(255, 255, 255)
                                               : ImColor(180, 180, 180),
                                  inScale, animation, true);

                    // Bound key (Solstice keeps this commented out; keybinds
                    // are live here, so the badge is drawn).
                    if (m->key() > 0) {
                        const char* kn = keys::Name(m->key());
                        const float kw = gui::GetTextWidth(kn, inScale * 0.7f);
                        gui::DrawText(ImVec2(modRect.z - 6.0f - kw, ny + 2.0f), kn,
                                      ImColor(170, 170, 170), inScale * 0.7f, animation, true);
                    }

                    // --- interaction ----------------------------------------
                    if (gui::IsMouseOver(modRect) && cp.isExtended && interactive) {
                        if (gui::IsMouseOver(catWindow))
                            tooltip = m->description();

                        if (ImGui::IsMouseClicked(0)) {
                            if (!moduleToggled) {
                                m->toggle();
                                moduleToggled = true;
                                LOG_INFO("menu: %s -> %s", m->name(),
                                         m->enabled() ? "ON" : "OFF");
                                // Module callbacks run on the game's render
                                // thread; a fresh module is the likeliest thing
                                // to hang on first enable, so it is guarded.
                                ModulePhaseGuard::run(m, m->enabled()
                                                          ? ModulePhaseGuard::ENABLE
                                                          : ModulePhaseGuard::DISABLE);
                            }
                        } else if (ImGui::IsMouseClicked(1)) {
                            if (!m->settings().empty()) m->showSettings = !m->showSettings;
                        } else if (ImGui::IsMouseClicked(2)) {
                            m_lastMod   = m;
                            m_isBinding = true;
                        }
                    }
                }

                // Soft shadow under an expanded module.
                if (modRect.y > catRect.y - modHeight) {
                    gui::FillGradient(ImVec4(modRect.x, modRect.w, modRect.z,
                                             modRect.w + 10.0f * m->cAnim * animation),
                                      ImColor(0, 0, 0), ImColor(0, 0, 0),
                                      0.0f, 0.55f * animation);
                }

                moduleY += modHeight;
            }

            draw->PopClipRect();

            // --- keybind capture --------------------------------------------
            if (m_isBinding && m_lastMod) {
                tooltip = std::string("Currently binding ") + m_lastMod->name() +
                          "... Press ESC to unbind.";
                for (int vk = 8; vk <= 0xFE && m_isBinding; vk++) {
                    if (keys::PressedThisFrame(vk)) {
                        m_lastMod->setKey(vk == VK_ESCAPE ? 0 : vk);
                        m_isBinding = false;
                        LOG_INFO("menu: bound %s -> %s", m_lastMod->name(),
                                 keys::Name(vk));
                    }
                }
            }

            if (m_isBoolSettingBinding && m_lastBoolSetting) {
                tooltip = std::string("Currently binding ") + m_lastBoolSetting->mName +
                          "... Press ESC to unbind.";
                for (int vk = 8; vk <= 0xFE && m_isBoolSettingBinding; vk++) {
                    if (keys::PressedThisFrame(vk)) {
                        m_lastBoolSetting->mKey = (vk == VK_ESCAPE) ? 0 : vk;
                        m_isBoolSettingBinding  = false;
                        LOG_INFO("menu: bound setting %s -> %s",
                                 m_lastBoolSetting->mName.c_str(), keys::Name(vk));
                    }
                }
            }

            // --- category header ---------------------------------------------
            const std::string catName = gui::ApplyNaming(categories[i].c_str());

            if (gui::IsMouseOver(catRect) && ImGui::IsMouseClicked(1) &&
                !ImGui::GetIO().WantCaptureMouse)
                cp.isExtended = !cp.isExtended;

            ImVec4 headRect = catRect;
            headRect.w += 1.5f;
            gui::FillRect(headRect, ModernGui::darkBlack, animation, 15.0f, draw,
                          ImDrawFlags_RoundCornersTop);

            // Solstice draws a per-category glyph from a bundled icon font.
            // No icon font ships here, so a themed dot takes its place.
            {
                ImColor dot = gui::GetThemedColor((float)i * 20.0f);
                dot.Value.w = animation;
                gui::FillCircle(ImVec2(headRect.x + 12.0f,
                                       headRect.y + gui::RectH(headRect) * 0.5f),
                                4.0f * animation, dot, animation, 12);
            }

            const float catTextSize = inScale * 1.15f;
            const float cth = gui::GetTextHeight(catTextSize);
            const float nw  = gui::GetTextWidth(catName.c_str(), catTextSize);
            const float nx  = headRect.x + (gui::RectW(headRect) - nw) * 0.5f;
            const float cy  = headRect.y + (gui::RectH(headRect) - cth) * 0.5f;
            gui::DrawText(ImVec2(nx, cy), catName.c_str(), ModernGui::textColor,
                          catTextSize, animation, true);

            // --- dragging ------------------------------------------------------
            static bool   dragging   = false;
            static ImVec2 dragOffset = ImVec2(0.0f, 0.0f);

            cp.x = gui::Clamp(cp.x, 0.0f, screen.x - ModernGui::catWidth);
            cp.y = gui::Clamp(cp.y, 0.0f, screen.y - ModernGui::catHeight);

            if (cp.isDragging) {
                if (ImGui::IsMouseDown(0)) {
                    if (!dragging) {
                        dragOffset = ImVec2(gui::GetMousePos().x - catRect.x,
                                            gui::GetMousePos().y - catRect.y);
                        dragging = true;
                    }
                    ImVec2 np = ImVec2(gui::GetMousePos().x - dragOffset.x,
                                       gui::GetMousePos().y - dragOffset.y);
                    np.x = gui::Clamp(np.x, 0.0f, screen.x - ModernGui::catWidth);
                    np.y = gui::Clamp(np.y, 0.0f, screen.y - ModernGui::catHeight);
                    cp.x = std::round(np.x / 2.0f) * 2.0f;
                    cp.y = std::round(np.y / 2.0f) * 2.0f;
                } else {
                    cp.isDragging = false;
                    dragging      = false;
                }
            } else if (gui::IsMouseOver(catRect) && ImGui::IsMouseClicked(0) &&
                       isEnabled && !ImGui::GetIO().WantCaptureMouse) {
                cp.isDragging = true;
                dragOffset    = ImVec2(gui::GetMousePos().x - catRect.x,
                                       gui::GetMousePos().y - catRect.y);
            }
        }

        drawTooltip(tooltip, screen, animation, inScale);

        if (isEnabled) scrollDirection = 0;
    }

    drawColorPicker(screen, animation);
}

} // namespace ui
