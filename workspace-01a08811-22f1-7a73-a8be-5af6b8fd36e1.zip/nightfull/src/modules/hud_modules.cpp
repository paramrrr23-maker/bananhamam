// hud_modules.cpp - the curated local-only HUD roster.

#include "modules/hud_modules.h"

#include <Windows.h>
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <psapi.h>

#include "core/module_manager.h"
#include "overlay/overlay.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"

namespace nf {
namespace {

// Anchor indices (match HudPositionNames order).
enum Anchor { TopLeft = 0, TopRight, BottomLeft, BottomRight, TopCenter, BottomCenter };

constexpr float kPad = 10.0f;

ImVec2 Place(const ImVec2& screen, const ImVec2& size, int anchor, float pad = kPad) {
    switch (anchor) {
        case TopRight:    return ImVec2(screen.x - pad - size.x, pad);
        case BottomLeft:  return ImVec2(pad, screen.y - pad - size.y);
        case BottomRight: return ImVec2(screen.x - pad - size.x, screen.y - pad - size.y);
        case TopCenter:   return ImVec2((screen.x - size.x) * 0.5f, pad);
        case BottomCenter:return ImVec2((screen.x - size.x) * 0.5f, screen.y - pad - size.y);
        case TopLeft:
        default:          return ImVec2(pad, pad);
    }
}

ImColor AccentOf(BoolSetting* useTheme, ColorSetting* color) {
    if (useTheme && useTheme->mValue) return gui::Accent();
    if (color) return color->getAsImColor();
    return ImColor(255, 255, 255);
}

// One dark chip with a left accent bar (shared HUD look).
ImVec2 DrawChip(const ImVec2& pos, const char* text, float scale, const ImColor& accent) {
    const float units = 0.82f * scale;
    const float padX = 10.0f * scale, padY = 6.0f * scale;
    const float w = gui::GetTextWidth(text, units) + padX * 2.0f + 3.0f * scale;
    const float h = gui::GetTextHeight(units) + padY * 2.0f;
    const ImVec4 r(pos.x, pos.y, pos.x + w, pos.y + h);
    gui::FillRect(r, ImColor(13, 12, 20), 0.88f, 6.0f * scale);
    gui::FillRect(ImVec4(r.x, r.y, r.x + 3.0f * scale, r.w), accent, 1.0f, 2.0f * scale);
    gui::DrawString(ImVec2(pos.x + padX + 3.0f * scale, pos.y + padY), text,
                  ImColor(240, 240, 245), units, 1.0f, true);
    return ImVec2(w, h);
}

ImVec2 ChipSize(const char* text, float scale) {
    const float units = 0.82f * scale;
    return ImVec2(gui::GetTextWidth(text, units) + 10.0f * scale * 2.0f + 3.0f * scale,
                  gui::GetTextHeight(units) + 6.0f * scale * 2.0f);
}

} // namespace

// ======================== Watermark ========================
WatermarkModule::WatermarkModule()
    : Module("HUD", "Watermark", "Top pill: tag + FPS + clock") {
    hiddenFromLists = true;
    m_text = addSetting<StringSetting>("Text", "Watermark tag.", "Nightfull", 24);
    m_background = addSetting<BoolSetting>("Background", "Dark pill behind the text.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the pill.", false);
    m_fps = addSetting<BoolSetting>("FPS", "FPS segment.", true);
    m_clock = addSetting<BoolSetting>("Clock", "Clock segment.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Pill opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    m_scale = addSetting<NumberSetting>("Scale", "Pill size.", 1.0f, 0.6f, 2.0f, 0.05f);
    setEnabled(true);
}

void WatermarkModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const float s = m_scale->mValue;

    std::string text = m_text->mValue.empty() ? "Nightfull" : m_text->mValue;
    const ImGuiIO& io = ImGui::GetIO();
    if (m_fps->mValue) {
        char b[24];
        snprintf(b, sizeof(b), "  |  %d FPS", io.Framerate > 0.1f ? (int)(io.Framerate + 0.5f) : 0);
        text += b;
    }
    if (m_clock->mValue) {
        SYSTEMTIME st{}; GetLocalTime(&st);
        char b[24]; snprintf(b, sizeof(b), "  |  %02u:%02u", st.wHour, st.wMinute);
        text += b;
    }

    const float units = 0.78f * s;
    const float padX = 14.0f * s, padY = 6.0f * s;
    const float w = gui::GetTextWidth(text.c_str(), units) + padX * 2.0f;
    const float h = gui::GetTextHeight(units) + padY * 2.0f;
    const ImVec2 pos((screen.x - w) * 0.5f, 12.0f * s);
    ImDrawList* d = gui::Bg();

    if (m_background->mValue)
        gui::FillRect(ImVec4(pos.x, pos.y, pos.x + w, pos.y + h),
                      ImColor(13, 12, 20), m_opacity->mValue, h * 0.5f);
    if (m_outline->mValue)
        d->AddRect(ImVec2(pos.x + 0.7f, pos.y + 0.7f), ImVec2(pos.x + w - 0.7f, pos.y + h - 0.7f),
                   gui::Accent(), h * 0.5f - 0.7f, 0, 1.4f);
    gui::DrawString(ImVec2(pos.x + padX, pos.y + padY), text.c_str(),
                  ImColor(240, 240, 245), units, 1.0f, true);
}

// ======================== Arraylist ========================
ArraylistModule::ArraylistModule()
    : Module("HUD", "Arraylist", "Right-edge list of enabled modules") {
    hiddenFromLists = true;
    m_showMode = addSetting<BoolSetting>("Show Mode", "First enum value next to the name.", true);
    m_visibility = addSetting<EnumSetting>("Visibility", "Which modules are listed.", 0,
                                           std::vector<std::string>{ "All", "Bound" });
    m_fontSize = addSetting<NumberSetting>("Font Size", "Text size in pixels.", 15.0f, 10.0f, 30.0f, 0.5f);
    m_opacity = addSetting<NumberSetting>("Opacity", "Row opacity.", 0.6f, 0.0f, 1.0f, 0.05f);
    m_scale = addSetting<NumberSetting>("Scale", "Overall scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    setEnabled(true);
}

void ArraylistModule::onRender() {
    if (overlay::g_showMenu) return;   // the menu has its own right panels
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    ImFont* font = fonts::Current();
    if (!font) return;

    const float s = m_scale->mValue;
    const float px = m_fontSize->mValue * s;
    const float units = px / gui::kFontUnit;
    const bool boundOnly = m_visibility->mValue == 1;

    const auto& reg = modules().modules();
    if (m_anim.size() != reg.size()) m_anim.assign(reg.size(), 0.0f);

    struct Entry { size_t i; Module* m; std::string name, mode; float w; };
    std::vector<Entry> entries;
    for (size_t i = 0; i < reg.size(); i++) {
        Module* m = reg[i].get();
        if (!m || m->hiddenFromLists) continue;
        if (boundOnly && m->key() == 0) continue;
        Entry e{ i, m, gui::ApplyNaming(m->name()), "", 0.0f };
        if (m_showMode->mValue) {
            for (const auto& st : m->settings()) {
                if (st->mType == SettingType::Enum) {
                    e.mode = " " + static_cast<EnumSetting*>(st.get())->current();
                    break;
                }
            }
        }
        e.w = font->CalcTextSizeA(px, FLT_MAX, 0.0f, (e.name + e.mode).c_str()).x;
        entries.push_back(std::move(e));
    }
    std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
        if (a.w != b.w) return a.w > b.w;
        return a.name < b.name;
    });

    const ImColor accent = gui::Accent();
    const float dt = gui::GetDeltaTime();
    const float padY = 3.0f * s, barW = 3.0f * s, textPad = 10.0f * s;
    float y = 6.0f * s;
    for (const Entry& e : entries) {
        float& a = m_anim[e.i];
        a = gui::Animate(e.m->enabled() ? 1.0f : 0.0f, a, dt * 12.0f);
        if (a < 0.01f) continue;
        const float rowH = font->CalcTextSizeA(px, FLT_MAX, 0.0f, e.name.c_str()).y + padY * 2.0f;
        const float slide = (1.0f - a) * (e.w + 60.0f * s);
        const float right = screen.x + slide;
        const float left = right - (textPad + e.w + textPad);
        gui::FillRect(ImVec4(left, y, right + 8.0f * s, y + rowH),
                      ImColor(13, 12, 20), m_opacity->mValue * a, 5.0f * s,
                      nullptr, ImDrawFlags_RoundCornersLeft);
        gui::FillRect(ImVec4(right - 7.0f * s - barW, y + padY, right - 7.0f * s, y + rowH - padY),
                      accent, a, barW * 0.5f);
        const float tx = right - 7.0f * s - barW - 5.0f * s;
        if (!e.mode.empty())
            gui::DrawString(ImVec2(tx - gui::GetTextWidth(e.mode.c_str(), units, font), y + padY),
                          e.mode.c_str(), ImColor(150, 150, 165), units, a, false, nullptr, font);
        gui::DrawString(ImVec2(tx - e.w, y + padY), e.name.c_str(),
                      ImColor(235, 235, 240), units, a, false, nullptr, font);
        y += rowH * a;
    }
}

// ======================== FPS ========================
FpsModule::FpsModule()
    : Module("Интерфейс", "FPS Counter", "Плавность игры в реальном времени.") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
    setEnabled(true);
}

void FpsModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float fps = io.Framerate > 0.1f ? io.Framerate
                                          : (io.DeltaTime > 0.0f ? 1.0f / io.DeltaTime : 0.0f);
    char b[32]; snprintf(b, sizeof(b), "FPS: %d", (int)(fps + 0.5f));
    DrawChip(Place(screen, ChipSize(b, m_scale->mValue), m_position->mValue),
             b, m_scale->mValue, AccentOf(m_useTheme, m_color));
}

// ======================== CPS ========================
CpsModule::CpsModule() : Module("HUD", "CPS", "Clicks-per-second chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_buttons = addSetting<BoolSetting>("Buttons", "Separate LMB / RMB counters.", true);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
    setEnabled(true);
}

void CpsModule::record(std::array<unsigned long long, kMaxClicks>& b, int& head,
                       int& count, unsigned long long now) {
    b[head] = now;
    head = (head + 1) % kMaxClicks;
    if (count < kMaxClicks) count++;
}

int CpsModule::recent(const std::array<unsigned long long, kMaxClicks>& b, int head,
                      int count, unsigned long long now) const {
    int n = 0;
    for (int i = 0; i < count; i++) {
        const unsigned long long t = b[(head - 1 - i + kMaxClicks) % kMaxClicks];
        if (t != 0 && now >= t && now - t <= 1000) n++;
    }
    return n;
}

void CpsModule::onTick() {
    const unsigned long long now = GetTickCount64();
    if (ImGui::IsMouseClicked(0)) record(m_lmb, m_lmbHead, m_lmbCount, now);
    if (ImGui::IsMouseClicked(1)) record(m_rmb, m_rmbHead, m_rmbCount, now);
}

void CpsModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const unsigned long long now = GetTickCount64();
    char b[64];
    if (m_buttons->mValue)
        snprintf(b, sizeof(b), "LMB: %d  |  RMB: %d",
                 recent(m_lmb, m_lmbHead, m_lmbCount, now),
                 recent(m_rmb, m_rmbHead, m_rmbCount, now));
    else snprintf(b, sizeof(b), "CPS: %d", recent(m_lmb, m_lmbHead, m_lmbCount, now));
    DrawChip(Place(screen, ChipSize(b, m_scale->mValue), m_position->mValue),
             b, m_scale->mValue, AccentOf(m_useTheme, m_color));
}

// ======================== Keybinds ========================
KeybindsModule::KeybindsModule()
    : Module("HUD", "Keybinds", "Plate of bound modules with status dots") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Plate size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme Color is off.", 0xFF8E5CFF);
    setEnabled(true);
}

void KeybindsModule::onRender() {
    if (overlay::g_showMenu) return;   // the menu has its own Keybinds panel
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;

    struct Row { std::string name, key; bool on; };
    std::vector<Row> rows;
    for (const auto& m : modules().modules()) {
        if (!m || m->hiddenFromLists || m->key() <= 0) continue;
        rows.push_back({ gui::ApplyNaming(m->name()), keys::Name(m->key()), m->enabled() });
    }
    if (rows.empty()) return;

    const float s = m_scale->mValue;
    const float units = 0.72f * s, headU = 0.78f * s;
    const float pad = 10.0f * s, rowH = 20.0f * s, headH = 26.0f * s;
    float w = gui::GetTextWidth("Keybinds", headU);
    for (const Row& r : rows)
        w = std::max(w, gui::GetTextWidth(r.name.c_str(), units) +
                            gui::GetTextWidth(r.key.c_str(), units) + 30.0f * s);
    w += pad * 2.0f;
    const float h = headH + rows.size() * rowH + pad * 0.5f;
    ImVec2 pos = Place(screen, ImVec2(w, h), m_position->mValue);
    if (m_position->mValue == TopRight || m_position->mValue == TopLeft) pos.y += 0;  // corners
    const ImColor accent = AccentOf(m_useTheme, m_color);

    gui::FillRect(ImVec4(pos.x, pos.y, pos.x + w, pos.y + h),
                  ImColor(13, 12, 20), m_opacity->mValue, 8.0f * s);
    if (m_outline->mValue)
        gui::Bg()->AddRect(ImVec2(pos.x + 0.7f, pos.y + 0.7f),
                           ImVec2(pos.x + w - 0.7f, pos.y + h - 0.7f),
                           accent, 8.0f * s - 0.7f, 0, 1.4f);
    gui::DrawString(ImVec2(pos.x + pad, pos.y + pad * 0.6f), "Keybinds", accent, headU, 1.0f, true);
    float y = pos.y + headH;
    for (const Row& r : rows) {
        const ImVec2 dotC(pos.x + pad + 3.0f * s, y + rowH * 0.5f);
        gui::FillCircle(dotC, 3.0f * s,
                        r.on ? ImColor(40, 220, 90) : ImColor(230, 60, 60), 1.0f, 10);
        gui::DrawString(ImVec2(pos.x + pad + 10.0f * s, y + (rowH - gui::GetTextHeight(units)) * 0.5f),
                      r.name.c_str(), ImColor(235, 235, 240), units, 1.0f, true);
        const float kw = gui::GetTextWidth(r.key.c_str(), units);
        gui::DrawString(ImVec2(pos.x + w - pad - kw, y + (rowH - gui::GetTextHeight(units)) * 0.5f),
                      r.key.c_str(), ImColor(160, 160, 175), units, 1.0f, true);
        y += rowH;
    }
}

// ======================== Time ========================
TimeModule::TimeModule() : Module("HUD", "Time", "Local wall-clock chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_seconds = addSetting<BoolSetting>("Seconds", "Include seconds.", false);
    m_24h = addSetting<BoolSetting>("24 Hour", "24-hour format.", true);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
}

void TimeModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    SYSTEMTIME st{}; GetLocalTime(&st);
    char b[32];
    if (m_24h->mValue)
        snprintf(b, sizeof(b), m_seconds->mValue ? "Time: %02u:%02u:%02u" : "Time: %02u:%02u",
                 st.wHour, st.wMinute, st.wSecond);
    else {
        const unsigned h = (st.wHour % 12) == 0 ? 12 : st.wHour % 12;
        snprintf(b, sizeof(b), m_seconds->mValue ? "Time: %02u:%02u:%02u %s" : "Time: %02u:%02u %s",
                 h, st.wMinute, st.wSecond, st.wHour < 12 ? "AM" : "PM");
    }
    DrawChip(Place(screen, ChipSize(b, m_scale->mValue), m_position->mValue),
             b, m_scale->mValue, AccentOf(m_useTheme, m_color));
}

// ======================== Memory ========================
MemoryModule::MemoryModule() : Module("HUD", "Memory", "Process working-set chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
}

void MemoryModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    static SIZE_T cached = 0;
    static unsigned long long nextSample = 0;
    const unsigned long long now = GetTickCount64();
    if (now >= nextSample) {
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb = sizeof(pmc);
        if (GetProcessMemoryInfo(GetCurrentProcess(),
                                 reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc)))
            cached = pmc.WorkingSetSize;
        nextSample = now + 250;
    }
    char b[32]; snprintf(b, sizeof(b), "Memory: %.0f MB", (double)cached / (1024.0 * 1024.0));
    DrawChip(Place(screen, ChipSize(b, m_scale->mValue), m_position->mValue),
             b, m_scale->mValue, AccentOf(m_useTheme, m_color));
}

// ======================== Mouse Strokes ========================
MouseStrokesModule::MouseStrokesModule()
    : Module("HUD", "Mouse Strokes", "Cursor motion trail") {
    m_scale = addSetting<NumberSetting>("Scale", "Trail scale.", 1.0f, 0.5f, 2.0f, 0.05f);
    m_length = addSetting<NumberSetting>("Length", "Max trail points.", 28.0f, 4.0f, 64.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line width.", 2.0f, 1.0f, 6.0f, 0.5f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Trail color when Theme Color is off.", 0xFF8E5CFF);
}

void MouseStrokesModule::onEnable() { m_count = 0; }
void MouseStrokesModule::onDisable() { m_count = 0; }

void MouseStrokesModule::expire(unsigned long long now) {
    int live = 0;
    while (live < m_count && now - m_points[live].ms > kLifetimeMs) live++;
    if (live > 0) {
        for (int i = 0; i + live < m_count; i++) m_points[i] = m_points[i + live];
        m_count -= live;
    }
}

void MouseStrokesModule::onTick() {
    const unsigned long long now = GetTickCount64();
    expire(now);
    const ImGuiIO& io = ImGui::GetIO();
    if (io.MousePos.x < 0.0f || io.MousePos.y < 0.0f) return;
    if (std::fabs(io.MouseDelta.x) < 0.01f && std::fabs(io.MouseDelta.y) < 0.01f) return;
    if (m_count < kMaxPoints) m_points[m_count++] = { io.MousePos, now };
    else {
        for (int i = 1; i < kMaxPoints; i++) m_points[i - 1] = m_points[i];
        m_points[kMaxPoints - 1] = { io.MousePos, now };
    }
}

void MouseStrokesModule::onRender() {
    const unsigned long long now = GetTickCount64();
    expire(now);
    if (m_count < 2) return;
    const int visible = std::min(m_count, (int)m_length->mValue);
    const int first = m_count - visible;
    const float s = m_scale->mValue;
    const ImColor base = AccentOf(m_useTheme, m_color);
    ImDrawList* d = ImGui::GetForegroundDrawList();
    for (int i = first + 1; i < m_count; i++) {
        const float age = (float)(now - m_points[i].ms) / (float)kLifetimeMs;
        const float life = gui::Clamp(1.0f - age, 0.0f, 1.0f);
        if (life <= 0.0f) continue;
        const float t = (float)(i - first) / (float)std::max(1, visible - 1);
        d->AddLine(m_points[i - 1].pos, m_points[i].pos,
                   ImColor(base.Value.x, base.Value.y, base.Value.z, (0.08f + 0.82f * t) * life),
                   m_thickness->mValue * s);
    }
}

// ======================== Keystrokes ========================
KeystrokesModule::KeystrokesModule()
    : Module("Интерфейс", "Keystrokes", "Наглядное отображение нажатий клавиш.") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomCenter, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Widget size.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_spacing = addSetting<NumberSetting>("Spacing", "Gap between cells.", 2.0f, 0.0f, 8.0f, 0.5f);
    m_rounding = addSetting<NumberSetting>("Rounding", "Cell corner radius.", 5.0f, 0.0f, 12.0f, 0.5f);
    m_showMouse = addSetting<BoolSetting>("Mouse Buttons", "LMB / RMB cells.", true);
    m_pressed = addSetting<ColorSetting>("Pressed", "Held-key color.", 0xFF8E5CFF);
    m_released = addSetting<ColorSetting>("Released", "Idle-key color.", 0xFF2A2438);
    setEnabled(true);
}

void KeystrokesModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const float s = m_scale->mValue;
    const float cell = 34.0f * s, gap = m_spacing->mValue * s;
    const int rows = m_showMouse->mValue ? 3 : 2;
    const ImVec2 size(cell * 3.0f + gap * 2.0f, cell * (float)rows + gap * (float)(rows - 1));
    const ImVec2 origin = Place(screen, size, m_position->mValue);
    ImDrawList* d = ImGui::GetForegroundDrawList();

    struct Cell { const char* label; int vk; float x, y, w; };
    const Cell cells[] = {
        { "W", 'W', 1.0f, 0.0f, 1.0f },
        { "A", 'A', 0.0f, 1.0f, 1.0f }, { "S", 'S', 1.0f, 1.0f, 1.0f }, { "D", 'D', 2.0f, 1.0f, 1.0f },
        { "LMB", VK_LBUTTON, 0.0f, 2.0f, 1.45f }, { "RMB", VK_RBUTTON, 1.55f, 2.0f, 1.45f },
    };
    const int n = m_showMouse->mValue ? 6 : 4;
    const float units = 0.64f * s;
    for (int i = 0; i < n; i++) {
        const Cell& c = cells[i];
        const ImVec2 p(origin.x + c.x * (cell + gap), origin.y + c.y * (cell + gap));
        const float w = c.w * cell + (c.w > 1.0f ? gap * 0.45f : 0.0f);
        const bool down = (c.vk == VK_LBUTTON) ? ImGui::IsMouseDown(0)
                        : (c.vk == VK_RBUTTON) ? ImGui::IsMouseDown(1)
                        : keys::Down(c.vk);
        const ImColor edge = down ? m_pressed->getAsImColor() : m_released->getAsImColor();
        d->AddRectFilled(p, ImVec2(p.x + w, p.y + cell),
                         ImColor(13, 12, 20, down ? 245 : 225), m_rounding->mValue * s);
        d->AddRect(p, ImVec2(p.x + w, p.y + cell),
                   ImColor(edge.Value.x, edge.Value.y, edge.Value.z, down ? 0.95f : 0.5f),
                   m_rounding->mValue * s, 0, 1.0f * s);
        const float tw = gui::GetTextWidth(c.label, units);
        const float th = gui::GetTextHeight(units);
        gui::DrawString(ImVec2(p.x + (w - tw) * 0.5f, p.y + (cell - th) * 0.5f),
                      c.label, edge, units, 1.0f, true);
    }
}

// ======================== Crosshair ========================
CrosshairModule::CrosshairModule()
    : Module("Визуал", "Crosshair", "Точность начинается с твоего прицела.") {
    m_dynamic = addSetting<BoolSetting>("Dynamic", "Expand with mouse motion.", true);
    m_gap = addSetting<NumberSetting>("Gap", "Center gap.", 5.0f, 0.0f, 18.0f, 0.5f);
    m_length = addSetting<NumberSetting>("Length", "Arm length.", 7.0f, 2.0f, 20.0f, 0.5f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line thickness.", 2.0f, 1.0f, 5.0f, 0.5f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Color when Theme Color is off.", 0xFFFFFFFF);
    setEnabled(true);
}

void CrosshairModule::onRender() {
    if (overlay::g_showMenu) return;   // cursor is visible with the menu
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float motion = std::sqrt(io.MouseDelta.x * io.MouseDelta.x + io.MouseDelta.y * io.MouseDelta.y);
    const float gap = m_gap->mValue + (m_dynamic->mValue ? gui::Clamp(motion * 0.7f, 0.0f, 7.0f) : 0.0f);
    const float len = m_length->mValue, th = m_thickness->mValue;
    const ImVec2 c(screen.x * 0.5f, screen.y * 0.5f);
    const ImU32 col = AccentOf(m_useTheme, m_color);
    ImDrawList* d = ImGui::GetForegroundDrawList();
    d->AddLine(ImVec2(c.x - gap - len, c.y), ImVec2(c.x - gap, c.y), col, th);
    d->AddLine(ImVec2(c.x + gap, c.y), ImVec2(c.x + gap + len, c.y), col, th);
    d->AddLine(ImVec2(c.x, c.y - gap - len), ImVec2(c.x, c.y - gap), col, th);
    d->AddLine(ImVec2(c.x, c.y + gap), ImVec2(c.x, c.y + gap + len), col, th);
}

} // namespace nf
