// stub_modules.cpp - menu-driven module holders.
//
// Identity strings (names, categories, descriptions) and default on/off
// states mirror the Nightfull reference. See stub_modules.h for the
// replacement contract.

#include "modules/stub_modules.h"

#include <algorithm>
#include <cmath>

#include "overlay/overlay.h"
#include "utils/logger.h"

namespace nf {

HudModule::HudModule()
    : Module("HUD", "HUD", "Всё важное — всегда перед глазами.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
    setEnabled(true);
}

SkyboxModule::SkyboxModule()
    : Module("World", "Skybox", "Новая атмосфера привычного мира.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
}

ZoomModule::ZoomModule()
    : Module("Visual", "Zoom", "Прицельное приближение — удерживай клавишу.") {
    m_zoomFov = addSetting<NumberSetting>("Zoom FOV", "Field of view while zoomed.",
                                          30.0f, 10.0f, 120.0f, 1.0f);
    m_smooth = addSetting<BoolSetting>("Smooth", "Smooth zoom-in transition.", true);
    mHoldToUse = true;
}

void ZoomModule::onEnable() {
    static bool warned = false;
    float base = 0.0f;
    if (!overlay::ZoomPrepare(&base)) {
        if (!warned) {
            warned = true;
            LOG_ERROR("zoom: options offsets not verified - zoom off");
        }
        setEnabled(false);
        return;
    }
    m_cur = base;
    m_lastMs = GetTickCount64();
    m_prepared = true;
}

void ZoomModule::onTick() {
    if (!m_prepared) return;
    const unsigned long long now = GetTickCount64();
    const float dt = std::min(0.1f, (float)(now - m_lastMs) / 1000.0f);
    m_lastMs = now;
    const float target = m_zoomFov ? m_zoomFov->mValue : 30.0f;
    if (m_smooth && m_smooth->mValue) {
        const float k = 1.0f - std::exp(-10.0f * std::max(dt, 0.001f));
        m_cur += (target - m_cur) * k;
    } else {
        m_cur = target;
    }
    overlay::ZoomWrite(m_cur);
}

void ZoomModule::onDisable() {
    if (m_prepared) {
        overlay::ZoomRestore();
        m_prepared = false;
    }
}

HotbarModule::HotbarModule()
    : Module("HUD", "Hotbar", "Плавные анимации панели предметов.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
    setEnabled(true);
}

TimeChangerModule::TimeChangerModule()
    : Module("World", "Time Changer", "Любимое время суток для мира.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
}

} // namespace nf
