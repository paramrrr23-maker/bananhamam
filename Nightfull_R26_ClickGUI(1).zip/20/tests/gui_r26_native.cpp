// Headless native UI regression. Synthetic modules and mocked platform/game APIs ONLY.
#include <cstdint>
#include <fstream>
#include <iostream>
#include <cassert>
#include "../src/ui/menu.cpp"
namespace nf {
namespace fonts {
ImFont* icon = nullptr; ImFont* UI(){return ImGui::GetFont();} ImFont* UISemi(){return ImGui::GetFont();}
ImFont* Bold(){return ImGui::GetFont();} ImFont* Title(){return ImGui::GetFont();}
ImFont* Mono(){return ImGui::GetFont();} ImFont* Icon(){return icon;} ImFont* Current(){return ImGui::GetFont();}
}
namespace logger {void Write(const char*,const char*,va_list){} }
namespace overlay { bool g_showMenu=true,g_hudEdit=false; int g_menuKey=45; bool g_guiMouseDown[5]={},g_guiMousePressed[5]={},g_guiMouseReleased[5]={};float g_guiMouseWheel=0,g_guiMouseWheelH=0;
void HudEditSet(bool b){g_hudEdit=b;} bool HudEditActive(){return g_hudEdit;}
}
namespace keys {void SetTextCapture(bool){} const char* Name(unsigned k){return k ? "INSERT" : "None";} bool TextInput(char*,size_t,bool){return false;} bool Down(unsigned){return false;} bool PressedThisFrame(unsigned){return false;} }
namespace config {bool validProfileName(const std::wstring& n){return !n.empty();} bool saveProfile(const std::wstring&){return true;} std::vector<std::wstring> listProfiles(){return {L"Main",L"PvP",L"Recording"};} bool Save(){return true;} bool loadProfile(const std::wstring&){return true;} bool deleteProfile(const std::wstring&){return true;} }
void ModulePhaseGuard::run(Module* m,Phase p){if(p==Phase::Enable)m->onEnable();if(p==Phase::Disable)m->onDisable();}
void TextHotkeysModule::onSlotEdited(const Setting*){}
}
using namespace nf; using namespace nf::ui;
static int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"CHECK FAILED "<<__LINE__<<": "<<#x<<"\n";std::abort();}}while(0)
void frame(float mx=-500,float my=-500,bool click=false){
    gui::BeginFrame(ImVec2(1440,900),ImVec2(mx,my),1.0f/60); gui::SetTextScale(2.5f);
    auto& io=ImGui::GetIO();io.DisplaySize=ImVec2(1440,900);io.DeltaTime=1.0f/60;
    io.MousePos=ImVec2(mx,my);overlay::g_guiMousePressed[0]=click;
    ImGui::NewFrame();Ctx c;c.d=ImGui::GetBackgroundDrawList();c.origin=ImVec2(0,0);c.dt=1.0f/60;c.interact=true;c.accent=gui::Accent();bool claimed=false;
    PaintReferenceShell(c,claimed); if(g_modal==M_Save)PaintSaveModal(c); ImGui::Render();overlay::g_guiMousePressed[0]=false;
}
void dump(const std::string& base){
 auto* dd=ImGui::GetDrawData();std::ofstream o(base+".mesh",std::ios::binary);
 auto wr=[&](auto x){o.write((char*)&x,sizeof(x));};wr((uint32_t)dd->CmdListsCount);
 for(int k=0;k<dd->CmdListsCount;k++){auto* l=dd->CmdLists[k];wr((uint32_t)l->VtxBuffer.Size);wr((uint32_t)l->IdxBuffer.Size);wr((uint32_t)l->CmdBuffer.Size);
 for(auto& v:l->VtxBuffer){wr(v.pos.x);wr(v.pos.y);wr(v.uv.x);wr(v.uv.y);wr(v.col);}for(auto i:l->IdxBuffer)wr((uint32_t)i);
 for(auto& c:l->CmdBuffer){wr(c.ClipRect.x);wr(c.ClipRect.y);wr(c.ClipRect.z);wr(c.ClipRect.w);wr(c.ElemCount);wr(c.IdxOffset);wr(c.VtxOffset);}}
 unsigned char* px;int w,h;ImGui::GetIO().Fonts->GetTexDataAsAlpha8(&px,&w,&h);std::ofstream t(base+".atlas",std::ios::binary);t.write((char*)&w,4);t.write((char*)&h,4);t.write((char*)px,w*h);
}
int main(int argc,char** argv){
 ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;
 static const ImWchar tr[]={0x20,0xff,0x400,0x52f,0x2000,0x206f,0x2de0,0x2dff,0xa640,0xa69f,0};
 io.Fonts->AddFontFromFileTTF(std::getenv("NF_TEST_UI_FONT"),24,nullptr,tr);
 static const ImWchar ir[]={0x20,0x7e,0xe000,0xe600,0};nf::fonts::icon=io.Fonts->AddFontFromFileTTF("src/fonts/lucide.ttf",24,nullptr,ir);
 unsigned char* pixels;int width,height;io.Fonts->GetTexDataAsAlpha8(&pixels,&width,&height);
 CHECK(io.Fonts->Fonts[0]->FindGlyphNoFallback(0x2026));CHECK(io.Fonts->Fonts[0]->FindGlyphNoFallback(0x2014));CHECK(io.Fonts->Fonts[0]->FindGlyphNoFallback(0x2022));
 modules().add(std::make_unique<GeneralModule>());modules().add(std::make_unique<ThemesModule>());
 auto add=[&](const char* name,const char* cat){auto m=std::make_unique<Module>(cat,name,"Настройки модуля Nightfull и его анимаций.");m->addSetting<EnumSetting>("Style","Выбери стиль отображения.",0,std::vector<std::string>{"Glass","Compact","Minimal"});m->addSetting<NumberSetting>("Intensity","Интенсивность эффекта.",0.65f,0.f,1.f,0.01f);m->addSetting<BoolSetting>("Animations","Плавные анимации элемента.",true);m->addSetting<ColorSetting>("Accent color","Цвет акцентов и индикатора.",0xff8ae4ff);m->addSetting<StringSetting>("Custom label","Текст рядом с элементом HUD.","Nightfull",128);Module* p=m.get();modules().add(std::move(m));return p;};
 Module* a=add("Armor HUD","HUD");add("Cooldowns","HUD");add("Target HUD","HUD");add("Keystrokes","HUD");add("Potions","HUD");add("Crosshair","Visual");add("AutoSprint","Movement");add("TextHotkeys","Client");
 // Verify actual controls and data state, not HTML mock controls.
 for(int n=0;n<90;n++)frame();const float cw=(kRefCenterW-16)/3;
 CHECK(RefModuleSettingsHeight(a)==94+10+90+10+64+10+78+10+102+10);
 auto hidden=a->addSetting<BoolSetting>("Hidden","",true);hidden->mIsVisible=[] {return false;};CHECK(RefModuleSettingsHeight(a)==478);
 bool initial=a->enabled();frame(kRefCenterX+cw-24,kRefBodyY+27,true);CHECK(a->enabled()!=initial);frame();
 frame(kRefCenterX+cw-53,kRefBodyY+27,true);CHECK(SystemFavorite(a));frame();SystemToggleFavorite(a);CHECK(!SystemFavorite(a));
 frame(kRefCenterX+40,kRefBodyY+27,true);CHECK(!a->uiExpanded);for(int n=0;n<90;n++)frame();CHECK(a->uiExpandT<0.002f);
 a->uiExpanded=true;for(int n=0;n<90;n++)frame();
 frame(kRefCenterX+60,kRefBodyY+72+54+15,true);CHECK(g_systemEnum!=nullptr);CHECK(KeyboardCaptured());frame();
 float ey=(g_systemEnumRect.w)+4;frame(kRefCenterX+80,ey+4+34+17,true);CHECK(static_cast<EnumSetting*>(a->findSetting("Style"))->mValue==1);CHECK(!g_systemEnum);
 g_systemEnum=static_cast<EnumSetting*>(a->findSetting("Style"));CHECK(DismissTopmost());CHECK(!g_systemEnum);
 overlay::g_guiMouseWheel=-1;frame(kRefCenterX+40,700);overlay::g_guiMouseWheel=0;CHECK(g_systemColumnTarget[0]>0);CHECK(g_systemColumnTarget[1]==0);
 std::strcpy(g_search,"no-such-module");std::vector<Module*> out;RefCollect(-1,out);CHECK(out.empty());g_search[0]=0;
 GeneralModule::instance()->m_guiAppearance->setValue(1);SystemPalette();CHECK(kText.Value.x>0.8f);GeneralModule::instance()->m_guiAppearance->setValue(0);SystemPalette();CHECK(kText.Value.x<0.2f);

 // Slider capture updates the actual number and releases on the input edge.
 for(int col=0;col<3;col++)g_systemColumnScroll[col]=g_systemColumnTarget[col]=0;
 auto* ns=static_cast<NumberSetting*>(a->findSetting("Intensity"));
 frame(kRefCenterX+16+(cw-32)*0.4f,kRefBodyY+72+104+90-23+7,true);CHECK(g_dragV==&ns->mValue);UpdateFloatDrag();CHECK(std::fabs(ns->mValue-0.4f)<0.01f);overlay::g_guiMouseReleased[0]=true;UpdateFloatDrag();CHECK(!g_dragV);overlay::g_guiMouseReleased[0]=false;ns->mValue=0.65f;frame();
 // Boolean setting uses its own switch; it must not toggle the module.
 const bool enabledBefore = a->enabled();
 auto* bs=static_cast<BoolSetting*>(a->findSetting("Animations"));bool boolBefore=bs->mValue;
 for(int col=0;col<3;col++)g_systemColumnScroll[col]=g_systemColumnTarget[col]=0;
 frame(kRefCenterX+cw-45,kRefBodyY+72+104+100+24,true);CHECK(bs->mValue!=boolBefore);CHECK(a->enabled()==enabledBefore);frame();
 // String edit claims keyboard and ESC restores the exact original value.
 auto* ss=static_cast<StringSetting*>(a->findSetting("Custom label"));std::string before=ss->mValue;
 frame(kRefCenterX+80,kRefBodyY+72+104+100+74+88+65,true);CHECK(g_stringEditSetting==ss);CHECK(KeyboardCaptured());ss->mValue="changed";CHECK(DismissTopmost());CHECK(ss->mValue==before);
 auto* cs=static_cast<ColorSetting*>(a->findSetting("Accent color"));
 frame(kRefCenterX+cw-30,kRefBodyY+72+104+100+74+25,true);CHECK(g_colorEditSetting==cs);CHECK(RefModuleSettingsHeight(a)==624);CHECK(DismissTopmost());CHECK(!g_colorEditSetting);frame();
 g_animsOff=true;a->uiExpanded=false;frame();CHECK(a->uiExpandT==0);a->uiExpanded=true;frame();CHECK(a->uiExpandT==1);g_animsOff=false;
 // External HUD right-click opens the module's real category, even if search/config/favorites were active.
 g_systemConfigs=true;g_systemFavoritesOnly=true;std::strcpy(g_search,"missing");OpenModuleSettings(a);CHECK(g_refCategory==3);CHECK(!g_systemConfigs&&!g_systemFavoritesOnly);CHECK(!g_search[0]);CHECK(a->uiExpanded);frame();CHECK(!g_systemFocus);g_refCategory=-1;for(int n=0;n<90;n++)frame();
 std::string fit=SystemFit("Очень длинное название модуля",60,14,Ctx{});CHECK(fit.find("…")!=std::string::npos);CHECK(fit.size()>3);
 g_systemColumnScroll[0]=g_systemColumnTarget[0]=0;
 std::string mode=argc>1?argv[1]:"light";
 if(mode=="dark")GeneralModule::instance()->m_guiAppearance->setValue(1);
 if(mode=="empty")std::strcpy(g_search,"Not found");
 if(mode=="settings")g_showGeneral=true;
 if(mode=="themes")g_refCategory=6;
 if(mode=="configs")g_systemConfigs=true;
 if(mode=="save"){g_systemConfigs=true;g_modal=M_Save;std::strcpy(g_profileName,"PvP");}
 for(int n=0;n<90;n++)frame();
 if(mode=="enum"){frame(kRefCenterX+60,kRefBodyY+72+54+15,true);frame();}
 if(mode=="color"){g_colorEditSetting=static_cast<ColorSetting*>(a->findSetting("Accent color"));for(int n=0;n<90;n++)frame();}
 if(argc>2)dump(argv[2]);
 std::cout<<"PASS "<<checks<<" native GUI checks; vertices="<<ImGui::GetDrawData()->TotalVtxCount<<"\n";ImGui::DestroyContext();
}
