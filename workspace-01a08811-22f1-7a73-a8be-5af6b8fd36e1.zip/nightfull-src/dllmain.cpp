// dllmain.cpp - DLL entry point (thin layer over the overlay engine).
//
// The heavy lifting lives in overlay.cpp (hooks, render, input) and
// ui/clickgui.cpp (the menu). This file only:
//   - spawns the injector thread on DLL_PROCESS_ATTACH,
//   - on DLL_PROCESS_DETACH asks the engine to tear down cleanly,
//     then waits a moment so the engine thread can finish its cleanup.
//
// The engine never blocks on the loader lock: all D3D/ImGui work happens in
// the spawned thread and inside hooked game code (not in DllMain).
//
// NOTE: ASCII only in this file (project rule).

#include "pch.h"
#include "overlay.h"

namespace {
DWORD WINAPI AttachThread(LPVOID param) {
    HMODULE hMod = (HMODULE)param;
    overlay::MainThread(hMod);
    return 0;
}
} // namespace

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        HANDLE hThread = CreateThread(nullptr, 0, AttachThread, hModule, 0, nullptr);
        if (hThread) CloseHandle(hThread);
    }
    else if (reason == DLL_PROCESS_DETACH) {
        overlay::NotifyDetach();
    }
    return TRUE;
}