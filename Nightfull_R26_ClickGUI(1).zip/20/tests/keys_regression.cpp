// State/UTF-8 tests against real keys.cpp with a mocked Windows API.
// Not a Windows build, a real keyboard-layout test, or an in-game test.
#include <Windows.h>
#include "utils/keys.h"
#include <cassert>
#include <cstring>
#include <iostream>
#include <thread>
#include <vector>
using namespace nf::keys;
static char text[512] = {};
static void fresh(bool capture = true) {
    SetTextCapture(false); Reset(); SetTextCapture(capture);
    std::memset(testAsync, 0, sizeof(testAsync));
    testRussian = testCaps = false; testClock = 0; text[0] = 0;
}
static void tap(unsigned key) { FeedKey(key, true); FeedKey(key, false); }
static void drain() { TextInput(text, sizeof(text), true); }
int main() {
    std::vector<std::thread> threads;
    for (unsigned i = 0; i < 8; ++i)
        threads.emplace_back([i] { FeedKey('A' + i, true); FeedKey('A' + i, false); });
    for (auto& t : threads) t.join();
    fresh(); tap('A'); drain(); assert(std::strcmp(text, "a") == 0);
    fresh();
    FeedKey('A', true); FeedKey('A', true); FeedKey('A', true); FeedChar('a');
    drain(); assert(std::strcmp(text, "a") == 0);
    fresh(); tap('A'); tap('B'); tap('C'); drain();
    assert(std::strcmp(text, "abc") == 0);
    BeginFrame(); assert(PressedThisFrame('A')); assert(!Down('A'));
    BeginFrame(); assert(!PressedThisFrame('A'));
    fresh(); FeedKey(VK_RSHIFT, true); tap('A'); drain();
    assert(std::strcmp(text, "A") == 0); BeginFrame(); assert(Down(VK_SHIFT));
    FeedKey(VK_RSHIFT, false); BeginFrame(); assert(!Down(VK_SHIFT));
    fresh(); testCaps = true; tap('A'); drain(); assert(std::strcmp(text, "A") == 0);
    fresh(); testRussian = true; tap('F'); drain();
    assert(std::strcmp(text, "\xD0\xB0") == 0);
    tap(VK_BACK); drain(); assert(text[0] == 0);
    fresh(); tap(0xBF); tap('S'); tap('P'); tap('A'); tap('W'); tap('N'); drain();
    assert(std::strcmp(text, "/spawn") == 0);
    fresh(); FeedKey(VK_RCONTROL, true); FeedKey('V', true); BeginFrame(); drain();
    assert(text[0] == 0); assert(Down(VK_CONTROL)); assert(PressedThisFrame('V'));
    fresh(); FeedKey('A', true); BeginFrame(); drain();
    testClock = 449; BeginFrame(); drain(); assert(std::strcmp(text, "a") == 0);
    testClock = 450; BeginFrame(); drain(); assert(std::strcmp(text, "aa") == 0);
    FeedKey('A', false); testClock = 600; BeginFrame(); drain();
    assert(std::strcmp(text, "aa") == 0);
    fresh(); tap('A'); TextInput(nullptr, 0, false); drain(); assert(text[0] == 0);
    tap('B'); drain(); assert(std::strcmp(text, "b") == 0);
    fresh(false); FeedChar(0xD83D); drain(); assert(text[0] == 0);
    FeedChar(0xDE00); drain(); assert(std::strcmp(text, "\xF0\x9F\x98\x80") == 0);
    FeedChar(8); drain(); assert(text[0] == 0);
    FeedChar(0xDC00); drain(); assert(text[0] == 0);
    fresh(false); char small[2] = {};
    FeedChar(0x0430); TextInput(small, sizeof(small), true); assert(small[0] == 0);
    fresh(); testAsync['A'] = (short)0x8000;
    const unsigned before = testPolls;
    do { BeginFrame(); } while (testPolls == before);
    assert(Down('A'));
    testAsync['B'] = (short)0x8000;
    FeedKey('B', true); BeginFrame(); assert(Down('B'));
    BeginFrame(); assert(Down('B')); assert(!PressedThisFrame('B'));
    FeedKey('B', false); BeginFrame(); assert(!Down('B'));
    fresh(); FeedKey(999, true); assert(!Down(999)); assert(!PressedThisFrame(999));
    std::cout << "PASS: keyboard regression suite (mocked Win32)\n";
}
