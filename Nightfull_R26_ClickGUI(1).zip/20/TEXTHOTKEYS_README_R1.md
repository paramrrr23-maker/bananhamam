# TextHotkeys R1

Added `TextHotkeys` to the existing Nightfull module registry.

## Behaviour

- Six persistent slots are available in the existing module settings UI.
- Each slot has `Key`, `Text`, `Name`, and `Enabled`; the UI presents the
  key capture first, then the message field.
- Empty or disabled slots behave like deleted bindings.
- Commands and normal chat text are both accepted.
- `keys::PressedThisFrame()` is used, so a held key fires once only.
- There is deliberately no cooldown, debounce, timer, or minimum interval.
- Every later physical key press creates a new send attempt.
- `INSERT` and `END` remain reserved by the client.
- Settings are persisted by the existing Nightfull JSON config/profile system.

## Delivery path

The module uses the existing game window input path: it opens chat, posts
UTF-16 text into the current chat input, and submits with Enter. Minecraft's
own chat/command UI remains responsible for parsing, validation, and network
delivery. No packet format or parallel chat transport was added.

## Example

Configure one slot as:

```text
Key: 71   (G)
Text: /spawn
Name: Spawn
Enabled: ON
```

The settings UI now supports editing StringSetting values directly: click the
text field, type, press Enter to commit, or Escape to cancel.
