#include "modules/text_hotkeys.h"

#include <Windows.h>
#include <cstdio>
#include <string>

#include "overlay/overlay.h"
#include "utils/keys.h"
#include "utils/logger.h"

namespace nf {

TextHotkeysModule::TextHotkeysModule()
    : Module("Client", "TextHotkeys",
             "Send saved text or commands once per physical key press") {
    for (int i = 0; i < kSlots; ++i) {
        char label[32];
        std::snprintf(label, sizeof(label), "Slot %d", i + 1);
        std::string prefix = label;
        Slot& s = m_slots[i];
        // Setting names are config keys - never rename them.
        s.key = addSetting<NumberSetting>(prefix + " Key",
                                          "Клик -> нажми клавишу. ПКМ / Backspace - сбросить.",
                                          0.0f, 0.0f, 255.0f, 1.0f);
        s.key->mIsKeybind = true;
        s.text = addSetting<StringSetting>(prefix + " Text",
                                           "Текст или команда (/spawn). Enter - сохранить.",
                                           "", 400);
        s.name = addSetting<StringSetting>(prefix + " Name",
                                           "Подпись для себя (необязательно).",
                                           "", 32);
        s.enabled = addSetting<BoolSetting>(prefix + " Enabled",
                                            "Слот активен.", true);
    }
    setEnabled(true);
}

void TextHotkeysModule::onTick() {
    // Dispatch is called by ui::DispatchBinds(), which already performed the
    // gameplay-screen gate. Keeping this tick empty avoids repeating the
    // expensive screen proof for every frame.
}

void TextHotkeysModule::dispatchPressedBinds() {
    for (int i = 0; i < kSlots; ++i) {
        const Slot& s = m_slots[i];
        if (!s.name || !s.key || !s.text || !s.enabled) continue;
        // r34: Name is only a label now. It used to be mandatory, so a slot
        // with a key + text but no name silently never fired.
        if (!s.enabled->mValue || s.text->mValue.empty()) continue;

        const int vk = (int)s.key->mValue;
        if (vk <= 0 || vk >= 256) continue;
        if (!keys::PressedThisFrame((unsigned)vk)) continue;
        if (vk == overlay::g_menuKey || vk == VK_END) continue;

        if (overlay::SendChatText(s.text->mValue.c_str())) {
            LOG_INFO("text_hotkeys: fired slot=%d name=%s key=%s",
                     i + 1, s.name->mValue.c_str(), keys::Name((unsigned)vk));
        } else {
            LOG_INFO("text_hotkeys: send skipped slot=%d name=%s",
                     i + 1, s.name->mValue.c_str());
        }
    }
}

void TextHotkeysModule::onSlotEdited(const Setting* edited) {
    if (!edited) return;
    for (int i = 0; i < kSlots; ++i) {
        Slot& s = m_slots[i];
        if (edited != s.key && edited != s.text) continue;
        if (s.enabled && s.key && s.text && s.key->mValue > 0.0f &&
            !s.text->mValue.empty() && !s.enabled->mValue) {
            s.enabled->mValue = true;
            LOG_INFO("text_hotkeys: slot %d auto-enabled", i + 1);
        }
        return;
    }
}

} // namespace nf
