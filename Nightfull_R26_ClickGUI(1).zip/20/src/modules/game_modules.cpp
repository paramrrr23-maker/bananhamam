// game_modules.cpp - AutoSprint, FullBright and NoHurtCam.

#include "modules/game_modules.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

#include "core/module_manager.h"
#include "overlay/overlay.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/logger.h"

namespace nf {
namespace {

constexpr int kBoxEdges[12][2] = {
    {0, 1}, {1, 3}, {3, 2}, {2, 0},
    {4, 5}, {5, 7}, {7, 6}, {6, 4},
    {0, 4}, {1, 5}, {2, 6}, {3, 7}
};

void DrawWhiteBoxLine(ImDrawList* draw, const ImVec2& start,
                      const ImVec2& end, ImU32 color, float width,
                      const ImVec2& screen) {
    if (!draw) return;
    // Match DrawUtils::addLine: a projected endpoint outside GuiData's screen
    // is rejected instead of letting ImGui stretch an edge across the frame.
    if (start.x < 0.0f || start.x > screen.x || start.y < 0.0f || start.y > screen.y ||
        end.x < 0.0f || end.x > screen.x || end.y < 0.0f || end.y > screen.y)
        return;
    draw->AddLine(start, end, color, width);
}

// Convex hull polygon of the projected box corners (the walk behind Flarial's
// DrawUtils::addBox mode 2). Returned as unique vertices in wrap order; the
// polygon is treated as closed by every consumer.
struct HullPoly {
    ImVec2 pts[16] = {};
    int count = 0;
};

static HullPoly BuildHullPoly(const ImVec2 points[8], const bool valid[8]) {
    HullPoly hull;
    // Compact (original index, screen point) list of projected corners.
    //
    // Fixed-size stack storage. This runs once per actor per frame, and the
    // previous std::vector<std::tuple<int, ImVec2>> + std::vector<int> pair
    // cost two heap allocations per actor for at most 8 elements each - up to
    // ~3 000 allocations per second at 26 actors and 60 FPS.
    struct Cord { int idx; ImVec2 pt; };
    Cord cords[8];
    int cordCount = 0;
    for (int i = 0; i < 8; ++i) {
        if (valid[i]) cords[cordCount++] = Cord{ i, points[i] };
    }
    if (cordCount < 3) {
        // A degenerate (edge-on) box still has a usable line hull.
        for (int i = 0; i < cordCount; ++i)
            if (hull.count < 16) hull.pts[hull.count++] = cords[i].pt;
        return hull;
    }

    // Leftmost corner starts the wrap.
    Cord start = cords[0];
    for (int i = 1; i < cordCount; ++i) {
        if (cords[i].pt.x < start.pt.x) start = cords[i];
    }

    constexpr float kPi = 3.1415927f;
    int indices[8] = {};
    int indexCount = 0;
    Cord current = start;
    indices[indexCount++] = current.idx;
    ImVec2 lastDir(0.0f, -1.0f);
    do {
        float smallestAngle = kPi * 2.0f;
        ImVec2 smallestDir(0.0f, 0.0f);
        Cord smallestE = current;
        bool found = false;
        const float lastAtan = std::atan2(lastDir.y, lastDir.x);
        for (int i = 0; i < cordCount; ++i) {
            if (current.idx == cords[i].idx) continue;
            ImVec2 dir(cords[i].pt.x - current.pt.x,
                       cords[i].pt.y - current.pt.y);
            float angle = std::atan2(dir.y, dir.x) - lastAtan;
            if (angle > kPi) angle -= 2.0f * kPi;
            else if (angle <= -kPi) angle += 2.0f * kPi;
            if (angle >= 0.0f && angle < smallestAngle) {
                smallestAngle = angle;
                smallestDir = dir;
                smallestE = cords[i];
                found = true;
            }
        }
        if (!found) break;
        if (indexCount >= 8) break;   // same cap the walk used before
        indices[indexCount++] = smallestE.idx;
        lastDir = smallestDir;
        current = smallestE;
    } while (current.idx != start.idx && indexCount < 8);

    for (int k = 0; k < indexCount; ++k) {
        for (int i = 0; i < cordCount; ++i) {
            if (cords[i].idx != indices[k]) continue;
            if (hull.count < 16) hull.pts[hull.count++] = cords[i].pt;
            break;
        }
    }
    // Drop the duplicate closing vertex if the walk returned to the start.
    if (hull.count > 1 && hull.pts[0].x == hull.pts[hull.count - 1].x &&
        hull.pts[0].y == hull.pts[hull.count - 1].y)
        --hull.count;
    return hull;
}

// Closed-polygon segments. When screenBounds is given, endpoints outside the
// GuiData screen are rejected (Flarial's addLine behaviour for the sharp
// outline); glow and fill passes pass nullptr and rely on ImGui clipping.
static void DrawHullSegments(ImDrawList* draw, const HullPoly& hull,
                             ImU32 color, float width,
                             const ImVec2* screenBounds = nullptr) {
    if (!draw || hull.count < 2 || width <= 0.0f) return;
    const int segs = hull.count > 2 ? hull.count : 1;
    for (int i = 0; i < segs; ++i) {
        const ImVec2& a = hull.pts[i];
        const ImVec2& b = hull.pts[(i + 1) % hull.count];
        if (a.x == b.x && a.y == b.y) continue;
        if (screenBounds)
            DrawWhiteBoxLine(draw, a, b, color, width, *screenBounds);
        else
            draw->AddLine(a, b, color, width);
    }
}

// SystemDLC-style box glow ("Свечение бокса"): a soft multi-pass halo stroked
// around the box silhouette. Approximates their blur post-effect with layered
// strokes - widest and faintest first, brightest core last.
//
// The pass colors/widths only depend on the module settings (and ImGui style),
// which are frame-constant, so the plan is built once per frame and every
// hull in that frame reuses it: the ImGui color conversions and the pass
// arithmetic run once per frame instead of once per pass per actor.
struct HullGlowPlan {
    static constexpr int kMaxPasses = 6;
    ImU32 colors[kMaxPasses] = {};
    float widths[kMaxPasses] = {};
    int passCount = 0;
};

static HullGlowPlan BuildHullGlowPlan(const ImVec4& color, float radius,
                                      float brightness) {
    HullGlowPlan plan;
    if (radius < 1.0f || brightness <= 0.0f) return plan;
    constexpr int kPasses = 6;
    ImU32 prevColor = 0;
    float prevWidth = 0.0f;
    for (int p = kPasses; p >= 1; --p) {
        const float t = (float)p / (float)kPasses;
        const float falloff = (1.0f - t) * (1.0f - t);
        const float alpha = brightness * 0.20f * falloff;
        if (alpha < 0.004f) continue;
        const float w = std::max(1.0f, radius * t);
        const ImU32 c = ImGui::GetColorU32(ImVec4(
            color.x, color.y, color.z, std::min(1.0f, alpha)));
        // Two consecutive passes with identical width and color (possible
        // when the radius clamps to the 1 px width floor) stroke the same
        // polygon - skip the inner duplicate.
        if (plan.passCount > 0 && w == prevWidth && c == prevColor) continue;
        plan.colors[plan.passCount] = c;
        plan.widths[plan.passCount] = w;
        ++plan.passCount;
        prevColor = c;
        prevWidth = w;
    }
    return plan;
}

static void DrawHullGlow(ImDrawList* draw, const HullPoly& hull,
                         const HullGlowPlan& plan) {
    if (!draw || hull.count < 2 || plan.passCount == 0) return;
    const int segs = hull.count > 2 ? hull.count : 1;
    for (int p = 0; p < plan.passCount; ++p) {
        for (int i = 0; i < segs; ++i) {
            const ImVec2& a = hull.pts[i];
            const ImVec2& b = hull.pts[(i + 1) % hull.count];
            if (a.x == b.x && a.y == b.y) continue;
            draw->AddLine(a, b, plan.colors[p], plan.widths[p]);
        }
    }
}

// Wavy animated outline (SystemDLC "огненная волнистая обводка"): displace
// each hull vertex along its polygon normal with a time-phased sine.
static void DisplaceHullWavy(HullPoly& hull, float timeSec, float strengthPx) {
    const int n = hull.count;
    if (n < 3 || strengthPx <= 0.0f) return;
    ImVec2 src[16];
    for (int i = 0; i < n; ++i) src[i] = hull.pts[i];
    for (int i = 0; i < n; ++i) {
        const ImVec2& prev = src[(i + n - 1) % n];
        const ImVec2& next = src[(i + 1) % n];
        const float tx = next.x - prev.x;
        const float ty = next.y - prev.y;
        const float len = std::sqrt(tx * tx + ty * ty);
        if (len < 0.001f) continue;
        const float nx = -ty / len;
        const float ny = tx / len;
        const float wave =
            std::sin(timeSec * 3.1f + (float)i * 2.399963f);
        hull.pts[i].x = src[i].x + nx * strengthPx * wave;
        hull.pts[i].y = src[i].y + ny * strengthPx * wave;
    }
}

// Box fill (SystemDLC "Заливка"): fill the camera-facing sides of the cuboid.
// The visibility test runs in world space against each face's outward normal,
// so exactly the three front faces are drawn regardless of the projection
// convention, and alpha blending never stacks a back face under a front face.
static void DrawBoxFill3D(ImDrawList* draw, const float mins[3],
                          const float maxs[3], const ImVec2 points[8],
                          const bool valid[8], const float camera[3],
                          ImU32 color) {
    static constexpr int kFaces[6][4] = {
        {0, 1, 3, 2},  // -Z
        {4, 5, 7, 6},  // +Z
        {0, 2, 6, 4},  // -X
        {1, 3, 7, 5},  // +X
        {0, 1, 5, 4},  // -Y
        {2, 3, 7, 6},  // +Y
    };
    static constexpr float kNormals[6][3] = {
        {0.0f, 0.0f, -1.0f}, {0.0f, 0.0f, 1.0f},
        {-1.0f, 0.0f, 0.0f}, {1.0f, 0.0f, 0.0f},
        {0.0f, -1.0f, 0.0f}, {0.0f, 1.0f, 0.0f},
    };
    if (!draw) return;
    for (int f = 0; f < 6; ++f) {
        const int* quad = kFaces[f];
        ImVec2 screen[4];
        float cx = 0.0f, cy = 0.0f, cz = 0.0f;
        bool ok = true;
        for (int k = 0; k < 4; ++k) {
            const int c = quad[k];
            if (!valid[c]) { ok = false; break; }
            screen[k] = points[c];
            cx += ((c & 1) ? maxs[0] : mins[0]) * 0.25f;
            cy += ((c & 2) ? maxs[1] : mins[1]) * 0.25f;
            cz += ((c & 4) ? maxs[2] : mins[2]) * 0.25f;
        }
        if (!ok) continue;
        if (kNormals[f][0] * (cx - camera[0]) +
                kNormals[f][1] * (cy - camera[1]) +
                kNormals[f][2] * (cz - camera[2]) >=
            0.0f)
            continue;  // back face or edge-on
        draw->AddQuadFilled(screen[0], screen[1], screen[2], screen[3], color);
    }
}

// Project all 8 corners and report per-corner validity.
//
// Flarial's DrawUtils::addBox(mode 1) pushes each of the 12 edges through
// addLine3D independently, so an edge whose endpoint falls outside the frustum
// is skipped while the remaining edges still draw. Requiring all 8 corners to
// project - as the previous version did - dropped the entire box as soon as one
// corner crossed the near plane, which made close entities lose their hitbox.
int ProjectBox(const float mins[3], const float maxs[3], ImVec2 points[8],
               float depths[8], bool valid[8]) {
    if (!mins || !maxs || !points || !depths || !valid) return 0;
    int validCount = 0;
    for (int corner = 0; corner < 8; ++corner) {
        // Same corner ordering as Flarial's DrawUtils::addBox vertices[]:
        // bit0 = x max, bit1 = y max, bit2 = z max.
        const float world[3] = {
            (corner & 1) ? maxs[0] : mins[0],
            (corner & 2) ? maxs[1] : mins[1],
            (corner & 4) ? maxs[2] : mins[2]
        };
        float sx = 0.0f, sy = 0.0f, depth = 0.0f;
        valid[corner] =
            overlay::ProjectWorldToScreen(world, &sx, &sy, &depth) &&
            std::isfinite(sx) && std::isfinite(sy) &&
            std::isfinite(depth) && depth >= 0.3f;
        if (!valid[corner]) continue;
        points[corner] = ImVec2(sx, sy);
        depths[corner] = depth;
        ++validCount;
    }
    return validCount;
}

} // namespace

AutoSprintModule::AutoSprintModule()
    : Module("Movement", "AutoSprint", "Automatically sprints while moving") {
    // Mirrors the reference module's user-facing control. When disabled, the
    // module remains available in ClickGUI but does not synthesize sprint.
    m_alwaysSprint = addSetting<BoolSetting>(
        "Always Sprint", "Automatically hold sprint while moving", true);
}

void AutoSprintModule::onEnable() {
    // Flarial Sprint parity: the baseTick hook writes the MoveInputComponent
    // sprint flags for the local player on every game tick while enabled.
    overlay::SetAutoSprintEnabled(true);
}

void AutoSprintModule::onDisable() {
    // No restore writes: the game re-authors its input state every tick and
    // stops sprinting as soon as the flags stop being forced.
    overlay::SetAutoSprintEnabled(false);
}

FullBrightModule::FullBrightModule()
    : Module("Visual", "FullBright", "Raises the in-game gamma") {
    // Bedrock's normal gamma is approximately 1.0; Solstice/Flarial use a
    // high gamma value (13-25) for full brightness. Keep it user-adjustable.
    m_gamma = addSetting<NumberSetting>(
        "Brightness", "Target gamma returned by the Options hook", 13.0f,
        1.0f, 25.0f, 0.5f);
}

void FullBrightModule::onEnable() {
    m_currentGamma = 1.0f;
}

void FullBrightModule::onDisable() {
    // The hook returns vanilla gamma when disabled; animate our local value
    // back as well so a later enable starts from a predictable state.
    m_currentGamma = 1.0f;
}

void FullBrightModule::onRender() {
    const float target = m_gamma ? m_gamma->mValue : 13.0f;
    const float dt = std::max(0.0f, std::min(0.25f, ImGui::GetIO().DeltaTime));
    // Same smooth target behavior as the reference implementation, without
    // touching Options memory directly.
    const float amount = std::min(1.0f, 10.0f * dt);
    m_currentGamma += (target - m_currentGamma) * amount;
}

NoHurtCamModule::NoHurtCamModule()
    : Module("Visual", "NoHurtCam", "Solstice-style validated camera instruction patch") {}

void NoHurtCamModule::onEnable() {
    // The overlay resolves the Solstice CameraComponent candidate once and
    // refuses to patch when it is missing or ambiguous.
    overlay::SetNoHurtCamEnabled(true);
}

void NoHurtCamModule::onDisable() {
    overlay::SetNoHurtCamEnabled(false);
}

void NoHurtCamModule::onTick() {
    if (enabled())
        overlay::SetNoHurtCamEnabled(true);
}

// ======================== Saturation ========================
// Flarial HueChanger parity: one slider ("Saturation Intensity" there,
// "Intensity" here), range 0..3, default 0.5. The overlay applies the filter
// to the game frame before the HUD, exactly like Flarial's D2D pass.
SaturationModule::SaturationModule()
    : Module("Visual", "Saturation", "Фильтр насыщенности как во Flarial") {
    m_intensity = addSetting<NumberSetting>(
        "Intensity", "Saturation factor: 0 = grayscale, 1 = unchanged, up to 3 = oversaturated",
        0.5f, 0.0f, 3.0f, 0.05f);
}

void SaturationModule::onEnable() {
    overlay::SetSaturationEnabled(true);
    overlay::SetSaturationIntensity(m_intensity ? m_intensity->mValue : 0.5f);
}

void SaturationModule::onTick() {
    // Live slider updates while the module runs (like CpsLimiter).
    overlay::SetSaturationIntensity(m_intensity ? m_intensity->mValue : 0.5f);
}

void SaturationModule::onDisable() {
    overlay::SetSaturationEnabled(false);
}

// ======================== Motion Blur ========================
// All GPU work lives in the overlay (same pass discipline as Saturation):
// the module only publishes its settings every frame. "Only in world" and
// "Pause in ClickGUI" gate the pass itself; re-arming it resets the history
// so an old frame never bleeds into the first blurred one.
MotionBlurModule::MotionBlurModule()
    : Module("Visual", "Motion Blur", "Frame-accumulation motion blur on the game image") {
    m_mode = addSetting<EnumSetting>(
        "Mode", "Blend = smooth accumulated trail, Ghost = mix with the previous frame only.",
        0, std::vector<std::string>{ "Blend", "Ghost" });
    m_intensity = addSetting<NumberSetting>(
        "Intensity", "How much of the previous image stays on screen (0 = off, 0.95 = heavy).",
        0.55f, 0.0f, 0.95f, 0.01f);
    m_fpsIndependent = addSetting<BoolSetting>(
        "FPS Independent", "Same trail length at any frame rate (scaled to Reference FPS).", true);
    m_refFps = addSetting<NumberSetting>(
        "Reference FPS", "Frame rate at which Intensity is applied as-is.",
        60.0f, 30.0f, 360.0f, 1.0f);
    m_refFps->mIsVisible = [this] { return m_fpsIndependent && m_fpsIndependent->mValue; };
    m_onlyInWorld = addSetting<BoolSetting>(
        "Only In World", "Skip the blur on the main menu and loading screens.", true);
    m_pauseInMenu = addSetting<BoolSetting>(
        "Pause In ClickGUI", "No blur while the Nightfull menu or HUD editor is open.", false);
}

void MotionBlurModule::push() {
    bool active = true;
    if (m_onlyInWorld && m_onlyInWorld->mValue && !overlay::IsInWorld()) active = false;
    if (m_pauseInMenu && m_pauseInMenu->mValue &&
        (overlay::g_showMenu || overlay::HudEditActive()))
        active = false;
    overlay::SetMotionBlurParams(m_intensity ? m_intensity->mValue : 0.55f,
                                 m_mode ? m_mode->mValue : 0,
                                 m_fpsIndependent ? m_fpsIndependent->mValue : true,
                                 m_refFps ? m_refFps->mValue : 60.0f);
    overlay::SetMotionBlurEnabled(active);
}

void MotionBlurModule::onEnable() { push(); }

void MotionBlurModule::onTick() {
    // Live settings + gates while the module runs (like Saturation).
    push();
}

void MotionBlurModule::onDisable() {
    overlay::SetMotionBlurEnabled(false);
}

// ======================== World particles ========================
WorldParticlesModule::WorldParticlesModule()
    : Module("Visual", "World Particles", "Ambient particles with conservative block collision and world occlusion") {
    m_count = addSetting<NumberSetting>("Count", "Maximum particles in the world.", 80.0f, 10.0f, 300.0f, 1.0f);
    m_radius = addSetting<NumberSetting>("Radius", "Spawn and draw radius around the camera in blocks.", 8.0f, 2.0f, 14.0f, 0.5f);
    m_size = addSetting<NumberSetting>("Size", "Screen size of each particle.", 3.0f, 1.0f, 12.0f, 0.5f);
    m_speed = addSetting<NumberSetting>("Speed", "Horizontal and falling motion speed.", 0.8f, 0.0f, 3.0f, 0.05f);
    m_gravity = addSetting<NumberSetting>("Gravity", "Downward acceleration; zero makes particles float.", 0.12f, 0.0f, 1.0f, 0.01f);
    m_shape = addSetting<EnumSetting>("Shape", "Particle glyph.", 0, std::vector<std::string>{"Snowflake", "Dot", "Dollar", "Star", "Heart"});
    m_color = addSetting<ColorSetting>("Color", "Particle color.", 0xD9FFFFFFu);
}

void WorldParticlesModule::resetParticle(Particle& p, const float camera[3], unsigned int index) {
    p.seed = index * 747796405u + 2891336453u;
    auto rnd = [&]() { p.seed = p.seed * 1664525u + 1013904223u; return (p.seed & 0x00FFFFFFu) / 16777215.0f; };
    const float r = m_radius ? m_radius->mValue : 8.0f;
    const float angle = rnd() * 6.2831853f;
    const float dist = std::sqrt(rnd()) * r;
    p.p[0] = camera[0] + std::cos(angle) * dist;
    p.p[1] = camera[1] - 1.0f + rnd() * (r * 1.8f + 2.0f);
    p.p[2] = camera[2] + std::sin(angle) * dist;
    p.v[0] = (rnd() - 0.5f) * 0.35f;
    p.v[1] = -(0.08f + rnd() * 0.16f);
    p.v[2] = (rnd() - 0.5f) * 0.35f;
    p.age = rnd() * 4.0f;
}

void WorldParticlesModule::onEnable() {
    LOG_INFO("particles: World Particles enabled (safe render-only mode)");
    overlay::SetParticleWorldEnabled(true);
    m_particles.clear();
    m_visible.clear();
    m_nextVisibilityCheck = 0;
}

void WorldParticlesModule::onDisable() {
    LOG_INFO("particles: World Particles disabled");
    overlay::SetParticleWorldEnabled(false);
    m_particles.clear();
    m_visible.clear();
    m_nextVisibilityCheck = 0;
}

void WorldParticlesModule::onTick() {
    if (overlay::g_showMenu || !overlay::IsInWorld()) return;
    float camera[3] = {};
    if (!overlay::GetCameraWorldPosition(camera)) return;
    const int wanted = (int)(m_count ? m_count->mValue : 80.0f);
    if ((int)m_particles.size() < wanted) {
        const size_t old = m_particles.size();
        m_particles.resize((size_t)wanted);
        m_visible.resize((size_t)wanted, 1);
        for (size_t i = old; i < m_particles.size(); ++i) resetParticle(m_particles[i], camera, (unsigned int)i);
    } else if ((int)m_particles.size() > wanted) {
        m_particles.resize((size_t)wanted);
        m_visible.resize((size_t)wanted, 1);
    }
    const float dt = gui::Clamp(gui::GetDeltaTime(), 0.001f, 0.05f);
    const float speed = m_speed ? m_speed->mValue : 0.8f;
    const float gravity = m_gravity ? m_gravity->mValue : 0.12f;
    const float radius = m_radius ? m_radius->mValue : 8.0f;
    for (size_t i = 0; i < m_particles.size(); ++i) {
        Particle& p = m_particles[i];
        const float oldPos[3] = {p.p[0], p.p[1], p.p[2]};
        p.v[1] -= gravity * dt;
        float next[3] = {p.p[0] + p.v[0] * speed * dt, p.p[1] + p.v[1] * speed * dt, p.p[2] + p.v[2] * speed * dt};
        // The per-step displacement is much smaller than one voxel, so the
        // endpoint test is equivalent here and avoids a redundant ray walk.
        if (overlay::ParticleWorldCellSolid((int)std::floor(next[0]),
                                             (int)std::floor(next[1]),
                                             (int)std::floor(next[2]))) {
            p.v[1] = std::abs(p.v[1]) * 0.45f;
            next[0] = oldPos[0]; next[1] = oldPos[1] + 0.015f; next[2] = oldPos[2];
        }
        p.p[0] = next[0]; p.p[1] = next[1]; p.p[2] = next[2]; p.age += dt;
        const float dx = p.p[0] - camera[0], dy = p.p[1] - camera[1], dz = p.p[2] - camera[2];
        if (p.age > 9.0f || dx*dx + dy*dy + dz*dz > (radius + 2.0f) * (radius + 2.0f) || p.p[1] < camera[1] - radius)
            resetParticle(p, camera, (unsigned int)i + (unsigned int)(p.age * 100.0f));
    }
}

void WorldParticlesModule::onRender() {
    if (overlay::g_showMenu || !overlay::IsInWorld()) return;
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;
    float camera[3] = {};
    if (!overlay::GetCameraWorldPosition(camera)) return;
    const ImColor c = m_color ? m_color->getAsImColor() : ImColor(1.0f,1.0f,1.0f,0.85f);
    const ImU32 col = ImGui::GetColorU32(c.Value);
    const float size = m_size ? m_size->mValue : 3.0f;
    const ImVec2 screen = gui::GetScreenSize();
    // Occlusion is expensive because it walks voxels. Refresh it at 8 Hz and
    // reuse the result between checks; particles still collide every tick.
    const ULONGLONG now = GetTickCount64();
    if (m_visible.size() != m_particles.size()) m_visible.assign(m_particles.size(), 1);
    if (now >= m_nextVisibilityCheck) {
        m_nextVisibilityCheck = now + 125u;
        for (size_t i = 0; i < m_particles.size(); ++i)
            m_visible[i] = overlay::ParticleWorldSegmentClear(camera, m_particles[i].p) ? 1 : 0;
    }
    for (size_t i = 0; i < m_particles.size(); ++i) {
        const Particle& p = m_particles[i];
        if (!m_visible[i]) continue;
        float x = 0, y = 0, depth = 0;
        if (!overlay::ProjectWorldToScreen(p.p, &x, &y, &depth) || depth <= 0.05f) continue;
        if (x < -20 || y < -20 || x > screen.x + 20 || y > screen.y + 20) continue;
        const float s = gui::Clamp(size * (18.0f / depth), 1.0f, size * 2.5f);
        const ImVec2 q(x, y);
        if (!m_shape || m_shape->mValue == 0) {
            draw->AddLine(ImVec2(x-s,y), ImVec2(x+s,y), col, 1.0f);
            draw->AddLine(ImVec2(x,y-s), ImVec2(x,y+s), col, 1.0f);
            draw->AddLine(ImVec2(x-s*.65f,y-s*.65f), ImVec2(x+s*.65f,y+s*.65f), col, 1.0f);
            draw->AddLine(ImVec2(x+s*.65f,y-s*.65f), ImVec2(x-s*.65f,y+s*.65f), col, 1.0f);
        } else if (m_shape->mValue == 1) draw->AddCircleFilled(q, s * 0.48f, col, 10);
        else if (m_shape->mValue == 2) gui::DrawString(ImVec2(x-s, y-s*1.4f), "$", c, s / gui::kFontUnit * 2.0f, c.Value.w, true, draw);
        else if (m_shape->mValue == 3) {
            ImVec2 pts[10]{}; for (int k=0;k<10;++k) { const float a=-1.5707963f+k*0.6283185f; const float rr=(k&1)?s*.42f:s; pts[k]=ImVec2(x+std::cos(a)*rr,y+std::sin(a)*rr); } draw->AddConvexPolyFilled(pts,10,col);
        } else {
            draw->AddCircleFilled(ImVec2(x-s*.32f,y-s*.1f), s*.42f, col, 10); draw->AddCircleFilled(ImVec2(x+s*.32f,y-s*.1f), s*.42f,col,10);
            ImVec2 pts[3] = {ImVec2(x-s*.72f,y),ImVec2(x+s*.72f,y),ImVec2(x,y+s*.95f)}; draw->AddConvexPolyFilled(pts,3,col);
        }
    }
}

// ======================== Hitbox box smoothing ========================
// PacketV2 keeps its boxes glued to the entity by lerping posOld -> pos with
// the tick fraction (DrawUtils::drawEntityBox). The part that matters is not
// the lerp itself but where the data comes from: a box sampled once per tick
// steps at 20 Hz while the world runs at display rate, which reads as lag.
// Our AABB comes from a tick-updated component too, so it has exactly the
// same problem.
//
// Same idea, no extra game reads: ease the drawn box toward the freshly read
// one with a one-tick time constant. A jump larger than kBoxSmoothSnap blocks
// is a teleport (or a recycled actor pointer), so it snaps instead of gliding
// the box across the map.
struct BoxSmoothEntry {
    void* actor = nullptr;
    float mins[3] = {};
    float maxs[3] = {};
    ULONGLONG at = 0;
};

constexpr float kBoxSmoothTauMs = 40.0f;  // ~one game tick
constexpr float kBoxSmoothSnap = 3.0f;    // blocks; beyond this, snap

void SmoothHitboxAabb(void* actor, float mins[3], float maxs[3]) {
    static BoxSmoothEntry table[256];
    const ULONGLONG now = GetTickCount64();

    BoxSmoothEntry* slot = nullptr;
    BoxSmoothEntry* spare = nullptr;
    BoxSmoothEntry* oldest = &table[0];
    for (BoxSmoothEntry& e : table) {
        if (e.actor == actor) { slot = &e; break; }
        if (!e.actor && !spare) spare = &e;
        if (e.at < oldest->at) oldest = &e;
    }

    if (slot) {
        const float jump = std::max(
            std::max(std::fabs(mins[0] - slot->mins[0]),
                     std::fabs(mins[1] - slot->mins[1])),
            std::fabs(mins[2] - slot->mins[2]));
        if (jump <= kBoxSmoothSnap) {
            const float dt = static_cast<float>(now - slot->at);
            // Frame-rate independent ease; dt == 0 leaves the box untouched.
            const float k =
                dt > 0.0f ? 1.0f - std::exp(-dt / kBoxSmoothTauMs) : 0.0f;
            for (int c = 0; c < 3; ++c) {
                slot->mins[c] += (mins[c] - slot->mins[c]) * k;
                slot->maxs[c] += (maxs[c] - slot->maxs[c]) * k;
                mins[c] = slot->mins[c];
                maxs[c] = slot->maxs[c];
            }
            slot->at = now;
            return;
        }
    }

    // First sight, a teleport, or a recycled pointer: adopt the target box.
    BoxSmoothEntry& e = slot ? *slot : (spare ? *spare : *oldest);
    e.actor = actor;
    e.at = now;
    std::memcpy(e.mins, mins, sizeof(e.mins));
    std::memcpy(e.maxs, maxs, sizeof(e.maxs));
}

HitboxesModule::HitboxesModule()
    : Module("Visual", "Hitboxes", "Entity hitboxes: Normal / Wireframe / Glow") {
    // House style: bold readable boxes (growing lines, soft glow, filled
    // faces). PacketV2-exact is one click away: Thickness 1.0, Targets
    // Players, Scale with distance off, Fill off, Box glow off.
    m_maxDistance = addSetting<NumberSetting>(
        "Max distance", "Maximum entity render distance in blocks", 20.0f, 5.0f, 30.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>(
        "Thickness", "Multiplier over the distance width.", 2.0f, 0.1f, 5.0f, 0.1f);
    m_staticThickness = addSetting<BoolSetting>(
        "Static thickness", "Keep line width constant regardless of distance.", false);
    m_2dMode = addSetting<BoolSetting>(
        "2D mode", "Flat rectangles instead of 3D cuboids.", false);
    // PacketV2 enemy white (0.9, 0.9, 0.9). Mobs always draw PacketV2 blue;
    // see onRender.
    m_boxColor = addSetting<ColorSetting>(
        "Box color", "Hitbox line color.", 0xFFE6E6E6u);
    m_boxOpacity = addSetting<NumberSetting>(
        "Box opacity", "Hitbox transparency.", 1.0f, 0.0f, 1.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>(
        "Use theme", "Paint lines and glow with the GUI theme accent.", true);

    // House style shows everything ("все все все"); Players-only is the
    // PacketV2-effective default.
    m_targets = addSetting<EnumSetting>(
        "Targets", "Which entities get a hitbox.", 2,
        std::vector<std::string>{"Players", "Mobs", "All"});
    m_scaleDistance = addSetting<BoolSetting>(
        "Scale with distance", "Thicken lines with distance (house style).", true);
    m_throughWalls = addSetting<BoolSetting>(
        "Show through walls", "Draw boxes behind walls (occlusion off).", false);
    m_outline = addSetting<BoolSetting>(
        "Outline", "Dark stroke under the lines for contrast.", false);
    m_outlineColor = addSetting<ColorSetting>(
        "Outline color", "Outline stroke color.", 0xFF000000u);
    m_fill = addSetting<BoolSetting>(
        "Fill", "Fill the surface, not just the perimeter (house style).", true);
    m_fillColor = addSetting<ColorSetting>(
        "Fill color", "Fill color (alpha = fill strength).", 0x4CFFFFFFu);
    m_boxGlow = addSetting<BoolSetting>(
        "Box glow", "Soft blurred glow around the box lines (house style).", true);
    m_glowRadius = addSetting<NumberSetting>(
        "Glow radius", "Glow halo radius in pixels.", 20.0f, 4.0f, 96.0f, 1.0f);
    m_glowBrightness = addSetting<NumberSetting>(
        "Glow brightness", "Glow brightness.", 1.0f, 0.1f, 4.0f, 0.05f);
    m_glowColor = addSetting<ColorSetting>(
        "Glow color", "Glow halo color.", 0xFF36D6FFu);
    m_gradient = addSetting<BoolSetting>(
        "Gradient", "Smooth transition between two glow colors.", false);
    m_secondColor = addSetting<ColorSetting>(
        "Second color", "Second glow gradient color.", 0xFFFF6B36u);
    m_gradientSpeed = addSetting<NumberSetting>(
        "Gradient speed", "Gradient movement speed (0 - static).", 0.0f, 0.0f, 5.0f, 0.05f);
    // Render style. Index is the stable API (configs store it): 0 Normal
    // (clean hull silhouette, PacketV2-like), 1 Glow (house aura
    // silhouette), 2 Wireframe (full 12-edge cuboid, no top lift).
    m_mode = addSetting<EnumSetting>(
        "Mode", "Box render style: Normal / Glow / Wireframe.", 2,
        std::vector<std::string>{"Normal", "Glow", "Wireframe"});
    m_silhouetteColor = addSetting<ColorSetting>(
        "Silhouette color", "Silhouette fill color in Glow mode.", 0x40FFFFFFu);
    m_auraRadius = addSetting<NumberSetting>(
        "Aura radius", "Silhouette aura radius in pixels.", 24.0f, 4.0f, 96.0f, 1.0f);
    m_auraBrightness = addSetting<NumberSetting>(
        "Aura brightness", "Silhouette aura brightness.", 1.5f, 0.3f, 4.0f, 0.05f);
    m_animation = addSetting<BoolSetting>(
        "Animation", "Wavy animated aura outline in Glow mode.", false);
    m_animStrength = addSetting<NumberSetting>(
        "Animation strength", "Wave distortion strength.", 1.0f, 0.0f, 3.0f, 0.05f);
    m_animSize = addSetting<NumberSetting>(
        "Animation size", "Aura expansion with animation.", 1.0f, 1.0f, 2.5f, 0.05f);
}

void HitboxesModule::onEnable() {
    // PacketV2 idea: ticking actors refresh their own AABB cache entry on the
    // game's tick thread while hitboxes are enabled.
    overlay::SetHitboxTickRefresh(true);
}

void HitboxesModule::onDisable() {
    overlay::SetHitboxTickRefresh(false);
}

void HitboxesModule::onRender() {
    // Flarial parity: the ClickGUI replaces the world view, so hitboxes are
    // not drawn while the menu is open (same as its onRender gate).
    if (overlay::g_showMenu) return;
    // World/menu validation is owned by the setup capture. Do not call
    // IsInWorld here: its guarded fallback can resolve a live local-player
    // vtable. The frame packet below naturally makes this callback a no-op
    // outside the active world.
    const float maxDistance = m_maxDistance
        ? gui::Clamp(m_maxDistance->mValue, 5.0f, 30.0f) : 20.0f;
    overlay::SetHitboxMaxDistance(maxDistance);
    overlay::SetHitboxThroughWalls(m_throughWalls ? m_throughWalls->mValue
                                                  : false);

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x < 2.0f || screen.y < 2.0f) return;

    // The Present path has already selected the immutable camera/actor snapshot.
    // This module callback only copies that snapshot; it never resolves view,
    // EntityContext, components, RPM or native game objects here.

    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    float camera[3] = {};
    if (!overlay::GetCameraWorldPosition(camera)) return;

    // ---- settings (PacketV2 ESP parity) ----
    const float thickness = m_thickness
        ? gui::Clamp(m_thickness->mValue, 0.1f, 5.0f) : 1.0f;
    const bool staticThickness = m_staticThickness && m_staticThickness->mValue;
    const bool mode2d = m_2dMode && m_2dMode->mValue;
    // Theme accent spreads to the whole client: lines (and glow below)
    // follow it unless the module opts out. Mob blue is kept so targets and
    // mobs never share a color.
    const bool useTheme = !m_useTheme || m_useTheme->mValue;
    ImColor boxColor = useTheme ? gui::Accent()
                                : (m_boxColor ? m_boxColor->getAsImColor() : ImColor(0.9f, 0.9f, 0.9f, 1.0f));
    const float opacity = m_boxOpacity
        ? gui::Clamp(m_boxOpacity->mValue, 0.0f, 1.0f) : 1.0f;
    boxColor.Value.w *= opacity;
    const ImU32 lineU32 = ImGui::GetColorU32(boxColor.Value);

    // PacketV2 enemy blue (0.2, 0.2, 0.9) for mobs; players draw Box color
    // (default 0.9 gray = PacketV2 enemy white). Opacity applies to both.
    const ImU32 mobU32 =
        ImGui::GetColorU32(ImVec4(0.2f, 0.2f, 0.9f, opacity));
    const bool scaleDistance = m_scaleDistance && m_scaleDistance->mValue;
    const bool outlineOn = m_outline && m_outline->mValue;
    const ImColor outlineColor = m_outlineColor
        ? m_outlineColor->getAsImColor() : ImColor(0.0f, 0.0f, 0.0f, 1.0f);
    const ImU32 outlineU32 = ImGui::GetColorU32(outlineColor.Value);
    const bool fillOn = m_fill && m_fill->mValue;
    const ImColor fillColor = m_fillColor
        ? m_fillColor->getAsImColor() : ImColor(1.0f, 1.0f, 1.0f, 0.30f);
    const ImU32 fillU32 = ImGui::GetColorU32(fillColor.Value);
    const bool glowOn = m_boxGlow && m_boxGlow->mValue;
    const float glowRadius = m_glowRadius
        ? gui::Clamp(m_glowRadius->mValue, 4.0f, 96.0f) : 20.0f;
    const float glowBrightness = m_glowBrightness
        ? gui::Clamp(m_glowBrightness->mValue, 0.1f, 4.0f) : 1.0f;
    ImVec4 glowColor = useTheme ? gui::Accent().Value
                                : (m_glowColor ? m_glowColor->getAsImColor().Value
                                               : ImVec4(0.21f, 0.84f, 1.0f, 1.0f));
    const bool gradientOn = m_gradient && m_gradient->mValue;
    const ImColor secondColor = m_secondColor
        ? m_secondColor->getAsImColor() : ImColor(1.0f, 0.42f, 0.21f, 1.0f);
    const float gradientSpeed = m_gradientSpeed
        ? gui::Clamp(m_gradientSpeed->mValue, 0.0f, 5.0f) : 0.0f;
    const int renderMode = m_mode ? m_mode->mValue : 2;  // 0 Normal, 1 Glow, 2 Wireframe
    const ImColor silhouetteColor = m_silhouetteColor
        ? m_silhouetteColor->getAsImColor() : ImColor(1.0f, 1.0f, 1.0f, 0.25f);
    const ImU32 silhouetteU32 = ImGui::GetColorU32(silhouetteColor.Value);
    float auraRadius = m_auraRadius
        ? gui::Clamp(m_auraRadius->mValue, 4.0f, 96.0f) : 24.0f;
    const float auraBrightness = m_auraBrightness
        ? gui::Clamp(m_auraBrightness->mValue, 0.3f, 4.0f) : 1.5f;
    const bool animOn = m_animation && m_animation->mValue;
    const float animStrength = m_animStrength
        ? gui::Clamp(m_animStrength->mValue, 0.0f, 3.0f) : 1.0f;
    const float animSize = m_animSize
        ? gui::Clamp(m_animSize->mValue, 1.0f, 2.5f) : 1.0f;
    const int targets = m_targets ? m_targets->mValue : 0;  // 0/1/2, PacketV2 = players

    // SystemDLC "Градиент": the glow color oscillates between the main glow
    // color and the second one; speed 0 keeps a static 50/50 blend.
    if (gradientOn) {
        const double nowSec = (double)ImGui::GetTime();
        const float phase = gradientSpeed > 0.0f
            ? 0.5f + 0.5f * std::sin((float)nowSec * gradientSpeed * 2.0f)
            : 0.5f;
        const float* src = &secondColor.Value.x;
        float* dst = &glowColor.x;  // ImVec4 is a plain 4-float aggregate
        for (int c = 0; c < 4; ++c) dst[c] += (src[c] - dst[c]) * phase;
    }

    // Frame-constant glow plans: pass colors/widths do not vary per actor,
    // so the conversions run once here instead of per pass per actor.
    const HullGlowPlan auraGlowPlan =
        BuildHullGlowPlan(glowColor, auraRadius * (animOn ? animSize : 1.0f),
                          auraBrightness);
    const HullGlowPlan boxGlowPlan =
        BuildHullGlowPlan(glowColor, glowRadius, glowBrightness);

    void* actors[256] = {};
    const int actorCount = overlay::GetActors(actors, 256);
    // Hysteresis band against cull-line blinking (see m_visible).
    constexpr float kCullHysteresis = 2.0f;
    // Static so its capacity survives across frames: the previous local vector
    // was reconstructed (and reallocated) every frame, and the swap at the end
    // of this function already hands its storage over to m_visible anyway.
    static std::vector<void*> stillVisible;
    stillVisible.clear();
    if (stillVisible.capacity() < static_cast<size_t>(actorCount))
        stillVisible.reserve(static_cast<size_t>(actorCount));
    // PacketV2 width, exactly: fmax(0.2, 1 / fmax(1, dist)), times the
    // Thickness multiplier (1.0 = 1:1 with PacketV2). Near boxes are ~1 px,
    // far ones bottom out at 0.2. The damage-time alpha
    // (fmax(0.1, fmin(1, 15 / (damageTime + 1)))) is identically 1.0 for every
    // real damageTime value (0..14), and the numeric field has no proven
    // offset on this build - so the box draws at full opacity, like PacketV2
    // does in practice. The growing "Scale with distance" branch stays as an
    // explicit opt-in extra (NOT PacketV2).
    int drawnCount = 0;
    int aabbOkCount = 0;
    int culledCount = 0;

    for (int i = 0; i < actorCount; ++i) {
        // The local player's own hitbox is never drawn - neither in first
        // person nor from the F5 third-person camera.
        if (overlay::IsHitboxLocalPlayer(actors[i])) continue;
        // SystemDLC "Цели": an unknown class (unreadable category word) still
        // draws - the categories offset is unproven on 1.21.11x.
        const int actorClass = overlay::GetActorClass(actors[i]);
        if (actorClass != 0) {
            if (targets == 0 && actorClass != 1) continue;  // Players
            if (targets == 1 && actorClass != 2) continue;  // Mobs
        }
        float mins[3] = {}, maxs[3] = {};
        if (!overlay::ActorReadAabb(actors[i], mins, maxs)) continue;
        ++aabbOkCount;

        // PacketV2's smoothing idea, applied to the box we just read: the
        // component only moves on the tick, so without this the box steps at
        // 20 Hz inside a display-rate world.
        SmoothHitboxAabb(actors[i], mins, maxs);

        const float dx = (mins[0] + maxs[0]) * 0.5f - camera[0];
        const float dy = (mins[1] + maxs[1]) * 0.5f - camera[1];
        const float dz = (mins[2] + maxs[2]) * 0.5f - camera[2];
        const float distanceSq = dx * dx + dy * dy + dz * dz;
        // Hard cull at maxDistance, but keep last frame's visible actors until
        // maxDistance + hysteresis: without this a mob walking the cull line
        // blinks every time its center crosses the boundary by centimeters.
        const bool wasVisible =
            std::find(m_visible.begin(), m_visible.end(), actors[i]) != m_visible.end();
        const float cullDist = wasVisible ? maxDistance + kCullHysteresis : maxDistance;
        if (distanceSq > cullDist * cullDist) {
            ++culledCount;
            continue;
        }
        stillVisible.push_back(actors[i]);

        // PacketV2 Normal lift: render.upper.y += 0.1 (drawEntityBox), also
        // used by its draw2D corners. Applied in Box mode for both the 3D box
        // and the flat projection; Glow mode keeps raw bounds.
        float pmaxs[3] = { maxs[0], maxs[1], maxs[2] };
        if (renderMode == 0) pmaxs[1] += 0.1f;
        ImVec2 points[8] = {};
        float depths[8] = {};
        bool valid[8] = {};
        // An edge that cannot be projected is skipped instead of discarding
        // the whole wireframe; fewer than 2 points kills the box, exactly
        // like PacketV2's drawBox early-out.
        if (ProjectBox(mins, pmaxs, points, depths, valid) < 2) continue;

        const float distance = std::sqrt(distanceSq);
        // PacketV2: 3D fmax(0.2, 1 / fmax(1, dist)), 2D corners
        // fmax(0.4, 1 / fmax(1, dist * 3)) - both times Thickness.
        const float packetWidth = mode2d
            ? std::max(0.4f, 1.0f / std::max(1.0f, distance * 3.0f))
            : std::max(0.2f, 1.0f / std::max(1.0f, distance));
        const float lineWidth =
            staticThickness
                ? thickness
                : scaleDistance
                    ? std::min(6.0f, thickness * std::max(1.0f, distance * 0.12f))
                    : thickness * packetWidth;
        // PacketV2 fixed colors: mobs blue, everyone else Box color.
        const ImU32 actorLineU32 = (actorClass == 2) ? mobU32 : lineU32;

        HullPoly hull = BuildHullPoly(points, valid);

        if (renderMode == 1) {
            // SystemDLC "Свечение" mode: a filled glowing silhouette instead
            // of sharp lines. Fill sits under the aura, the wavy animation
            // distorts the aura polygon and widens it.
            HullPoly aura = hull;
            if (animOn) {
                // The animSize widening is already baked into auraGlowPlan.
                DisplaceHullWavy(aura, (float)ImGui::GetTime(),
                                 animStrength * 8.0f);
            }
            if (aura.count >= 3)
                draw->AddConvexPolyFilled(aura.pts, aura.count, silhouetteU32);
            DrawHullGlow(draw, aura, auraGlowPlan);
            ++drawnCount;
            continue;
        }

        // House composite order: glow, fill, outline, lines.
        // Normal draws the gift-wrap silhouette (PacketV2-like clean box);
        // Wireframe draws the full 12-edge cuboid (classic house look).
        const bool wireframe = (renderMode == 2);
        if (glowOn)
            DrawHullGlow(draw, hull, boxGlowPlan);

        if (fillOn) {
            if (mode2d) {
                if (hull.count >= 3)
                    draw->AddConvexPolyFilled(hull.pts, hull.count, fillU32);
            } else {
                DrawBoxFill3D(draw, mins, pmaxs, points, valid, camera, fillU32);
            }
        }

        bool drewEdge = false;
        if (mode2d) {
            if (outlineOn)
                DrawHullSegments(draw, hull, outlineU32, lineWidth * 2.2f,
                                 &screen);
            DrawHullSegments(draw, hull, actorLineU32, lineWidth, &screen);
            drewEdge = hull.count >= 2;
        } else if (wireframe) {
            if (outlineOn) {
                // All outline strokes first so every line sits above them.
                for (const auto& edge : kBoxEdges) {
                    if (!valid[edge[0]] || !valid[edge[1]]) continue;
                    DrawWhiteBoxLine(draw, points[edge[0]], points[edge[1]],
                                     outlineU32, lineWidth * 2.2f, screen);
                }
            }
            for (const auto& edge : kBoxEdges) {
                if (!valid[edge[0]] || !valid[edge[1]]) continue;
                DrawWhiteBoxLine(draw, points[edge[0]], points[edge[1]],
                                 actorLineU32, lineWidth, screen);
                drewEdge = true;
            }
        } else {
            if (outlineOn)
                DrawHullSegments(draw, hull, outlineU32, lineWidth * 2.2f,
                                 &screen);
            DrawHullSegments(draw, hull, actorLineU32, lineWidth, &screen);
            drewEdge = hull.count >= 2;
        }
        if (drewEdge) ++drawnCount;
    }

    m_visible.swap(stillVisible);

    static ULONGLONG nextDiag = 0;
    const ULONGLONG now = GetTickCount64();
    if (now >= nextDiag) {
        nextDiag = now + 1000u;
        // aabbOk separates the two failure modes: actors>0 with aabbOk=0 means
        // the component read is still failing, while aabbOk>0 with drawn=0
        // means the projection is rejecting the boxes.
        LOG_INFO("hitboxes: boxes actors=%d aabbOk=%d culled=%d drawn=%d matrixMode=%d mode=%d",
                 actorCount, aabbOkCount, culledCount, drawnCount,
                 overlay::GetHitboxMatrixMode(), renderMode);
    }
}

// ======================== Target ESP (SystemDLC parity) ========================
// A faithful port of SystemDLC's TargetESP particle math: the same effect
// shapes, noise and constants. Particles live in world space around the last
// actor the local player hit (feet origin, +Y up), are projected every frame
// and drawn as layered glow dots and glowing ribbons.

static float EspHash01(int v) {
    v = v ^ 61 ^ (v >> 16);
    v *= 9;
    v ^= v >> 4;
    v *= 668265261;
    v ^= v >> 15;
    return (float)(v & 16777215) / 16777215.0f;
}

// SystemDLC's getFloatByIntFloat: smooth noise between per-step hashes.
static float EspNoise(int idx, float t) {
    const int i = (int)std::floor(t);
    const float f = t - (float)i;
    const float u = f * f * (3.0f - 2.0f * f);
    const float a = EspHash01(idx + i * 8191) * 2.0f - 1.0f;
    const float b = EspHash01(idx + (i + 1) * 8191) * 2.0f - 1.0f;
    return a + (b - a) * u;
}

struct EspCtx {
    float ox = 0.0f, oy = 0.0f, oz = 0.0f;   // actor feet (world)
    float radius = 0.7f;                     // width * Radius
    float height = 1.8f;                     // actor height
    float sizeS = 0.17f;                     // Fatness (world units)
    float phase = 0.0f;                      // animation phase
    int count = 120;                         // Density
    int tail = 6;                            // Tail
    float dist = 6.0f;                       // camera distance
    float focal = 700.0f;                    // focal length, px
    float appear = 1.0f;                     // smooth appear alpha
    ImVec4 col = ImVec4(1, 1, 1, 1);
    ImDrawList* d = nullptr;
};

static void EspDot(const EspCtx& E, float x, float y, float z, float sz, float a) {
    if (!E.d || a <= 0.004f || sz <= 0.0f) return;
    const float p[3] = { E.ox + x, E.oy + y, E.oz + z };
    float sx = 0.0f, sy = 0.0f;
    if (!overlay::ProjectWorldToScreen(p, &sx, &sy, nullptr)) return;
    const float r = std::max(0.7f, sz * E.focal / std::max(1.0f, E.dist));
    const float aa = std::min(1.0f, a) * E.appear;
    const ImU32 outer = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, E.col.w * aa * 0.10f));
    const ImU32 mid = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, E.col.w * aa * 0.30f));
    const ImU32 core = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, E.col.w * aa * 0.95f));
    E.d->AddCircleFilled(ImVec2(sx, sy), r * 3.4f, outer, 10);
    E.d->AddCircleFilled(ImVec2(sx, sy), r * 1.9f, mid, 12);
    E.d->AddCircleFilled(ImVec2(sx, sy), r, core, 12);
}

static void EspRibbon(const EspCtx& E, const float pts[][3], const float* alphas,
                      int n, float sz) {
    if (!E.d || n < 2 || sz <= 0.0f) return;
    float sx[64] = {}, sy[64] = {};
    const int m = std::min(n, 64);
    for (int i = 0; i < m; ++i) {
        const float p[3] = { E.ox + pts[i][0], E.oy + pts[i][1], E.oz + pts[i][2] };
        if (!overlay::ProjectWorldToScreen(p, &sx[i], &sy[i], nullptr)) return;
    }
    const float w = std::max(1.0f, sz * E.focal / std::max(1.0f, E.dist));
    for (int i = 0; i + 1 < m; ++i) {
        const float a = std::min(1.0f, 0.5f * (alphas[i] + alphas[i + 1])) * E.appear;
        if (a <= 0.004f) continue;
        const ImU32 mid = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, E.col.w * a * 0.35f));
        const ImU32 core = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, E.col.w * a * 0.9f));
        E.d->AddLine(ImVec2(sx[i], sy[i]), ImVec2(sx[i + 1], sy[i + 1]), mid, w * 2.6f);
        E.d->AddLine(ImVec2(sx[i], sy[i]), ImVec2(sx[i + 1], sy[i + 1]), core, w);
    }
}

// RingParticleLayout.place
static void EspRingPlace(const EspCtx& E, int ringIdx, float frameAng, float frameH,
                         float out[3]) {
    const float a = 6.2831853f * (float)ringIdx / (float)std::max(1, E.count);
    const float r = E.radius * (1.0f + 0.045f * std::sin(a * 2.0f + frameAng));
    out[0] = std::cos(a) * r;
    out[1] = frameH;
    out[2] = std::sin(a) * r;
}

// TriangleParticleLayout.place
static void EspTriPlace(const EspCtx& E, int ringIdx, float frameAng, float frameH,
                        float out[3]) {
    const int per = std::max(4, E.count / 3);
    const int edge = ringIdx / per;
    const float f = (float)(ringIdx % per) / (float)per;
    const float a1 = frameAng + (float)edge * 2.0943951f;
    const float a2 = a1 + 2.0943951f;
    const float x1 = std::cos(a1) * E.radius, z1 = std::sin(a1) * E.radius;
    const float x2 = std::cos(a2) * E.radius, z2 = std::sin(a2) * E.radius;
    out[0] = x1 + (x2 - x1) * f;
    out[1] = frameH;
    out[2] = z1 + (z2 - z1) * f;
}

// Crystals effect: one shaded octahedron shard, projected through the same
// world->screen pipeline as the other effects. Faces are painter-sorted by
// distance so front facets win; the edges stay bright for the shard look.
static void EspCrystal(const EspCtx& E, float cx, float cy, float cz, float size,
                       float yaw, float tilt, bool filled, float hitT) {
    if (!E.d || !(size > 0.0001f) || !std::isfinite(size)) return;
    const float halfH = size * 0.70f;
    const float halfW = size * 0.55f;
    float v[6][3] = {
        { 0.0f,  halfH, 0.0f }, { 0.0f, -halfH, 0.0f },
        {  halfW, 0.0f, 0.0f }, { -halfW, 0.0f, 0.0f },
        { 0.0f, 0.0f,  halfW }, { 0.0f, 0.0f, -halfW },
    };
    const float ct = std::cos(tilt), st = std::sin(tilt);
    const float cyw = std::cos(yaw), syw = std::sin(yaw);
    for (int i = 0; i < 6; ++i) {
        const float vx = v[i][0];
        const float vy = v[i][1] * ct - v[i][2] * st;
        const float vz = v[i][1] * st + v[i][2] * ct;
        v[i][0] = cx + vx * cyw - vz * syw;
        v[i][1] = cy + vy;
        v[i][2] = cz + vx * syw + vz * cyw;
    }
    float sx[6] = {}, sy[6] = {};
    bool ok[6] = {};
    for (int i = 0; i < 6; ++i) {
        const float p[3] = { v[i][0], v[i][1], v[i][2] };
        ok[i] = overlay::ProjectWorldToScreen(p, &sx[i], &sy[i], nullptr);
    }
    const float glow = E.appear;
    // r25: the old soft halo disc behind each shard is gone - the crystals
    // effect now draws ONLY the crystal geometry (faces + edges).
    if (filled) {
        static const int kFaces[8][3] = {
            {0, 2, 4}, {0, 4, 3}, {0, 3, 5}, {0, 5, 2},
            {1, 4, 2}, {1, 3, 4}, {1, 5, 3}, {1, 2, 5},
        };
        int order[8] = { 0, 1, 2, 3, 4, 5, 6, 7 };
        float depth[8] = {};
        for (int f = 0; f < 8; ++f) {
            const float mx = (v[kFaces[f][0]][0] + v[kFaces[f][1]][0] + v[kFaces[f][2]][0]) * (1.0f / 3.0f);
            const float my = (v[kFaces[f][0]][1] + v[kFaces[f][1]][1] + v[kFaces[f][2]][1]) * (1.0f / 3.0f);
            const float mz = (v[kFaces[f][0]][2] + v[kFaces[f][1]][2] + v[kFaces[f][2]][2]) * (1.0f / 3.0f);
            const float dx = mx - E.ox, dy = my - E.oy, dz = mz - E.oz;
            depth[f] = dx * dx + dy * dy + dz * dz;
        }
        for (int a = 0; a < 8; ++a) {
            for (int b = a + 1; b < 8; ++b) {
                if (depth[order[b]] > depth[order[a]]) {
                    const int tmp = order[a]; order[a] = order[b]; order[b] = tmp;
                }
            }
        }
        for (int k = 0; k < 8; ++k) {
            const int f = order[k];
            if (!ok[kFaces[f][0]] || !ok[kFaces[f][1]] || !ok[kFaces[f][2]]) continue;
            const float yAvg = (v[kFaces[f][0]][1] + v[kFaces[f][1]][1] + v[kFaces[f][2]][1]) * (1.0f / 3.0f);
            float grad = (yAvg - (cy - halfH)) / std::max(1e-3f, halfH * 2.0f);
            grad = gui::Clamp(grad, 0.0f, 1.0f);
            const float mix = 0.55f + 0.45f * grad;
            float cr = E.col.x + (1.0f - E.col.x) * 0.55f * mix;
            float cg = E.col.y + (1.0f - E.col.y) * 0.55f * mix;
            float cb = E.col.z + (1.0f - E.col.z) * 0.55f * mix;
            cr += (1.0f - cr) * hitT * 0.6f;
            cg *= 1.0f - 0.35f * hitT;
            cb *= 1.0f - 0.35f * hitT;
            const ImVec2 tri[3] = {
                ImVec2(sx[kFaces[f][0]], sy[kFaces[f][0]]),
                ImVec2(sx[kFaces[f][1]], sy[kFaces[f][1]]),
                ImVec2(sx[kFaces[f][2]], sy[kFaces[f][2]]),
            };
            E.d->AddConvexPolyFilled(tri, 3, ImGui::GetColorU32(ImVec4(cr, cg, cb, 0.34f * glow)));
        }
    }
    static const int kEdges[12][2] = {
        {0, 2}, {0, 3}, {0, 4}, {0, 5}, {1, 2}, {1, 3},
        {1, 4}, {1, 5}, {2, 4}, {2, 5}, {3, 4}, {3, 5},
    };
    const ImU32 edgeCol = ImGui::GetColorU32(ImVec4(E.col.x, E.col.y, E.col.z, 0.85f * glow));
    for (int e = 0; e < 12; ++e) {
        if (!ok[kEdges[e][0]] || !ok[kEdges[e][1]]) continue;
        E.d->AddLine(ImVec2(sx[kEdges[e][0]], sy[kEdges[e][0]]),
                     ImVec2(sx[kEdges[e][1]], sy[kEdges[e][1]]), edgeCol, 1.6f);
    }
}

TargetEspModule::TargetEspModule()
    : Module("Visual", "Target ESP",
             "SystemDLC-style glowing mark around the player you last hit") {
    m_effect = addSetting<EnumSetting>("Effect", "Glow shape around the target.", 0,
        std::vector<std::string>{ "Ring", "Triangle", "Helix", "Orbits", "Embers", "Pulse", "Crystals" });
    m_color = addSetting<ColorSetting>("Color", "Mark color.", 0xFFF45464);
    m_speed = addSetting<NumberSetting>("Speed", "Animation speed.", 0.7f, 0.1f, 2.0f, 0.1f);
    m_duration = addSetting<NumberSetting>("Duration", "How long the mark stays after a hit, s.",
                                           2.3f, 0.3f, 10.0f, 0.1f);
    m_fatness = addSetting<NumberSetting>("Fatness", "Glow dot size.", 0.17f, 0.04f, 0.4f, 0.01f);
    m_radius = addSetting<NumberSetting>("Radius", "Mark radius relative to the target width.",
                                         0.7f, 0.4f, 1.6f, 0.05f);
    m_density = addSetting<NumberSetting>("Density", "Particle count.", 120.0f, 30.0f, 220.0f, 2.0f);
    m_tail = addSetting<NumberSetting>("Tail", "Fading trail length.", 6.0f, 0.0f, 12.0f, 1.0f);
    m_brightness = addSetting<NumberSetting>("Glow Strength", "Mark brightness.",
                                             1.0f, 0.2f, 3.0f, 0.05f);
    m_crystalsCount = addSetting<NumberSetting>("Crystal Count", "Crystals: shard count.",
                                                6.0f, 1.0f, 16.0f, 1.0f);
    m_crystalsSize = addSetting<NumberSetting>("Crystal Size", "Crystals: shard size.",
                                               0.55f, 0.2f, 1.2f, 0.05f);
    m_crystalsSpin = addSetting<NumberSetting>("Crystal Spin", "Crystals: orbit speed.",
                                               1.25f, 0.0f, 6.0f, 0.05f);
    m_crystalsFill = addSetting<BoolSetting>("Crystal Fill", "Crystals: filled faces.", true);
    auto crystalOnly = [this] { return m_effect && m_effect->mValue == 6; };
    m_crystalsCount->mIsVisible = crystalOnly;
    m_crystalsSize->mIsVisible = crystalOnly;
    m_crystalsSpin->mIsVisible = crystalOnly;
    m_crystalsFill->mIsVisible = crystalOnly;
}

void TargetEspModule::onEnable() {
    m_alpha = 0.0f;
    m_lastActor = nullptr;
    overlay::TargetEspClear();
}

void TargetEspModule::onDisable() {
    m_alpha = 0.0f;
    m_lastActor = nullptr;
    overlay::TargetEspClear();
}

void TargetEspModule::onRender() {
    if (overlay::g_showMenu) return;
    if (!overlay::IsWorldHudScreen()) return;   // r24: never over inventory/pause/chat
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (!d) return;

    void* actor = overlay::GetTargetEspActor();
    if (!actor) { m_alpha = 0.0f; m_lastActor = nullptr; return; }
    if (actor != m_lastActor) { m_lastActor = actor; m_alpha = 0.0f; }

    const ULONGLONG now = GetTickCount64();
    const unsigned long long hitAt = overlay::GetTargetEspHitAtMs();
    const float lifeMs = (m_duration ? gui::Clamp(m_duration->mValue, 0.3f, 10.0f) : 2.3f) * 1000.0f;
    const bool latched = hitAt != 0 && now >= hitAt && (float)(now - hitAt) < lifeMs;
    m_alpha += ((latched ? 1.0f : 0.0f) - m_alpha) * (latched ? 0.15f : 0.25f);
    if (m_alpha < 0.03f) {
        if (!latched) { m_alpha = 0.0f; m_lastActor = nullptr; overlay::TargetEspClear(); }
        return;
    }

    float mins[3] = {}, maxs[3] = {};
    if (!overlay::ActorReadAabb(actor, mins, maxs)) return;

    float camera[3] = {};
    const bool camOk = overlay::GetCameraWorldPosition(camera);
    const float ccx = (mins[0] + maxs[0]) * 0.5f;
    const float ccy = (mins[1] + maxs[1]) * 0.5f;
    const float ccz = (mins[2] + maxs[2]) * 0.5f;
    const float dist = camOk
        ? std::max(1.5f, std::sqrt((ccx - camera[0]) * (ccx - camera[0]) +
                                   (ccy - camera[1]) * (ccy - camera[1]) +
                                   (ccz - camera[2]) * (ccz - camera[2])))
        : 6.0f;

    EspCtx E;
    E.ox = ccx;
    E.oy = mins[1];
    E.oz = ccz;
    E.height = std::max(0.2f, maxs[1] - mins[1]);
    E.radius = std::max(0.1f, maxs[0] - mins[0]) *
               (m_radius ? gui::Clamp(m_radius->mValue, 0.4f, 1.6f) : 0.7f);
    E.sizeS = m_fatness ? gui::Clamp(m_fatness->mValue, 0.04f, 0.4f) : 0.17f;
    E.phase = (float)ImGui::GetTime() *
              (m_speed ? gui::Clamp(m_speed->mValue, 0.1f, 2.0f) : 0.7f) * 0.8f;
    E.count = (int)(m_density ? gui::Clamp(m_density->mValue, 30.0f, 220.0f) : 120.0f);
    E.tail = (int)(m_tail ? gui::Clamp(m_tail->mValue, 0.0f, 12.0f) : 6.0f);
    E.dist = dist;
    float focal = overlay::GetCritFocalPx();
    if (!(focal > 1.0f && focal < 10000.0f)) focal = 700.0f;
    E.focal = focal;
    const float ap = std::min(1.0f, m_alpha);
    E.appear = ap * ap * (3.0f - 2.0f * ap);
    E.col = (m_color ? m_color->getAsImColor() : ImColor(244, 84, 100, 255)).Value;
    E.d = d;
    const int effect = m_effect ? m_effect->mValue : 0;

    if (effect == 0) {
        // RING: every ring angle emits a head dot plus a wavy ribbon whose
        // points trail the head in time (SystemDLC RingParticleLayout).
        const int i = E.tail > 0 ? std::min(10, 2 + E.tail) : 1;
        const int jj = std::max(1, i - 1);
        const float fshift = (float)E.tail * 0.009f;
        float fh[12] = {}, fa[12] = {};
        const int m = std::min(i, 12);
        for (int k = 0; k < m; ++k) {
            const float pk = E.phase - fshift * (float)k / (float)jj;
            float h = pk + EspNoise(11, pk * 0.7f) * 0.05f;
            h -= std::floor(h);
            fh[k] = h * E.height;
            fa[k] = pk * 3.0f + EspNoise(12, pk * 0.6f) * 3.0f;
        }
        float base[12] = {};
        float prev[3] = {};
        for (int l = 0; l < m; ++l) {
            float px[3] = {};
            EspRingPlace(E, 0, fa[l], fh[l], px);
            float f1 = 1.0f;
            if (l > 0) {
                const float dx = px[0] - prev[0], dy = px[1] - prev[1], dz = px[2] - prev[2];
                f1 = std::min(1.0f, std::sqrt(dx * dx + dy * dy + dz * dz) /
                                       std::max(1e-4f, E.sizeS * 0.3f));
            }
            const float f13 = 1.0f - (float)l / (float)m;
            base[l] = 0.9f * f13 * f13 * f1;
            prev[0] = px[0]; prev[1] = px[1]; prev[2] = px[2];
        }
        for (int j2 = 1; j2 < E.count; ++j2) {
            float pts[12][3] = {};
            for (int k2 = 0; k2 < m; ++k2)
                EspRingPlace(E, j2, fa[k2], fh[k2], pts[k2]);
            EspDot(E, pts[0][0], pts[0][1], pts[0][2], E.sizeS, base[0]);
            if (m > 1) EspRibbon(E, pts, base, m, E.sizeS * 0.8f);
        }
    } else if (effect == 1) {
        // TRIANGLE: three twisting triangle ribbons (SystemDLC layout).
        const int per = std::max(4, E.count / 3);
        const int i = per * 3;
        const int jj = std::max(1, i - 1);
        const float fshift = (float)E.tail * 0.009f;
        float fh[16] = {}, fa[16] = {};
        const int m = std::min(i, 16);
        for (int k = 0; k < m; ++k) {
            const float pk = E.phase - fshift * (float)k / (float)jj;
            float h = pk + EspNoise(21, pk * 0.7f) * 0.05f;
            h -= std::floor(h);
            fh[k] = h * E.height;
            fa[k] = pk * 6.2831853f * 2.2f + EspNoise(22, pk * 0.9f) * 0.65f;
        }
        float base[16] = {};
        float prev[3] = {};
        for (int l = 0; l < m; ++l) {
            float px[3] = {};
            EspTriPlace(E, l, fa[l], fh[l], px);
            float f1 = 1.0f;
            if (l > 0) {
                const float dx = px[0] - prev[0], dy = px[1] - prev[1], dz = px[2] - prev[2];
                f1 = std::min(1.0f, std::sqrt(dx * dx + dy * dy + dz * dz) /
                                       std::max(1e-4f, E.sizeS * 0.3f));
            }
            const float f13 = 1.0f - (float)l / (float)m;
            base[l] = 0.85f * f13 * f13 * f1;
            prev[0] = px[0]; prev[1] = px[1]; prev[2] = px[2];
        }
        for (int j2 = 0; j2 < i; ++j2) {
            float pts[16][3] = {};
            for (int k2 = 0; k2 < m; ++k2)
                EspTriPlace(E, j2, fa[k2], fh[k2], pts[k2]);
            EspDot(E, pts[0][0], pts[0][1], pts[0][2], E.sizeS, base[0]);
            if (m > 1) EspRibbon(E, pts, base, m, E.sizeS * 0.8f);
        }
    } else if (effect == 2) {
        // HELIX: two mirrored rising spiral ribbons.
        const int i = std::max(28, E.count / 4);
        const int m = std::min(i, 48);
        const float f = E.phase * 6.2831853f * 0.9f + EspNoise(31, E.phase * 0.8f) * 0.55f;
        float pts[48][3] = {};
        float al[48] = {};
        for (int k = 0; k < m; ++k) {
            const float u = (float)k / (float)(m - 1);
            const float rr = E.radius *
                             (1.0f - 0.12f * u + 0.09f * EspNoise(32, E.phase * 1.1f + u * 3.0f));
            const float ang = f + u * 2.2f * 6.2831853f;
            pts[k][0] = std::cos(ang) * rr;
            pts[k][1] = u * E.height;
            pts[k][2] = std::sin(ang) * rr;
            al[k] = 0.8f * (0.45f + 0.55f * std::sin(3.1415927f * u)) * u;
        }
        EspRibbon(E, pts, al, m, E.sizeS * 0.6f);
        for (int k = 0; k < m; ++k) { pts[k][0] = -pts[k][0]; pts[k][2] = -pts[k][2]; }
        EspRibbon(E, pts, al, m, E.sizeS * 0.6f);
    } else if (effect == 3) {
        // ORBITS: three tilted counter-rotating rings, each with a comet.
        const int trailLen = (E.tail + 4) * 3;
        const float fr = E.radius * 1.2f;
        const float fy0 = E.height * 0.55f;
        for (int j = 0; j < 3; ++j) {
            const float f2 = (float)j * 1.0471976f + EspNoise(41 + j, E.phase * 0.5f) * 0.3f;
            const float f3 = 1.0f + EspNoise(51 + j, E.phase * 0.45f) * 0.22f;
            const float c2 = std::cos(f2), s2 = std::sin(f2);
            const float c3 = std::cos(f3), s3 = std::sin(f3);
            const float f4 = c2 * fr, f5 = s2 * fr;
            const float f6 = -s2 * c3 * fr, f7 = -s3 * fr, f8 = c2 * c3 * fr;
            const float f17 = ((float)j + 0.9f) / 3.0f;
            float ring[57][3] = {};
            float ral[57] = {};
            for (int k = 0; k < 56; ++k) {
                const float f9 = 6.2831853f * (float)k / 56.0f;
                const float c9 = std::cos(f9), s9 = std::sin(f9);
                ring[k][0] = f4 * c9 + f6 * s9;
                ring[k][1] = fy0 + f7 * s9;
                ring[k][2] = f5 * c9 + f8 * s9;
                ral[k] = 0.2f * f17;
            }
            ring[56][0] = ring[0][0];
            ring[56][1] = ring[0][1];
            ring[56][2] = ring[0][2];
            ral[56] = ral[0];
            EspRibbon(E, ring, ral, 57, E.sizeS * 0.28f);
            const float f18 = E.phase * 6.2831853f * (1.1f + (float)j * 0.17f) +
                              (float)j * 2.1f + EspNoise(61 + j, E.phase * 0.7f) * 0.9f;
            for (int l = 0; l < trailLen && l < 64; ++l) {
                const float f10 = f18 - (float)l * 0.032f;
                const float f11 = 1.0f - (float)l / (float)trailLen;
                const float c10 = std::cos(f10), s10 = std::sin(f10);
                EspDot(E,
                       f4 * c10 + f6 * s10,
                       fy0 + f7 * s10,
                       f5 * c10 + f8 * s10,
                       E.sizeS * (0.5f + 0.7f * f11),
                       f11 * f11 * f17 * 0.35f);
            }
        }
    } else if (effect == 4) {
        // EMBERS: rising sparks with flicker (SystemDLC hash layout).
        for (int k = 0; k < E.count; ++k) {
            float f = E.phase * 0.35f + EspHash01(k * 7919);
            f -= std::floor(f);
            const float f1 = EspHash01(k * 104729) * 6.2831853f + f * 0.7f +
                             EspNoise(k * 13, E.phase * 0.6f) * 0.5f;
            const float f2 = E.radius * (0.25f + 0.8f * EspHash01(k * 15486)) +
                             EspNoise(k * 29, E.phase * 0.9f + f * 2.0f) * 0.07f;
            const float f3 = std::sin(3.1415927f * f) * f;
            EspDot(E,
                   std::cos(f1) * f2,
                   f * E.height * 1.25f,
                   std::sin(f1) * f2,
                   E.sizeS * (0.45f + 0.65f * EspHash01(k * 32452)),
                   f3 * 0.75f);
        }
    } else if (effect == 5) {
        // PULSE: three expanding shockwave rings.
        const int i = std::max(24, E.count);
        for (int j = 0; j < 3; ++j) {
            float f = E.phase * 0.85f + (float)j / 3.0f + EspNoise(91 + j, E.phase * 0.5f) * 0.05f;
            f -= std::floor(f);
            const float f1 = E.radius * (0.3f + f * 1.6f);
            const float f2 = 0.03f + f * E.height * 0.15f;
            const float f3 = (1.0f - f) * (1.0f - f) * std::min(1.0f, f * 5.0f) * f;
            const float f4 = E.sizeS * (1.0f - 0.35f * f);
            for (int l = 0; l < i && l < 240; ++l) {
                const float f5 = 6.2831853f * (float)l / (float)i;
                EspDot(E, std::cos(f5) * f1, f2, std::sin(f5) * f1, f4, f3 * 0.8f);
            }
        }
    } else if (effect == 6) {
        // CRYSTALS: a shell of spinning octahedron shards around the target
        // (inspired by the NewLight TargetESP crystal mode, rebuilt here on
        // this module's projection + fade pipeline). The shards scatter in on
        // appear and flare red briefly after a fresh hit.
        const int shards = (int)gui::Clamp(m_crystalsCount ? m_crystalsCount->mValue : 6.0f, 1.0f, 16.0f);
        const float shardSize = gui::Clamp(m_crystalsSize ? m_crystalsSize->mValue : 0.55f, 0.15f, 1.2f);
        const float spin = gui::Clamp(m_crystalsSpin ? m_crystalsSpin->mValue : 1.25f, 0.0f, 6.0f);
        const bool filled = m_crystalsFill ? m_crystalsFill->mValue : true;
        float hitT = 0.0f;
        if (hitAt != 0 && now >= hitAt) {
            const float since = (float)(now - hitAt);
            if (since < 250.0f) hitT = 1.0f - since / 250.0f;
        }
        hitT = hitT * hitT * (3.0f - 2.0f * hitT);
        const float t = (float)ImGui::GetTime();
        const float golden = 2.39996322972865332f;
        const float orbit = t * spin * 0.85f;
        const float radiusMul = 1.0f + (1.0f - E.appear) * 0.35f;
        const float ySpread = 1.0f + (1.0f - E.appear) * 0.12f;
        const float baseY = E.oy + E.height * 0.52f;
        for (int i = 0; i < shards; ++i) {
            const float idx = (float)i;
            const float u = (idx + 0.5f) / (float)shards;
            const float phi = std::acos(1.0f - 2.0f * u);
            const float theta = golden * idx;
            float dirX = std::cos(theta) * std::sin(phi);
            const float dirY = std::cos(phi);
            float dirZ = std::sin(theta) * std::sin(phi);
            const float ca = std::cos(orbit + idx * 0.25f);
            const float sa = std::sin(orbit + idx * 0.25f);
            const float rx = dirX * ca - dirZ * sa;
            dirZ = dirX * sa + dirZ * ca;
            dirX = rx;
            const float jitter = 0.72f + 0.28f * (0.5f + 0.5f * std::sin(idx * 4.13f));
            const float rr = E.radius * radiusMul * jitter;
            const float yBob = 0.10f * std::sin(t * 3.1f + idx * 1.7f);
            const float cx = E.ox + dirX * rr;
            const float cy = baseY + dirY * (E.height * 0.35f * ySpread) + yBob;
            const float cz = E.oz + dirZ * rr;
            const float s = shardSize * (E.height / 1.8f) * (0.75f + 0.25f * E.appear) *
                            (1.0f - 0.22f * hitT) * (0.90f + 0.10f * std::sin(t * 2.6f + idx));
            EspCrystal(E, cx, cy, cz, s, orbit * 1.6f + idx * 0.9f,
                       0.55f * std::sin(t * 1.25f + idx * 0.8f), filled, hitT);
        }
    }
}


JavaInventoryHotkeysModule::JavaInventoryHotkeysModule()
    : Module("Client", "Java Hotkeys",
              "Java-like hotbar swaps in the standard player inventory") {}

void JavaInventoryHotkeysModule::onEnable() {
    // The overlay owns the controller hook, bounded queue and options.txt
    // parser. Enabling the module only arms that already-installed path.
    overlay::SetJavaInventoryEnabled(true);
}

void JavaInventoryHotkeysModule::onDisable() {
    overlay::SetJavaInventoryEnabled(false);
}

// ======================== VSync Disabler ========================
VSyncDisablerModule::VSyncDisablerModule()
    : Module("Client", "VSync Disabler",
             "Present without the vertical sync wait (uncapped FPS)") {
    // r25 Flarial parity: the tearing flag lives on the swapchain from its
    // creation. This one-shot recreate applies it immediately instead of
    // waiting for the next client restart (Flarial's recreate path).
    m_recreate = addSetting<BoolSetting>("Recreate Swapchain",
        "Применить сразу: один раз пересоздать swapchain с tearing (как в Flarial).", false);
}

void VSyncDisablerModule::onEnable() {
    // The DXGI Present hook forces SyncInterval to 0 and presents with the
    // tearing flag once the swapchain carries it.
    overlay::SetVSyncDisabled(true);
}

void VSyncDisablerModule::onDisable() {
    overlay::SetVSyncDisabled(false);
}

void VSyncDisablerModule::onTick() {
    if (m_recreate && m_recreate->mValue) {
        m_recreate->mValue = false;   // one-shot
        overlay::RequestVSyncRecreate();
    }
}

// ======================== Null Movement ========================
NullMovementModule::NullMovementModule()
    : Module("Movement", "Null Movement",
             "Last pressed of A/D and W/S wins - no standstill") {
    m_adPair = addSetting<BoolSetting>("A/D Pair", "Null the A/D pair.", true);
    m_wsPair = addSetting<BoolSetting>("W/S Pair", "Null the W/S pair.", true);
}

void NullMovementModule::onEnable() {
    overlay::SetNullMovementEnabled(true);
    overlay::SetNullMovementPairs(m_adPair ? m_adPair->mValue : true,
                                  m_wsPair ? m_wsPair->mValue : true);
}

void NullMovementModule::onTick() {
    // Live pair toggles while the module runs.
    overlay::SetNullMovementPairs(m_adPair ? m_adPair->mValue : true,
                                  m_wsPair ? m_wsPair->mValue : true);
}

void NullMovementModule::onDisable() {
    overlay::SetNullMovementEnabled(false);
}

// ======================== CPS Limiter ========================
CpsLimiterModule::CpsLimiterModule()
    : Module("Combat", "CPS Limiter",
             "Капает клики, которые игра регистрирует в секунду") {
    m_left = addSetting<NumberSetting>("Left limit", "LMB clicks per second.",
                                       16.0f, 1.0f, 50.0f, 1.0f);
    m_right = addSetting<NumberSetting>("Right limit", "RMB clicks per second.",
                                        24.0f, 1.0f, 50.0f, 1.0f);
}

void CpsLimiterModule::onEnable() {
    overlay::SetCpsLimiterEnabled(true);
    overlay::SetCpsLimits((int)m_left->mValue, (int)m_right->mValue);
}

void CpsLimiterModule::onTick() {
    // Live limit updates while the module runs.
    overlay::SetCpsLimits((int)m_left->mValue, (int)m_right->mValue);
}

void CpsLimiterModule::onDisable() {
    overlay::SetCpsLimiterEnabled(false);
}

GuiScaleModule::GuiScaleModule()
    : Module("Client", "GUI Scale", "Native Minecraft GUI size: inventory, chat and screens") {
    // Match Flarial's gradual control instead of a discrete enum. The value
    // is sampled every frame, so dragging this slider changes Bedrock's own
    // GUI continuously from the smallest to the largest supported scale.
    m_scale = addSetting<NumberSetting>(
        "Scale", "Native Minecraft GUI scale, 1.0 to 4.0.", 2.0f, 1.0f, 4.0f, 0.05f);
}

float GuiScaleModule::targetScale() const {
    const float value = m_scale ? m_scale->mValue : 2.0f;
    return value < 1.0f ? 1.0f : (value > 4.0f ? 4.0f : value);
}

// ============================ r22 feature modules ============================
// Viewmodel / Item Physics / Jump Circles / Freelook / Glint. The overlay owns
// every game hook and the world-matrix access; these classes only read their
// settings and compute values, so nothing here touches game memory directly.

namespace {

Module* R22FindModule(const char* name, Module** cache) {
    if (*cache && std::strcmp((*cache)->name(), name) == 0) return *cache;
    *cache = modules().find(name);
    return *cache;
}

void Mat4Identity(float* m) {
    std::memset(m, 0, sizeof(float) * 16);
    m[0] = m[5] = m[10] = m[15] = 1.0f;
}
void Mat4Mul(float* out, const float* a, const float* b) {
    float r[16];
    for (int c = 0; c < 4; ++c)
        for (int row = 0; row < 4; ++row) {
            float sum = 0.0f;
            for (int k = 0; k < 4; ++k) sum += a[k * 4 + row] * b[c * 4 + k];
            r[c * 4 + row] = sum;
        }
    std::memcpy(out, r, sizeof(r));
}
void Mat4Translate(float* out, const float* a, float x, float y, float z) {
    float t[16]; Mat4Identity(t);
    t[12] = x; t[13] = y; t[14] = z;
    Mat4Mul(out, a, t);
}
void Mat4Scale(float* out, const float* a, float x, float y, float z) {
    float s[16]; Mat4Identity(s);
    s[0] = x; s[5] = y; s[10] = z;
    Mat4Mul(out, a, s);
}
void Mat4RotateX(float* out, const float* a, float rad) {
    const float c = std::cos(rad), s = std::sin(rad);
    float r[16]; Mat4Identity(r);
    r[5] = c; r[6] = s; r[9] = -s; r[10] = c;
    Mat4Mul(out, a, r);
}
void Mat4RotateY(float* out, const float* a, float rad) {
    const float c = std::cos(rad), s = std::sin(rad);
    float r[16]; Mat4Identity(r);
    r[0] = c; r[2] = -s; r[8] = s; r[10] = c;
    Mat4Mul(out, a, r);
}
void Mat4RotateZ(float* out, const float* a, float rad) {
    const float c = std::cos(rad), s = std::sin(rad);
    float r[16]; Mat4Identity(r);
    r[0] = c; r[1] = s; r[4] = -s; r[5] = c;
    Mat4Mul(out, a, r);
}
constexpr float kDegToRad = 0.01745329251994329577f;

} // namespace

// -------- Viewmodel --------
ViewModelModule::ViewModelModule()
    : Module("Visual", "ViewModel", "Сдвиг, поворот и масштаб предмета в руке.") {
    m_posX = addSetting<NumberSetting>("Offset X", "Item offset left/right.", 0.0f, -1.0f, 1.0f, 0.01f);
    m_posY = addSetting<NumberSetting>("Offset Y", "Item offset up/down.", 0.0f, -1.0f, 1.0f, 0.01f);
    m_posZ = addSetting<NumberSetting>("Offset Z", "Item offset forward/back.", 0.0f, -1.0f, 1.0f, 0.01f);
    m_rotX = addSetting<NumberSetting>("Rotation X", "Item rotation around X, degrees.", 0.0f, -90.0f, 90.0f, 1.0f);
    m_rotY = addSetting<NumberSetting>("Rotation Y", "Item rotation around Y, degrees.", 0.0f, -90.0f, 90.0f, 1.0f);
    m_rotZ = addSetting<NumberSetting>("Rotation Z", "Item rotation around Z, degrees.", 0.0f, -90.0f, 90.0f, 1.0f);
    m_scaleX = addSetting<NumberSetting>("Scale X", "Item width scale.", 1.0f, 0.2f, 2.5f, 0.05f);
    m_scaleY = addSetting<NumberSetting>("Scale Y", "Item height scale.", 1.0f, 0.2f, 2.5f, 0.05f);
    m_scaleZ = addSetting<NumberSetting>("Scale Z", "Item depth scale.", 1.0f, 0.2f, 2.5f, 0.05f);
}

void ViewModelModule::onEnable() {
    if (!overlay::EnsureItemRenderHook()) {
        LOG_ERROR("viewmodel: item render hook unavailable - feature off");
        setEnabled(false);
    }
}

bool ViewModelActive() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("ViewModel", &cache);
    if (!m || !m->enabled()) return false;
    const ViewModelModule* vm = static_cast<const ViewModelModule*>(m);
    if (!vm->m_posX) return false;
    return vm->m_posX->mValue != 0.0f || vm->m_posY->mValue != 0.0f ||
           vm->m_posZ->mValue != 0.0f || vm->m_rotX->mValue != 0.0f ||
           vm->m_rotY->mValue != 0.0f || vm->m_rotZ->mValue != 0.0f ||
           vm->m_scaleX->mValue != 1.0f || vm->m_scaleY->mValue != 1.0f ||
           vm->m_scaleZ->mValue != 1.0f;
}

void ViewModelApplyLocalMatrix() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("ViewModel", &cache);
    if (!m || !m->enabled()) return;
    const ViewModelModule* vm = static_cast<const ViewModelModule*>(m);
    if (!vm->m_posX) return;
    float acc[16] = {};
    if (!overlay::WorldMatrixTopGet(acc)) return;
    float tmp[16];
    if (vm->m_posX->mValue != 0.0f || vm->m_posY->mValue != 0.0f || vm->m_posZ->mValue != 0.0f) {
        Mat4Translate(tmp, acc, vm->m_posX->mValue, vm->m_posY->mValue, vm->m_posZ->mValue);
        std::memcpy(acc, tmp, sizeof(acc));
    }
    if (vm->m_rotX->mValue != 0.0f) { Mat4RotateX(tmp, acc, vm->m_rotX->mValue * kDegToRad); std::memcpy(acc, tmp, sizeof(acc)); }
    if (vm->m_rotY->mValue != 0.0f) { Mat4RotateY(tmp, acc, vm->m_rotY->mValue * kDegToRad); std::memcpy(acc, tmp, sizeof(acc)); }
    if (vm->m_rotZ->mValue != 0.0f) { Mat4RotateZ(tmp, acc, vm->m_rotZ->mValue * kDegToRad); std::memcpy(acc, tmp, sizeof(acc)); }
    if (vm->m_scaleX->mValue != 1.0f || vm->m_scaleY->mValue != 1.0f || vm->m_scaleZ->mValue != 1.0f) {
        Mat4Scale(tmp, acc, vm->m_scaleX->mValue, vm->m_scaleY->mValue, vm->m_scaleZ->mValue);
        std::memcpy(acc, tmp, sizeof(acc));
    }
    overlay::WorldMatrixTopSet(acc);
}

// -------- Item Physics --------
ItemPhysicsModule::ItemPhysicsModule()
    : Module("Visual", "Item Physics", "Дропнутые предметы падают плашмя и красиво оседают.") {
    m_speed = addSetting<NumberSetting>("Speed", "Airborne spin speed.", 8.0f, 1.0f, 15.0f, 0.5f);
    m_yOffset = addSetting<NumberSetting>("Y Offset", "Vertical offset for non-block items.", 0.3f, -0.5f, 0.5f, 0.01f);
    m_preserve = addSetting<BoolSetting>("Preserve Rotation", "Keep the landing angle instead of settling.", false);
    m_smooth = addSetting<BoolSetting>("Smooth Rotation", "Ease the settle instead of snapping.", true);
}

void ItemPhysicsModule::onEnable() {
    if (!overlay::EnsureItemRenderHook()) {
        LOG_ERROR("itemphysics: item render hook unavailable - feature off");
        setEnabled(false);
    }
}

bool ItemPhysicsActive() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Item Physics", &cache);
    return m && m->enabled();
}

void ItemPhysicsApplyItemMatrix(const ItemPhysicsInput& in) {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Item Physics", &cache);
    if (!m || !m->enabled()) return;
    const ItemPhysicsModule* ip = static_cast<const ItemPhysicsModule*>(m);
    if (!ip->m_speed) return;

    struct PhysEntry { float rotX, rotY, rotZ; float spinDir; unsigned long long lastMs; };
    static std::unordered_map<long long, PhysEntry> s_items;

    const unsigned long long now = GetTickCount64();
    if (s_items.size() > 512) s_items.clear();   // bounded: servers recycle ids
    auto it = s_items.find(in.rid);
    if (it == s_items.end()) {
        PhysEntry e;
        e.rotX = 90.0f;
        e.rotY = (float)(std::rand() % 360);
        e.rotZ = 0.0f;
        e.spinDir = (std::rand() & 1) ? 1.0f : -1.0f;
        e.lastMs = now;
        it = s_items.emplace(in.rid, e).first;
    }
    PhysEntry& e = it->second;

    float dt = (float)(now - e.lastMs) / 1000.0f;
    e.lastMs = now;
    if (!(dt > 0.0f) || dt > 0.25f) dt = dt > 0.25f ? 0.05f : 0.0f;

    const float speedDeg = ip->m_speed->mValue * 30.0f * dt;
    float rotX = e.rotX, rotY = e.rotY, rotZ = e.rotZ;
    if (!in.onGround) {
        if (dt > 0.0f) {
            e.rotY += e.spinDir * speedDeg;
            e.rotY = std::fmod(e.rotY + 3600.0f, 360.0f);
        }
        rotY = e.rotY;
    } else {
        const bool preserve = ip->m_preserve && ip->m_preserve->mValue;
        const bool smooth = ip->m_smooth && ip->m_smooth->mValue;
        if (!preserve && !smooth) {
            rotX = 90.0f;
            rotY = 0.0f;
            rotZ = in.isBlock ? 174.0f : 0.0f;
        } else if (smooth) {
            if (!preserve && dt > 0.0f) {
                const float targetY = in.isBlock ? 90.0f : 180.0f;
                const float targetZ = in.isBlock ? 174.0f : 0.0f;
                const float lerpF = 1.0f - std::exp(-10.0f * dt);
                float diff = std::fmod(targetY - e.rotY + 540.0f, 360.0f) - 180.0f;
                e.rotY = std::fmod(e.rotY + diff * lerpF + 3600.0f, 360.0f);
                e.rotZ += (targetZ - e.rotZ) * lerpF;
            }
            rotY = e.rotY;
            rotZ = e.rotZ;
        } else {
            rotY = e.rotY;
            rotZ = e.rotZ;
        }
    }

    float cur[16] = {};
    if (!overlay::WorldMatrixTopGet(cur)) return;
    const float tx = cur[12], tz = cur[14];
    float sx = std::sqrt(cur[0] * cur[0] + cur[1] * cur[1] + cur[2] * cur[2]);
    float sy = std::sqrt(cur[4] * cur[4] + cur[5] * cur[5] + cur[6] * cur[6]);
    float sz = std::sqrt(cur[8] * cur[8] + cur[9] * cur[9] + cur[10] * cur[10]);
    if (!(sx > 1e-6f) || !std::isfinite(sx)) sx = 1.0f;
    if (!(sy > 1e-6f) || !std::isfinite(sy)) sy = 1.0f;
    if (!(sz > 1e-6f) || !std::isfinite(sz)) sz = 1.0f;

    float mtx[16];
    Mat4Identity(mtx);
    Mat4Translate(mtx, mtx, tx, in.relY, tz);
    Mat4Scale(mtx, mtx, sx, sy, sz);
    if (!in.isBlock) Mat4Translate(mtx, mtx, 0.0f, ip->m_yOffset->mValue, 0.0f);
    Mat4RotateX(mtx, mtx, rotX * kDegToRad);
    Mat4RotateY(mtx, mtx, rotY * kDegToRad);
    Mat4RotateZ(mtx, mtx, rotZ * kDegToRad);
    if (!in.isBlock) Mat4Translate(mtx, mtx, 0.0f, -0.5f, 0.0f);
    overlay::WorldMatrixTopSet(mtx);
}

// -------- Jump Circles --------
JumpCirclesModule::JumpCirclesModule()
    : Module("Visual", "Jump Circles", "Кольца-волны у ног при прыжке и приземлении.") {
    m_trigger = addSetting<EnumSetting>("Trigger", "When rings appear.", 0,
        std::vector<std::string>{ "Landing", "Jump", "Both" });
    m_radius = addSetting<NumberSetting>("Max Radius", "Largest ring radius, blocks.", 1.6f, 0.4f, 3.5f, 0.05f);
    m_life = addSetting<NumberSetting>("Life (ms)", "Ring lifetime, ms.", 900.0f, 300.0f, 2500.0f, 50.0f);
    m_rings = addSetting<NumberSetting>("Rings", "Concentric ring count.", 3.0f, 1.0f, 4.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line width, px.", 2.0f, 1.0f, 5.0f, 0.5f);
    m_color = addSetting<ColorSetting>("Color", "Ring color.", 0xFFF45464);
}

void JumpCirclesModule::onDisable() {
    m_circles.clear();
}

void JumpCirclesModule::onRender() {
    if (overlay::g_showMenu) return;
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (!d) return;

    overlay::JumpCircleSpawn spawns[8];
    const int n = overlay::JumpCirclePollSpawns(spawns, 8);
    for (int i = 0; i < n; ++i) {
        if (m_circles.size() >= 32) break;
        Circle c;
        c.x = spawns[i].x; c.y = spawns[i].y; c.z = spawns[i].z;
        c.at = spawns[i].at;
        m_circles.push_back(c);
    }
    if (m_circles.empty()) return;

    const unsigned long long now = GetTickCount64();
    const float life = m_life ? std::max(200.0f, m_life->mValue) : 900.0f;
    const float maxR = m_radius ? m_radius->mValue : 1.6f;
    const int rings = m_rings ? (int)m_rings->mValue : 3;
    const float thick = m_thickness ? m_thickness->mValue : 2.0f;
    const ImVec4 col = m_color ? m_color->getAsImColor().Value : ImVec4(1, 1, 1, 1);
    constexpr int kSeg = 40;

    for (size_t ci = 0; ci < m_circles.size();) {
        const Circle& c = m_circles[ci];
        const float age = (float)(now - c.at);
        if (age >= life) {
            m_circles[ci] = m_circles.back();
            m_circles.pop_back();
            continue;
        }
        const float t = age / life;
        const float grow = 1.0f - (1.0f - t) * (1.0f - t);
        const float radius = std::max(0.05f, maxR * grow);
        const float fade = (1.0f - t);
        const float y = c.y + 0.03f + t * 0.06f;
        for (int r = 0; r < rings; ++r) {
            const float rr = radius - (float)r * 0.07f;
            if (rr <= 0.03f) continue;
            const float ra = col.w * fade * fade * (1.0f - (float)r / (float)(rings + 1));
            float prevX = 0.0f, prevY = 0.0f;
            bool prevOk = false;
            for (int s2 = 0; s2 <= kSeg; ++s2) {
                const float ang = 6.2831853f * (float)s2 / (float)kSeg;
                const float wp[3] = { c.x + std::cos(ang) * rr, y, c.z + std::sin(ang) * rr };
                float px = 0.0f, py2 = 0.0f;
                const bool ok = overlay::ProjectWorldToScreen(wp, &px, &py2, nullptr);
                if (ok && prevOk) {
                    d->AddLine(ImVec2(prevX, prevY), ImVec2(px, py2),
                               ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, ra * 0.35f)), thick * 2.4f);
                    d->AddLine(ImVec2(prevX, prevY), ImVec2(px, py2),
                               ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, ra)), thick);
                }
                prevOk = ok;
                prevX = px;
                prevY = py2;
            }
        }
        ++ci;
    }
}

bool JumpCirclesEnabled() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Jump Circles", &cache);
    return m && m->enabled();
}

int JumpCirclesTrigger() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Jump Circles", &cache);
    if (!m || !m->enabled()) return 0;
    const JumpCirclesModule* jc = static_cast<const JumpCirclesModule*>(m);
    return jc->m_trigger ? jc->m_trigger->mValue : 0;
}

// -------- Freelook --------
FreelookModule::FreelookModule()
    : Module("Visual", "Freelook",
             "Свободный обзор камерой, не поворачивая персонажа (удерживай клавишу).") {
    m_mode = addSetting<EnumSetting>("Mode", "View mode while freelooking.", 0,
        std::vector<std::string>{ "Third Person Back", "Third Person Front", "First Person" });
    mHoldToUse = true;
}

void FreelookModule::onEnable() {
    static bool warned = false;
    const unsigned long long now = GetTickCount64();
    if (m_lastAttempt != 0 && now - m_lastAttempt < 3000ull) {
        setEnabled(false);
        return;
    }
    m_lastAttempt = now;
    static const int kModeMap[3] = { 1, 2, 0 };   // back / front / first
    const int idx = (m_mode && m_mode->mValue >= 0 && m_mode->mValue <= 2) ? m_mode->mValue : 0;
    if (!overlay::FreelookBegin(kModeMap[idx])) {
        if (!warned) {
            warned = true;
            LOG_ERROR("freelook: game patterns unavailable - feature off");
        }
        setEnabled(false);
    }
}

void FreelookModule::onTick() {
    static const int kModeMap[3] = { 1, 2, 0 };
    const int idx = (m_mode && m_mode->mValue >= 0 && m_mode->mValue <= 2) ? m_mode->mValue : 0;
    overlay::FreelookSetMode(kModeMap[idx]);
}

void FreelookModule::onDisable() {
    overlay::FreelookEnd();
}

// -------- Glint --------
GlintModule::GlintModule()
    : Module("Visual", "Glint", "Свой цвет свечения зачарованных предметов.") {
    m_color = addSetting<ColorSetting>("Color", "Glint color.", 0xFFC77DFF);
    m_onlyLocal = addSetting<BoolSetting>("Only Local Player",
        "Recolor only your own enchanted items.", false);
}

void GlintColorNow(float out[4], bool* active, bool isLocal) {
    if (active) *active = false;
    static Module* cache = nullptr;
    Module* m = R22FindModule("Glint", &cache);
    if (!m || !m->enabled()) return;
    const GlintModule* g = static_cast<const GlintModule*>(m);
    if (!g->m_color) return;
    if (g->m_onlyLocal && g->m_onlyLocal->mValue && !isLocal) return;
    out[0] = g->m_color->mValue[0];
    out[1] = g->m_color->mValue[1];
    out[2] = g->m_color->mValue[2];
    out[3] = g->m_color->mValue[3];
    if (active) *active = true;
}

// -------- Clear Chat / Clear Scoreboard (r23) --------
// Background-only strippers: the module state is the single source of truth
// for the overlay's UI-tree pass; nothing here touches game memory.
ClearChatModule::ClearChatModule()
    : Module("Visual", "Clear Chat", "Убирает только фон чата — текст и история остаются.") {}

ClearScoreboardModule::ClearScoreboardModule()
    : Module("Visual", "Clear Scoreboard", "Убирает только фон таблицы — текст и данные остаются.") {}

bool ClearChatEnabled() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Clear Chat", &cache);
    return m && m->enabled();
}

bool ClearScoreboardEnabled() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Clear Scoreboard", &cache);
    return m && m->enabled();
}

bool ArmorHudEnabled() {
    static Module* cache = nullptr;
    Module* m = R22FindModule("Armor HUD", &cache);
    return m && m->enabled();
}

} // namespace nf
