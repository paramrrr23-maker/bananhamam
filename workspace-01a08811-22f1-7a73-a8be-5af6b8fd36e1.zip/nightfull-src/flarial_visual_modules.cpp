#include "pch.h"
#include "modules/visual/flarial_visual_modules.h"

#include "modules/visual/packet_hud.h"
#include "modules/module_manager.h"
#include "modules/settings/flarial_settings_module.h"
#include "overlay.h"
#include "utils/entity_registry.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <psapi.h>

namespace modules {
namespace {

enum HudPosition {
    TOP_LEFT = 0,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT,
    TOP_CENTER,
};

float HudScale() {
    FlarialSettingsModule* s = FlarialSettingsModule::instance();
    return s && s->m_hudScale ? gui::Clamp(s->m_hudScale->mValue, 0.5f, 2.0f) : 1.0f;
}

float FontScale() {
    FlarialSettingsModule* s = FlarialSettingsModule::instance();
    return s && s->m_fontScale ? gui::Clamp(s->m_fontScale->mValue, 0.6f, 1.6f) : 1.0f;
}

float HudPadding() {
    FlarialSettingsModule* s = FlarialSettingsModule::instance();
    return s && s->m_hudPadding ? gui::Clamp(s->m_hudPadding->mValue, 0.0f, 48.0f) : 10.0f;
}

bool HideInMenu() {
    FlarialSettingsModule* s = FlarialSettingsModule::instance();
    return overlay::g_ShowMenu && (!s || !s->m_hideHudInMenu || s->m_hideHudInMenu->mValue);
}

bool Shadows() {
    FlarialSettingsModule* s = FlarialSettingsModule::instance();
    return !s || !s->m_shadows || s->m_shadows->mValue;
}

ImColor Accent(float phase = 0.0f, float alpha = 1.0f) {
    const ImColor c = gui::GetThemedColor(phase);
    return ImColor(c.Value.x, c.Value.y, c.Value.z, alpha);
}

bool Screen(ImVec2& screen) {
    if (HideInMenu()) return false;
    screen = gui::GetScreenSize();
    return screen.x > 1.0f && screen.y > 1.0f;
}

ImVec2 Place(const ImVec2& screen, const ImVec2& size, int position, float padding) {
    switch (position) {
        case TOP_RIGHT:     return ImVec2(screen.x - padding - size.x, padding);
        case BOTTOM_LEFT:   return ImVec2(padding, screen.y - padding - size.y);
        case BOTTOM_RIGHT:  return ImVec2(screen.x - padding - size.x, screen.y - padding - size.y);
        case TOP_CENTER:    return ImVec2((screen.x - size.x) * 0.5f, padding);
        case TOP_LEFT:
        default:            return ImVec2(padding, padding);
    }
}

void DrawChip(const ImVec2& pos, const char* text, float scale,
              const ImColor& color, bool shadow) {
    if (!text || !*text) return;
    const float textSize = 0.82f * scale * FontScale();
    const float padX = 8.0f * scale;
    const float padY = 5.0f * scale;
    const float width = gui::GetTextWidth(text, textSize) + padX * 2.0f;
    const float height = gui::GetTextHeight(textSize) + padY * 2.0f;
    const ImVec4 rect(pos.x, pos.y, pos.x + width, pos.y + height);
    gui::FillShadowRect(rect, color, shadow ? 0.16f : 0.0f, 5.0f * scale, 0, 6.0f * scale);
    gui::FillRect(rect, ImColor(18, 23, 17), 0.92f, 6.0f * scale);
    gui::FillRect(ImVec4(rect.x, rect.y, rect.x + 2.0f * scale, rect.w), color,
                  0.95f, 1.0f * scale);
    gui::DrawText(ImVec2(pos.x + padX, pos.y + padY), text, color,
                  textSize, 1.0f, shadow);
}

// Placement of one Packet V2 HUD row for our anchor enum. Packet anchors its
// HUD rows at the bottom-left of the screen (FPS at windowSize.y - 50,
// Hooks.cpp:834); other anchors mirror that geometry onto the corners.
void PacketRowAnchor(const ImVec2& screenPx, int position, float rowWidthU,
                     float scale, float& xU, float& rowYU) {
    const float u = packethud::Unit();
    const bool top   = (position == TOP_LEFT || position == TOP_RIGHT || position == TOP_CENTER);
    const bool right = (position == TOP_RIGHT || position == BOTTOM_RIGHT);
    xU = 2.5f;
    if (right) xU = screenPx.x / u - rowWidthU - 2.5f;
    else if (position == TOP_CENTER) xU = (screenPx.x / u - rowWidthU) * 0.5f;
    rowYU = top ? 0.f : screenPx.y / u - 50.f * scale;
}

} // namespace

// ======================== FPS ============================================
FlarialFPS::FlarialFPS()
    : Module("Render", "FPS", "Packet V2-style local frame-rate display") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", BOTTOM_LEFT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_color = addSetting<EnumSetting>("Color", "HUD colour scheme", 0, packethud::ColorNames());
    set_enabled(true);
}

void FlarialFPS::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    packethud::Frame();

    const ImGuiIO& io = ImGui::GetIO();
    const float fps = io.Framerate > 0.1f ? io.Framerate :
                      (io.DeltaTime > 0.0f ? 1.0f / io.DeltaTime : 0.0f);
    char buffer[64];
    sprintf_s(buffer, "FPS: %d", (int)(fps + 0.5f));

    const float s = m_scale->mValue;
    const float w = packethud::HudRowWidthU(buffer, s);
    float xU = 0.f, rowY = 0.f;
    PacketRowAnchor(screen, m_position->mValue, w, s, xU, rowY);
    // PacketV2 Hooks.cpp:838-848: black box (hudMod->opacity 0.6) + scheme text.
    packethud::HudRow(buffer, xU, rowY, packethud::Sel(m_color->mValue), s);
}

// ======================== CPS ============================================
FlarialCPS::FlarialCPS()
    : Module("Render", "CPS", "Packet V2-style clicks-per-second display") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", BOTTOM_RIGHT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_showButtons = addSetting<BoolSetting>("Buttons", "Show LMB and RMB labels.", true);
    m_color = addSetting<EnumSetting>("Color", "HUD colour scheme", 0, packethud::ColorNames());
    set_enabled(true);
}

CPSLimiter::CPSLimiter()
    : Module("Misc", "CPS Limiter", "Limit left and right clicks per second") {
    m_left = addSetting<NumberSetting>("Left", "Maximum left clicks per second", 16.0f, 1.0f, 30.0f, 1.0f);
    m_right = addSetting<NumberSetting>("Right", "Maximum right clicks per second", 24.0f, 1.0f, 30.0f, 1.0f);
}

void FlarialCPS::record(std::array<unsigned long long, kMaxClicks>& buffer,
                        int& head, int& count, unsigned long long now) {
    buffer[head] = now;
    head = (head + 1) % kMaxClicks;
    if (count < kMaxClicks) ++count;
}

int FlarialCPS::recent(const std::array<unsigned long long, kMaxClicks>& buffer,
                       int head, int count, unsigned long long now) const {
    int result = 0;
    for (int i = 0; i < count; ++i) {
        const int index = (head - 1 - i + kMaxClicks) % kMaxClicks;
        const unsigned long long stamp = buffer[index];
        if (stamp != 0 && now >= stamp && now - stamp <= 1000ull) ++result;
    }
    return result;
}

void FlarialCPS::on_tick() {
    if (HideInMenu()) return;
    const unsigned long long now = GetTickCount64();
    if (ImGui::IsMouseClicked(0)) record(m_lmb, m_lmbHead, m_lmbCount, now);
    if (ImGui::IsMouseClicked(1)) record(m_rmb, m_rmbHead, m_rmbCount, now);
}

void FlarialCPS::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    packethud::Frame();

    const unsigned long long now = GetTickCount64();
    const int lmb = recent(m_lmb, m_lmbHead, m_lmbCount, now);
    const int rmb = recent(m_rmb, m_rmbHead, m_rmbCount, now);
    char buffer[96];
    if (m_showButtons->mValue)
        sprintf_s(buffer, "LMB: %d  |  RMB: %d", lmb, rmb);
    else
        sprintf_s(buffer, "CPS: %d", lmb);

    const float s = m_scale->mValue;
    const float w = packethud::HudRowWidthU(buffer, s);
    float xU = 0.f, rowY = 0.f;
    PacketRowAnchor(screen, m_position->mValue, w, s, xU, rowY);
    packethud::HudRow(buffer, xU, rowY, packethud::Sel(m_color->mValue), s);
}

// ======================== Keystrokes =====================================
FlarialKeystrokes::FlarialKeystrokes()
    : Module("Visual", "Keystrokes", "Flarial-style movement and mouse keys") {
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_spacing = addSetting<NumberSetting>("Spacing", "Gap between key cells.", 2.0f, 0.0f, 8.0f, 0.5f);
    m_rounding = addSetting<NumberSetting>("Rounding", "Cell corner radius.", 5.0f, 0.0f, 12.0f, 0.5f);
    m_showMouse = addSetting<BoolSetting>("Mouse Buttons", "Show LMB and RMB cells.", true);
    m_enabledColor = addSetting<ColorSetting>("Pressed Color", "Color of a held key.", 0xFFD8F24A);
    m_disabledColor = addSetting<ColorSetting>("Released Color", "Color of an idle key.", 0xFF253021);
    set_enabled(true);
}

void FlarialKeystrokes::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;

    const float scale = m_scale->mValue * HudScale();
    const float cell = 34.0f * scale;
    const float gap = m_spacing->mValue * scale;
    const float mouseW = cell * 1.5f + gap * 0.5f;
    const int rows = m_showMouse->mValue ? 3 : 2;
    const float width = cell * 3.0f + gap * 2.0f;
    const float height = cell * (float)rows + gap * (float)(rows - 1);
    const ImVec2 origin(HudPadding(), screen.y - HudPadding() - height);
    ImDrawList* draw = ImGui::GetForegroundDrawList();

    struct KeyCell { const char* label; int vk; float x; float y; float w; };
    const KeyCell cells[] = {
        {"W", 'W', 1.0f, 0.0f, 1.0f},
        {"A", 'A', 0.0f, 1.0f, 1.0f}, {"S", 'S', 1.0f, 1.0f, 1.0f},
        {"D", 'D', 2.0f, 1.0f, 1.0f},
        {"LMB", VK_LBUTTON, 0.0f, 2.0f, 1.45f},
        {"RMB", VK_RBUTTON, 1.55f, 2.0f, 1.45f},
    };
    const int cellCount = m_showMouse->mValue ? 6 : 4;
    for (int i = 0; i < cellCount; ++i) {
        const KeyCell& c = cells[i];
        const ImVec2 p(origin.x + c.x * (cell + gap), origin.y + c.y * (cell + gap));
        const float w = c.w * cell + (c.w > 1.0f ? gap * 0.45f : 0.0f);
        const bool down = (c.vk == VK_LBUTTON || c.vk == VK_RBUTTON)
            ? ImGui::IsMouseDown(c.vk == VK_LBUTTON ? 0 : 1)
            : keys::Down(c.vk);
        const ImColor color = down ? m_enabledColor->getAsImColor() : m_disabledColor->getAsImColor();
        draw->AddRectFilled(p, ImVec2(p.x + w, p.y + cell),
                            ImColor(18, 23, 17, down ? 245 : 225), m_rounding->mValue * scale);
        draw->AddRect(p, ImVec2(p.x + w, p.y + cell),
                      ImColor(color.Value.x, color.Value.y, color.Value.z, down ? 0.95f : 0.42f),
                      m_rounding->mValue * scale, 0, 1.0f * scale);
        const float ts = 0.64f * scale * FontScale();
        const float tw = gui::GetTextWidth(c.label, ts);
        const float th = gui::GetTextHeight(ts);
        gui::DrawText(ImVec2(p.x + (w - tw) * 0.5f, p.y + (cell - th) * 0.5f),
                      c.label, color, ts, 1.0f, Shadows());
    }
}

// ======================== Crosshair ======================================
FlarialCrosshair::FlarialCrosshair()
    : Module("Visual", "Crosshair", "Flarial-style screen-space crosshair") {
    m_dynamic = addSetting<BoolSetting>("Dynamic", "Expand with local mouse motion.", true);
    m_gap = addSetting<NumberSetting>("Gap", "Center gap.", 5.0f, 0.0f, 18.0f, 0.5f);
    m_length = addSetting<NumberSetting>("Length", "Arm length.", 7.0f, 2.0f, 20.0f, 0.5f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line thickness.", 2.0f, 1.0f, 5.0f, 0.5f);
    m_color = addSetting<ColorSetting>("Color", "Crosshair color.", 0xFFD8F24A);
    set_enabled(true);
}

void FlarialCrosshair::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float scale = HudScale();
    const float motion = std::sqrt(io.MouseDelta.x * io.MouseDelta.x + io.MouseDelta.y * io.MouseDelta.y);
    const float gap = (m_gap->mValue + (m_dynamic->mValue ? gui::Clamp(motion * 0.7f, 0.0f, 7.0f) : 0.0f)) * scale;
    const float len = m_length->mValue * scale;
    const float thickness = m_thickness->mValue * scale;
    const ImVec2 center(screen.x * 0.5f, screen.y * 0.5f);
    const ImColor color = m_color->getAsImColor();
    ImDrawList* draw = ImGui::GetForegroundDrawList();
    draw->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), color, thickness);
    draw->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), color, thickness);
    draw->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), color, thickness);
    draw->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), color, thickness);
}

// ======================== Mouse strokes ==================================
FlarialMouseStrokes::FlarialMouseStrokes()
    : Module("Render", "Mouse Strokes", "Flarial-style local mouse movement trail") {
    m_scale = addSetting<NumberSetting>("Scale", "Trail scale.", 1.0f, 0.5f, 2.0f, 0.05f);
    m_length = addSetting<NumberSetting>("Length", "Maximum trail points.", 28.0f, 4.0f, 64.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Trail line width.", 2.0f, 1.0f, 6.0f, 0.5f);
    const ImColor defAccent = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>("Color", "Trail color.",
                                       defAccent.Value.x, defAccent.Value.y, defAccent.Value.z, 1.0f);
}

void FlarialMouseStrokes::on_enable() {
    m_pointCount = 0;
}

void FlarialMouseStrokes::on_disable() {
    m_pointCount = 0;
}

void FlarialMouseStrokes::on_tick() {
    const unsigned long long now = GetTickCount64();
    // Expire points even while the cursor is stationary. Without this pass,
    // the final segment stayed visible forever because no new point arrived.
    int firstLive = 0;
    while (firstLive < m_pointCount &&
           now - m_points[firstLive].timestamp > kPointLifetimeMs)
        ++firstLive;
    if (firstLive > 0) {
        const int remaining = m_pointCount - firstLive;
        for (int i = 0; i < remaining; ++i)
            m_points[i] = m_points[i + firstLive];
        m_pointCount = remaining;
    }

    // Visible inside the ClickGUI too: the trail keeps recording and drawing.
    const ImGuiIO& io = ImGui::GetIO();
    if (io.MousePos.x < 0.0f || io.MousePos.y < 0.0f) return;
    if (std::fabs(io.MouseDelta.x) < 0.01f && std::fabs(io.MouseDelta.y) < 0.01f) return;
    if (m_pointCount < kMaxPoints) {
        m_points[m_pointCount++] = TrailPoint{io.MousePos, now};
    } else {
        for (int i = 1; i < kMaxPoints; ++i) m_points[i - 1] = m_points[i];
        m_points[kMaxPoints - 1] = TrailPoint{io.MousePos, now};
    }
}

void FlarialMouseStrokes::on_render() {
    // Render can continue while the game tick is paused or throttled. Expire
    // points here as well as in on_tick so the last segment never lingers when
    // the mouse stops moving.
    const unsigned long long now = GetTickCount64();
    int firstLive = 0;
    while (firstLive < m_pointCount &&
           now - m_points[firstLive].timestamp > kPointLifetimeMs)
        ++firstLive;
    if (firstLive > 0) {
        const int remaining = m_pointCount - firstLive;
        for (int i = 0; i < remaining; ++i)
            m_points[i] = m_points[i + firstLive];
        m_pointCount = remaining;
    }

    // Renders inside the ClickGUI too (visible over the menu).
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f || m_pointCount < 2) return;
    const int visible = std::min(m_pointCount, (int)m_length->mValue);
    const int first = m_pointCount - visible;
    const float scale = m_scale->mValue * HudScale();
    ImDrawList* draw = ImGui::GetForegroundDrawList();
    for (int i = first + 1; i < m_pointCount; ++i) {
        const float age = (float)(now - m_points[i].timestamp) /
                          (float)kPointLifetimeMs;
        const float life = gui::Clamp(1.0f - age, 0.0f, 1.0f);
        if (life <= 0.0f) continue;
        const float t = (float)(i - first) / (float)std::max(1, visible - 1);
        const ImColor base = m_color->getAsImColor();
        const ImColor color(base.Value.x, base.Value.y, base.Value.z,
                            (0.08f + 0.82f * t) * life);
        draw->AddLine(m_points[i - 1].position, m_points[i].position,
                      color, m_thickness->mValue * scale);
    }
}

// ======================== Direction HUD ==================================
FlarialDirectionHUD::FlarialDirectionHUD()
    : Module("Visual", "Direction HUD", "Compass overlay; rotation hook can be attached later") {
    m_scale = addSetting<NumberSetting>("Scale", "Compass scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_degrees = addSetting<BoolSetting>("Degrees", "Show cardinal degree values.", true);
    m_color = addSetting<ColorSetting>("Color", "Compass color.", 0xFFD8F24A);
    set_enabled(false);
}

void FlarialDirectionHUD::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    const float scale = m_scale->mValue * HudScale();
    const float ts = 0.76f * scale * FontScale();
    const char* text = m_degrees->mValue ? "N 0    NE 45    E 90    SE 135    S 180    SW 225    W 270    NW 315"
                                         : "N    NE    E    SE    S    SW    W    NW";
    const ImVec2 size(gui::GetTextWidth(text, ts) + 16.0f * scale,
                      gui::GetTextHeight(ts) + 10.0f * scale);
    DrawChip(Place(screen, size, TOP_CENTER, HudPadding()), text, scale,
             m_color->getAsImColor(), Shadows());
}

// ======================== Clock ==========================================
FlarialClock::FlarialClock()
    : Module("Visual", "Time", "Local wall-clock overlay") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", BOTTOM_LEFT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_seconds = addSetting<BoolSetting>("Seconds", "Include seconds.", false);
    m_24Hour = addSetting<BoolSetting>("24 Hour", "Use 24-hour time.", true);
    m_color = addSetting<ColorSetting>("Color", "Text accent.", 0xFFD8F24A);
}

void FlarialClock::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buffer[64];
    if (m_24Hour->mValue) {
        if (m_seconds->mValue) sprintf_s(buffer, "Time: %02u:%02u:%02u", st.wHour, st.wMinute, st.wSecond);
        else sprintf_s(buffer, "Time: %02u:%02u", st.wHour, st.wMinute);
    } else {
        const unsigned hour = (st.wHour % 12u) == 0u ? 12u : st.wHour % 12u;
        if (m_seconds->mValue) sprintf_s(buffer, "Time: %02u:%02u:%02u %s", hour, st.wMinute, st.wSecond, st.wHour < 12 ? "AM" : "PM");
        else sprintf_s(buffer, "Time: %02u:%02u %s", hour, st.wMinute, st.wHour < 12 ? "AM" : "PM");
    }
    const float scale = m_scale->mValue * HudScale();
    const float ts = 0.82f * scale * FontScale();
    const ImVec2 size(gui::GetTextWidth(buffer, ts) + 16.0f * scale,
                      gui::GetTextHeight(ts) + 10.0f * scale);
    DrawChip(Place(screen, size, m_position->mValue, HudPadding()), buffer, scale,
             m_color->getAsImColor(), Shadows());
}

// ======================== Memory =========================================
FlarialMemory::FlarialMemory()
    : Module("Visual", "Memory", "Current process working-set display") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", BOTTOM_RIGHT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_color = addSetting<ColorSetting>("Color", "Text accent.", 0xFFD8F24A);
}

void FlarialMemory::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    static SIZE_T cachedWorkingSet = 0;
    static unsigned long long nextSample = 0;
    const unsigned long long now = GetTickCount64();
    if (now >= nextSample) {
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb = sizeof(pmc);
        if (GetProcessMemoryInfo(GetCurrentProcess(),
                                 reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc),
                                 sizeof(pmc)))
            cachedWorkingSet = pmc.WorkingSetSize;
        nextSample = now + 250ull;
    }
    char buffer[64];
    sprintf_s(buffer, "Memory: %.0f MB", (double)cachedWorkingSet / (1024.0 * 1024.0));
    const float scale = m_scale->mValue * HudScale();
    const float ts = 0.82f * scale * FontScale();
    const ImVec2 size(gui::GetTextWidth(buffer, ts) + 16.0f * scale,
                      gui::GetTextHeight(ts) + 10.0f * scale);
    DrawChip(Place(screen, size, m_position->mValue, HudPadding()), buffer, scale,
             m_color->getAsImColor(), Shadows());
}

// ======================== Animations (Flarial port) ========================
Animations::Animations()
    : Module("Render", "Animations",
             "Animate the selected hotbar slot while switching slots (Flarial)") {
    m_speed = addSetting<NumberSetting>("Hotbar Speed", "Selected slot animation speed",
                                        7.0f, 1.0f, 20.0f, 0.5f);
    // Flarial ships this module disabled by default.
}

// ======================== Reach Display (Flarial port) =====================
ReachDisplay::ReachDisplay()
    : Module("Render", "Reach Display", "Distance of your last attack (Packet V2 HUD style)") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", TOP_LEFT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 1.0f, 0.6f, 2.0f, 0.05f);
    m_color = addSetting<EnumSetting>("Color", "HUD colour scheme", 0, packethud::ColorNames());
}

void ReachDisplay::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    packethud::Frame();

    // Flarial ReachCounter::onTick resets the value after 15 seconds without
    // a hit; the displayed value refreshes 10 times per second.
    static float shownReach = 0.0f;
    static unsigned long nextSample = 0;
    const unsigned long now = GetTickCount();
    if (now >= nextSample) {
        float reach = 0.0f;
        if (overlay::g_lastHitValid &&
            now - overlay::g_lastHitTickMs <= 15000ull) {
            reach = overlay::g_lastHitDistance;
        }
        shownReach = reach;
        nextSample = now + 100ull;   // 10 Hz
    }
    char buffer[48];
    sprintf_s(buffer, "Reach: %.3f", shownReach);

    const float s = m_scale->mValue;
    const float w = packethud::HudRowWidthU(buffer, s);
    float xU = 0.f, rowY = 0.f;
    PacketRowAnchor(screen, m_position->mValue, w, s, xU, rowY);
    packethud::HudRow(buffer, xU, rowY, packethud::Sel(m_color->mValue), s);
}

// ======================== Pulse-style plates ===============================
namespace {

// Lucide glyph bytes (same icon font the ClickGUI uses).
constexpr const char* kGlyphActivity = "\xEE\x80\xB8";  // U+E038 pulse line
constexpr const char* kGlyphKeyboard = "\xEE\x8A\x84";  // U+E284 keyboard

// English effect names (Bedrock), indexed by MobEffect::EffectType - 1.
const char* const kEffectNames[] = {
    "Speed", "Slowness", "Haste", "Mining Fatigue",
    "Strength", "Instant Health", "Instant Damage", "Jump Boost",
    "Nausea", "Regeneration", "Resistance", "Fire Resistance",
    "Water Breathing", "Invisibility", "Blindness", "Night Vision",
    "Hunger", "Weakness", "Poison", "Wither",
    "Health Boost", "Absorption", "Saturation", "Levitation",
    "Fatal Poison", "Conduit Power", "Slow Falling",
    "Bad Omen", "Hero of the Village", "Darkness",
    "Trial Omen", "Wind Charged", "Weaving", "Oozing",
    "Infested", "Raid Omen",
};
constexpr int kEffectNameCount = (int)(sizeof(kEffectNames) / sizeof(kEffectNames[0]));

struct PulsePlateRow {
    std::string left;
    std::string right;
    ImColor     dot = ImColor(0, 0, 0, 0);   // a = 0 -> no status dot
    ImColor     color = ImColor(0, 0, 0, 0); // a = 0 -> default white
};

// Status dot: flat single-colour circle (no glow).
void DrawNeonDot(ImDrawList* d, const ImVec2& center, float radius, const ImColor& c) {
    d->AddCircleFilled(center, radius, c, 12);
}

// One Pulse-style plate: dark rounded plate, header row (icon + title), then
// data rows (left text / right text, optional status dot + per-row colour).
float DrawPulsePlate(const ImVec2& pos, float scale, const ImColor& accent,
                     const char* icon, const char* title, bool outline,
                     const std::vector<PulsePlateRow>& rows, float bgOpacity) {
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    ImFont* font = gui::CurrentFont();
    ImFont* icons = gui::IconFont();

    const float pad = 8.0f * scale;
    const float headH = 20.0f * scale;
    const float rowH = 15.0f * scale;
    const float tsHead = 11.5f * scale;
    const float tsRow = 10.5f * scale;
    const float isz = 12.0f * scale;
    const ImColor rowWhite(0.95f, 0.96f, 0.96f, 1.0f);

    // measure
    const float titleW = font ? font->CalcTextSizeA(tsHead, FLT_MAX, 0, title).x : 0.f;
    float rowsW = 0.f;
    for (const auto& r : rows) {
        const float l = font ? font->CalcTextSizeA(tsRow, FLT_MAX, 0, r.left.c_str()).x : 0.f;
        const float rv = font ? font->CalcTextSizeA(tsRow, FLT_MAX, 0, r.right.c_str()).x : 0.f;
        const float dotW = (r.dot.Value.w > 0.0f) ? (1.6f * scale * 2.0f + 5.0f * scale) : 0.0f;
        rowsW = (std::max)(rowsW, dotW + l + rv + 14.0f * scale);
    }
    const float w = pad * 2.0f + (std::max)(rowsW, (icons ? isz : 0.f) + 6.0f * scale + titleW);
    const float h = headH + rows.size() * rowH + pad * 0.6f;

    gui::FillRect(ImVec4(pos.x, pos.y, pos.x + w, pos.y + h),
                  ImColor(9, 9, 13), bgOpacity, 7.0f * scale);
    if (outline)
        d->AddRect(ImVec2(pos.x + 0.7f, pos.y + 0.7f),
                   ImVec2(pos.x + w - 0.7f, pos.y + h - 0.7f),
                   accent, 7.0f * scale - 0.7f, 0, 1.4f);

    float y = pos.y + pad * 0.5f;
    float cx = pos.x + pad;
    if (icons) {
        d->AddText(icons, isz, ImVec2(cx, y + headH * 0.5f - isz * 0.55f), accent, icon);
        cx += isz + 5.0f * scale;
    }
    if (font) {
        const float th = font->CalcTextSizeA(tsHead, FLT_MAX, 0, title).y;
        d->AddText(font, tsHead, ImVec2(cx, y + headH * 0.5f - th * 0.5f), accent, title);
    }

    y += headH;
    for (const auto& r : rows) {
        const float lth = font ? font->CalcTextSizeA(tsRow, FLT_MAX, 0, r.left.c_str()).y : 0.f;
        if (font) {
            float tx = pos.x + pad;
            if (r.dot.Value.w > 0.0f) {
                DrawNeonDot(d, ImVec2(tx + 1.6f * scale, y + rowH * 0.5f),
                            1.6f * scale, r.dot);
                tx += 1.6f * scale * 2.0f + 5.0f * scale;
            }
            d->AddText(font, tsRow, ImVec2(tx, y + rowH * 0.5f - lth * 0.5f),
                       ImGui::ColorConvertFloat4ToU32(
                           r.color.Value.w > 0.0f ? r.color.Value : rowWhite.Value),
                       r.left.c_str());
            const float rth = font->CalcTextSizeA(tsRow, FLT_MAX, 0, r.right.c_str()).x;
            d->AddText(font, tsRow,
                       ImVec2(pos.x + w - pad - rth, y + rowH * 0.5f - lth * 0.5f),
                       ImGui::ColorConvertFloat4ToU32(
                           r.color.Value.w > 0.0f ? r.color.Value : rowWhite.Value),
                       r.right.c_str());
        }
        y += rowH;
    }
    return y;
}

} // namespace

// ======================== Potions (Pulse style) ============================
PotionsHud::PotionsHud()
    : Module("Render", "Potions", "Active potion effects with timers (Pulse)") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", TOP_LEFT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 2.0f, 0.5f, 4.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme color", "Follow the interface theme accent.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.78f, 0.0f, 1.0f, 0.05f);
    const ImColor def = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme color is off.",
                                       def.Value.x, def.Value.y, def.Value.z, 1.0f);
    set_enabled(true);
}

void PotionsHud::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    // Only inside a world/server: hidden in Minecraft's menus, the server
    // list and every loading screen.
    if (!overlay::IsInWorld()) return;

    overlay::PotionEffect effects[24];
    const int count = overlay::GetPotionEffects(effects, 24);

    std::vector<PulsePlateRow> rows;
    rows.reserve(count);
    for (int i = 0; i < count; ++i) {
        const overlay::PotionEffect& e = effects[i];
        const int idx = (int)e.id - 1;
        // Unknown effect ids are skipped entirely (no "Effect N" placeholders).
        if (idx < 0 || idx >= kEffectNameCount) continue;
        const float remainSec = e.noCounter ? 1e9f : (float)e.duration / 20.0f;

        PulsePlateRow row;
        row.left = std::string(kEffectNames[idx]) + " " + std::to_string(e.amplifier + 1);
        if (e.noCounter || e.duration <= 0) {
            row.right = "\xE2\x88\x9E";  // infinity sign
        } else {
            const int total = e.duration / 20;
            char buf[16];
            sprintf_s(buf, sizeof(buf), "%d:%02d", total / 60, total % 60);
            row.right = buf;
        }
        // Last 10 seconds: the row smoothly fades from white to red.
        const float t = 1.0f - gui::Clamp(remainSec / 10.0f, 0.0f, 1.0f);
        row.color = ImColor(gui::LerpColor(ImColor(0.95f, 0.96f, 0.96f, 1.0f),
                                           ImColor(1.0f, 0.15f, 0.15f, 1.0f), t));
        rows.push_back(std::move(row));
    }

    const ImColor accent = (m_useTheme && m_useTheme->mValue)
                               ? gui::GetThemedColor(0)
                               : m_color->getAsImColor();

    // anchored below the watermark (Pulse keeps the potions under it)
    const ImVec2 anchor = Place(screen, ImVec2(0, 0), m_position->mValue, HudPadding());
    const float s = m_scale->mValue * HudScale();
    DrawPulsePlate(ImVec2(anchor.x, anchor.y + 34.0f * s), s, accent,
                   kGlyphActivity, "Potions",
                   m_outline && m_outline->mValue, rows, m_opacity->mValue);
}

// ======================== Keybinds (Pulse style) ===========================
KeybindsHud::KeybindsHud()
    : Module("Render", "Keybinds", "Bound modules with live status dots (Pulse)") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", TOP_RIGHT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 2.0f, 0.5f, 4.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme color", "Follow the interface theme accent.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.78f, 0.0f, 1.0f, 0.05f);
    const ImColor def = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme color is off.",
                                       def.Value.x, def.Value.y, def.Value.z, 1.0f);
    set_enabled(true);
}

void KeybindsHud::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    // Only inside a world/server: hidden in Minecraft's menus, the server
    // list and every loading screen.
    if (!overlay::IsInWorld()) return;

    std::vector<PulsePlateRow> rows;
    for (const auto& m : Modules().modules()) {
        if (!m || m->key() <= 0 || !m->name()) continue;
        if (m.get() == this) continue;
        const std::string raw = m->name();
        if (raw == "Watermark" || raw == "Arraylist" || raw == "Potions" ||
            raw == "Keybinds")
            continue;
        PulsePlateRow row;
        row.left = gui::ApplyNaming(raw.c_str());
        row.right = keys::Name(m->key());
        // live status dot: green while the module is on, red when off
        row.dot = m->enabled() ? ImColor(0.1f, 1.0f, 0.35f, 1.0f)
                               : ImColor(1.0f, 0.15f, 0.15f, 1.0f);
        rows.push_back(std::move(row));
    }

    const ImColor accent = (m_useTheme && m_useTheme->mValue)
                               ? gui::GetThemedColor(0)
                               : m_color->getAsImColor();

    const ImVec2 anchor = Place(screen, ImVec2(0, 0), m_position->mValue, HudPadding());
    const float s = m_scale->mValue * HudScale();
    DrawPulsePlate(anchor, s, accent, kGlyphKeyboard, "Keybinds",
                   m_outline && m_outline->mValue, rows, m_opacity->mValue);
}

// ======================== Monitoring (Pulse style) ==========================
MonitoringHud::MonitoringHud()
    : Module("Render", "Monitoring",
             "FPS / BPS / TPS / server IP / CPS / local time (Pulse)") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", TOP_RIGHT,
                                         std::vector<std::string>{"Top left", "Top right", "Bottom left", "Bottom right", "Top center"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 2.0f, 0.5f, 4.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme color", "Follow the interface theme accent.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.78f, 0.0f, 1.0f, 0.05f);
    const ImColor def = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme color is off.",
                                       def.Value.x, def.Value.y, def.Value.z, 1.0f);
    set_enabled(true);
}

void MonitoringHud::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    // Same gating as Potions/Keybinds: hidden in menus and loading screens.
    if (!overlay::IsInWorld()) return;

    overlay::TryInstallBaseTickHook();

    const unsigned long now = GetTickCount();

    // FPS: frames per rolling second
    static unsigned s_frames = 0;
    static unsigned long s_fpsMs = 0;
    static int s_fps = -1;
    ++s_frames;
    if (now - s_fpsMs >= 1000) {
        s_fps = (int)((double)s_frames * 1000.0 / (double)(now - s_fpsMs));
        s_frames = 0;
        s_fpsMs = now;
    }

    // TPS: local-player client ticks per second (baseTick hook counter)
    static LONG s_tickSnap = 0;
    static unsigned long s_tpsMs = 0;
    static int s_tps = -1;
    const LONG ticks = overlay::g_monitorTickCounter;
    if (now - s_tpsMs >= 1000) {
        s_tps = (int)(ticks - s_tickSnap);
        s_tickSnap = ticks;
        s_tpsMs = now;
    }

    // BPS: horizontal speed from the state-vector velocity (blocks/tick * 20)
    static float s_bps = 0.0f;
    static bool s_bpsOk = false;
    {
        float pos[3], vel[3];
        if (overlay::GetLocalPlayerState(pos, vel)) {
            const float target = sqrtf(vel[0] * vel[0] + vel[2] * vel[2]) * 20.0f;
            s_bps += (target - s_bps) * 0.25f;
            s_bpsOk = true;
        } else {
            s_bpsOk = false;
        }
    }

    // CPS (left button): press transitions of VK_LBUTTON
    static bool s_lastLmb = false;
    static unsigned s_clicks[32] = {};
    static int s_cHead = 0, s_cCount = 0;
    const bool lmb = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    if (lmb && !s_lastLmb) {
        s_clicks[s_cHead] = now;
        s_cHead = (s_cHead + 1) % 32;
        if (s_cCount < 32) ++s_cCount;
    }
    s_lastLmb = lmb;
    int cps = 0;
    for (int i = 0; i < s_cCount; ++i)
        if (now - s_clicks[i] <= 1000) ++cps;

    // joined server IP (empty when playing a local world)
    char ip[65];
    const bool ipOk = overlay::GetServerIpString(ip, sizeof(ip));

    // local time
    SYSTEMTIME st;
    GetLocalTime(&st);
    char timeBuf[16];
    sprintf_s(timeBuf, sizeof(timeBuf), "%02u:%02u", st.wHour, st.wMinute);

    std::vector<PulsePlateRow> rows;
    char b[32];
    PulsePlateRow row;

    row.left = "FPS";
    if (s_fps >= 0) { sprintf_s(b, sizeof(b), "%d", s_fps); row.right = b; }
    else row.right = "--";
    rows.push_back(row);

    row = PulsePlateRow{};
    row.left = "BPS";
    if (s_bpsOk) { sprintf_s(b, sizeof(b), "%.2f", s_bps); row.right = b; }
    else row.right = "--";
    rows.push_back(row);

    row = PulsePlateRow{};
    row.left = "TPS";
    if (s_tps >= 0 && overlay::g_monitorTickCounter > 0) {
        sprintf_s(b, sizeof(b), "%d", s_tps);
        row.right = b;
    } else row.right = "--";
    rows.push_back(row);

    row = PulsePlateRow{};
    row.left = "IP";
    row.right = ipOk ? std::string(ip) : std::string("Local");
    rows.push_back(row);

    row = PulsePlateRow{};
    row.left = "CPS (L)";
    sprintf_s(b, sizeof(b), "%d", cps);
    row.right = b;
    rows.push_back(row);

    row = PulsePlateRow{};
    row.left = "Time";
    row.right = timeBuf;
    rows.push_back(row);

    const ImColor accent = (m_useTheme && m_useTheme->mValue)
                               ? gui::GetThemedColor(0)
                               : m_color->getAsImColor();
    const ImVec2 anchor = Place(screen, ImVec2(0, 0), m_position->mValue, HudPadding());
    const float s = m_scale->mValue * HudScale();
    DrawPulsePlate(anchor, s, accent, kGlyphActivity, "Monitoring",
                   m_outline && m_outline->mValue, rows, m_opacity->mValue);
}

// ======================== Target HUD (SystemDLC port) =======================
TargetHud::TargetHud()
    : Module("Render", "Target HUD",
             "SystemDLC-style plate: appears on crosshair aim / attack, sits "
             "above the hotbar") {
    m_position = addSetting<EnumSetting>("Position", "HUD anchor.", 0,
                                         std::vector<std::string>{"Hotbar", "Top left", "Top right", "Bottom left", "Bottom right"});
    m_scale = addSetting<NumberSetting>("Scale", "Widget scale.", 2.0f, 0.5f, 4.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme color", "Follow the interface theme accent.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.85f, 0.0f, 1.0f, 0.05f);
    const ImColor def = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme color is off.",
                                       def.Value.x, def.Value.y, def.Value.z, 1.0f);
}

namespace {

// 8x8 Minecraft-style face, drawn per-pixel; colors are hashed from the name
// so every entity gets a stable, recognizable avatar.
void DrawAvatarFace(ImDrawList* d, ImFont* font, const ImVec2& tilePos,
                    float tile, float a, const char* name,
                    const ImColor& accent) {
    unsigned hash = 2166136261u;
    for (const char* c = name; *c; ++c) { hash ^= (unsigned char)*c; hash *= 16777619u; }

    // palettes: skin / hair
    static const float skins[4][3] = {
        {0.96f, 0.80f, 0.66f}, {0.90f, 0.68f, 0.52f},
        {0.70f, 0.50f, 0.36f}, {0.55f, 0.38f, 0.27f}};
    static const float hairs[5][3] = {
        {0.28f, 0.17f, 0.10f}, {0.12f, 0.09f, 0.08f},
        {0.75f, 0.58f, 0.28f}, {0.62f, 0.32f, 0.16f},
        {0.45f, 0.45f, 0.48f}};
    const float* skin = skins[(hash >> 4) % 4];
    const float* hair = hairs[(hash >> 9) % 5];
    const float pupil[3] = {0.16f, 0.24f, 0.42f};
    const float white[3] = {0.95f, 0.95f, 0.95f};
    const float mouth[3] = {0.55f, 0.34f, 0.30f};

    const char rows[8][9] = {
        "HHHHHHHH",
        "HHHHHHHH",
        "HSSSSSSH",
        "HSSSSSSH",
        "SWPESSWP",
        "SSSSSSSS",
        "SSMMSSMS",
        "SSSSSSSS",
    };
    // note: row4 is "S W P E S S W P" mirrored eye pair (E=skin filler)

    const float px = tile / 8.0f;
    const ImU32 cH = ImGui::GetColorU32(ImVec4(hair[0], hair[1], hair[2], a));
    const ImU32 cS = ImGui::GetColorU32(ImVec4(skin[0], skin[1], skin[2], a));
    const ImU32 cW = ImGui::GetColorU32(ImVec4(white[0], white[1], white[2], a));
    const ImU32 cP = ImGui::GetColorU32(ImVec4(pupil[0], pupil[1], pupil[2], a));
    const ImU32 cM = ImGui::GetColorU32(ImVec4(mouth[0], mouth[1], mouth[2], a));

    for (int r = 0; r < 8; ++r) {
        for (int c = 0; c < 8; ++c) {
            char ch = rows[r][c];
            // mirror the eye columns so both eyes look symmetric
            if (r == 4) {
                if (c == 1 || c == 6) ch = 'W';
                else if (c == 2 || c == 5) ch = 'P';
                else ch = 'S';
            }
            if (r == 6) {
                if (c == 3 || c == 4) ch = 'M';
            }
            const ImU32 col = (ch == 'H') ? cH : (ch == 'W') ? cW
                            : (ch == 'P') ? cP : (ch == 'M') ? cM : cS;
            d->AddRectFilled(
                ImVec2(tilePos.x + c * px, tilePos.y + r * px),
                ImVec2(tilePos.x + (c + 1) * px, tilePos.y + (r + 1) * px),
                col);
        }
    }
    (void)font; (void)accent;
}

// ---- damage FX (particles + floating numbers over the hurt entity) --------
struct DmgFx {
    float         world[3];
    unsigned long ms;
    float         amount;
    unsigned      seed;
};
DmgFx         s_dmgFx[16];
int           s_dmgFxCount = 0;
unsigned long s_dmgLastMs = 0;
unsigned long s_dmgShakeMs = 0;

float DmgRand(int seed) {
    seed = seed ^ 61 ^ (seed >> 16);
    seed *= 9;
    seed ^= seed >> 4;
    seed *= 668265261;
    seed ^= seed >> 15;
    return (seed & 0xFFFFFF) / 16777215.0f;
}

// drain fresh damage events into the fx list; returns nothing, the shake
// timestamp lands in s_dmgShakeMs when the CURRENT target lost hp
void ConsumeDamageFx(unsigned long now, void* currentTarget) {
    const LONG head = overlay::g_damageHead;
    for (LONG i = head - overlay::kMaxDamageEvents; i < head; ++i) {
        if (i < 0) continue;
        const overlay::DamageEvent& ev =
            overlay::g_damageEvents[i % overlay::kMaxDamageEvents];
        if (ev.ms <= s_dmgLastMs || !ev.actor) continue;
        s_dmgLastMs = ev.ms;
        float pos[3], vel[3];
        if (!game::ActorReadStateVector(ev.actor, pos, vel)) continue;
        if (s_dmgFxCount >= 16) {
            memmove(s_dmgFx, s_dmgFx + 1, sizeof(DmgFx) * 15);
            s_dmgFxCount = 15;
        }
        DmgFx& fx = s_dmgFx[s_dmgFxCount++];
        fx.world[0] = pos[0];
        fx.world[1] = pos[1] + 1.2f;
        fx.world[2] = pos[2];
        fx.ms = ev.ms;
        fx.amount = ev.amount;
        fx.seed = (unsigned)(ev.ms ^ (uintptr_t)ev.actor);
        if (ev.actor == currentTarget) s_dmgShakeMs = ev.ms;
    }
}

void RenderDamageFx(unsigned long now, float s, const ImColor& accent,
                    ImFont* font) {
    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (!d) return;
    (void)accent;

    int n = 0;
    for (int i = 0; i < s_dmgFxCount; ++i)
        if (now - s_dmgFx[i].ms <= 950) s_dmgFx[n++] = s_dmgFx[i];
    s_dmgFxCount = n;

    for (int i = 0; i < s_dmgFxCount; ++i) {
        const DmgFx& fx = s_dmgFx[i];
        const float age = (float)(now - fx.ms);
        const float t = age / 950.0f;
        float sx, sy, depth;
        if (!overlay::ProjectWorldToScreen(fx.world, &sx, &sy, &depth)) continue;

        // particle burst during the first 500 ms
        if (age < 500.0f) {
            const float pt = age / 500.0f;
            const float ease = 1.0f - (1.0f - pt) * (1.0f - pt);
            for (int k = 0; k < 12; ++k) {
                const float h1 = DmgRand((int)fx.seed + k * 131);
                const float h2 = DmgRand((int)fx.seed + k * 977);
                const float h3 = DmgRand((int)fx.seed + k * 613);
                const float ang = h1 * 6.2831853f;
                const float dist = (10.0f + 34.0f * h2) * ease * (s * 0.5f + 0.6f);
                const float px = sx + cosf(ang) * dist;
                const float py = sy + sinf(ang) * dist * 0.7f + 26.0f * pt * pt * s;
                const ImColor col = gui::LerpColor(
                    ImColor(1.0f, 1.0f, 1.0f, 1.0f),
                    ImColor(1.0f, 0.30f, 0.25f, 1.0f), h3);
                d->AddCircleFilled(ImVec2(px, py),
                                   (1.1f + 1.4f * h2) * s,
                                   ImColor(col.Value.x, col.Value.y,
                                           col.Value.z, (1.0f - pt) * 0.9f),
                                   8);
            }
        }

        // floating damage number: rises, pops in, fades out
        const float riseT = gui::Clamp(age / 700.0f, 0.0f, 1.0f);
        const float rise = (1.0f - (1.0f - riseT) * (1.0f - riseT)) * 30.0f * s;
        const float numA = (1.0f - t) * (1.0f - t);
        const float tsNum = 11.5f * s
                            * (1.0f + 0.5f * (1.0f - gui::Clamp(age / 160.0f, 0.0f, 1.0f)));
        char num[16];
        sprintf_s(num, sizeof(num), "-%.1f", (double)fx.amount);
        const ImVec2 tsz = font->CalcTextSizeA(tsNum, FLT_MAX, 0, num);
        const ImVec2 np(sx - tsz.x * 0.5f, sy - tsz.y - 6.0f * s - rise);
        d->AddText(font, tsNum, ImVec2(np.x + 1.0f, np.y + 1.0f),
                   ImColor(0.0f, 0.0f, 0.0f, 0.7f * numA), num);
        d->AddText(font, tsNum, np,
                   ImColor(1.0f, 0.42f, 0.38f, numA), num);
    }
}

} // namespace

void TargetHud::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    if (!overlay::IsInWorld()) return;

    // camera upkeep (eye/matrix) + actor registry (baseTick hook)
    overlay::UpdateCritCamera();
    overlay::TryInstallBaseTickHook();

    const unsigned long now = GetTickCount();

    // ---- target selection: crosshair aim first, fresh attack second --------
    void* hover = overlay::GetCrosshairEntity();
    void* attacked = (void*)overlay::g_targetActor;
    const unsigned long hitMs = (unsigned long)overlay::g_targetTickMs;
    const bool freshAttack = attacked && (now - hitMs) <= 2000;
    void* target = hover ? hover : (freshAttack ? attacked : nullptr);

    static void* s_target = nullptr;
    static char s_name[64] = "";
    static float s_hp = -1.0f;        // shown (smoothed) health
    static float s_ghost = -1.0f;     // delayed "damage ghost" bar value
    static bool s_hpOk = false;
    static float s_alpha = 0.0f;
    static unsigned long s_hitAnimMs = 0;
    static unsigned long s_lastHitSeen = 0;
    static unsigned long s_appearMs = 0;

    if (target != s_target) {
        s_target = target;
        s_name[0] = 0;
        s_hp = -1.0f;
        s_ghost = -1.0f;
        s_hpOk = false;
        if (target) {
            game::ActorReadName(target, s_name, sizeof(s_name));
            s_appearMs = now;
        }
    }

    // hit animation trigger: a new hit landed on the CURRENT target
    if (hitMs != s_lastHitSeen) {
        if (attacked && attacked == s_target) s_hitAnimMs = now;
        s_lastHitSeen = hitMs;
        if (attacked && attacked != s_target && !hover) {
            // attacked a new entity without aiming: snap the target to it
            s_target = attacked;
            s_name[0] = 0;
            s_hp = -1.0f;
            s_ghost = -1.0f;
            s_hpOk = false;
            game::ActorReadName(s_target, s_name, sizeof(s_name));
            s_appearMs = now;
        }
    }

    const float dt = gui::Clamp(gui::GetDeltaTime(), 0.0f, 0.1f);
    const float targetAlpha = target ? 1.0f : 0.0f;
    s_alpha += (targetAlpha - s_alpha) * gui::Clamp(dt * 12.0f, 0.0f, 1.0f);

    ImDrawList* d = ImGui::GetBackgroundDrawList();
    ImFont* font = gui::CurrentFont();
    if (!d || !font) return;

    const ImColor accent = (m_useTheme && m_useTheme->mValue)
                               ? gui::GetThemedColor(0)
                               : m_color->getAsImColor();

    if (s_alpha < 0.015f && !target) {
        // even with the plate hidden, damage FX keep playing
        ConsumeDamageFx(now, nullptr);
        RenderDamageFx(now, m_scale->mValue * HudScale(), accent, font);
        return;
    }
    ConsumeDamageFx(now, s_target);

    // ---- data --------------------------------------------------------------
    if (s_target) {
        float hp = 0.0f;
        if (game::ActorReadHealth(s_target, &hp)) {
            if (!s_hpOk) { s_hp = hp; s_ghost = hp; }
            s_hp += (hp - s_hp) * gui::Clamp(dt * 10.0f, 0.0f, 1.0f);
            // the ghost bar lingers on the old value and decays slowly
            if (s_ghost < s_hp) s_ghost = s_hp;
            else s_ghost += (s_hp - s_ghost) * gui::Clamp(dt * 2.0f, 0.0f, 1.0f);
            s_hpOk = true;
        } else {
            s_hpOk = false;
        }
        if (!s_name[0])
            game::ActorReadName(s_target, s_name, sizeof(s_name));
    }

    // ---- animation envelopes ------------------------------------------------
    const float hitT = (now - s_hitAnimMs) / 300.0f;
    const float pulse = (hitT >= 0.0f && hitT < 1.0f)
                            ? 1.0f + 0.05f * sinf(hitT * 3.1415926f) * (1.0f - hitT)
                            : 1.0f;
    // appear pop: easeOutBack from 0.9 to 1 with a slight overshoot
    const float apT = (now - s_appearMs) / 350.0f;
    float pop = 1.0f;
    if (apT >= 0.0f && apT < 1.0f) {
        const float u = apT - 1.0f;
        const float c1 = 1.70158f, c3 = c1 + 1.0f;
        pop = 0.90f + 0.10f * (1.0f + c3 * u * u * u + c1 * u * u);
    }
    // ---- layout (Pulse plate style) ----------------------------------------
    const float s = m_scale->mValue * HudScale() * pulse * pop;
    // damage shake on the current target
    const float shakeT = (now - s_dmgShakeMs) / 350.0f;
    const float shakeX = (shakeT >= 0.0f && shakeT < 1.0f)
                             ? sinf(shakeT * 22.0f) * 2.6f * s * (1.0f - shakeT)
                             : 0.0f;
    const float a = s_alpha;
    const float W = 196.0f * s;
    const float H = 52.0f * s;
    const float rad = 7.0f * s;
    const float bgOp = m_opacity->mValue * a;

    ImVec2 p;
    if (m_position->mValue == 0) {
        // above the hotbar, slightly to the right of its center
        p = ImVec2(screen.x * 0.5f + 18.0f * s, screen.y - 100.0f * s - H);
    } else {
        p = Place(screen, ImVec2(0, 0), m_position->mValue - 1, HudPadding());
    }
    p.x += shakeX;
    // slide-up on appear
    p.y += (1.0f - a) * 8.0f * s;

    ImColor bgCol(9, 9, 13);
    bgCol.Value.w *= bgOp;
    gui::FillRect(ImVec4(p.x, p.y, p.x + W, p.y + H), bgCol, 1.0f, rad);
    // accent strip on the left edge
    gui::FillRect(ImVec4(p.x, p.y, p.x + 3.0f * s, p.y + H),
                  ImColor(accent.Value.x, accent.Value.y, accent.Value.z,
                          accent.Value.w * a),
                  1.0f, rad);
    if (m_outline && m_outline->mValue)
        d->AddRect(ImVec2(p.x + 0.7f, p.y + 0.7f),
                   ImVec2(p.x + W - 0.7f, p.y + H - 0.7f),
                   ImColor(accent.Value.x, accent.Value.y, accent.Value.z,
                           accent.Value.w * a),
                   rad - 0.7f, 0, 1.4f);

    // ---- avatar tile with a pixel face + accent ring ------------------------
    const float tile = H - 8.0f * s;
    const ImVec2 tp(p.x + 4.0f * s, p.y + 4.0f * s);
    ImColor headBg(30, 30, 38);
    headBg.Value.w *= bgOp;
    gui::FillRect(ImVec4(tp.x, tp.y, tp.x + tile, tp.y + tile), headBg, 1.0f,
                  6.0f * s);
    const float inset = 4.0f * s;
    DrawAvatarFace(d, font, ImVec2(tp.x + inset, tp.y + inset),
                   tile - inset * 2.0f, a, s_name[0] ? s_name : "?", accent);
    // ring: flashes white on hit, accent otherwise
    const float flash = (hitT >= 0.0f && hitT < 1.0f) ? (1.0f - hitT) : 0.0f;
    ImColor ring(gui::LerpColor(accent, ImColor(1.0f, 1.0f, 1.0f, 1.0f), flash));
    ring.Value.w *= a;
    d->AddRect(tp, ImVec2(tp.x + tile, tp.y + tile), ring, 6.0f * s, 0,
               1.4f * s + 1.2f * s * flash);

    // ---- name + hp value -----------------------------------------------------
    const float tx = tp.x + tile + 8.0f * s;
    const float textW = W - (tx - p.x) - 8.0f * s;
    const float tsName = 11.5f * s;
    const ImColor nameCol(0.95f, 0.96f, 0.96f, 1.0f);

    if (s_name[0]) {
        std::string shown(s_name);
        if (font->CalcTextSizeA(tsName, FLT_MAX, 0, shown.c_str()).x > textW) {
            const float dotsW = font->CalcTextSizeA(tsName, FLT_MAX, 0, "...").x;
            std::string acc;
            for (const char* c = s_name; *c; ++c) {
                acc.push_back(*c);
                if (font->CalcTextSizeA(tsName, FLT_MAX, 0, acc.c_str()).x + dotsW > textW) {
                    acc.pop_back();
                    break;
                }
            }
            shown = acc + "...";
        }
        d->AddText(font, tsName, ImVec2(tx, p.y + 5.0f * s),
                   ImColor(nameCol.Value.x, nameCol.Value.y, nameCol.Value.z, a),
                   shown.c_str());
    } else {
        d->AddText(font, tsName, ImVec2(tx, p.y + 5.0f * s),
                   ImColor(nameCol.Value.x, nameCol.Value.y, nameCol.Value.z,
                           0.5f * a),
                   "Entity");
    }

    // ---- HP caption row + bar with damage ghost -----------------------------
    const float barX = tx;
    const float barW = textW;
    const float barH = 5.0f * s;
    const float capY = p.y + 21.0f * s;
    const float barY = p.y + 32.0f * s;
    const float tsCap = 8.5f * s;

    // caption "HP" in accent + the numeric value on the right
    d->AddText(font, tsCap, ImVec2(barX, capY),
               ImColor(accent.Value.x, accent.Value.y, accent.Value.z,
                       0.9f * a),
               "HP");
    if (s_hpOk) {
        char valTxt[24];
        sprintf_s(valTxt, sizeof(valTxt), "%.1f / 20.0", (double)s_hp);
        const float vw = font->CalcTextSizeA(tsCap, FLT_MAX, 0, valTxt).x;
        d->AddText(font, tsCap, ImVec2(p.x + W - 8.0f * s - vw, capY),
                   ImColor(1.0f, 1.0f, 1.0f, 0.7f * a), valTxt);
    }

    ImColor track(255, 255, 255);
    track.Value.w = 0.10f * a;
    gui::FillRect(ImVec4(barX, barY, barX + barW, barY + barH), track, 1.0f,
                  barH * 0.5f);

    if (s_hpOk) {
        const float ratioG = gui::Clamp(s_ghost / 20.0f, 0.0f, 1.0f);
        ImColor ghost(1.0f, 1.0f, 1.0f);
        ghost.Value.w = 0.35f * a;
        gui::FillRect(ImVec4(barX, barY, barX + barW * ratioG, barY + barH),
                      ghost, 1.0f, barH * 0.5f);

        const float ratio = gui::Clamp(s_hp / 20.0f, 0.0f, 1.0f);
        ImColor fill;
        if (ratio >= 0.5f)
            fill = gui::LerpColor(ImColor(1.0f, 0.80f, 0.20f, 1.0f),
                                  ImColor(0.10f, 1.00f, 0.35f, 1.0f),
                                  (ratio - 0.5f) / 0.5f);
        else
            fill = gui::LerpColor(ImColor(1.0f, 0.15f, 0.15f, 1.0f),
                                  ImColor(1.0f, 0.80f, 0.20f, 1.0f),
                                  ratio / 0.5f);
        // white flash on hit
        if (hitT >= 0.0f && hitT < 1.0f)
            fill = gui::LerpColor(fill, ImColor(1.0f, 1.0f, 1.0f, 1.0f),
                                  (1.0f - hitT) * 0.7f);
        fill.Value.w = a;
        gui::FillRect(ImVec4(barX, barY, barX + barW * ratio, barY + barH),
                      fill, 1.0f, barH * 0.5f);
    }

    // ---- damage burst around the plate (current target lost hp) ------------
    const float dmgT = (now - s_dmgShakeMs) / 450.0f;
    if (dmgT >= 0.0f && dmgT < 1.0f) {
        const float ease = 1.0f - (1.0f - dmgT) * (1.0f - dmgT);
        const float ccx = p.x + W * 0.5f;
        const float ccy = p.y + H * 0.5f;
        for (int k = 0; k < 14; ++k) {
            const float h1 = DmgRand((int)s_dmgShakeMs + k * 173);
            const float h2 = DmgRand((int)s_dmgShakeMs + k * 541);
            const float ang = h1 * 6.2831853f;
            // start at the plate edge, fly outward
            const float edge = (W * 0.5f) * (0.9f + 0.25f * h2);
            const float dist = edge + 36.0f * s * ease;
            const float px = ccx + cosf(ang) * dist;
            const float py = ccy + sinf(ang) * dist * 0.85f;
            const ImColor col = gui::LerpColor(
                ImColor(1.0f, 1.0f, 1.0f, 1.0f),
                ImColor(1.0f, 0.30f, 0.25f, 1.0f), h2);
            d->AddCircleFilled(ImVec2(px, py), (1.0f + 1.6f * h2) * s,
                               ImColor(col.Value.x, col.Value.y, col.Value.z,
                                       (1.0f - dmgT) * 0.95f), 8);
        }
    }

    // ---- damage FX: particles + floating numbers over the hurt entity -------
    RenderDamageFx(now, s, accent, font);
}

// ======================== Hitboxes (entity ESP) =============================
Hitboxes::Hitboxes()
    : Module("Render", "Hitboxes", "Hitbox ESP for every entity") {
    // UTF-8: Режим / Периметр / Заполненный / Прозрачность / Толщина обводки
    m_mode = addSetting<EnumSetting>(
        "\xD0\xA0\xD0\xB5\xD0\xB6\xD0\xB8\xD0\xBC", "Hitbox render mode",
        0, std::vector<std::string>{
               "\xD0\x9F\xD0\xB5\xD1\x80\xD0\xB8\xD0\xBC\xD0\xB5\xD1\x82\xD1\x80",
               "\xD0\x97\xD0\xB0\xD0\xBF\xD0\xBE\xD0\xBB\xD0\xBD\xD0\xB5\xD0\xBD\xD0\xBD\xD1\x8B\xD0\xB9"});
    m_opacity = addSetting<NumberSetting>(
        "\xD0\x9F\xD1\x80\xD0\xBE\xD0\xB7\xD1\x80\xD0\xB0\xD1\x87\xD0\xBD\xD0\xBE\xD1\x81\xD1\x82\xD1\x8C",
        "Box transparency", 0.8f, 0.05f, 1.0f, 0.05f);
    m_thickness = addSetting<NumberSetting>(
        "\xD0\xA2\xD0\xBE\xD0\xBB\xD1\x89\xD0\xB8\xD0\xBD\xD0\xB0 \xD0\xBE\xD0\xB1\xD0\xB2\xD0\xBE\xD0\xB4\xD0\xBA\xD0\xB8",
        "Outline thickness, px (perimeter mode)", 1.5f, 1.0f, 4.0f, 0.5f);
    m_useTheme = addSetting<BoolSetting>(
        "Theme color", "Follow the interface theme accent.", true);
    const ImColor def = gui::GetThemedColor(0);
    m_color = addSetting<ColorSetting>(
        "Color", "Box color when Theme color is off.",
        def.Value.x, def.Value.y, def.Value.z, 1.0f);
}

void Hitboxes::on_render() {
    ImVec2 screen;
    if (!Screen(screen)) return;
    if (!overlay::IsInWorld()) return;

    // camera upkeep (view matrix) + the actor registry from the baseTick hook
    overlay::UpdateCritCamera();
    overlay::TryInstallBaseTickHook();

    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (!d) return;

    const ImColor accent = (m_useTheme && m_useTheme->mValue)
                               ? gui::GetThemedColor(0)
                               : m_color->getAsImColor();
    const bool filled = m_mode && m_mode->mValue == 1;
    const float alpha = gui::Clamp(m_opacity->mValue, 0.0f, 1.0f);
    if (alpha <= 0.0f) return;
    const float thickness = m_thickness ? m_thickness->mValue : 2.0f;

    // one shared color: fill and outline use the same RGB + Opacity alpha
    const ImU32 col = ImGui::GetColorU32(
        ImVec4(accent.Value.x, accent.Value.y, accent.Value.z, alpha));
    void* actors[128];
    const int count = overlay::GetActors(actors, 128);

    for (int i = 0; i < count; ++i) {
        float mins[3], maxs[3];
        if (!game::ActorReadAabb(actors[i], mins, maxs)) continue;

        // project all 8 corners; a box with any corner behind the camera is
        // skipped entirely (guide behavior - no exploded lines)
        ImVec2 pts[8];
        bool ok = true;
        for (int c = 0; c < 8; ++c) {
            const float p[3] = {
                (c & 1) ? maxs[0] : mins[0],
                (c & 2) ? maxs[1] : mins[1],
                (c & 4) ? maxs[2] : mins[2]};
            float sx, sy, depth;
            if (!overlay::ProjectWorldToScreen(p, &sx, &sy, &depth) ||
                depth < 0.3f) {
                ok = false;
                break;
            }
            pts[c] = ImVec2(sx, sy);
        }
        if (!ok) continue;

        // convex hull of the 8 projected corners (Andrew's monotone chain)
        ImVec2 hull[8];
        int hn = 0;
        {
            // sort by (x, y)
            for (int a2 = 1; a2 < 8; ++a2) {
                ImVec2 key = pts[a2];
                int b2 = a2 - 1;
                while (b2 >= 0 && (pts[b2].x > key.x ||
                                   (pts[b2].x == key.x && pts[b2].y > key.y))) {
                    pts[b2 + 1] = pts[b2];
                    --b2;
                }
                pts[b2 + 1] = key;
            }
            auto cross = [](const ImVec2& o, const ImVec2& p, const ImVec2& q) {
                return (p.x - o.x) * (q.y - o.y) - (p.y - o.y) * (q.x - o.x);
            };
            int k = 0;
            static ImVec2 lower[8], upper[8];
            for (int n2 = 0; n2 < 8; ++n2) {
                while (k >= 2 &&
                       cross(lower[k - 2], lower[k - 1], pts[n2]) <= 0.0f)
                    --k;
                lower[k++] = pts[n2];
            }
            const int lowerSize = k;
            k = 0;
            for (int n2 = 7; n2 >= 0; --n2) {
                while (k >= 2 &&
                       cross(upper[k - 2], upper[k - 1], pts[n2]) <= 0.0f)
                    --k;
                upper[k++] = pts[n2];
            }
            for (int n2 = 0; n2 < lowerSize - 1; ++n2) hull[hn++] = lower[n2];
            for (int n2 = 0; n2 < k - 1; ++n2) hull[hn++] = upper[n2];
        }
        if (hn < 3) continue;

        // bounds sanity: skip degenerate/offscreen monsters
        {
            float mnx = hull[0].x, mny = hull[0].y, mxx = hull[0].x,
                  mxy = hull[0].y;
            for (int v = 1; v < hn; ++v) {
                if (hull[v].x < mnx) mnx = hull[v].x;
                if (hull[v].x > mxx) mxx = hull[v].x;
                if (hull[v].y < mny) mny = hull[v].y;
                if (hull[v].y > mxy) mxy = hull[v].y;
            }
            if (mxx - mnx < 4.0f || mxy - mny < 4.0f) continue;
            if (mxx - mnx > screen.x || mxy - mny > screen.y) continue;
        }

        if (filled) {
            // the whole area under the perimeter, same color
            d->AddConvexPolyFilled(hull, hn, col);
            // crisp edge of the same color (fixed width: the Outline Width
            // setting applies to the outline mode only, per the spec)
            d->AddPolyline(hull, hn, col, ImDrawFlags_Closed, 1.0f);
        } else {
            d->AddPolyline(hull, hn, col, ImDrawFlags_Closed, thickness);
        }
    }
}
// Bursts are stamped by the GameMode::attack hook in overlay.cpp ONLY when
// the attacker is falling (a real crit) and the target has left its 500 ms
// damage-immunity window. Each burst carries the world-space hit point; the
// shapes below are generated around it in world coordinates and projected
// through the game's view matrix (overlay::ProjectWorldToScreen), so the
// effect sits on the entity, not at the crosshair.

namespace {

// Deterministic 0..1 hash in the spirit of SystemDLC's TargetEffect RNG.
float CritRand(int seed) {
    seed = seed ^ 61 ^ (seed >> 16);
    seed *= 9;
    seed ^= seed >> 4;
    seed *= 668265261;
    seed ^= seed >> 15;
    return (seed & 0xFFFFFF) / 16777215.0f;
}

// smooth 0..1 ramp used for easing everywhere below
float CritSmooth(float t) { return t * t * (3.0f - 2.0f * t); }

constexpr float kCritTau = 6.2831853f;
constexpr float kCritPi  = 3.1415926f;

} // namespace

CritParticles::CritParticles()
    : Module("Visual", "Crit Particles",
             "SystemDLC-style burst around the entity on a landed crit") {
    // UTF-8: РљРѕР»СЊС†Рѕ / РўСЂРµСѓРіРѕР»СЊРЅРёРє / РњРѕР»РЅРёРё / РЎРїРёСЂР°Р»СЊ / РћСЂР±РёС‚С‹
    m_mode = addSetting<EnumSetting>(
        "Effect", "Burst shape",
        0, std::vector<std::string>{
               "\xD0\x9A\xD0\xBE\xD0\xBB\xD1\x8C\xD1\x86\xD0\xBE",
               "\xD0\xA2\xD1\x80\xD0\xB5\xD1\x83\xD0\xB3\xD0\xBE\xD0\xBB\xD1\x8C\xD0\xBD\xD0\xB8\xD0\xBA",
               "\xD0\x9C\xD0\xBE\xD0\xBB\xD0\xBD\xD0\xB8\xD0\xB8",
               "\xD0\xA1\xD0\xBF\xD0\xB8\xD1\x80\xD0\xB0\xD0\xBB\xD1\x8C",
               "\xD0\x9E\xD1\x80\xD0\xB1\xD0\xB8\xD1\x82\xD1\x8B"});
    m_radius = addSetting<NumberSetting>(
        "Radius", "Shape radius, blocks", 1.0f, 0.4f, 2.5f, 0.05f);
    m_density = addSetting<NumberSetting>(
        "Density", "Point count", 48.0f, 12.0f, 120.0f, 2.0f);
    m_duration = addSetting<NumberSetting>(
        "Duration", "Burst lifetime", 900.0f, 300.0f, 2300.0f, 20.0f);
    m_speed = addSetting<NumberSetting>(
        "Speed", "Animation speed", 1.0f, 0.2f, 2.5f, 0.05f);
    m_size = addSetting<NumberSetting>(
        "Size", "Glow dot size, blocks", 0.055f, 0.02f, 0.15f, 0.005f);
    m_useTheme = addSetting<BoolSetting>(
        "Theme color", "Paint the burst in the accent theme color", true);
    m_color = addSetting<ColorSetting>(
        "Color", "Burst color when Theme color is off", 0xFFFFB45309ul);
}

void CritParticles::on_render() {
    // per-frame camera upkeep: eye history (crit checks) + view matrix cache
    overlay::UpdateCritCamera();

    const LONG tick = overlay::g_critBurstTick;
    if (!tick) return;

    const unsigned long now = GetTickCount();
    const unsigned long life = (unsigned long)m_duration->mValue;

    // gather the still-alive bursts (writers only fill ring slots)
    overlay::CritBurst live[overlay::kMaxCritBursts];
    int liveCount = 0;
    for (int i = 0; i < overlay::kMaxCritBursts; i++) {
        const overlay::CritBurst& b = overlay::g_critBursts[i];
        if (!b.startMs) continue;
        const long age = (long)(now - b.startMs);
        if (age < 0 || age > (long)life) continue;
        live[liveCount++] = b;
        if (liveCount >= overlay::kMaxCritBursts) break;
    }
    if (!liveCount) return;

    ImDrawList* d = ImGui::GetBackgroundDrawList();
    if (!d) return;

    ImColor base;
    if (m_useTheme && m_useTheme->mValue) {
        base = gui::GetThemedColor(0);
    } else if (m_color) {
        base = m_color->getAsImColor();
    } else {
        base = ImColor(255, 180, 60);
    }

    const int   mode    = m_mode ? m_mode->mValue : 0;
    const float radius  = m_radius->mValue;
    const int   density = (int)m_density->mValue;
    const float speed   = m_speed->mValue;
    const float dotW    = m_size->mValue;
    const float focal   = overlay::GetCritFocalPx();

    for (int bi = 0; bi < liveCount; bi++) {
        const overlay::CritBurst& b = live[bi];
        const float t = (float)(now - b.startMs) / (float)life;   // 0..1
        // envelope: quick in, slow out (SystemDLC's uProgress feel)
        const float env = CritSmooth(t < 0.12f ? t / 0.12f
                                     : t > 0.55f ? 1.0f - (t - 0.55f) / 0.45f
                                                 : 1.0f);
        const float spin = (float)(b.startMs % 100000) * 0.001f * speed;
        const int   seed = (int)b.seed;

        auto emitDot = [&](const float p[3], float alpha) {
            if (alpha <= 0.004f) return;
            float sx, sy, depth;
            if (!overlay::ProjectWorldToScreen(p, &sx, &sy, &depth)) return;
            const float pxR = dotW * focal / depth;
            if (pxR < 0.5f) return;
            ImColor glow(base.Value.x, base.Value.y, base.Value.z,
                         base.Value.w * 0.25f * alpha * env);
            ImColor core(base.Value.x, base.Value.y, base.Value.z,
                         base.Value.w * alpha * env);
            d->AddCircleFilled(ImVec2(sx, sy), pxR * 2.4f, glow, 10);
            d->AddCircleFilled(ImVec2(sx, sy), pxR, core, 10);
        };

        auto emitLine = [&](const float p0[3], const float p1[3], float alpha,
                            float pxWidth) {
            if (alpha <= 0.004f) return;
            float ax, ay, bx, by;
            if (!overlay::ProjectWorldToScreen(p0, &ax, &ay)) return;
            if (!overlay::ProjectWorldToScreen(p1, &bx, &by)) return;
            ImColor c(base.Value.x, base.Value.y, base.Value.z,
                      base.Value.w * alpha * env);
            d->AddLine(ImVec2(ax, ay), ImVec2(bx, by), c, pxWidth);
        };

        switch (mode) {
        case 0: {   // RING: spinning circle of dots with a fading tail
            const int n = density;
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < 3; k++) {
                    const float th = kCritTau * ((float)i / n + spin * 0.15f)
                                     - kCritTau * (float)k * 1.5f / n;
                    const float p[3] = {
                        b.pos[0] + cosf(th) * radius,
                        b.pos[1] + 0.02f * k,
                        b.pos[2] + sinf(th) * radius};
                    const float a = (k == 0) ? 1.0f : (0.5f - 0.22f * k);
                    emitDot(p, a);
                }
            }
            break;
        }
        case 1: {   // TRIANGLE: three spinning arcs with gaps
            const int n = (density / 3) * 3;
            if (n < 3) break;
            const int seg = n / 3;
            const int arcLen = seg * 7 / 10;
            for (int i = 0; i < n; i++) {
                const int arcPos = i % seg;
                if (arcPos >= arcLen) continue;   // the gap
                const float th = kCritTau * ((float)i / n + spin * 0.2f);
                const float p[3] = {
                    b.pos[0] + cosf(th) * radius,
                    b.pos[1],
                    b.pos[2] + sinf(th) * radius};
                const float a = 1.0f - 0.55f * ((float)arcPos / (float)arcLen);
                emitDot(p, a);
            }
            break;
        }
        case 2: {   // LIGHTNING: jagged bolts flashing outward
            const int bolts = 6;
            for (int bo = 0; bo < bolts; bo++) {
                const int k = seed + bo * 7717;
                const float th0 = CritRand(k) * kCritTau;
                const float dir = CritRand(k + 3) < 0.5f ? -1.0f : 1.0f;
                const float len = radius * (1.6f + CritRand(k + 7) * 2.0f);
                const float fadeB = 1.0f - t * t;
                float prev[3] = {b.pos[0], b.pos[1], b.pos[2]};
                for (int sgm = 1; sgm <= 14; sgm++) {
                    const float u = (float)sgm / 14.0f;
                    const float th = th0 + dir * len * 0.35f * u
                                     + (CritRand(k + sgm * 53) - 0.5f) * 0.32f;
                    const float rr = len * u;
                    const float p[3] = {
                        b.pos[0] + cosf(th) * rr,
                        b.pos[1] + (CritRand(k + sgm * 97) - 0.5f) * 0.3f * radius
                                   + rr * 0.18f,
                        b.pos[2] + sinf(th) * rr};
                    emitLine(prev, p,
                             fadeB * (1.0f - 0.7f * u)
                                 * (0.25f + 0.75f * sinf(kCritPi * u)),
                             2.0f);
                    if (sgm % 4 == 0) emitDot(p, fadeB * 0.8f * (1.0f - u));
                    prev[0] = p[0]; prev[1] = p[1]; prev[2] = p[2];
                }
            }
            break;
        }
        case 3: {   // SPIRAL: double helix rising around the target
            const int m = density;
            for (int strand = 0; strand < 2; strand++) {
                for (int j = 0; j < m; j++) {
                    const float s = (float)j / (float)(m - 1);
                    const float ph = spin * 1.1f * kCritTau
                                     + (float)strand * kCritPi
                                     + s * 2.2f * kCritTau
                                     + (strand ? -1.0f : 1.0f) * t * 2.0f;
                    const float rr = radius * (1.0f - 0.12f * s);
                    const float p[3] = {
                        b.pos[0] + cosf(ph) * rr,
                        b.pos[1] + s * radius * 1.2f - t * 0.2f,
                        b.pos[2] + sinf(ph) * rr};
                    const float a = (0.45f + 0.55f * sinf(kCritPi * s))
                                    * (1.0f - 0.5f * (float)strand * s);
                    emitDot(p, a);
                }
            }
            break;
        }
        default: {  // ORBITS: three tilted spinning rings
            for (int o = 0; o < 3; o++) {
                const float tilt = (float)o * kCritPi / 3.0f
                                   + CritRand(seed + 41 + o) * 0.3f;
                const float w = radius * (1.0f + CritRand(seed + 51 + o) * 0.22f);
                const int n = density;
                float prev[3] = {};
                for (int j = 0; j <= n; j++) {
                    const float u = kCritTau * (float)j / (float)n
                                    + spin * kCritTau * (0.35f + 0.12f * o);
                    // circle in the XZ plane, tilted around X, spun around Y
                    const float cxp = cosf(u) * w;
                    const float cyp = sinf(u) * w * sinf(tilt);
                    const float czp = sinf(u) * w * cosf(tilt);
                    const float ry = spin * (0.6f + 0.17f * (float)o) * kCritTau;
                    const float p[3] = {
                        b.pos[0] + cxp * cosf(ry) + czp * sinf(ry),
                        b.pos[1] + cyp,
                        b.pos[2] - cxp * sinf(ry) + czp * cosf(ry)};
                    emitDot(p, 0.35f + 0.65f * (1.0f - (float)o / 3.0f));
                    if (j > 0 && j % 6 == 0)
                        emitLine(prev, p, 0.22f - 0.06f * o, 1.5f);
                    prev[0] = p[0]; prev[1] = p[1]; prev[2] = p[2];
                }
            }
            break;
        }
        }
    }
}
} // namespace modules
