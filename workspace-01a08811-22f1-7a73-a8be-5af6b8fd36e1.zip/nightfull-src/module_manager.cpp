// module_manager.cpp - module manager implementation.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/module_manager.h"

namespace modules {

ModuleManager& ModuleManager::instance() {
    static ModuleManager mgr;
    return mgr;
}

void ModuleManager::add(std::unique_ptr<Module> m) {
    if (m)
        m_modules.push_back(std::move(m));
}

bool ModuleManager::toggle(const char* name) {
    if (!name)
        return false;
    for (auto& m : m_modules) {
        if (strcmp(m->name(), name) == 0) {
            m->toggle();
            return true;
        }
    }
    return false;
}

} // namespace modules