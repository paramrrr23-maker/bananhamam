// game_modules.h - target-compatible gameplay modules.
//
// These modules intentionally keep their UI/state in the normal Module
// system. Game-facing work is performed by the already-existing input and
// render hooks in overlay.cpp; the reference repositories are not included
// in the target build.

#pragma once

#include <vector>

#include "core/module.h"

namespace nf {

class AutoSprintModule final : public Module {
public:
    AutoSprintModule();

    void onEnable() override;
    void onDisable() override;

    BoolSetting* m_alwaysSprint = nullptr;
};

class FullBrightModule final : public Module {
public:
    FullBrightModule();

    void onEnable() override;
    void onDisable() override;
    void onRender() override;

    float currentGamma() const { return m_currentGamma; }

    NumberSetting* m_gamma = nullptr;

private:
    float m_currentGamma = 1.0f;
};

class NoHurtCamModule final : public Module {
public:
    NoHurtCamModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;
};

// Flarial HueChanger parity (display name "Saturation"): the overlay applies
// a D2D-equivalent saturation filter to the game frame before the HUD draws.
class SaturationModule final : public Module {
public:
    SaturationModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

    NumberSetting* m_intensity = nullptr;
};

// Motion Blur: frame-accumulation blur on the GAME frame (before the ImGui
// overlay, so the Nightfull HUD/ClickGUI stays sharp). Blend = exponential
// trail (Flarial-style accumulation), Ghost = mix with the previous frame only.
class MotionBlurModule final : public Module {
public:
    MotionBlurModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    void push();

    EnumSetting* m_mode = nullptr;
    NumberSetting* m_intensity = nullptr;
    BoolSetting* m_fpsIndependent = nullptr;
    NumberSetting* m_refFps = nullptr;
    BoolSetting* m_onlyInWorld = nullptr;
    BoolSetting* m_pauseInMenu = nullptr;
};

class WorldParticlesModule final : public Module {
public:
    WorldParticlesModule();
    void onEnable() override;
    void onDisable() override;
    void onTick() override;
    void onRender() override;

private:
    struct Particle { float p[3]{}; float v[3]{}; float age = 0.0f; unsigned int seed = 0; };
    void resetParticle(Particle& p, const float camera[3], unsigned int index);
    std::vector<Particle> m_particles;
    std::vector<unsigned char> m_visible;
    unsigned long long m_nextVisibilityCheck = 0;
    NumberSetting* m_count = nullptr;
    NumberSetting* m_radius = nullptr;
    NumberSetting* m_size = nullptr;
    NumberSetting* m_speed = nullptr;
    NumberSetting* m_gravity = nullptr;
    EnumSetting* m_shape = nullptr;
    ColorSetting* m_color = nullptr;
};

class HitboxesModule final : public Module {
public:
    HitboxesModule();

    void onEnable() override;
    void onDisable() override;
    void onRender() override;

private:
    // Flarial-parity base controls (see Hitbox::defaultConfig/settingsRender).
    // Eye line / look line / show-self were removed per user request: the
    // module draws only the plain hitbox wireframe, never the local player.
    NumberSetting* m_maxDistance = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_staticThickness = nullptr;
    BoolSetting* m_2dMode = nullptr;
    ColorSetting* m_boxColor = nullptr;
    NumberSetting* m_boxOpacity = nullptr;
    BoolSetting* m_useTheme = nullptr;    // follow the GUI theme accent
    // SystemDLC PlayerESP parity: targets, shape, outline, fill, box glow
    // (soft blurred halo around the lines), gradient glow colors and the
    // silhouette "Glow" render mode with its wavy animated outline.
    EnumSetting* m_targets = nullptr;       // Players / Mobs / All
    BoolSetting* m_scaleDistance = nullptr; // thicken lines with distance
    BoolSetting* m_throughWalls = nullptr;  // false = occlusion (default)
    BoolSetting* m_outline = nullptr;       // dark stroke under the lines
    ColorSetting* m_outlineColor = nullptr;
    BoolSetting* m_fill = nullptr;          // fill the box faces/silhouette
    ColorSetting* m_fillColor = nullptr;
    BoolSetting* m_boxGlow = nullptr;       // soft halo around the lines
    NumberSetting* m_glowRadius = nullptr;
    NumberSetting* m_glowBrightness = nullptr;
    ColorSetting* m_glowColor = nullptr;
    BoolSetting* m_gradient = nullptr;      // glow color oscillation
    ColorSetting* m_secondColor = nullptr;
    NumberSetting* m_gradientSpeed = nullptr;
    EnumSetting* m_mode = nullptr;          // Box / Glow
    ColorSetting* m_silhouetteColor = nullptr;
    NumberSetting* m_auraRadius = nullptr;
    NumberSetting* m_auraBrightness = nullptr;
    BoolSetting* m_animation = nullptr;     // wavy aura outline
    NumberSetting* m_animStrength = nullptr;
    NumberSetting* m_animSize = nullptr;
    // Cull hysteresis: actors visible last frame survive until maxDistance +
    // the band below, so a mob pacing on the cull line does not blink.
    std::vector<void*> m_visible;
};

class TargetEspModule final : public Module {
public:
    TargetEspModule();
    void onEnable() override;
    void onDisable() override;
    void onRender() override;

private:
    EnumSetting* m_effect = nullptr;
    ColorSetting* m_color = nullptr;
    NumberSetting* m_speed = nullptr;
    NumberSetting* m_duration = nullptr;
    NumberSetting* m_fatness = nullptr;
    NumberSetting* m_radius = nullptr;
    NumberSetting* m_density = nullptr;
    NumberSetting* m_tail = nullptr;
    NumberSetting* m_brightness = nullptr;
    NumberSetting* m_crystalsCount = nullptr;   // Crystals: shard count
    NumberSetting* m_crystalsSize = nullptr;    // Crystals: shard size
    NumberSetting* m_crystalsSpin = nullptr;    // Crystals: orbit speed
    BoolSetting* m_crystalsFill = nullptr;      // Crystals: filled faces
    float m_alpha = 0.0f;      // fade state (SystemDLC 0.15 up / 0.25 down)
    void* m_lastActor = nullptr;
};

class JavaInventoryHotkeysModule final : public Module {
public:
    JavaInventoryHotkeysModule();

    void onEnable() override;
    void onDisable() override;
};

class VSyncDisablerModule final : public Module {
public:
    VSyncDisablerModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    BoolSetting* m_recreate = nullptr;   // r25: one-shot recreate (Flarial)
};

class NullMovementModule final : public Module {
public:
    NullMovementModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    BoolSetting* m_adPair = nullptr;
    BoolSetting* m_wsPair = nullptr;
};

class CpsLimiterModule final : public Module {
public:
    CpsLimiterModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    NumberSetting* m_left = nullptr;
    NumberSetting* m_right = nullptr;
};

class GuiScaleModule final : public Module {
public:
    GuiScaleModule();

    float targetScale() const;

    NumberSetting* m_scale = nullptr;
};

// ---------------------------------------------------------------------------
// r22 feature modules (inspired by the NewLight / Flarial sources, rebuilt on
// Nightfull's own overlay bridges - nothing here touches game memory directly).
// ---------------------------------------------------------------------------

class ViewModelModule final : public Module {
public:
    ViewModelModule();
    void onEnable() override;

public:
    NumberSetting* m_posX = nullptr;
    NumberSetting* m_posY = nullptr;
    NumberSetting* m_posZ = nullptr;
    NumberSetting* m_rotX = nullptr;
    NumberSetting* m_rotY = nullptr;
    NumberSetting* m_rotZ = nullptr;
    NumberSetting* m_scaleX = nullptr;
    NumberSetting* m_scaleY = nullptr;
    NumberSetting* m_scaleZ = nullptr;
};

class ItemPhysicsModule final : public Module {
public:
    ItemPhysicsModule();
    void onEnable() override;

public:
    NumberSetting* m_speed = nullptr;
    NumberSetting* m_yOffset = nullptr;
    BoolSetting* m_preserve = nullptr;
    BoolSetting* m_smooth = nullptr;
};

class JumpCirclesModule final : public Module {
public:
    JumpCirclesModule();
    void onRender() override;
    void onDisable() override;

    struct Circle {
        float x = 0.0f, y = 0.0f, z = 0.0f;
        unsigned long long at = 0;
    };

public:
    EnumSetting* m_trigger = nullptr;
    NumberSetting* m_radius = nullptr;
    NumberSetting* m_life = nullptr;
    NumberSetting* m_rings = nullptr;
    NumberSetting* m_thickness = nullptr;
    ColorSetting* m_color = nullptr;
    std::vector<Circle> m_circles;
};

class FreelookModule final : public Module {
public:
    FreelookModule();
    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    EnumSetting* m_mode = nullptr;
    unsigned long long m_lastAttempt = 0;
};

class GlintModule final : public Module {
public:
    GlintModule();

public:
    ColorSetting* m_color = nullptr;
    BoolSetting* m_onlyLocal = nullptr;
};

// ---- r22 render-hook consumers (called from overlay.cpp detours) ----------
// Cheap probes: overlay.cpp checks these before it pays for any matrix work.
bool ViewModelActive();
bool ItemPhysicsActive();
bool JumpCirclesEnabled();
int  JumpCirclesTrigger();            // 0 = land, 1 = jump, 2 = both
// Viewmodel: apply the configured offset/rotation/scale to the CURRENT world
// matrix top (the caller restores it after the original render returns).
void ViewModelApplyLocalMatrix();
// ItemPhysics: adjust the current world-matrix top for one dropped item.
struct ItemPhysicsInput {
    float relX = 0.0f, relY = 0.0f, relZ = 0.0f;  // render pos vs camera origin
    bool onGround = false;
    bool isBlock = false;
    long long rid = 0;
};
void ItemPhysicsApplyItemMatrix(const ItemPhysicsInput& in);
// Glint: current color + activity for the shader-params detour.
void GlintColorNow(float out[4], bool* active, bool isLocal);

// ---------------------------------------------------------------------------
// r23: Clear Chat / Clear Scoreboard. Both strip ONLY the background layer of
// the vanilla chat / scoreboard UI (via the overlay's UI-tree pass); messages,
// entries and updates stay vanilla. The getters below are how the overlay
// knows when its per-frame pass has to run.
// ---------------------------------------------------------------------------

class ClearChatModule final : public Module {
public:
    ClearChatModule();
};

class ClearScoreboardModule final : public Module {
public:
    ClearScoreboardModule();
};

bool ClearChatEnabled();
bool ClearScoreboardEnabled();
bool ArmorHudEnabled();

} // namespace nf
