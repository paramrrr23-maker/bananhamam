// module_guard.cpp - guarded execution of module callbacks.
//
// See module_guard.h for why this exists.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/module_guard.h"

#include "modules/module.h"
#include "overlay.h"
#include "utils/logger.h"

namespace modules {

const char* ModulePhaseGuard::phaseName(Phase phase) {
    switch (phase) {
        case ENABLE:   return "on_enable";
        case DISABLE:  return "on_disable";
        case TICK:     return "on_tick";
        case RENDER:   return "on_render";
        case SETTINGS: return "render_settings";
    }
    return "?";
}

// NOTE: only POD locals here - MSVC forbids __try in a frame that needs C++
// object unwinding (error C2712).
void ModulePhaseGuard::run(Module* m, Phase phase) {
    if (!m) return;

    overlay::g_activeModuleName = m->name();
    overlay::g_activePhase      = phaseName(phase);

    LARGE_INTEGER t0; t0.QuadPart = 0;
    LARGE_INTEGER t1; t1.QuadPart = 0;
    LARGE_INTEGER fr; fr.QuadPart = 0;
    QueryPerformanceCounter(&t0);

    int faulted = 0;
#ifdef _MSC_VER
    __try {
#endif
        switch (phase) {
            case ENABLE:   m->on_enable();       break;
            case DISABLE:  m->on_disable();      break;
            case TICK:     m->on_tick();         break;
            case RENDER:   m->on_render();       break;
            case SETTINGS: m->render_settings(); break;
            default: break;
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        faulted = 1;
    }
#endif

    QueryPerformanceCounter(&t1);
    QueryPerformanceFrequency(&fr);
    const double ms = (fr.QuadPart != 0)
        ? (double)(t1.QuadPart - t0.QuadPart) * 1000.0 / (double)fr.QuadPart
        : 0.0;

    if (faulted) {
        LOG_ERROR("module '%s' raised an exception in %s - DISABLING it "
                  "(frame continues, game stays alive)",
                  m->name(), phaseName(phase));
        m->set_enabled(false);
    } else if (ms > 100.0) {
        LOG_ERROR("module '%s' blocked the render thread for %.1f ms in %s - "
                  "DISABLING it (a module must never block)",
                  m->name(), ms, phaseName(phase));
        m->set_enabled(false);
    } else if (ms > 5.0) {
        LOG_ERROR("module '%s' took %.1f ms in %s (render-thread budget ~5 ms)",
                  m->name(), ms, phaseName(phase));
    }

    overlay::g_activeModuleName = nullptr;
    overlay::g_activePhase      = nullptr;
}

} // namespace modules
