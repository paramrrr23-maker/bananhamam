# NIGHTFULL — FULL SOURCE CODE ANALYSIS REPORT

- **Repo analyzed:** `paramrrr23-maker/hamambanan`, shallow clone at `/home/user/nightfull-src` (55 files, flat layout, no subdirectories, no build files)
- **Analysis mode:** strictly read-only. No source file was created, modified, renamed, moved, or deleted inside `nightfull-src/`.
- **Coverage:** every non-vendored project file was read in full, except `overlay.cpp` (5545 lines — read strategically: all hook sites, init/shutdown, frame path, input, game readers, signature tables; some long helper bodies skimmed via targeted reads) and stock vendored ImGui (not analyzed — third-party).
- **Legend:** `[R]` = verified by reading the code; `[U]` = unconfirmed (file/symbol absent from the repo or body not read — stated explicitly per the no-assumptions rule).

---

## 1. Project Overview

Nightfull is a **Minecraft Bedrock (primary target 1.21.111) in-process overlay client DLL**: it injects into the game process, hooks the DXGI `Present`/`ResizeBuffers` vtable, renders an ImGui overlay (menu + HUD) on top of the game frame, and integrates with the game through ~20 detours installed with MinHook plus signature scanning.

Architecturally it is a **composite of named ports**, each module/GUI file header states its origin:

| Origin project | What was ported |
|---|---|
| Solstice | `Keyboard::feed` input detour idea, `ModernGui` panel engine (dead), ClickGui menu frame (easing/scrim/autosave), `Interface` theme module, gamma FullBright, `EasingUtil`, `nes`-style concepts (but **no** event bus was ported) |
| Flarial | HUD widgets (FPS/CPS/Keystrokes/Crosshair/MouseStrokes/Direction/Clock/Memory), `GuiScale` engine (`GuiData+0x5C` write + UI-tree relayout), `Animations` (hotbar lerp via `TextureGroup::getTexture` + `MUIRC::drawImage` hooks), Reach counter via `GameMode::attack`, `Actor::baseTick` vtable slot 25, `createPacket`/`TextPacket` chat send, `UIControl::getPosition` walk, Flarial settings (HUD scale/padding/font/shadows) |
| Packet V2 / Packet-Source | Shared HUD color engine (`packethud`: rainbow wheel, dynamic gray wave, static palette, UI-unit coordinate system), `Arraylist` V3 style, `Freelook` camera update logic, mouse-feed dispatcher concept |
| SystemDLC (CollapseLoader) | `CitronGui` — the **active** menu (1188×700 design window, sidebar, 3-column masonry cards, search modal, friends page, config page), `TargetHud` plate, `CritParticles` burst aesthetics |
| Pulse (videos) | Watermark pill, Potions/Keybinds/Monitoring plate design language |

**Headline finding #1 — the repo does not compile as-is.** All project `#include`s use subdirectory paths (`modules/...`, `modules/visual/...`, `modules/misc/...`, `modules/movement/...`, `modules/player/...`, `modules/settings/...`, `ui/...`, `utils/...`, `game/...`), but the repo is a **flat dump**: all files sit in the root, and **~16 referenced headers/source files are absent entirely** (all of `utils/`, most module implementation files). There is no `.sln`, `.vcxproj`, or `CMakeLists.txt`, no MinHook source/headers, and no injector source. `nightfull.rar` is a 1-byte placeholder.

**Headline finding #2 — comments say "demo only", code says full game integration.** Many headers claim modules "never touch the game" (`module.h`, `visual_modules.h`, `flarial_visual_modules.h`, `clickgui.cpp`, `nightfull_modules.h`). The actual code installs detours on `GameMode::attack`, `Actor::baseTick`, `Keyboard::feed`, `MouseDevice::feed`, `RakPeer::GetAveragePing`, `GuiData`, gamma, camera, `MUIRC::drawImage`, `TextureGroup::getTexture`, `ScreenView::setupAndRender`, container UI, reads MobEffects via entt, sends `TextPacket` chat, writes `GuiData` GUI scale, and scrapes the server IP from the RakNet connector. The comments are outdated/aspirational; the `.cpp` bodies are authoritative.

---

## 2. Project Structure

### 2.1 File inventory (55 files, all in repo root)

| Group | Files | Lines (approx) |
|---|---|---|
| Entry | `dllmain.cpp` | 30 |
| Precompiled-style header | `pch.h` | 40 |
| Overlay engine | `overlay.h` (180), `overlay.cpp` (**5545**) | 5725 |
| Module core | `module.h` (115), `module_manager.h/.cpp` (33/31), `module_registry.h/.cpp` (13/91), `module_guard.h/.cpp` (43/83), `setting.h` (177) | 586 |
| Menu shell | `clickgui.h` (33), `clickgui.cpp` (391) | 424 |
| GUI engines | `modern_gui.h/.cpp` (113/966, **dead**), `citron_gui.h/.cpp` (126/2163, **active**) | 3368 |
| Modules (present) | `visual_modules.h/.cpp` (136/391), `flarial_visual_modules.h/.cpp` (273/1709), `interface_module.h/.cpp`, `clickgui_module.h/.cpp`, `nightfull_modules.h/.cpp`, `packet_hud.h/.cpp` (60/154) | ~2900 |
| Game-access helper | `bedrock_entt.hpp` | ~120 [R, size approx] |
| Vendored ImGui 1.91.8 + backends | `imgui*.h/.cpp`, `imgui_impl_dx11/dx12/win32`, `imstb_*`, `imconfig.h` | stock, not analyzed |
| Fonts | 7× `.ttf` (Inter / Poppins / JetBrainsMono / InstrumentSerif / Lucide variants) | binary |
| Placeholder | `nightfull.rar` (1 byte) | — |

### 2.2 Layout mismatch (why it cannot build)

Every project include uses a rooted path, e.g. `#include "modules/visual/visual_modules.h"`, `#include "ui/citron_gui.h"`, `#include "utils/logger.h"`, `#include "game/bedrock_entt.hpp"`. The repo has **zero subdirectories**, so even the files that *are* present do not resolve at their referenced paths. Two distinct failure classes:

- **(a) Path-only mismatch** — file exists in root but the include expects a subdir (`modules/module.h`, `ui/*`, `game/bedrock_entt.hpp`, …). Fixable by restoring folders [U: exact original tree is unconfirmed].
- **(b) Genuinely absent** — no file with that basename anywhere (see §27).

### 2.3 Text/encoding notes [R]

- `visual_modules.cpp`, `flarial_visual_modules.cpp` use CRLF; most other files use LF.
- Project rule "ASCII only in code files" is violated by raw Cyrillic in `flarial_visual_modules.h` comments (Hitboxes/CritParticles mode names in Russian). User-visible Russian strings in `Hitboxes`/`CritParticles` constructors are `\x`-escaped UTF-8 bytes (still ASCII bytes — compliant technique).

---

## 3. Entry Point

**File:** `dllmain.cpp` [R, full read].

```text
DLL_PROCESS_ATTACH → DisableThreadLibraryCalls → CreateThread(AttachThread) → overlay::MainThread(hModule)
DLL_PROCESS_DETACH → overlay::NotifyDetach()
```

- No D3D/ImGui/hook work happens on the loader lock: `DllMain` only spawns a thread (attach) or requests teardown (detach).
- `overlay::MainThread` is a thin SEH wrapper (`__try/__except`, MSVC only) around `MainThreadImpl` — split exists because MSVC error C2712 forbids `__try` in functions with C++ destructors [R, overlay.cpp:5417-5545].

---

## 4. Initialization

**Full startup sequence** (`MainThreadImpl`, overlay.cpp:5420+) [R]:

```text
1.  LOG_INFO("MainThread started, pid=..")
2.  InitializeCriticalSection(&g_RenderCs)            // guards D3D12 recording + ImGui + resize teardown
3.  CreateThread(OverlayWatchdogThread)               // publishes menuOpen/heartbeat; frees ext. input masks if render stalls
4.  LogGameVersion()                                  // ProductVersion of game exe → log (for picking Keyboard::feed sig)
5.  TryInstallPingHook()                              // EARLY: RakPeer ping needed during server browse/connect
6.  spin until GetModuleHandleA("d3d11.dll")
7.  spin until CollectGameWindows() non-empty         // game must own a visible window first (else early DXGI work crashes it)
8.  CreateFallbackWindow() + TryCreateDummySwapChain(hwnd)  // dummy D3D11 device to steal the DXGI vtable
9.  HookVTable(vtable, PRESENT_INDEX, hkPresent)      // direct vtable patch (NOT MinHook)
    HookVTable(vtable, RESIZEBUFFERS_INDEX, hkResizeBuffers)
10. Release dummy objects; LOG_INFO("MainThread done")
11. CreateThread(WatchdogThread)                      // Present watchdog: if hkPresent never fires, RehookPresentOnce()
```

**Lazy second-stage init inside `hkPresent`** (first frames) [R, 4378-4548]:

```text
hkPresent:
  liveness stamp (g_lastFrameMs, frameTick) FIRST
  if (!g_Init):
     try D3D11: GetDevice → immediate ctx → CreateRT11 → ImGui::CreateContext
               → ui::ApplyStyle() → modules::RegisterAllModules()
               → capture game HWND from swapchain desc → ImGui_ImplWin32/DX11_Init
     else D3D12: InitD3D12(sc) over the game's own queue (queue captured by hkExecCmdLists,
                installed lazily — creating a D3D12 device during game startup crashes it)
  if (g_Init) per-frame:
     TryInstallKeyboardHook/MouseHook/GuiDataHook/ScreenSizeHook/GammaHook/
       PerspectiveHook/FreelookCameraHook/FlarialHooks/PingHook   // each self-guards (tried-once flags)
     ApplyGameGuiScale()      // Flarial scale enforcement
     TryInstallRawInputBlock()// user32 GetRawInputData/Data detour (version-independent)
     UpdateHotkeys()          // external watcher counters + CPS publisher + cursor
     render under g_RenderCs (D3D11: NewFrame→UpdateInputState→ImGui::NewFrame→ui::Render→Render→DX11_RenderDrawData;
                              D3D12: RenderD3D12Frame(sc))
     if (g_UnloadRequested) FinishUnload()
  VSync override → oPresent(sc, disableVsync ? 0 : sync, flags)
```

Notable: `RegisterAllModules()` runs on the **game's render thread** inside `hkPresent`, not on the attach thread. Config load happens even later — first `ui::Render()` frame (`config::Load()` once, guarded by `g_stateLoaded`) [R].

---

## 5. Core Architecture

Layer diagram (bottom = closest to OS/game):

```text
┌─────────────────────────────────────────────────────────────┐
│ injector.exe --watch child (EXTERNAL, source ABSENT)         │ desktop process: WH_KEYBOARD_LL/WH_MOUSE_LL masks,
│ writes g_ext_key_flags via WriteProcessMemory               │ K/INSERT/ESC/END counters, CPS-limiter enforcement
├─────────────────────────────────────────────────────────────┤
│ overlay engine (overlay.h/.cpp)                             │ Present/Resize/CMD-queue hooks, MinHook detours,
│  + bedrock_entt.hpp + game:: readers (utils/entity_         │ sig scanner, input fusion, W2S, game-data readers,
│     registry.h — ABSENT) + file_utils (ABSENT)              │ D3D11/D3D12 backends, unload/teardown, watchdog threads
├─────────────────────────────────────────────────────────────┤
│ ui shell (clickgui.h/.cpp)                                  │ per-frame: keys snapshot, config load/save,
│                                                             │ theme push, keybind dispatch, module TICK+RENDER,
│                                                             │ menu easing, scrim, Citron render               │
├─────────────────────────────────────────────────────────────┤
│ GUI engines: CitronGui (ACTIVE) │ ModernGui (DEAD)          │ immediate-mode custom widgets on ImGui draw lists
├─────────────────────────────────────────────────────────────┤
│ modules + settings (Module/ModuleManager/ModulePhaseGuard)  │ Watermark/Arraylist/HUD plates/ESP/menu config…
├─────────────────────────────────────────────────────────────┤
│ missing utils/: logger keys config easing fonts             │ LOG_*, key snapshot, JSON persistence, EasingUtil,
│   gui_render gui_theme math build_info                      │ draw helpers, theme engine, fonts (ALL ABSENT —
│                                                             │ only call-sites visible)                        │
└─────────────────────────────────────────────────────────────┘
```

Design rules visible in code: no I/O per frame on the render thread (except the once-per-boot config load and debounced save); bounded work per frame; SEH around every game-touching call; hooks degrade to null gracefully (pointers stay null when a signature misses, features turn off instead of crashing).

---

## 6. Module System

**Core classes** (`module.h`, `module_manager.h/.cpp`, `module_registry.h/.cpp`, `module_guard.h/.cpp`) [R]:

- `modules::Module` — base: identity (`category/name/description`), state (`enabled/key`), `addSetting<T>/removeSetting/findSetting`, `settings()`, menu animation fields (`cAnim/cScale/showSettings`), virtuals `on_enable/on_disable/on_tick/on_render/on_key_trigger/render_settings`. Constructor takes `(category, name, description)`.
- `modules::ModuleManager` — singleton (`Modules()`), owns `vector<unique_ptr<Module>>`, `add()`, `toggle(name)`.
- `modules::RegisterAllModules()` — builds the roster; **push order = menu display order** and Arraylist/Keybinds-HUD enumeration order.
- `modules::ModulePhaseGuard::run(m, Phase)` — wraps **every** module callback: SEH + QPC timing (>5 ms logs, >100 ms or fault → auto-disable) + watchdog markers (`g_activeModuleName/Phase`) [R, pre-compaction read of guard + confirmed call-sites in clickgui/citron/modern].
- `modules::NightfullModule` — trivial subclass; `CreateNightfullModules()` **returns an empty vector** (factory reserved for future use; real roster lives in `module_registry.cpp`) [R].

**Registered roster (28, in registry order)** [R]:

| # | Module | Category [R where seen] | Declared in | Status |
|---|---|---|---|---|
| 1 | Watermark | Render | visual_modules.h | full impl, default ON |
| 2 | Arraylist | Render | visual_modules.h | full impl, default ON |
| 3 | FPS (FlarialFPS) | Render | flarial_visual_modules.h | full impl, default ON |
| 4 | CPS (FlarialCPS) | Render | flarial_visual_modules.h | full impl, default ON |
| 5 | Mouse Strokes | Render | flarial_visual_modules.h | full impl |
| 6 | CPS Limiter | Misc | flarial_visual_modules.h | settings only; enforced by **external watcher** via shared block |
| 7 | FullBright | Visual | visual_modules.h | gamma lerp consumed by `hkGamma` (overlay.cpp:1123) |
| 8 | GUI Scale | Visual | visual_modules.h | settings only; consumed by `ApplyGameGuiScale` (writes `GuiData+0x5C`) |
| 9 | VSync Disabler | Render | visual_modules.h | empty class; consumed in `hkPresent` tail (sync→0) |
| 10 | Sprint | ? [U] | **MISSING** `modules/movement/movement_modules.h` | NO implementation in repo |
| 11 | NullMovement | ? [U] | **MISSING** (same) | NO implementation in repo |
| 12 | Freelook | Visual | visual_modules.h | flags consumed by `hkUpdateFromCamera` |
| 13 | FriendsModule | ? [U] | **MISSING** `modules/misc/friends_module.h` | referenced by clickgui+citron (`instance/friends/addFriend/removeFriend/showToast`); NO impl in repo |
| 14 | MidClickModule | ? [U] | **MISSING** (same/friends header) | referenced by citron; NO impl in repo |
| 15 | Animations | Render | flarial_visual_modules.h | speed setting only; consumed by `hkGetTexture`/`hkDrawImage` |
| 16 | Reach Display | Render | flarial_visual_modules.h | reads `g_lastHitDistance` (attack hook) |
| 17 | TextHotkey | ? [U] | **MISSING** `modules/misc/misc_modules.h` | referenced (`kModuleName`, `AddMacro`, `on_key_trigger`); NO impl |
| 18 | JavaHotkeys | ? [U] | **MISSING** (player or misc header [U]) | engine partly in overlay.cpp (`JavaHotkeysTrySwap`, slot-hover hook); module class ABSENT |
| 19 | NoHurtCam | ? [U] | **MISSING** | NO implementation in repo |
| 20 | Potions | Render | flarial_visual_modules.h | `GetPotionEffects` (entt), default ON |
| 21 | Keybinds | Render | flarial_visual_modules.h | registry scan, default ON |
| 22 | Monitoring | Render | flarial_visual_modules.h | TPS/BPS/IP/CPS/time, default ON |
| 23 | Target HUD | Render | flarial_visual_modules.h | crosshair entity + attack data + damage FX |
| 24 | Hitboxes | Render | flarial_visual_modules.h | entity ESP via `GetActors`+AABB+W2S |
| 25 | Crit Particles | Visual | flarial_visual_modules.h | crit-burst ring buffer + W2S |
| 26 | FlarialSettingsModule | ? [U] | **MISSING** `modules/settings/flarial_settings_module.h` | referenced settings: `m_hudScale/m_fontScale/m_hudPadding/m_hideHudInMenu/m_shadows`; NO impl |
| 27 | General (ClickGuiModule) | Settings | clickgui_module.h | menu self-config (instance singleton) |
| 28 | Themes (InterfaceModule) | Settings | interface_module.h | theme config (instance singleton) |

**Defined but NEVER registered (dead in practice)** [R]: `ESP`, `Nametags`, `NoRender`, `Zoom` (constructor-only, **no** `on_render` — pure data), `FlarialKeystrokes`, `FlarialCrosshair`, `FlarialDirectionHUD`, `FlarialClock`, `FlarialMemory` (complete local-only implementations, some `set_enabled(true)`, but unreachable without registry entries).

**Module game-touch matrix** (reality, not comments):

| Module | Touches game? | Via |
|---|---|---|
| Watermark | reads | `g_pingMs` (RakPeer hook) |
| CPS Limiter | writes (indirect) | external watcher rejects clicks before MC receives them |
| FullBright | writes | `hkGamma` returns lerped gamma |
| GUI Scale | writes | `GuiData` float write + UI-tree relayout |
| VSync Disabler | writes | `Present` sync-interval override |
| Freelook | writes | camera-angle redirect in `hkUpdateFromCamera` |
| Animations | writes | hotbar-texture position lerp in `hkDrawImage` |
| Reach/Target/Hitboxes/Crit/Potions/Monitoring | reads | attack/baseTick/ping/entt/state-vector/IP hooks |
| TextHotkey | writes [U: impl absent] | `SendChatText` (TextPacket id 9) is the obvious sink |
| JavaHotkeys | writes | container-controller swaps (`JavaSwap`→`ProcessPendingSwap`) |
| FPS/CPS/MouseStrokes/Keybinds/Arraylist/menu | no | ImGui IO / Win32 / registry only |

---

## 7. Settings System

**Types** (`setting.h`, 177 lines, header-only — no `setting.cpp`) [R]:

| Type | Storage | Semantics [R] |
|---|---|---|
| `BoolSetting` | `mValue: bool` | + `mKey` bindable key, `boolScale` menu anim |
| `NumberSetting` | `mValue/min/max/step: float` | snap-to-step; middle-click drag rounding; `setValue` clamps |
| `EnumSetting` | `mValue: int`, `mValues: vector<string>` | wrapping cycle; `current()`; `setValue` wraps |
| `ColorSetting` | `mValue[4] float` | `getAsImColor()`; ARGB-hex ctor (`0xFF8E5CFF`); alpha supported (picker uses `AlphaBar`) |
| `StringSetting` | `mValue: string` | `mMaxLength` enforced by GUI editors |

Base `Setting`: `mName/mDescription/mType/mKey`, **`mIsVisible` predicate** (`std::function<bool()>`, default true) — used heavily (Interface custom palette gating, per-card setting filtering, search filtering), per-setting anim fields.

**Keybinds:** modules (`m->key/setKey`) and **bool settings** (`s->mKey`) are bindable; capture by middle-click (ModernGui) / keybind chip (Citron); ESC unbinds; dispatch in `DispatchKeybinds()` only when menu closed **and** `IsInWorld()`; `on_key_trigger()` lets trigger-modules (TextHotkey) consume presses instead of toggling [R].

---

## 8. GUI System

### 8.1 Shell — `ui::` (`clickgui.h/.cpp`) [R]

Public API (4 functions): `ApplyStyle()` (fonts + ImGui dark style), `RegisterModules()`, `SaveState()` (`config::Save` + log), `Render()` (the whole menu frame).

`Render()` order: key-source switch detection (menu open/closed use different key mirrors → `ResetKeyMirrors` + `keys::Reset`) → `keys::BeginFrame()` → one-time `config::Load()` → `ApplyInterfaceSettings()` (push Interface module → `gui::SetTheme/...`) → `DispatchKeybinds()` (menu closed only) → guarded TICK+RENDER for every enabled module → open/close easing (`EasingUtil` + Glass/Zoom/Bounce shaping) → hash + debounced autosave (1.5 s) → scrim → `g_citronGui.render(...)`.

Config hashing (`StateHash`, FNV-1a over module names/categories/enabled/keys + every setting value + friends list) runs **every frame**, allocation-free [R].

### 8.2 Active renderer — `ui::CitronGui` (SystemDLC port) [R, full read]

- **Design space:** 1188×700 pt, radius 12; uniform scale `sBase` (1.0 at 1920×1080, clamped to fit); `Ctx` helper converts pt→px, does pt-space hit-testing; open animation 0.93→1.0 + 18 pt drop; window draggable by top bar/logo row (`m_winOffset`, runtime-only).
- **Sidebar:** 224↔48 pt collapse glide, logo row (Lucide activity + "Nightfull" serif wordmark), CATEGORIES section (All/Render/Visual/Movement/Player/Combat/Misc), CLIENT section (Theme/Settings/Friends [U: exact tab enum names beyond rendering — `TAB_THEME/TAB_SETTINGS/TAB_FRIENDS` seen]), server card bottom ("Nightfull / 1.21.111 | {ping} ms" — **game version hardcoded in the format string**).
- **Top bar:** 48 pt, sidebar toggle, sliding page title, icon actions (glass toggle → writes `ClickGuiModule::m_glass`, search modal, collapse-all).
- **Content:** 3-column masonry of module cards (301↔358 pt responsive to sidebar, radius 14); card = 56 pt header (category glyph, naming-styled title, keybind chip, 28×16 toggle) + in-place expansion (`Module::cAnim`, ring flash `m_ringAnim`); smooth per-page scroll + 2 pt scrollbar + 64 pt edge fades; cards culled when fully clipped.
- **Setting rows:** checkbox 16×16 r6, slider 6 pt + hover knob 10 pt with mono accent value, segmented (2-value enums) / dropdown overlay (3+, upward flip near bottom), color swatch → `ImGui::ColorPicker4` popup (`##nf_color`, 320×320), text field with caret + Enter-to-commit.
- **Theme page:** accent swatches (`gui::PaletteSwatch`), custom colors (visibility-gated), color slots + saturation + accent-motion sliders, naming dropdown.
- **Settings page:** Config card (Save/Load buttons → `config::Save/Load` + autosave note), Menu card (animation dropdown, glass checkbox, 7 sliders incl. midclick rounding), HUD card (FlarialSettingsModule: 3 sliders + 2 checkboxes; silently absent if module missing).
- **Friends page:** MidClick toggle card, Add-Friend form card (dup hint, Enter submits), friend rows (initial tile, remove → `removeFriend` + `showToast(name,false)`), empty-state hint mentions middle-click-adding a player.
- **Search modal:** 448×304 centered, dim scrim, live results (≤32, module + setting hits), mouse + arrows/Enter/Esc, navigates to page + expands + ring-flashes the hit.
- **Keybind capture:** global `vk 8..0xFE` scan for module or setting binds, ESC clears.
- **Particles:** 30 deterministic drifting dots + links, accent-tinted, behind window.

### 8.3 Dead renderer — `ui::ModernGui` (Solstice port) [R, full read]

Complete Solstice `ModernDropdown` engine: draggable category panels (200×30, 40 px gap), 30 px rows, search box, `ImGui::ColorPicker4` picker (Close **keeps** the color — deliberate Solstice-bug fix), tooltips, per-panel scroll, layout save/restore via `config::PanelPos`, left-toggle/right-expand/middle-bind. **Zero references from any other file** — `clickgui.cpp` instantiates only `CitronGui`. Dead/alternative code; still depends on missing `utils/config.h`, `keys::`, `gui::*`.

---

## 9. HUD System

All HUD rendering is **module `on_render()` drawing to ImGui background/foreground draw lists**; there is no separate HUD manager class. Shared helpers: file-local `DrawChip/Place/PacketRowAnchor/DrawPulsePlate` (flarial .cpp), `HudText/SolsticeShadow` (visual .cpp), `packethud` engine.

| HUD | Style | Anchor | Gating | Data source |
|---|---|---|---|---|
| Watermark | Pulse pill + Lucide icon | top-center | hidden in menu | text setting, `ImGui::IO.Framerate`, `g_pingMs` |
| Arraylist | Packet V3 plate rows + accent bar | right edge | hidden in menu | registry scan, first-enum mode suffix, per-module slide anim |
| FPS | Packet V2 row | 5-corner enum | `HideInMenu` (Flarial settings) | `ImGui::IO` |
| CPS | Packet V2 row | 5-corner enum | same | `ImGui::IsMouseClicked` ring buffers (64 clicks) |
| Mouse Strokes | polyline trail | cursor | **draws over menu too** | `ImGui::IO.MousePos/Delta` |
| Keystrokes [unregistered] | Flarial cells | bottom-left fixed | same | `keys::Down` + `ImGui::IsMouseDown` |
| Crosshair [unregistered] | 4-arm dynamic | center | same | `IO.MouseDelta` magnitude |
| Direction [unregistered] | static compass strip | top-center | same | **none — static text** ("rotation hook can be attached later") |
| Time [unregistered] | chip | 5-corner | same | `GetLocalTime` |
| Memory [unregistered] | chip | 5-corner | same | `GetProcessMemoryInfo` WorkingSet, 4 Hz cache |
| Reach Display | Packet V2 row | 5-corner | same | `g_lastHitDistance`, 15 s expiry, 10 Hz sampling |
| Potions | Pulse plate | 5-corner + 34 px below watermark | `IsInWorld` | `GetPotionEffects` (entt), m:ss, white→red last 10 s |
| Keybinds | Pulse plate + status dots | 5-corner | `IsInWorld` | registry (key>0, 4 HUD modules excluded) |
| Monitoring | Pulse plate | 5-corner | `IsInWorld` | FPS counter, BPS (state-vector vel×20, smoothed), TPS (`g_monitorTickCounter`), server IP/`Local`, LMB CPS (**`GetAsyncKeyState`**), clock |
| Target HUD | SystemDLC plate + avatar + HP + damage FX | hotbar-anchored default | `IsInWorld` | crosshair entity → else 2 s-fresh attack target; `ActorReadName/Health/StateVector`; ghost bar, hit pulse, appear pop, shake, 14-particle plate burst, world-anchored damage numbers (`g_damageEvents` ring) |
| Hitboxes | convex-hull ESP | world | `IsInWorld` | `GetActors` (≤128, local excluded, 500 ms freshness) + `ActorReadAabb` + 8-corner W2S (skip if any corner behind camera) |
| Crit Particles | 5 world-space shapes | world | none (burst-gated) | `g_critBursts` ring (attack hook stamps only falling-attacker + post-immunity), focal-scaled dots |

Global HUD policy helpers (flarial .cpp, all via **missing** `FlarialSettingsModule`, each with a sane fallback when the module is absent): `HudScale/FontScale/HudPadding/HideInMenu/Shadows`.

---

## 10. Rendering System

- **What renders:** stock ImGui 1.91.8 (`IMGUI_CHECKVERSION`, `CreateContext`, `NavEnableKeyboard`) + `imgui_impl_win32/dx11/dx12` backends (vendored, unmodified — the only `LOG_` matches in `imgui.cpp` are ImGui's own `IMGUI_DEBUG_LOG_*` macros) [R].
- **Two paths:** D3D11 (primary: `GetDevice` → RTV → `DX11_NewFrame/RenderDrawData` with explicit `OMSetRenderTargets`) and D3D12 (fallback over the game's own captured command queue; own allocator/list/fence; fence wait capped to avoid wedging `hkPresent`) [R].
- **How hooks attach:** `Present`/`ResizeBuffers` via **direct vtable patch** (`HookVTable` + `VirtualProtect` [U: protection handling inside `HookVTable` not read — inferred]); D3D12 queue via `HookCommandQueueVTable`→`hkExecCmdLists` (lazily installed from `InitD3D12`); everything else via **MinHook** (`MH_Initialize/CreateHook/EnableHook`) [R].
- **Threading:** all rendering serialized by `g_RenderCs`; re-entrancy guard `g_inRender`; `hkResizeBuffers` does full teardown → re-init on next Present [R].
- **What is NOT used:** the game's own renderer (bgfx/MUIRC) for drawing — except `hkDrawImage` which *modifies* hotbar-texture coordinates in-flight (Animations) rather than drawing. No D2D, no custom shaders, no textures of our own (no `AddImage` calls in project code [R: none found in module/GUI code]).

---

## 11. Rendering Pipeline

(D3D11 path; D3D12 equivalent inside `RenderD3D12Frame` [U: body not read line-by-line])

```text
game Present → hkPresent → liveness stamps → lazy init (once) → TryInstall* hooks
  → ApplyGameGuiScale → TryInstallRawInputBlock → UpdateHotkeys
  → EnterCriticalSection → ImGui_ImplDX11_NewFrame → ImGui_ImplWin32_NewFrame
  → EnsureOverlayDisplaySize → UpdateInputState (key/mouse snapshot → ImGui IO)
  → ImGui::NewFrame → ui::Render (keybinds, modules TICK+RENDER, menu)
  → ImGui::Render → OMSetRenderTargets → ImGui_ImplDX11_RenderDrawData
  → LeaveCriticalSection → VSync check → oPresent
```

Per-frame cost centers: `StateHash` (config digest), full-registry TICK+RENDER with SEH+QPC per module, Citron masonry measure+draw, W2S loops (Hitboxes ≤128×8 projections, Crit bursts ≤ density×modes). No profiling instrumentation beyond the guard's slow-call log.

---

## 12. Text Rendering

- **Exclusively ImGui CPU-rasterized TTF text** (`ImDrawList::AddText` with explicit `ImFont*` + pixel size). No game-font/MC-text rendering anywhere [R].
- **Font roles** (loaded by missing `gui::LoadFonts`, consumed via missing `gui::UIFont/DisplayFont/MonoFont/IconFont/CurrentFont` + `SetFontOverride`): UI regular, Display (serif wordmark), Mono (values/addresses), Icon (Lucide glyphs, U+E0xx–U+E4xx via UTF-8 byte literals), Current (HUD default) [R call-sites].
- **Helpers** (all missing impls): `gui::DrawText(pos,text,color,size,alpha,shadow,drawList?)`, `GetTextWidth/Height`, `kFontUnit` (deep constant: `packethud::Unit() = kFontUnit*0.1` = 1.8 px per MC UI unit [R]).
- Citron measures with override-font push/pop (`TextW/TextH`); HUD chips measure then plate; ellipsis truncation done manually (TargetHud name).

---

## 13. GUI → Renderer Connection

Strictly top-down immediate mode, no retained widgets, no GUI-side GPU resources:

```text
hkPresent → ui::Render (easing/autosave/scrim math)
  → CitronGui::render(animation, inScale, isEnabled)
    → gui::FillRect/StrokeR/Text/Glyph… (gui_render)
      → ImGui::GetBackgroundDrawList() primitives
    → ImGui::Begin/ColorPicker4/Button (ONLY for color popups)
  → ImGui::Render → backend RenderDrawData
```

Modules never touch backends; GUI never touches game memory (only `g_pingMs` for the server card and `IsInWorld` for gating). All interaction is manual hit-testing (`Ctx::Hover`, `gui::IsMouseOver`) against the fused key/mouse snapshot — ImGui itself "never sees a key event inside the UWP sandbox" per the header comment; mouse comes through ImGui IO normally [R].

---

## 14. HUD System

See §9 table. Structural notes:

- **No HUD manager/editor:** no drag-to-move, no per-HUD visibility toggles beyond `HideInMenu`; anchors are fixed 5-corner enums (+Hotbar for TargetHud); offsets are hardcoded (e.g. Potions +34 px, TargetHud hotbar `y-100-H`).
- **Packet V2 engine** (`packethud`, 154 lines) [R]: frame-shared rainbow wheel (`ApplyRainbow` hue += 0.0005/frame), dynamic gray wave (0.2–1.0, ±0.007/frame), static 8-color palette with Packet's enum skip (index 10 = removed Weather), UI-unit geometry (`U = 1.8 px`), text-only rows (plate intentionally removed — "read as a drop shadow").
- **Gating matrix:** menu-hidden (Watermark/Arraylist + all Flarial `Screen()` widgets when `HideInMenu`), `IsInWorld`-gated (Potions/Keybinds/Monitoring/Target/Hitboxes), always (MouseStrokes incl. over menu; Crit bursts whenever alive).
- **`IsInWorld()`** = `screenFlags` bit (from `getScreenName`=="hud_screen" published by `hkSetupAndRender`) with `LocalPlayerExists()` fallback [R].

---

## 15. Theme System

- **Owner:** `InterfaceModule` ("Settings"/"Themes") — Naming (4 styles), Theme (9 presets: Default/Purple/Blue/Cyan/Red/Green/Orange/Monochrome/Custom), Color Slots (1–6), Color 1–6 (ARGB defaults: violet→blue→cyan→mint→orange→rose), Accent Motion (0.25–20), Saturation (Custom-only) [R].
- **Engine:** missing `utils/gui_theme.h` — reconstructed API from ~40 call-sites: `SetTheme/SetNamingStyle/SetCustomColorCount/SetCustomColor(i,ImColor)/SetColorSpeed/SetSaturation`, `GetThemedColor(phase)` (cycling gradient accent — the single most-used color source), `ApplyNaming` (4 styles), `PaletteSwatch(i)` [R call-sites, impl U].
- **Application:** pushed every frame from `ApplyInterfaceSettings()`; consumed by Watermark accent, Arraylist bar, all Pulse plates (`m_useTheme`), Hitboxes/Crit fills, Citron `c.accent` + particles, ModernGui gradients/dots. `m_useTheme=false` falls back to per-module `ColorSetting`.
- **Glass material:** `ClickGuiModule::m_glass/m_transparency` re-tints Citron palette roles toward translucent white-on-dark (`UpdatePalette`); scrim alpha also derives from glass+blur. No real blur (D2D blur explicitly rejected — "needs a D2D device… so a flat translucent scrim is used") [R].

---

## 16. Event System

**There is no event bus** (no `nes`, no listener registry, no `Deafen/Listen`). The architecture is **hook → global → poll**:

| Producer (hook/thread) | Channel (overlay.h globals) | Consumer (poll site) |
|---|---|---|
| `hkGameModeAttack` | `g_targetActor/g_targetTickMs`, `g_lastHitDistance/Valid/TickMs`, `g_critBursts[]/g_critBurstTick` (ring), `g_damageEvents[]/g_damageHead` (ring) | TargetHud, ReachDisplay, CritParticles, damage FX |
| `hkActorBaseTick` | `s_actorMap` (actor→{id,ms}), `g_monitorTickCounter` | `GetActors` (Hitboxes), Monitoring TPS |
| `hkGetAveragePing` | `g_pingMs` | Watermark, Monitoring [U: Monitoring reads IP not ping — Watermark + server card confirmed], Citron server card |
| `hkSetupAndRender`/`PublishChatOpen` | `g_ext_key_flags.chatOpen/screenFlags` | `IsChatOpen/IsInWorld`, keybind gating, watcher-event dropping |
| `hkKeyboardFeed`/`hkMouseFeed`/watcher/poll | `g_FeedKeys[]`, `g_ext_key_flags`, `keys::` snapshot | `UpdateInputState`, `DispatchKeybinds`, Citron capture |
| `hkContainerSlotHovered` | pending-swap state [U: exact struct] | `ProcessPendingSwap` (JavaHotkeys) |
| `hkGamma` | reads `FullBright::m_currentGamma` | game (outbound "event") |
| `hkUpdateFromCamera` | reads/writes `Freelook` flags | game + module (bidirectional) |

Menu interactions call module code **synchronously** (toggle → `ModulePhaseGuard::run(ENABLE/DISABLE)` inline). Cross-thread communication uses `Interlocked*` + `volatile LONG` + frame counters; the only locks are `g_RenderCs` (render) and MinHook's internal one.

---

## 17. Input System

Four key sources in priority order + two sinks [R]:

1. **`Keyboard::feed` detour** (`hkKeyboardFeed`, Solstice signature for 1.21.101–111 + fallbacks [U: fallback list not fully read]) — primary when active; feeds `g_FeedKeys[8]` (256-bit); can swallow keys (menu-open consumption); sets `g_KeyHookActive` which **disables** the watcher path.
2. **External watcher** (`injector.exe --watch`, source absent): desktop process, `WriteProcessMemory` into exported `g_ext_key_flags` (`toggle/esc/end/alive/menuOpen/keyhookOn/chatOpen/screenFlags/frameTick/cps*` + 256-bit `keys[]`); installs global LL masks while `menuOpen=1` (unless `keyhookOn`); enforces CPS limits.
3. **In-process poll** (`PollHotkeyState`/`PollKeyDown`: INSERT/K/ESC/END + `keys::` snapshot) — "provably dead inside the AppContainer" for keys; mouse works.
4. **Raw-input capture** (`CaptureLocalRawInput` in `hkGetRawInputData`) + **neutralization** (`NeutralizeRawInput` while menu open; `preserveMouse` so ImGui keeps the cursor).

Mouse/cursor path: `hkMouseFeed` (Packet/Flarial dispatcher — the click-through/cancel point) → raw-input block fallback → `hkShowCursor` (+ `hkClipCursor/hkSetCapture/hkSetCursorPos` seen by name only [U: bodies/install sites not read]) → `UpdateCursorVisibility()` per frame → WndProc subclass (`g_origWnd`, forwards to `ImGui_ImplWin32_WndProcHandler`) [R structure, some bodies U].

Menu hotkeys: **K or INSERT toggle, ESC close, END unload** (each implemented 3×: feed-detour branch, watcher-counter branch, poll branch — e.g. `g_ShowMenu` writes at overlay.cpp:3237/3243, 3645/3650, 3922/3928) [R].

`JavaHotkeysTrySwap` + `JavaHotkeysFramePoll` drive container swaps from the input-feed path (bind value → `JavaSwap` → SEH wrapper → `ProcessPendingSwap` on hovered controller) [R structure].

---

## 18. Configuration / Persistence

- **API (missing `utils/config.h`):** `config::Save/Load/Path`, `config::PanelPos{x,y,extended}` (ModernGui layout — dead with ModernGui) [R call-sites].
- **Format:** JSON file ("re-reads and re-parses the JSON file") [R comment]; **path unknown** [U] (`config::Path()` impl absent).
- **Policy:** load-once on first rendered frame (re-injection reloads naturally via fresh globals); FNV-1a `StateHash` every frame over modules+settings+friends; write ~1.5 s after last change; `SaveState()` also forced on `OverlayShutdown` and from the Settings page; hand-edited values are clamped on read (`CurrentCgSettings`) [R].
- **Known quirk (fixed in code):** a per-frame `Load()` used to "undo" user edits before autosave — hence the `g_stateLoaded` once-guard [R comment].

---

## 19. Dependencies

**Internal** (project → project): everything includes `pch.h` first (Win32+D3D+ImGui+`utils/logger.h`+`utils/math.h` — the last two missing, so **no TU in the repo compiles**). `overlay.h` is the engine façade; `module.h/setting.h` the domain core; `gui_render/gui_theme/fonts/keys/config/easing` the missing utility ring; `entity_registry.h` (`namespace game`) the missing actor-reader ring; `friends/misc/movement/player/settings` module headers the missing roster ring.

**External** [R usage, sources absent except ImGui]:

| Dependency | Used for | Present? |
|---|---|---|
| ImGui 1.91.8 + dx11/dx12/win32 backends | all rendering/GUI | YES (vendored, stock) |
| MinHook (`MH_Initialize/CreateHook/EnableHook`) | ~15 detours | NO headers/lib/source in repo [U: include site — likely overlay.cpp top, not verified] |
| Windows SDK (D3D11/D3D12/DXGI/user32/psapi/winver) | swapchain, backends, cursor, memory info, version log | system (assumed at build) |
| MSVC SEH (`__try/__except`, `excpt.h`) | crash containment everywhere | toolchain |
| injector.exe (+ `--watch` child) | DLL injection + external key watcher + CPS enforcement | NO (protocol inferred from comments + shared struct) |
| Bedrock 1.21.111 game image | signature targets | runtime only |
| 7 TTF fonts | `gui::LoadFonts` | YES (binaries) |

---

## 20. Call Graph

**Startup:** `DllMain → AttachThread → MainThread → MainThreadImpl → {OverlayWatchdogThread, LogGameVersion, TryInstallPingHook, wait d3d11, wait window, dummy swapchain, HookVTable×2, WatchdogThread}` → (game frames) → `hkPresent → {D3D11/D3D12 init → ui::ApplyStyle, RegisterAllModules} → TryInstall* (×10) → UpdateHotkeys → ui::Render → oPresent`.

**Per-frame menu path:** `ui::Render → keys::BeginFrame → config::Load (once) → ApplyInterfaceSettings → DispatchKeybinds → ModulePhaseGuard::run(TICK+RENDER)×N → easing → autosave → scrim → CitronGui::render → (page builders, SSD* widgets, search, popups)`.

**Toggle paths:** card toggle / ModernGui click / keybind → `Module::toggle()` → `ModulePhaseGuard::run(ENABLE|DISABLE)` → module `on_enable/on_disable` → overlay state (e.g. Freelook flags, mouse-stroke reset, gamma baseline).

**Game→HUD chains:** `hkGameModeAttack → {g_target*, g_lastHit*, PushCritBurst, damage ring} → {TargetHud, ReachDisplay, CritParticles, RenderDamageFx}`; `hkActorBaseTick → s_actorMap/g_monitorTickCounter → {GetActors→Hitboxes, Monitoring}`; `hkGetAveragePing → g_pingMs → {Watermark, server card}`; `hkGetTexture/hkDrawImage + hkSetupAndRender → hotbar-lerp state → Animations speed read`; `hkUpdateScreenSize/hkGamma/hkGetViewPerspective/hkUpdateFromCamera → {GuiScale apply, FullBright gamma read, Freelook angles}`.

**Shutdown:** END key → `g_UnloadRequested → FinishUnload` (after frame) **or** process exit → `NotifyDetach → {stop watchdogs, g_ShowMenu=false, masks off, RestoreWndProc, ShutdownImpl (TryEnter only), RestoreHooks}`. `OverlayShutdown` (menu-triggered [U: no call-site in repo — likely console/unload command path or injector]) = `SaveState + ShutdownImpl`.

---

## 21. Data Flow

**Inbound (game → overlay):** signature-resolved function pointers + vtable slots → detour reads (hovered-slot controller, attack actor/hitresult, baseTick actor, ping, screen name, GuiData, camera, textures, potion entt components, RakNet GUID→IP, local-player state vector) → overlay globals/rings → module `on_render` polling → ImGui draw lists → Present.

**Outbound (overlay → game):** gamma float, GUI-scale float + relayout walks, camera angles, hotbar UV positions, swallowed/cancelled input (feed detours, raw-input neutralize, LL masks), crafted `TextPacket` (chat), container slot swaps, VSync interval, cursor visibility.

**Local loops:** key snapshot → keybinds/menu; settings → theme push → every colored draw; StateHash → autosave; CPS settings → shared block → external watcher; `UpdateCritCamera` (eye history + view-matrix cache [U: discovery heuristic `CritTryFindViewMatrix`/orthonormal scan — bodies skimmed, exact math not verified]) → `ProjectWorldToScreen` → ESP/particles/damage numbers.

---

## 22. Architectural Problems (no fixes — observations only)

1. **Repo is not buildable**: flat layout vs rooted includes; ~16 missing headers/sources; no build system; no MinHook; no injector.
2. **8 of 28 registered modules have no implementation** (Sprint, NullMovement, Friends, MidClick, TextHotkey, JavaHotkeys, NoHurtCam, FlarialSettings) — yet active code dereferences them (`FlarialSettingsModule::instance()` in every Flarial HUD file-local helper; `FriendsModule` in autosave hash + Friends page; `TextHotkey::kModuleName/AddMacro` in Citron).
3. **Comments systematically contradict code** ("never touches the game" vs 20+ game detours). Any future work must trust `.cpp` bodies, never header philosophy comments.
4. **Dead-but-complete second GUI** (`modern_gui`, 966 lines) + dead `config::PanelPos` persistence path + 9 unregistered modules (~700 lines impl) ship in the tree.
5. **Constructor-only modules with misleading descriptions** (ESP "Demo entity overlay", GuiScale "Change Minecraft's own interface scale" — the GuiScale *module* does nothing; the overlay does the work by name-matching the module).
6. **Name-based coupling**: overlay finds modules by string (`"CPS Limiter"`, `"VSync Disabler"`) instead of types/singletons — rename breaks behavior silently.
7. **UWP input contradiction**: `MonitoringHud` CPS uses `GetAsyncKeyState(VK_LBUTTON)` although the input design doc in-code says that API is "provably dead" in-process (mouse may work — keys don't; still inconsistent with the stated rule).
8. **Hardcoded game version string** in Citron server card (`"1.21.111 | %d ms"`) while signatures span 1.21.101–131.
9. **Hardcoded offsets/slots everywhere**: `GuiData+0x5C`, `Actor+0x8`, baseTick vft slot 25, MUIRC vtable[7], Present/Resize vtable indices [U: constant values not verified], entt `0x88/0x18` (1.21.30 layout per header name — 1.21.111 drift [U]).
10. **FOV constant**: `s_gameFovDeg = 70.0f` default [R] — W2S accuracy depends on `CritTryFindViewMatrix`/focal heuristics [U].
11. **Single render-thread assumption**: module `on_render` statics, `HoverAnim` slots, `s_local` caches assume one calling thread; `hkResizeBuffers` can arrive on another thread (mitigated by `g_RenderCs`, but module code itself takes no locks).
12. **Re-injection safety is partial**: MinHook re-init handled (`ALREADY_*` tolerated), but file-local statics (`s_dmgFx`, search state, `s_target`) reset silently — acceptable, but unlogged.
13. **136-line `CitronGui::render` + 1400-line body**: all pages/widgets inline; `modern_gui.cpp` similarly monolithic. No separation between layout, widgets, and state.
14. **No assertions/diagnostics for missing modules**: `if (fs)` / `if (fm)` null-guards hide the absent-files problem at runtime instead of reporting it.
15. **`nightfull.rar` 1-byte placeholder** and 7 loose TTFs with no manifest/mapping doc (which file → which `gui::LoadFonts` role [U]).
16. **Cursor-hook surface partially unverified**: `hkClipCursor/hkSetCapture/hkSetCursorPos` names seen [R in name list], bodies/install sites **not** found at the `MH_CreateHook` sites enumerated — install mechanism [U].

---

## 23. Dead Code

| Item | Size | Evidence |
|---|---|---|
| `ModernGui` (h+cpp) | ~1080 lines | zero references outside its own files [R grep] |
| `config::PanelPos` save/restore path | ~30 lines | only used by ModernGui |
| `FlarialKeystrokes/Crosshair/DirectionHUD/Clock/Memory` impls | ~450 lines | never registered [R] |
| `ESP/Nametags/NoRender/Zoom` ctors | ~60 lines | never registered; no `on_render` at all |
| `CreateNightfullModules()` | 5 lines | returns empty; caller [U: no call-site found in repo] |
| `NightfullModule` class | 6 lines | no usages [R: only registry grep + definition] |
| Solstice tab-bar code in clickgui.cpp | removed already | comment confirms removal (not dead — gone; noted for history) |
| Container-tick hook for JavaHotkeys | removed already | comment: "signature matched a function that never runs on 1.21.111" |
| `nightfull.rar` | 1 byte | placeholder, unusable |
| `m_searchFocused=true` default etc. | trivial | ModernGui-only state |

---

## 24. No Assumptions — Explicitly Unconfirmed List

1. Original subdirectory tree (include roots suggest `modules/*, ui/*, utils/*, game/*`, exact layout [U]).
2. All `utils/*` implementations (11 headers) — only call-site signatures reconstructed.
3. All 8 missing module implementations + their categories/descriptions/settings.
4. MinHook version, include path, linkage (static/dll) [U].
5. Injector CLI/protocol beyond what comments + `ExtKeyCounters` reveal [U].
6. `config::Path()` location + JSON schema [U].
7. TTF filename→font-role mapping [U].
8. Cursor hooks (`hkClipCursor/hkSetCapture/hkSetCursorPos`) bodies/install [U].
9. `RenderD3D12Frame`/`InitD3D12` internals (skimmed, not line-verified) [U].
10. View-matrix discovery math (`CritTryFindViewMatrix`, orthonormal scan) exactness [U].
11. `G_Texture`/`setupAndRender`/attack signature game-version coverage beyond comments [U].
12. Whether `OverlayShutdown`/`RequestUnload` have in-repo call-sites (none found — likely external/menu-command paths) [U].
13. `game::` reader offsets/versions (entity_registry absent; `bedrock_entt.hpp` targets 1.21.30 layout) [U].
14. Build toolchain (MSVC version, C++ standard, x64) [U — inferred MSVC/x64 from SEH + `__fastcall`].
15. `HookVTable` memory-protection handling [U: body not read].

---

## 25. No Changes Made

During this entire analysis **zero modifications** were performed on `/home/user/nightfull-src/`: no file created/edited/renamed/moved/deleted there; no build attempted; no code formatted. All reads used `cat/sed/grep` (read-only). Workspace writes were limited to this report file and the pre-existing `research/` + `nightfull-gui/` deliverables from earlier stages.

---

## 26. Final Report — Consolidated Reference

(This §26 is the protocol's "ИТОГОВЫЙ ОТЧЁТ" wrapper: §§1–25 + tables §§27–30 + §31 + WHAT I NOW UNDERSTAND below constitute the complete deliverable. Key one-line verdicts: **entry** DllMain→MainThread→hkPresent; **core** overlay engine + ui shell + Citron + modules/settings; **render** ImGui DX11/DX12 overlay; **input** 4-source fusion; **config** JSON hash-autosave; **events** hook→global→poll, no bus; **state** unbuildable flat partial copy with 8 roster modules + 11 utils + injector + build system missing; **direction** restore `utils/` + missing modules before any feature work.)

---

## 27. Important Classes Table

| Class | File | Responsibility | Used By | Depends On |
|---|---|---|---|---|
| `overlay::MainThread(MainThreadImpl)` | overlay.cpp | DLL worker: watchdog, version log, dummy swapchain, vtable hooks | dllmain | Win32, DXGI, MinHook [U], logger |
| `hkPresent/hkResizeBuffers` | overlay.cpp | frame interception, lazy init, render dispatch, teardown | DXGI vtable | ImGui backends, ui::Render |
| `ui::CitronGui` | citron_gui.* | active menu: sidebar/pages/cards/search/popups | ui::Render | ModuleManager, config, keys, gui_*, InterfaceModule, FriendsModule [U] |
| `ui::ModernGui` | modern_gui.* | DEAD Solstice panel engine | nobody | ModuleManager, config [U], keys/gui_* [U] |
| `modules::Module` | module.h | module base: identity/state/settings/virtuals/anim fields | all modules | Setting* |
| `modules::ModuleManager` | module_manager.* | singleton roster owner | ui, menus, HUDs, overlay | Module |
| `modules::ModulePhaseGuard` | module_guard.* | SEH+timed callback wrapper | ui::Render, menus, keybinds | Module |
| `modules::RegisterAllModules` | module_registry.cpp | roster construction (order = UI order) | hkPresent init | all module ctors (8 missing [U]) |
| `Setting` + 5 subclasses | setting.h | typed values, visibility, keybinds | Module, GUIs, config hash | — |
| `ClickGuiModule` | clickgui_module.* | menu self-config (anim/glass/sliders) | ui::Render, Citron | Module |
| `InterfaceModule` | interface_module.* | theme config (presets/custom/naming) | ApplyInterfaceSettings, Theme page | Module |
| `Watermark/Arraylist` | visual_modules.* | top pill + module list HUD | ui::Render | gui_*, g_pingMs |
| `FullBright/GuiScale/VsyncDisabler/Freelook` | visual_modules.* | game-effect settings holders | overlay hooks (gamma/scale/present/camera) | Module |
| `ESP/Nametags/NoRender/Zoom` | visual_modules.* | DEAD ctor-only placeholders | nobody | Module |
| `FlarialFPS/CPS/MouseStrokes` | flarial_visual_modules.* | Packet-style metric HUDs | ui::Render | packethud, ImGui IO |
| `FlarialKeystrokes/…/Memory` | flarial_visual_modules.* | DEAD (unregistered) local HUDs | nobody | keys/gui_* [U] |
| `CPSLimiter` | flarial_visual_modules.* | limiter settings holder | overlay→watcher publisher | Module |
| `Animations` | flarial_visual_modules.* | hotbar-lerp speed holder | hkGetTexture/hkDrawImage | Module |
| `ReachDisplay/PotionsHud/KeybindsHud/MonitoringHud/TargetHud/Hitboxes/CritParticles` | flarial_visual_modules.* | game-data HUDs | ui::Render | overlay readers, game:: readers [U], gui_* |
| `Sprint/NullMovement/Friends/MidClick/TextHotkey/JavaHotkeys/NoHurtCam/FlarialSettings` | MISSING headers | registered but absent | registry, Citron, autosave | [U] |
| `packethud::PacketHud` (file-local) | packet_hud.cpp | shared rainbow/dynamic/static color wheel + UI units | FPS/CPS/Reach rows | gui::kFontUnit, CurrentFont |
| `game::` readers | utils/entity_registry.h — MISSING | ActorReadStateVector/Name/Health/Aabb | Target/Hitboxes/Monitoring/damage FX | bedrock offsets [U] |
| `ExtKeyCounters/g_ext_key_flags` | overlay.h/.cpp | DLL↔watcher shared block (exported) | overlay, injector [U] | — |
| `bedrock_entt` components | bedrock_entt.hpp | entt type-name-keyed MobEffects read | FillPotionEffects | entt registry layout [U] |

---

## 28. Important Methods Table

| Method | Class / scope | Purpose | Called From | Important Notes |
|---|---|---|---|---|
| `DllMain` | — | attach→thread, detach→teardown | OS loader | never blocks on loader lock |
| `MainThread/MainThreadImpl` | overlay | worker init: watchdogs, hooks, dummy SC | AttachThread | SEH split (C2712) |
| `hkPresent` | overlay | frame hook: init + render + vsync + chain | DXGI Present | liveness stamp first; SEH → abort render, never crash game |
| `hkResizeBuffers` | overlay | full teardown on resize | DXGI | re-init next Present; takes g_RenderCs |
| `ui::Render` | ui | menu frame: keys/config/keybinds/modules/easing/autosave/menu | hkPresent paths | Citron only; ModernGui not referenced |
| `ui::ApplyStyle/RegisterModules/SaveState` | ui | fonts+style / roster build / config flush | hkPresent init, OverlayShutdown, Settings page | |
| `CitronGui::render` | ui::CitronGui | full menu immediate draw | ui::Render | ~1400-line body; Ctx pt-space |
| `ModernGui::render` | ui::ModernGui | DEAD panel draw | nobody | |
| `Module::toggle/setKey` | modules::Module | state flip / bind set | menus, keybinds | |
| `ModulePhaseGuard::run` | guard | guarded callback invoke | ui::Render, menus | >5ms log, fault/>100ms → disable |
| `DispatchKeybinds/StateHash/CurrentCgSettings/ApplyInterfaceSettings` | ui (file-local) | binds / hash / clamped menu cfg / theme push | ui::Render | |
| `TryInstall*` (×12) | overlay | once-guarded detour installers | hkPresent / module on_render | ping early; baseTick lazy from HUDs |
| `ScanSignature/ScanSignatureMatches/BuildPattern` | overlay | Solstice/Flarial pattern scan | TryInstall* | uniqueness-aware for called targets |
| `UpdateHotkeys/PollHotkeyState/UpdateInputState(Impl)` | overlay | watcher counters+CPS publish / poll fallback / IO snapshot | hkPresent/RenderD3D12 | K/INSERT/ESC/END ×3 paths |
| `UpdateCursorVisibility` | overlay | cursor show/hide arbitration | UpdateHotkeys | [U: body not read] |
| `hkKeyboardFeed/hkMouseFeed` | overlay | game input detours | game dispatch | primary key source; click cancel point |
| `hkGameModeAttack` | overlay | attack telemetry: target/dist/crit/damage | game | stamps 4 channels |
| `hkActorBaseTick` | overlay | actor census + tick counter | game vft slot 25 | feeds GetActors + TPS |
| `hkGetAveragePing` | overlay | RakNet ping mirror | game | → g_pingMs |
| `hkSetupAndRender/PublishChatOpen` | overlay | screen-name gate | game | chatOpen/screenFlags → IsInWorld |
| `hkGetTexture/hkDrawImage` | overlay | hotbar-lerp animation | game UI render | reads Animations::m_speed |
| `hkGamma/hkGetViewPerspective/hkUpdateFromCamera/hkUpdateScreenSize/hkGuiDataMessage/hkContainerSlotHovered` | overlay | gamma/camera/size/chat/container detours | game | FullBright/Freelook/GuiScale/JavaHotkeys sinks |
| `hkExecCmdLists/HookCommandQueueVTable` | overlay | D3D12 queue capture | game queue | lazy (startup-crash avoidance) |
| `GetActors/GetPotionEffects/GetLocalPlayerState/GetServerIpString` | overlay | game-data readers | HUDs | SEH + null-degrade |
| `ProjectWorldToScreen/UpdateCritCamera/GetCritFocalPx` | overlay | W2S + camera upkeep | ESP/particles/FX | heuristic matrix [U detail] |
| `PushCritBurst` | overlay | crit ring-buffer writer | hkGameModeAttack | falling + post-immunity only |
| `SendChatText/InjectGameKey` | overlay | TextPacket craft+send / key inject | TextHotkey [U], JavaHotkeys paths | createPacket(9), LoopbackPacketSender |
| `ApplyGameGuiScale/RawApplyGameGuiScale/RelayoutUiTree/FlarialUpdateScale` | overlay | Flarial scale engine | hkPresent | GuiData+0x5C + control-tree walk |
| `JavaHotkeysTrySwap/JavaSwap/ProcessPendingSwap/HandleTakeAll/HandlePlaceAll` | overlay | container quick-swap engine | input-feed path + slot hook | options.txt hotbar parse |
| `InitD3D12/RenderD3D12Frame/ShutdownImpl/RestoreWndProc/RestoreHooks/FinishUnload` | overlay | D3D12 path / teardown primitives | hkPresent/Detach/Unload | fence-capped; TryEnter-only on detach |
| `WndProc/InstallWndProcHook` | overlay | game-window subclass | init [U: call-site] | forwards to ImGui backend |
| `OverlayShutdown/NotifyDetach/RequestUnload` | overlay | public lifecycle | menu/detach/END [U partial] | SaveState-first; mask-off; 150 ms grace |
| `WatchdogThread/OverlayWatchdogThread/RehookPresentOnce` | overlay | liveness + rehook diagnostics | MainThread | frameTick/heartbeat driven |
| `packethud::Frame/Color/HudRow/…` | packethud | shared HUD color+row engine | FPS/CPS/Reach | per-frame wheel advance |
| `keys::BeginFrame/PressedThisFrame/Down/Name/TextInput/Reset` | keys [U impl] | fused key snapshot API | ui, menus, HUDs | semantics from call-sites |
| `config::Save/Load/Path` | config [U impl] | JSON persistence | ui, Settings page | schema/path unknown |
| `EasingUtil::*` | gui::easing [U impl] | percentage + shaped easings | ui::Render | Solstice port |

---

## 29. Rendering Primitives Table

| Primitive | Existing? | Location | Used By | Parameters | Notes |
|---|---|---|---|---|---|
| Rounded rect fill | YES | `gui::FillRect` [U impl] → `AddRectFilled` | virtually everything | rect, color, alpha, radius, drawlist?, flags? | central primitive |
| Rect outline | YES | `gui::StrokeR` (citron-local) / `AddRect` | cards, plates, pills | rect, color, radius, thickness, alpha | |
| Line | YES | `AddLine` direct | crosshair, trails, particles, links, sliders | p0, p1, color, thickness | |
| Polyline (closed) | YES | `AddPolyline` | Hitboxes hull, Crit orbits | pts, n, color, flags, thickness | |
| Convex fill | YES | `AddConvexPolyFilled` | Hitboxes filled mode | pts, n, color | |
| Circle fill | YES | `AddCircleFilled` / `gui::FillCircle` | dots, particles, damage FX, avatar ring | center, radius, color, segments | |
| Text | YES | `gui::DrawText` [U] / `AddText` | all labels/HUD | pos, text, color, size, alpha, shadow | multi-font via override |
| Shadow rect | YES | `gui::FillShadowRect` [U] | chips, menu window | rect, color, alpha, radius… | layered-fill technique (see SolsticeShadow) |
| Gradient fill | YES | `gui::FillGradient/FillRoundedGradient` [U] | ModernGui rows (dead), menu fades | rect, c0, c1, alphas | `AddRectFilledMultiColor` for fades |
| Glow/blur (fake) | PARTIAL | `SolsticeShadow` (visual .cpp) | arraylist-era helper | rect, color, alpha, strength | concentric fills; **no real blur anywhere** |
| D2D/Shader blur | NO | — | — | — | explicitly rejected (scrim instead) |
| Texture/image | NO | — | — | — | no `AddImage` in project code; avatar is procedural pixels |
| Clip rect | YES | `PushClipRect/PopClipRect` | cards, dropdowns, search, scroll content | min, max, intersect flag | |
| Transform/scale | PARTIAL | `gui::ScaleToPoint` [U], `Ctx::P/px` | zoom-from-center, pt→px | rect, pivot, amount | no rotation/matrix stack |
| Alpha/fade | YES | per-call alpha params × menu `animation` | everything | — | final α = product of stage alphas (menu×page×row) |
| Cursor | OS | `hkShowCursor`/cursor visibility | menu vs game | — | no custom cursor drawing |

---

## 30. Settings Table

| Setting Type | Exists? | Location | Used By | Default | GUI Control |
|---|---|---|---|---|---|
| Boolean | YES | `BoolSetting` (setting.h) | ~30 settings incl. Theme-color toggles, Glass, Shadows | per-setting | Citron 16×16 checkbox / ModernGui row |
| Float (slider) | YES | `NumberSetting` (setting.h) | scales, speeds, opacities, radii, CPS caps | per-setting | Citron 6pt slider + mono value / ModernGui slider |
| Integer | NO (as type) | — | (counts via float+step 1: CPS caps, color slots, density) | — | float slider with step≥1 formatting |
| Enum | YES | `EnumSetting` (setting.h) | positions, modes, themes, colors, animation | per-setting (index) | segmented (2) / dropdown (3+) / cycle |
| Color (RGBA) | YES | `ColorSetting` (setting.h) | accents, crosshair, keystroke cells, custom palette | ARGB hex / floats | swatch → ColorPicker4 popup (+AlphaBar in Citron) |
| Keybind (module) | YES | `Module::m_key` via key()/setKey | every module (0 = unbound) | 0 | chip → global vk scan, ESC clears |
| Keybind (setting) | YES | `Setting::mKey` (bool only dispatched) | bool settings | 0 | middle-click (ModernGui) [Citron path: g_bindSetting exists, set-site [U]] |
| String | YES | `StringSetting` (setting.h) | Watermark text (max 48) | "Nightfull" | text field, caret, Enter commits, maxLength clamp |
| Multi-select | NO | — | — | — | — |
| Button/action | NO (as type) | — | (TextHotkey "+ Add macro" is hardcoded in Citron, not a setting) | — | — |
| Visibility predicate | YES | `Setting::mIsVisible` | Interface customs, search, card rows | `[] { return true; }` | — (drives control presence) |

---

## 31. Final Understanding

Nightfull is a **game-integrated ImGui overlay client**, not a demo: a DLL that hooks `Present`, fuses four input sources, detours ~20 game functions via signature scanning + MinHook, and renders a SystemDLC-style menu (Citron) plus 15+ HUD/ESP widgets through stock ImGui on D3D11-or-D3D12. Its module/setting/menu/HUD architecture is complete and coherent at the seams I could read — but the repository is a **non-compilable flat partial copy**: the entire `utils/` ring (logging, keys, config, easing, fonts, draw helpers, theme engine, math, build info, entity readers, file utils), 8 registered module implementations, MinHook, the injector/watcher, and any build system are absent. The single most important rule for future work: **trust `.cpp` bodies over header comments** (the "never touches the game" comments are fiction), restore the missing rings before adding features, and extend through the existing `Module/Setting/Citron/packethud/overlay-reader` seams rather than creating parallel systems.

---

# WHAT I NOW UNDERSTAND

*(In my own words — every claim below traces to code I read; gaps are marked [U].)*

**How Nightfull is built.** It is a Windows x64 DLL (MSVC, SEH everywhere) injected into Minecraft Bedrock. There is no launcher, no separate process, no retained scene graph: everything the user sees is drawn fresh every frame by immediate-mode code sitting on stock ImGui 1.91.8. The project is organized as concentric rings — game/engine at the bottom (`overlay.*`, `bedrock_entt`), a thin menu shell (`clickgui.*`), two interchangeable GUI renderers (one live, one dead), a data-driven module/setting domain, and a missing utility ring (`utils/*`) whose API I reconstructed purely from call-sites.

**Where its work starts.** `DllMain` does almost nothing by design (loader-lock safety): on attach it spawns one thread and returns; on detach it calls `NotifyDetach`. The spawned thread (`MainThreadImpl`) initializes a critical section, starts a watchdog, logs the game build, installs the ping hook early, waits for `d3d11.dll` and a real game window, builds a throwaway D3D11 swapchain solely to steal the DXGI vtable, patches `Present`/`ResizeBuffers`, and exits — from then on, **the game's own render thread drives everything** through `hkPresent`. ImGui, the module roster, and the config all initialize lazily inside the first presented frames, which is why a re-injected DLL "just works": fresh globals → first frame → `RegisterAllModules` + `config::Load`.

**How systems are created.** There is no DI container, no factory registry, no plugin loading. Systems are created by *calling functions in order*: `ui::ApplyStyle` (fonts+style) → `RegisterAllModules` (roster) → backend `Init` → per-frame `TryInstall*` detours. Cross-cutting state lives in namespace-scope globals and file-local statics (`g_ShowMenu`, `g_pingMs`, ring buffers, `s_actorMap`, animation floats). Singletons exist only where the GUI needs stable handles (`ClickGuiModule::instance`, `InterfaceModule::instance`, `FriendsModule::instance` [U impl], `FlarialSettingsModule::instance` [U impl], `ModuleManager::instance`).

**How modules are created.** A module is a C++ class deriving `Module`, setting its identity in the ctor initializer (`Module("Render","FPS","…")`), declaring settings as member pointers filled by `addSetting<T>(name, description, defaults…, min/max/step or options)`, optionally overriding `on_enable/on_disable/on_tick/on_render`, and being `make_unique`'d into the registry vector. That is the entire protocol — no codegen, no macros, no reflection. Registration order is display order. Enable/disable flips a bool; the guard invokes the callbacks under SEH+timing. Settings own their storage (the module holds raw `XSetting*` into its own `unique_ptr` vector), so a module + its settings serialize, hash, and render generically.

**How settings work.** Five types with value semantics: bool / float-with-step / int-index-into-strings / float-RGBA / length-capped string. Each carries name, description, type tag, an optional keybind, a visibility predicate, and menu animation state. Numbers snap to step; enums wrap; colors convert to `ImColor` and accept ARGB hex; strings clamp length. The GUI renders them generically by type tag (checkbox/slider/segmented-or-dropdown/swatch+popup/text-field), the config hashes them generically by type tag, and visibility predicates (`mIsVisible`) implement all conditional UI (notably the Custom-theme gating). Keybinds attach to modules and bool settings; capture is a global vk-range scan; dispatch happens only with the menu closed inside a world.

**How the GUI works.** `ui::Render` computes one global open/close easing percentage, shapes it per style (Glass/Zoom/Bounce), derives `animation` (fade) and `inScale` (zoom), draws a flat scrim, and hands the frame to `CitronGui::render`. Citron lays out an 1188×700 point design scaled uniformly to the screen, draws sidebar → top bar → page content (module masonry via shortest-column placement, theme/settings/friends pages) with hand-rolled hit-testing (`Ctx::Hover`), then overlays (enum dropdown, search modal, color popup, bind capture) and supports window dragging. All widgets are immediate (`SSD*` functions return "clicked" booleans); persistent state is member floats/flags animated with `gui::Animate`. The dead `ModernGui` proves the shell was designed renderer-agnostic — `ui::Render` could host either engine.

**How rendering works.** The overlay never draws through the game. Each `hkPresent` (D3D11) or `RenderD3D12Frame` (D3D12) builds one ImGui frame: backend NewFrame → display-size sync → fused `UpdateInputState` → `ImGui::NewFrame` → `ui::Render` (which runs module TICK+RENDER *inside* the ImGui frame, so HUD draws interleave with menu draws on shared draw lists) → `ImGui::Render` → backend `RenderDrawData` into the game's backbuffer → chained `oPresent` (with the VSync override applied last). Draw lists used: background (almost everything) + foreground (keystrokes, crosshair, trails, tooltips). No textures, no shaders, no blur — every visual is vector primitives + rasterized TTF text.

**How the HUD works.** Each HUD widget is a module whose `on_render` (a) checks its gate (menu-hidden and/or in-world), (b) pulls data from overlay globals / `game::` readers / ImGui IO / Win32, (c) measures text, (d) draws plates/rows/shapes directly. There is no HUD layout pass, no retained HUD tree, no editor: positions come from 5-corner anchor enums + hardcoded offsets, sizes from per-module scale × global `HudScale()` × `kFontUnit` chains. The Packet engine provides the shared color wheel + UI-unit rows; Pulse helpers provide the plate look; W2S + the actor registry + ring buffers provide the world-anchored ESP/particles/damage numbers.

**How GUI connects to settings.** Directly and synchronously: cards iterate `m->settings()`, filter by `mIsVisible()`, switch on `mType`, and mutate `bs->mValue / ns->mValue / es->setValue / cs->mValue / ss->mValue` in place on click/drag/type. No view-models, no binding layer, no undo: the setting *is* the model, the widget *is* the editor, and the debounced `StateHash`→`config::Save` loop persists whatever the widgets wrote. Module toggles additionally fire guarded `ENABLE/DISABLE` callbacks inline so game-side state (Freelook flags, gamma baseline) follows the checkbox immediately.

**How HUD connects to the renderer.** HUD modules call `gui::FillRect/DrawText/GetTextWidth…` + raw `ImDrawList` APIs during `ui::Render`'s module pass, i.e. between `ImGui::NewFrame` and `ImGui::Render`. Background-list draws sit under ImGui windows (color popups) but over the game; foreground-list draws sit above everything including the menu (trails deliberately visible over the menu). Font pixels come from the TTFs loaded once in `ApplyStyle`; sizes are explicit per call (HUD text ~10–16 px × scale chains), so the HUD has no dependency on ImGui style or DPI — only on `DisplaySize`.

**How Theme connects to UI.** `InterfaceModule` owns the preference data; `ApplyInterfaceSettings()` pushes it into the (missing) `gui_theme` engine every frame; every colored draw pulls `gui::GetThemedColor(phase)` — a time-cycled gradient — unless its module opts out via `m_useTheme=false` into its own `ColorSetting`. Naming styles flow the same way (`ApplyNaming` at every module/setting title). The glass material re-tints palette roles globally. In short: theme is a per-frame push of ~10 values and a per-draw pull of one accent color — simple, total coverage, zero retained theme objects in the GUI layer.

**How input passes through the system.** Four producers (game `Keyboard::feed` detour → 256-bit mirror; external `--watch` counters + 256-bit block via shared memory; in-process poll fallback; raw-input capture) fuse into one per-frame snapshot (`keys::BeginFrame`, `UpdateInputState`) that feeds ImGui IO, menu hit-testing, text fields, bind capture, and keybind dispatch. Three independent consumers toggle the menu (feed branch, watcher-delta branch, poll branch for K/INSERT; ESC closes; END unloads). While the menu is open, up to three blockers stack so the game never sees the input: feed-detour swallowing, raw-input neutralization (mouse preserved for ImGui), and the watcher's global low-level masks — arbitrated by `menuOpen/keyhookOn` flags so they never double-swallow. Module/bool keybinds fire only when the menu is closed *and* the player is in a world *and* no chat screen owns the keyboard.

**Where the main extension points are.** New HUD widget → new `Module` subclass + `on_render` + registry line (reuse `packethud`/Pulse helpers/`overlay::` readers). New menu page → new `TAB_*` + page builder in `CitronGui::render` (reuse `Ctx`/`SSD*`/scroll/fade/scrollbar patterns). New setting type → `SettingType` + subclass + GUI row + hash case (all four switch-sites are explicit). New game data → new `TryInstall*` + signature + global/ring + reader in `overlay.*` (follow the attack/ping/baseTick templates incl. tried-once flags + null-degrade + SEH). New theme behavior → `InterfaceModule` setting + `gui_theme` push/pull (impl missing — must be restored first). New persistence → `config::Save/Load` + `StateHash` case (impl missing). Everything routes through existing seams; nothing requires a parallel system.

---

## APPENDIX A — Reconstructed API of missing `utils/` (from call-sites; impls [U])

- `utils/logger.h`: `LOG_INFO/LOG_ERROR(fmt, ...)` (printf-style; used in overlay/clickgui/citron/modern/guard).
- `utils/keys.h`: `BeginFrame/Reset/PressedThisFrame(vk)/Down(vk)/Name(vk)/TextInput(buf,len,active)`; polled `PollKeyDown` lives in overlay.cpp.
- `utils/config.h`: `Save/Load/Path()->string`, `struct PanelPos{x,y,extended}`; JSON format [U schema].
- `utils/easing.h`: `gui::EasingUtil` with `incrementPercentage/decrementPercentage/isPercentageMax/easeOutCubic/easeOutExpo/easeOutElastic/easeOutBack`.
- `utils/fonts.h`: `LoadFonts/CurrentFont/IconFont/UIFont/DisplayFont/MonoFont/SetFontOverride`.
- `utils/gui_render.h`: `FillRect/FillShadowRect/FillGradient/FillRoundedGradient/FillCircle/DrawText/GetTextWidth/GetTextHeight/GetScreenSize/GetMousePos/GetDeltaTime/IsMouseOver/Clamp/Lerp/LerpColor/Animate/ScaleToPoint/RectH/RectW`, const `kFontUnit`.
- `utils/gui_theme.h`: `SetTheme/SetNamingStyle/SetCustomColorCount/SetCustomColor/SetColorSpeed/SetSaturation/GetThemedColor(phase)/ApplyNaming/PaletteSwatch`.
- `utils/math.h`: unknown contents [U] (included by pch.h; no direct call-site identified).
- `utils/build_info.h`: unknown contents [U] (included by visual_modules.cpp; no call-site identified).
- `utils/entity_registry.h`: `namespace game::{ActorReadStateVector/ActorReadName/ActorReadHealth/ActorReadAabb}` (+ `CritLocalPlayerPtr`? [U — seen used in overlay.cpp:1961 `CritLocalPlayerPtr`, may live in overlay.cpp itself]).
- `utils/file_utils.h`: `file_utils::RoamingStatePathW()` (options.txt discovery for JavaHotkeys).

## APPENDIX B — Detour inventory (all [R] by name; install verified for MinHook ones listed)

MinHook detours: `hkGuiDataMessage, hkUpdateScreenSize, hkGamma, hkGetViewPerspective, hkUpdateFromCamera, hkGetAveragePing, hkSetupAndRender, hkGetTexture, hkGameModeAttack, hkContainerSlotHovered, hkKeyboardFeed, hkMouseFeed, hkGetRawInputData, hkGetRawInputBuffer, hkShowCursor, hkActorBaseTick` (+`hkDrawImage` via MUIRC vtable[7] patch). Vtable patches: `hkPresent, hkResizeBuffers, hkExecCmdLists`. Subclass: `WndProc`. Seen-by-name-only [U]: `hkClipCursor, hkSetCapture, hkSetCursorPos`.

## APPENDIX C — Signature/version coverage [R from comments + scan sites]

Primary target **1.21.111**; individual signatures cite 1.21.101/1.21.11x/1.21.110/1.21.13x/1.21.131/1.21.130/1.21.50/1.21.40/1.21.30 fallback lines; 15 `ScanSignature(game,…)` sites + uniqueness-gated `ScanSignatureMatches` for `setupAndRender` and `UIControl::getPosition`; `baseTick` via Actor-vtable pattern + slot 25; `createPacket` via Flarial 1.21.11x pattern.

---

```text
SOURCE ANALYSIS COMPLETE

I have analyzed the provided Nightfull source code and mapped:
- architecture
- initialization
- modules
- settings
- GUI
- HUD
- rendering
- events
- input
- configuration
- dependencies
- data flow
- important classes and methods

No source files were modified during this analysis.

I am ready for the next task.
```
