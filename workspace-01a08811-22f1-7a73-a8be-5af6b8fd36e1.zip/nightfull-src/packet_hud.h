// packet_hud.h - shared Packet V2 HUD drawing engine.
//
// Port of the HUD drawing machinery from PacketV2 (_ref_packetv2/Client/
// Memory/Hooks.cpp): the shared rainbow / dynamic colour state, the static
// palette, and the Packet "black box + coloured text" HUD row style used by
// its FPS / Speed / Position rows and the Watermark.
//
// Packet's DrawUtils operate in Minecraft UI units (text size 1.0 ~ 10 px);
// our ImGui font unit is 18 px, so every Packet absolute constant is written
// in UI units here and converted with Unit() at draw time. That keeps the
// proportions 1:1 with the original client.
//
// NOTE: ASCII only in this file.

#pragma once

#include <string>
#include <vector>

#include "imgui.h"

namespace packethud {

// Our enum index (0..11) -> Packet's HudModule colour value (Packet's enum
// skips 10). Entries: Rainbow, Dynamic, Horion, Fadeaway, White, Red, Orange,
// Yellow, Green, Blue, Purple, Pink.
int Sel(int enumIndex);
const std::vector<std::string>& ColorNames();

// Advance the shared rainbow wheel + dynamic gray wave once per ImGui frame.
// Packet updates these once per frame in RenderText (Hooks.cpp); both the
// Watermark and the HUD rows read the same shared state.
void Frame();

// Resolve a scheme colour to 0..1 RGBA. Rainbow -> the shared wheel value,
// Dynamic -> the gray wave, everything else -> the fixed palette colour.
ImVec4 Color(int packetSel);

// --- unit helpers -----------------------------------------------------------
float   Unit();                                            // pixels per UI unit
ImVec2  P(float x, float y);                               // units -> pixels
ImVec4  R(float x, float y, float z, float w);             // rect in units
float   TextWidthU(const std::string& text, float size);   // measured width, units

// Packet's DrawUtils::drawText: pos in units, shadow = colour/6 offset.
void Text(ImVec2 posU, const std::string& text, const ImVec4& color,
          float size, float alpha, bool shadow);
// Packet's DrawUtils::fillRectangle (rect in units).
void Fill(const ImVec4& rectU, const ImVec4& color, float alpha);

// One PacketV2 HUD row (Hooks.cpp:838-848), text only: the scheme-coloured
// text at (x + 2, rowY + 3.5), size 1, no shadow. xU/rowYU are already scaled
// by the caller's scale factor.
void HudRow(const std::string& text, float xU, float rowYU,
            int packetSel, float scale);

// Width of the HUD row box in units (for right-aligned placement).
float HudRowWidthU(const std::string& text, float scale);

} // namespace packethud
