# Rendering API Blueprint — концептуальный слой нашего клиента

Статус: **[PROPOSAL]** — спроектировано по итогам анализа Flarial / Solstice / Borion-OSS.
Названия — предложения, не обязательства. Никаких предположений о текущем src не делается.

Принципы, вынесенные из исходников:
1. **Три render path** (World3D / UI2D / Overlay) — независимые точки входа, общий frame data.
2. **FrameSnapshot один за кадр** — матрица+origin+fov+время собираются в одном месте.
3. **События с отменой** для перехвата поведения игры; прямые вызовы — для рисования.
4. **Весь доступ к игре — через адаптеры**, чтобы version-specific код жил в одном слое.

---

## 1. Компоненты blueprint

### 1.1. `FrameSnapshot` (данные кадра)
- **Ответственность:** единый снимок состояния рендера на кадр. Аналог `FrameTransform` (Flarial/Solstice).
- **Вход:** viewMatrix, origin, playerPos, fov, screenSize, lerpT, tickTime, currentScreen.
- **Выход:** структура, доступная всем рендерерам (по значению/const-ref).
- **Зависимости:** GameAdapter (ClientInstance/LevelRenderer/GuiData).
- **Где вызывается:** собирается в render-хуке (`setupAndRender`), раздаётся через очередь (overlay) и напрямую (world/UI пути).
- **Используют:** WorldToScreen, Renderer2D/3D, ParticleRenderer, HUD.

### 1.2. `WorldToScreen`
- **Ответственность:** чистая функция `bool project(world, &screen)` + батч-версия для 8 точек AABB.
- **Вход:** `vec3 world`, `FrameSnapshot`.
- **Выход:** `vec2 screen` / `false` (за камерой).
- **Зависимости:** только FrameSnapshot. Никакого прямого доступа к игре.
- **Где вызывается:** overlay-поток и UI-путь (там, где есть snapshot).
- **Используют:** ESP, Tracers, Nametags, HUD-маркеры, 2D-боксы.

### 1.3. `Renderer3D` (world-space, через Tessellator игры)
- **Ответственность:** линии/боксы/квады в мировых координатах.
- **Вход:** мировые `vec3`/AABB, цвет RGBA, толщина/флаги; `LevelRender* + ScreenContext* + Material*`.
- **Выход:** draw calls в Tessellator игры (немедленный flush).
- **Зависимости:** GameAdapter (tessellator/material функции), FrameSnapshot.origin.
- **Где вызывается:** ТОЛЬКО внутри `renderLevel`-хука (колбэк `onWorldRender`), после `begin` до возврата в оригинал.
- **Используют:** Hitbox3D, Tracers3D, BlockESP, TrailRenderer, ChinaHat-подобные эффекты.
- **Примитивы (минимум):** `line(a,b)`, `boxEdges(aabb)`, `boxFilled(aabb)`, `quad(a,b,c,d)`, `flush()`.

### 1.4. `Renderer2D` (screen-space)
- **Ответственность:** пиксельные примитивы поверх кадра. Две реализации за одним интерфейсом: `GameTessellator2D` (путь B) и `Overlay2D` (путь C, ImGui/D2D).
- **Вход:** экранные координаты, цвет, толщина; текст/текстуры делегируются.
- **Выход:** draw calls выбранного бэкенда.
- **Зависимости:** FrameSnapshot (размер экрана), бэкенд (MUIRC / ImGui context).
- **Где вызывается:** UI-путь — в `setupAndRender`-событии; Overlay — в `RenderEvent` из Present.
- **Используют:** ESP2D, HUD, Nametags, Tracers2D, GUI, Notifications.
- **Примитивы (минимум):** `line`, `rect` (outline+filled), `circle`, `gradientRect`, `roundedRect` (может собираться из базовых).

### 1.5. `TextRenderer`
- **Ответственность:** «нарисовать/замерить строку» независимо от бэкенда.
- **Вход:** строка, позиция, размер, цвет, выравнивание, стиль (тень/обводка).
- **Выход:** текст на экране; метрики (`measure(text, size) -> w/h`).
- **Зависимости:** бэкенд (игровой шрифт / ImGui font / D2D).
- **Где вызывается:** везде, где есть Renderer2D того же бэкенда (текст и фигуры должны быть в одной системе координат!).
- **Используют:** Nametags, HUD, Notifications, ClickGUI, FloatingText.

### 1.6. `TextureRenderer`
- **Ответственность:** загрузка/кэш/отрисовка текстур (файлы + игровые предметы).
- **Вход:** путь к файлу / ItemStack / BedrockTextureData, rect, opacity.
- **Выход:** текстура на экране.
- **Зависимости:** GPU device Present-потока (свои файлы) / ItemRenderer игры (предметы).
- **Где вызывается:** overlay (файлы), UI-путь (предметы).
- **Используют:** HUD (броня/предметы), ClickGUI (иконки), TabList (головы), Notifications.

### 1.7. `ParticleRenderer` + `ParticleManager`
- **Ответственность:** Manager — спавн/обновление/время жизни кастомных частиц; Renderer — отрисовка (через Renderer3D для world-частиц, Renderer2D для screen-частиц).
- **Вход:** событие спавна (entity/event/позиция), параметры (скорость, жизнь, размер, цвет, гравитация).
- **Выход:** обновлённый пул частиц; draw calls.
- **Зависимости:** Renderer3D/Renderer2D, FrameSnapshot (deltaTime), RNG.
- **Где вызывается:** update — в tick/render-событии; render — в `onWorldRender` (3D) или `RenderEvent` (2D).
- **Используют:** HitParticles, Trails, FloatingIndicators, ambient-эффекты.
- **Отдельно:** `GameParticleBridge` — спавн игровых частиц через `Level::addParticleEffect` (тип из ParticleType-таблицы, позиция, направление).

### 1.8. `RenderState`
- **Ответственность:** инкапсуляция состояний, которыми мы управляем: текущий цвет (colorHolder), выбранный материал, бленд/глубина (там, где контролируем), save/restore обёртки.
- **Вход:** запросы рендереров.
- **Выход:** гарантирует «после нашего рендера состояние как до».
- **Зависимости:** бэкенд (MUIRC/DX).
- **Где вызывается:** вокруг каждого нашего draw-пакета (RAII-гарды).
- **Используют:** все рендереры.

### 1.9. `Camera`
- **Ответственность:** чтение камеры игры + вычисляемые удобные значения (forward/right/up векторы, углы).
- **Вход:** GameAdapter (ClientInstance/LevelRenderer).
- **Выход:** viewMatrix, origin, fov, direction vectors.
- **Зависимости:** GameAdapter.
- **Где вызывается:** при сборке FrameSnapshot; напрямую — для aim/поворотов (не рендер).
- **Используют:** FrameSnapshot, WorldToScreen (через snapshot), модули.

### 1.10. `EntityAccess`
- **Ответственность:** единый доступ к сущностям: локальный игрок, список актёров, фильтры.
- **Вход:** предикаты (игроки/мобы/живность, дистанция, видимость).
- **Выход:** `LocalPlayer`, `forEachEntity(filter, cb)`, `getEntityList()`.
- **Зависимости:** GameAdapter (Level/регистр/регион — version-specific внутри).
- **Где вызывается:** render-колбэки и tick.
- **Используют:** все entity-фичи. Правило: callback (`ent, isNew`) + дедупликация, как у Borion.

### 1.11. `GuiFramework`
- **Ответственность:** окна/виджеты/лейаут/анимации поверх Renderer2D+TextRenderer+TextureRenderer.
- **Вход:** input-события (мышь/клавиатура), состояние настроек.
- **Выход:** отрисованный UI; изменённые значения настроек.
- **Зависимости:** Renderer2D, TextRenderer, TextureRenderer, InputEvents, Config (вне scope blueprint).
- **Где вызывается:** overlay `RenderEvent` (рекомендуется) — курсор/клик уже там.
- **Используют:** ClickGUI, HUD-редактор, Notifications.

### 1.12. `GameAdapter` (слой изоляции версий)
- **Ответственность:** ВСЕ прямые вызовы игры: сигнатуры, оффсеты, vtable-индексы, вызовы `renderMeshImmediately/tess_vertex/createUI`, чтение `ClientInstance/Level/GuiData`.
- **Вход:** запросы верхних слоёв.
- **Выход:** типизированные безопасные функции.
- **Зависимости:** только игра.
- **Где вызывается:** везде снизу — но только через него.
- **Используют:** все вышеперечисленные. Правило: за пределами GameAdapter нет ни сигнатур, ни оффсетов, ни `reinterpret_cast` по памяти игры.

### 1.13. `Math`
- **Ответственность:** vec2/vec3/vec4, матрица 4x4, AABB, цвета, lerp, углы, RNG-хелперы.
- **Зависимости:** нет (header-only, можно glm).
- **Используют:** все.

---

## 2. Схема зависимостей

```
                    ┌─────────────┐
                    │    Game     │  (игра: мир, entity, камера, DX)
                    └──────┬──────┘
                           │ только через адаптер
                    ┌──────▼──────┐
                    │ GameAdapter │  sigs/offsets/vtables/material funcs
                    └──┬───┬──┬───┘
        ┌──────────────┘   │  └──────────────┐
        ▼                  ▼                 ▼
  EntityAccess      Camera/FrameSnapshot   Hooks/Events
        │                  │                 │
        └────────┬─────────┴────────┬────────┘
                 ▼                  ▼
          WorldToScreen        RenderState
                 │                  │
        ┌────────┼─────────┬────────┼─────────┐
        ▼        ▼         ▼        ▼         ▼
   Renderer3D Renderer2D TextRenderer Texture Particle(M+R)
        │        │         │        │         │
        └────────┴────┬────┴────────┴─────────┘
                      ▼
              Features / GuiFramework
              (Hitbox/Tracer/HUD/ClickGUI/...)
```

---

## 3. Минимальный Rendering Core

### Required (без этого визуальные фичи невозможны)
| # | Компонент | Почему required (доказательство исследованием) |
|---|---|---|
| R1 | Render hook (минимум 1 путь) | Все клиенты начинают с хука; без точки входа рисовать негде |
| R2 | FrameSnapshot (matrix+origin+fov+screen) | Все W2S/ESP трёх клиентов зависят от этой четвёрки |
| R3 | WorldToScreen | ESP/Nametag/Tracer/HUD-маркеры невозможны без проекции |
| R4 | EntityAccess (local + list + AABB) | Все entity-фичи итерируют список и читают AABB/позицию |
| R5 | Renderer2D минимум (line/rect/fill) | 2D-боксы, HUD, весь текст живут в screen-space |
| R6 | Renderer3D минимум (line/box) | Хитбоксы/трейсеры в мире — через Tessellator |
| R7 | GameAdapter-заготовка | Без изоляции версий первый же апдейт игры ломает всё |
| R8 | Событие/колбэк рендера | Точка, куда фичи подписывают отрисовку (`RenderEvent`/`onPreRender`) |

### Useful (сильно ускоряет разработку)
| # | Компонент | Почему useful |
|---|---|---|
| U1 | TextRenderer (draw+measure) | Nametags/HUD/GUI без замера текста — костыли |
| U2 | RenderState RAII-гарды | Защита от «сломали состояние игры» — класс ошибок из ТЗ §16 |
| U3 | Второй render path | World3D+Overlay покрывают 95% фич; один путь — компромиссы |
| U4 | Input events (key/mouse) | Бинды модулей, ClickGUI, drag/scroll |
| U5 | Lerp/interp времени (lerpT) | Плавные боксы/трейсеры вместо дёргания по тикам |
| U6 | TextureRenderer (файлы) | Иконки/логотипы/головы для GUI и HUD |
| U7 | Screen-name фильтр | Рендерить HUD только на `hud_screen` (все клиенты так делают) |
| U8 | GameParticleBridge | Дешёвые красивые эффекты силами самой игры |

### Optional (позже)
| # | Компонент | Почему optional |
|---|---|---|
| O1 | ParticleManager кастомный | Нужен только для своих систем (trails, floating indicators) |
| O2 | GuiFramework полный | ClickGUI — отдельная большая задача; HUD живёт без него |
| O3 | Rounded/gradient/blur примитивы | Собираются из базовых; блюр требует backbuffer-менеджмента |
| O4 | Font atlas свой | Игровой шрифт/ImGui покрывают старт |
| O5 | Model/bone rendering | Перехват `ActorRenderDispatcher` — продвинутый уровень |
| O6 | D3D12-нативный путь | D3D11On12/фолбэк покрывают старт (как у Solstice) |
| O7 | VSync/Resize менеджмент | Полировка после стабильного рендера |

---

## 4. Feature → Dependency Map

Условные обозначения: `→` зависит от; `(R/U/O)` — класс компонента из §3.

### Entity Hitbox (3D)
```
EntityAccess(R4: list+filter) → AABB (компонент) → FrameSnapshot(R2: origin)
→ Renderer3D(R6: boxEdges/boxFilled) → RenderState(U2: материал+цвет)
→ [опц.] TextRenderer(U1: дистанция/имя]
Вызывается в: onWorldRender (renderLevel-хук).
```

### Entity Hitbox (2D outline)
```
EntityAccess → AABB → 8 углов → WorldToScreen(R3)×8 → выпуклый обход
→ Renderer2D(R5: line) → [опц.] заливка полигона
Вызывается в: RenderEvent (overlay) или SetupAndRender-событие (UI-путь).
```

### Tracer (линия к entity)
```
EntityAccess → Position (renderPos, U5 lerp) → Вариант A: WorldToScreen → Renderer2D.line
→ Вариант B: Renderer3D.line (мировые координаты)
Вызывается в: overlay/UI (A) или onWorldRender (B).
```

### Nametag (кастомный)
```
EntityAccess → Position+AABB.upper → WorldToScreen → TextRenderer(U1: draw+measure для центрирования)
→ [опц.] Renderer2D.фон-подложка → [опц.] TextureRenderer(U6: голова/иконка)
Вызывается в: overlay. Альтернатива: хук renderNameTags (O5).
```

### Tracers к блоку / BlockESP
```
BlockSource/ picking (блок под прицелом или координатные) → AABB блока → как Hitbox 3D/2D
+ Xray-вариант: BlockLegacy::getRenderLayer хук (категория «перехват поведения», не рисование).
```

### Particles (игровые, дешёвые)
```
Событие-триггер (хит/тик/модуль) → GameParticleBridge(U8: addParticleEffect)
→ Параметры: ParticleType, pos, dir. Рендерит сама игра.
```

### Particles (кастомные: trails, hit-sparks, floating)
```
Событие-триггер → ParticleManager(O1: spawn, пул) → Update (U5 deltaTime, гравитация, fade)
→ Renderer3D (world) / Renderer2D (screen) → RenderState (alpha-blend)
Вызывается в: update — tick/render; render — onWorldRender / RenderEvent.
```

### FloatingText / DamageIndicator
```
Событие (урон) → позиция + текст + TTL → Update (подъём, fade) → WorldToScreen каждый кадр
→ TextRenderer. Вызывается в: overlay.
```

### HUD (координаты/FPS/броня/эффекты)
```
GameData (позиция, FPS, инвентарь, эффекты) → HUD Manager (лейаут, вкл/выкл)
→ Renderer2D + TextRenderer → [опц.] TextureRenderer (иконки брони U6)
Вызывается в: RenderEvent + фильтр hud_screen (U7).
```

### ArrayList / Watermark / TabGUI
```
ModuleManager (список включённых) → сортировка/лейаут → Renderer2D + TextRenderer.
Вызывается в: overlay (Flarial/Solstice) или onPreRender/onPostRender (Borion).
```

### Notifications
```
Событие → очередь (текст, иконка, TTL, анимация slide/fade) → Renderer2D + TextRenderer.
Вызывается в: overlay RenderEvent (после модулей).
```

### Crosshair (кастомный)
```
Середина экрана (FrameSnapshot.screen/2) → Renderer2D.line / TextureRenderer.
Перехват игрового: drawImage-событие или ui_crosshair-материал. Вызывается в: overlay.
```

### ClickGUI
```
Input(U4: mouse move/click/wheel, key) → GUI State (открыт/закрыт, фокус, активный виджет)
→ Widgets (кнопки/тоглы/слайдеры/дропдауны/колорпикеры) → Layout
→ Renderer2D + TextRenderer + TextureRenderer(U6) → Анимации (U5 deltaTime)
→ Перехват ввода: отмена Mouse/Key событий для игры, пока открыто.
Вызывается в: overlay RenderEvent (поверх: ForegroundDrawList у Solstice).
```

### FullBright / Gamma / FOV / Zoom
```
Не рисование, а перехват: GetGamma хук / getFov хук → вернуть своё значение.
Зависимости: только Hooks. (Пример «поведенческого» модуля без рендера.)
```

### BoneESP / Chams (продвинутое, O5)
```
ActorRenderDispatcher хук (O5) → скрыть/перекрасить модель → свой рендер костей через Renderer3D.
Зависимости: R1(хук render)+R2+R6+ скелетные данные актёра (бэклог: структуры костей не изучены).
```

---

## 5. Rendering Lifecycle (один кадр)

### 5.1. Проверенная цепочка [C — порядок хуков подтверждён, точные границы потоков частично I]

```
┌─ GAME TICK (20 Hz, game thread) ──────────────────────────────┐
│ Actor::tick / Level::tick / GameMode::tick                    │
│ → модули: onTick / TickEvent (логика, НЕ рисование)           │
└───────────────────────────┬───────────────────────────────────┘
                            ▼
┌─ WORLD RENDER (render thread) ────────────────────────────────┐
│ RenderChunkCoordinator (чанки)                                │
│ ActorRenderDispatcher::render ×N (модели; перехват O5)        │
│ LevelRenderer::renderLevel ──▶ ХУК RENDERLEVEL                │
│   ├─ Flarial: trigger Render3DEvent(level, scn) → OUR 3D      │
│   │   → оригинал                                              │
│   └─ Borion: оригинал → onLevelRender → OUR 3D → сброс ctx    │
└───────────────────────────┬───────────────────────────────────┘
                            ▼
┌─ UI RENDER (render thread) ───────────────────────────────────┐
│ ScreenView::setupAndRender ──▶ ХУК SETUPANDRENDER              │
│   ├─ собрать FrameSnapshot {matrix, origin, fov} → очередь    │
│   ├─ Borion: setCtx → onPreRender → OUR UI-2D → flush         │
│   ├─ оригинал (MUIRenderContext: drawText/drawImage...)       │
│   │    └─ в-table хуки: DrawText/DrawImage-события            │
│   └─ Borion: onPostRender → OUR UI-2D поверх → flush           │
│      Flarial/Solstice: SetupAndRenderEvent(muirc)              │
└───────────────────────────┬───────────────────────────────────┘
                            ▼
┌─ PRESENT (present/DX thread) ─────────────────────────────────┐
│ IDXGISwapChain::Present ──▶ ХУК PRESENT                       │
│   ├─ RenderSync: очередь → Transform (с задержкой)            │
│   ├─ D2D::BeginDraw + ImGui::NewFrame                         │
│   ├─ trigger RenderEvent ──▶ OUR OVERLAY (ESP/HUD/ClickGUI)   │
│   ├─ ImGui::Render → RenderDrawData → RTV                     │
│   └─ оригинал Present → экран                                 │
└───────────────────────────────────────────────────────────────┘
```

### 5.2. Что НЕ установлено точно [U]
- Точное соответствие потоков (render thread vs game thread для `setupAndRender`) — косвенно подтверждено очередью с мьютексом, но нужны измерения.
- Вызывается ли `renderLevel` до или параллельно с чанками/актёрами — порядок внутри world render не восстанавливался.
- Частота Present относительно render (VSync on/off меняет картину).
- Где именно живут `Keyboard::feed`/`MouseDevice::feed` (скорее всего отдельный input/window thread).

### 5.3. Правила для наших фич (вывод из lifecycle)
1. **Не читать entity из Present-потока** — только из render-хуков или tick; в overlay передавать готовые screen-координаты/тексты (или snapshot + аккуратное чтение).
2. **3D — только в renderLevel-окне**, 2D-overlay — только в Present-окне, UI-2D — только в setupAndRender-окне.
3. **Тяжёлые вычисления — в tick**, рендер-колбэки должны быть дешёвыми (иначе просадка FPS всего Present).

---

## 6. Граница «Minecraft ↔ наш клиент» [PROPOSAL по итогам исследования]

### Предоставляет Minecraft (мы только читаем/вызываем)
| Данные/сервис | Через что | Version-specific? |
|---|---|---|
| Мир, чанки, блоки | BlockSource, Level | Да (оффсеты) |
| Сущности и компоненты | EntityContext/entt, Actor API | Да |
| Камера (матрица, origin, fov) | ClientInstance, LevelRenderer | Да |
| Tessellator + материалы | ScreenContext, RenderMaterialGroup | Да (сигнатуры) |
| UI-контекст (текст/картинки) | MUIRenderContext vtable | Да |
| Swapchain + DX device | IDXGISwapChain | Нет (стабильный DX API) |
| Игровые частицы/звуки | Level::addParticleEffect и др. | Да (vtable idx) |
| Шрифты | MinecraftGame fonts | Да |
| Ввод (клавиатура/мышь) | Keyboard/Mouse feed | Да (сигнатуры) |
| Экран/разрешение | GuiData | Да |

### Реализует наш клиент
| Компонент | Почему наш |
|---|---|
| Feature logic (ESP/HUD/модули) | Этого нет в игре |
| Rendering abstraction (Renderer2D/3D/...) | Единый API поверх 3 путей |
| WorldToScreen | Чистая математика (стабильна) |
| FrameSnapshot + очереди | Синхронизация потоков — наша забота |
| Event bus / module dispatch | Архитектура клиента |
| GUI framework + виджеты | Свои окна/настройки |
| ParticleManager кастомный | Свои системы частиц |
| TextureCache (файлы) | Свои ассеты |
| Config/настройки | Персистентность |
| Keybinds | Связка input→модули |

### Серая зона (решает GameAdapter)
Сигнатуры, оффсеты, vtable-индексы, версии структур, имена материалов, имена экранов — всё это «знания об игре», живут в одном изолированном слое и обновляются отдельно от логики.
