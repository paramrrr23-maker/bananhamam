# TextHotkeys R15: исправление под Minecraft Bedrock 1.21.111

## Причина из лога

В последней сессии R14: `chat-packet: createPacket sig matches=0`.
Клавиша обрабатывалась, но фабрика пакетов не находилась, после чего отправка
оставалась отключённой. В R14 использовались сигнатура от 1.21.130 и смещения
отправителя `0x1C8/0x1D0/0x1D8/0x1E0`, не соответствующие таблице 1.21.11X.

## Что изменено

- Сигнатура `MinecraftPackets::createPacket` из `SigInit::init21110`.
- Отправитель: `ClientInstance+0xF8`, как в наследуемой таблице Flarial;
  `sendToServer` в виртуальном слоте 2. Соседние поля не угадываются.
- Путь: фабрика пакета 9, проверка ID и структуры TextPacket, имя игрока,
  текст, тип CHAT, пустые xuid/platformId, translationNeeded=false,
  sendToServer. Никаких PostMessage/SendInput.
- Настоящий MSVC `std::shared_ptr` вместо намеренной утечки каждого пакета.
  Строки меняются через std::string::assign/clear.
- Чтение короткого имени в динамической памяти исправлено: режим хранения
  определяется capacity, а не length; добавлена проверка размера буфера.
- Отсутствие ClientInstance/игрока/отправителя не отключает модуль навсегда.
  Поиск сигнатуры повторяется не чаще раза в 5 секунд по нажатию.
- Интервал 2,5 секунды после передачи пакета игре, как у Flarial TextHotkey.
  Нажатия во время интервала отбрасываются, не ставятся в очередь.
- Лимит: 400 байт UTF-8 вместо скрытого порога 256 байт.
- Native SEH и C++ RAII разнесены по функциям для `/EHsc`.
  Поздние `NF_GUI_TRY/NF_GUI_EXCEPT` не используются.
- build.bat выводит `Nightfull_R15.dll`, а не R13; объектные файлы отдельные,
  в `build/obj_r15`.

Изменены только `src/overlay/overlay.cpp` и `build.bat`; добавлены этот документ
и `tests/text_hotkeys_r15_regression.py`. Остальные модули и настройки не менялись.
В экспортированном архиве один проект: старая вложенная копия `Nightfull_src`
и её DLL/объектные файлы не включены. Исходный архив не изменён.

## Сборка и проверка

1. Распаковать R15 в новую папку, не поверх предыдущих сборок.
2. Запустить корневой `build.bat` с установленным MSVC x64 и Windows SDK.
3. Перезапустить Minecraft, затем загрузить `build/Nightfull_R15.dll`.
   Сохранить папку fonts рядом с DLL.
4. В начале лога должна быть метка `r15-texthotkey-21111-20260927`.
5. Зайти в мир, задать слот TextHotkeys с клавишей и обычным текстом,
   закрыть меню, нажать клавишу. Подпись Name может быть пустой.
6. Ожидается `resolved 1.21.11X ... sender=ClientInstance+0xF8`,
   затем `submitted TextPacket id=9 ...`.
   Повторять не раньше чем через 2,5 секунды.

`submitted` означает возврат из функции отправки игры, не подтверждение доставки
сервером. Ограничения сервера, mute и антиспам этот код не обходит.
Как у Flarial TextHotkey, передаётся TextPacket; CommandRequestPacket не добавлен.
Обработка `/команд` сервером этим исправлением не гарантируется.

Таблица: 1.21.11X (целевая версия из лога: 1.21.111). Для 1.21.120, 1.21.130
и неизвестной версии отправка отключается с пояснением. Нужен MSVC x64 Release;
MinGW не может использовать MSVC STL ABI.

## Проверки и ограничения

Регрессионный тест извлекает изменённые функции из overlay.cpp и запускает их
на C++ test doubles с AddressSanitizer и UndefinedBehaviorSanitizer:
сигнатура, повторные попытки, offset отправителя, время ожидания, границы строк,
UTF-8, владение пакетом, ошибки, смена мира и блокировка ввода.
Запуск: `python tests/text_hotkeys_r15_regression.py` при наличии g++.
SEH моделируется C++ исключением, MSVC std::string отдельной моделью;
это не проверка настоящего Windows ABI.

Полная сборка DLL в MSVC и запуск в Minecraft здесь не выполнены:
в среде нет Windows SDK, Visual Studio и игры. Совпадение сигнатуры с конкретным
Minecraft.Windows.exe, работа ABI/SEH и доставка требуют проверки на твоём ПК.
Сбой AABB sampler из лога этим патчем не исправлялся.

## Источники

Flarial используется как технический ориентир; адаптер написан для Nightfull.
Лицензия репозитория Flarial: AGPL-3.0.

- [TextHotkey](https://github.com/flarialmc/dll-oss/blob/40ad1870efd021138241192894cfbfacef1aefa5/src/Client/Module/Modules/TextHotkey/TextHotkey.cpp)
- [Сигнатуры 1.21.11X](https://github.com/flarialmc/dll-oss/blob/aeaef8243bf1150fe8b233488c4eccba810542c1/src/Utils/Memory/Game/Sig/SigInit.cpp)
- [Смещения 1.21.11X](https://github.com/flarialmc/dll-oss/blob/aeaef8243bf1150fe8b233488c4eccba810542c1/src/Utils/Memory/Game/Offset/OffsetInit.cpp)
- [TextPacket 1.21.11X](https://github.com/flarialmc/dll-oss/blob/aeaef8243bf1150fe8b233488c4eccba810542c1/src/SDK/Client/Network/Packet/TextPacket.hpp)
- [SDK::createPacket](https://github.com/flarialmc/dll-oss/blob/40ad1870efd021138241192894cfbfacef1aefa5/src/SDK/SDK.cpp)
- [LoopbackPacketSender](https://github.com/flarialmc/dll-oss/blob/40ad1870efd021138241192894cfbfacef1aefa5/src/SDK/Client/Network/Packet/LoopbackPacketSender.hpp)

Подключение GitHub недоступно; использованы публичные страницы репозитория.
[Справка по подключению GitHub](https://help.clickup.com/hc/en-us/articles/6305771568791).
