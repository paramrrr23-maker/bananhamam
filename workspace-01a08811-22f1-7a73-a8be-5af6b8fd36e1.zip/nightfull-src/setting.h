// setting.h - module settings, ported from Solstice's Features/Modules/Setting.hpp.
//
// A setting is a named, described value owned by a module and rendered by the
// ClickGUI. Four kinds exist, exactly like in Solstice:
//   Bool   - on/off switch, optionally bound to a key
//   Number - float with min/max/step, rendered as a draggable slider
//   Enum   - one-of-many, rendered as a collapsible dropdown
//   Color  - RGBA, rendered as a swatch that opens a picker
//
// The per-setting animation fields (sliderEase, boolScale, enumSlide, ...) are
// part of the port too: Solstice keeps them on the setting so the animation
// survives across frames.
//
// Settings hold plain local values only - nothing here touches the game.
//
// NOTE: ASCII only in this file.

#pragma once

#include <string>
#include <vector>
#include <functional>
#include <cmath>

#include "imgui.h"

namespace modules {

enum class SettingType {
    Bool,
    Number,
    Enum,
    Color,
    String,
};

class Setting {
public:
    Setting(std::string name, std::string description, SettingType type)
        : mName(std::move(name)), mDescription(std::move(description)), mType(type) {}

    virtual ~Setting() = default;

    std::string  mName;
    std::string  mDescription;
    SettingType  mType;

    // Optional predicate: hidden settings are skipped by the GUI.
    std::function<bool()> mIsVisible = []() { return true; };

    // --- per-setting animation state (kept across frames) ---
    float sliderEase   = 0.0f;  // Number: eased slider position
    float boolScale    = 0.0f;  // Bool: 0..1 toggle animation
    bool  isDragging   = false; // Number: slider being dragged
    bool  enumExtended = false; // Enum: dropdown open
    float enumSlide    = 0.0f;  // Enum: dropdown open animation

    // Key the setting is bound to (0 = unbound). Handled by the GUI.
    int  mKey = 0;
};

// ------------------------------------------------------------------ Bool ---
class BoolSetting : public Setting {
public:
    BoolSetting(std::string name, std::string description, bool value)
        : Setting(std::move(name), std::move(description), SettingType::Bool),
          mValue(value) {}

    bool mValue = false;

    void setValue(bool v) { mValue = v; }
    explicit operator bool() const { return mValue; }
};

// ---------------------------------------------------------------- Number ---
class NumberSetting : public Setting {
public:
    NumberSetting(std::string name, std::string description,
                  float value, float min, float max, float step)
        : Setting(std::move(name), std::move(description), SettingType::Number),
          mValue(value), mMin(min), mMax(max), mStep(step)
    {
        if (mStep <= 0.0f) mStep = 0.01f;
    }

    float mValue = 0.0f;
    float mMin   = 0.0f;
    float mMax   = 1.0f;
    float mStep  = 0.01f;

    // Solstice snaps to the step so dragging feels discrete.
    void setValue(float v) { mValue = snap(v); }

    template <typename T> T as() const { return static_cast<T>(mValue); }

private:
    float snap(float v) const {
        return std::round(v / mStep) * mStep;
    }
};

// ------------------------------------------------------------------ Enum ---
class EnumSetting : public Setting {
public:
    EnumSetting(std::string name, std::string description,
                int index, std::vector<std::string> values)
        : Setting(std::move(name), std::move(description), SettingType::Enum),
          mValue(index), mValues(std::move(values)) {}

    int                      mValue = 0;
    std::vector<std::string> mValues;

    void setValue(int v) {
        if (mValues.empty()) return;
        mValue = ((v % (int)mValues.size()) + (int)mValues.size()) % (int)mValues.size();
    }

    const char* current() const {
        if (mValues.empty()) return "";
        const int i = (mValue >= 0 && mValue < (int)mValues.size()) ? mValue : 0;
        return mValues[i].c_str();
    }
};

// ----------------------------------------------------------------- Color ---
class ColorSetting : public Setting {
public:
    ColorSetting(std::string name, std::string description, float r, float g, float b, float a)
        : Setting(std::move(name), std::move(description), SettingType::Color)
    {
        mValue[0] = r; mValue[1] = g; mValue[2] = b; mValue[3] = a;
    }

    ColorSetting(std::string name, std::string description, unsigned long argb)
        : Setting(std::move(name), std::move(description), SettingType::Color)
    {
        setFromHex(argb);
    }

    float mValue[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

    void setValue(float r, float g, float b, float a) {
        mValue[0] = r; mValue[1] = g; mValue[2] = b; mValue[3] = a;
    }

    ImColor getAsImColor() const {
        return ImColor(mValue[0], mValue[1], mValue[2], mValue[3]);
    }

    void setFromImColor(const ImColor& c) {
        mValue[0] = c.Value.x; mValue[1] = c.Value.y;
        mValue[2] = c.Value.z; mValue[3] = c.Value.w;
    }

    void setFromHex(unsigned long argb) {
        mValue[0] = ((argb >> 16) & 0xFF) / 255.0f;
        mValue[1] = ((argb >> 8)  & 0xFF) / 255.0f;
        mValue[2] = ( argb        & 0xFF) / 255.0f;
        mValue[3] = ((argb >> 24) & 0xFF) / 255.0f;
    }
};

// ---------------------------------------------------------------- String ---
// Free-form text edited through the GUI's key-snapshot text entry
// (utils/keys.h). Used by e.g. the Text Hotkey module.
class StringSetting : public Setting {
public:
    StringSetting(std::string name, std::string description, std::string value,
                  size_t maxLength = 128)
        : Setting(std::move(name), std::move(description), SettingType::String),
          mValue(std::move(value)), mMaxLength(maxLength) {}

    std::string mValue;
    size_t      mMaxLength = 128;
};

} // namespace modules
