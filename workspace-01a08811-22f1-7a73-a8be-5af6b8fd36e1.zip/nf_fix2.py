#!/usr/bin/env python3
"""Fix the first-frame AV: null swapchain OutputWindow left g_hwnd empty, so
ImGui_ImplWin32_NewFrame() ran without Init. Probe the window ourselves, keep
the handle even if subclassing fails, guard the backend call, and poll the
mouse manually as a fallback."""
import sys

PATH = "/home/user/nightfull/src/overlay/overlay.cpp"

pairs = [
    # 0. probe struct carries the handle
    ("struct WindowProbe { int found = 0; DWORD pid = 0; };",
     "struct WindowProbe { int found = 0; DWORD pid = 0; HWND hwnd = nullptr; };"),
    # 1. capture it
    ("""    pr->found++;
    return FALSE;  // one is enough""",
     """    pr->found++;
    pr->hwnd = h;
    return FALSE;  // one is enough"""),
    # 2. finder next to the existence check
    ("""bool GameWindowExists() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.found > 0;
}""",
     """bool GameWindowExists() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.found > 0;
}

// Same criteria, but returns the handle (for the input hook + Win32 backend).
HWND FindGameWindow() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.hwnd;
}"""),
    # 3. forward declaration (used in HkPresent, defined below)
    ("void FinishUnload();  // defined below; called from the HkPresent tail",
     "void FinishUnload();  // defined below; called from the HkPresent tail\n"
     "HWND FindGameWindow();  // defined below; used when the swapchain has no OutputWindow"),
    # 4. keep the handle even when subclassing fails
    ("""void InstallWndHook(HWND hwnd) {
    if (g_wndHooked || !hwnd || !IsWindow(hwnd)) return;""",
     """void InstallWndHook(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return;
    if (!g_hwnd) g_hwnd = hwnd;  // usable for the Win32 backend even if the subclass fails
    if (g_wndHooked) return;"""),
    # 5. never call the backend handler before Init
    ("    ImGui_ImplWin32_WndProcHandler(h, msg, w, l);",
     "    if (g_win32Init) ImGui_ImplWin32_WndProcHandler(h, msg, w, l);"),
    # 6. manual mouse feed, inserted before the D3D teardown section
    ("// ============================ D3D teardown ============================",
     """// Manual mouse feed for ImGui when the Win32 backend is unavailable (no
// window handle / backend init failed). Keyboard keeps working through the
// keys:: poll in all cases.
void PollMouseFallback() {
    ImGuiIO& io = ImGui::GetIO();
    POINT pt{};
    if (GetCursorPos(&pt)) {
        if (g_hwnd) ScreenToClient(g_hwnd, &pt);
        io.MousePos = ImVec2((float)pt.x, (float)pt.y);
    }
    io.MouseDown[0] = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    io.MouseDown[1] = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
    io.MouseDown[2] = (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
    io.MouseDown[3] = (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
    io.MouseDown[4] = (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
}

// ============================ D3D teardown ============================"""),
    # 7. D3D12: guarded backend NewFrame
    ("""    ImGui_ImplDX12_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();""",
     """    ImGui_ImplDX12_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ImGui::NewFrame();"""),
    # 8. D3D11: same guard
    ("""    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();""",
     """    ImGui_ImplDX11_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ImGui::NewFrame();"""),
    # 9. init branch: probe the window when OutputWindow is null
    ("""            DXGI_SWAP_CHAIN_DESC sd{};
            if (SUCCEEDED(sc->GetDesc(&sd))) {
                g_w = sd.BufferDesc.Width;
                g_h = sd.BufferDesc.Height;
                if (sd.OutputWindow && !g_wndHooked) InstallWndHook(sd.OutputWindow);
            }""",
     """            DXGI_SWAP_CHAIN_DESC sd{};
            if (SUCCEEDED(sc->GetDesc(&sd))) {
                g_w = sd.BufferDesc.Width;
                g_h = sd.BufferDesc.Height;
            }
            if (!g_wndHooked) {
                // UWP/composition swapchains often report a null OutputWindow -
                // fall back to probing the process for its main window.
                HWND target = sd.OutputWindow ? sd.OutputWindow : FindGameWindow();
                if (target) {
                    if (!sd.OutputWindow)
                        LOG_INFO("overlay: swapchain OutputWindow is null - probing found %p", target);
                    InstallWndHook(target);
                } else {
                    LOG_ERROR("overlay: no game window for the input hook - will keep retrying");
                }
            }"""),
    # 10. keep probing at ~1 Hz until we have a handle (insert before win32 init)
    ("""            if (g_showMenu != g_menuWasOpen) {
                g_menuWasOpen = g_showMenu;
                keys::Reset();
            }""",
     """            if (g_showMenu != g_menuWasOpen) {
                g_menuWasOpen = g_showMenu;
                keys::Reset();
            }
            // No window handle yet (late window creation): keep probing at ~1 Hz.
            if (!g_hwnd) {
                static int probeTick = 0;
                if (++probeTick % 60 == 1) {
                    HWND t = FindGameWindow();
                    if (t) InstallWndHook(t);
                }
            }"""),
    # 11. honor the Win32 backend's return value
    ("""            if (!g_win32Init && g_hwnd) {
                ImGui_ImplWin32_Init(g_hwnd);
                g_win32Init = true;
                LOG_INFO("overlay: Win32 backend bound to %p", g_hwnd);
            }""",
     """            if (!g_win32Init && g_hwnd) {
                if (ImGui_ImplWin32_Init(g_hwnd)) {
                    g_win32Init = true;
                    LOG_INFO("overlay: Win32 backend bound to %p", g_hwnd);
                } else {
                    static int w32fails = 0;
                    if (++w32fails == 1 || w32fails % 600 == 0)
                        LOG_ERROR("overlay: Win32 backend init failed (%d) - poll fallback only", w32fails);
                }
            }"""),
]

with open(PATH, encoding="utf-8") as f:
    content = f.read()
for i, (old, new) in enumerate(pairs):
    n = content.count(old)
    if n != 1:
        print(f"FAIL pair {i}: found {n} matches (expected 1)")
        print("--- old text ---")
        print(old)
        sys.exit(1)
    content = content.replace(old, new, 1)
    print(f"ok pair {i}")
with open(PATH, "w", encoding="utf-8", newline="") as f:
    f.write(content)
print("ALL OK")
