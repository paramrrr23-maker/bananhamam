// interface_module.h - the Interface module (Solstice's Interface.hpp).
//
// Solstice's Interface module owns the client's look: naming style, colour
// theme, cycle speed, saturation and the six custom palette slots. Same here -
// the menu reads these every frame and pushes them into gui_theme.
//
// NOTE: ASCII only in this file.

#pragma once

#include "modules/module.h"

namespace modules {

class InterfaceModule : public Module {
public:
    // Nightfull theme presets. Values intentionally match gui_theme::Theme.
    enum Theme {
        THEME_DEFAULT = 0,
        THEME_PURPLE,
        THEME_BLUE,
        THEME_CYAN,
        THEME_RED,
        THEME_GREEN,
        THEME_ORANGE,
        THEME_MONOCHROME,
        THEME_CUSTOM,
    };

    // Solstice's NamingStyle, in the same order.
    enum Naming {
        NAMING_LOWERCASE = 0,
        NAMING_LOWERCASE_SPACED,
        NAMING_NORMAL,
        NAMING_NORMAL_SPACED,
    };

    InterfaceModule();

    static InterfaceModule* instance() { return s_instance; }

    EnumSetting*   m_namingStyle = nullptr;
    EnumSetting*   m_theme       = nullptr;
    NumberSetting* m_colors      = nullptr;
    ColorSetting*  m_color1      = nullptr;
    ColorSetting*  m_color2      = nullptr;
    ColorSetting*  m_color3      = nullptr;
    ColorSetting*  m_color4      = nullptr;
    ColorSetting*  m_color5      = nullptr;
    ColorSetting*  m_color6      = nullptr;
    NumberSetting* m_colorSpeed  = nullptr;
    NumberSetting* m_saturation  = nullptr;

private:
    static InterfaceModule* s_instance;
};

} // namespace modules
