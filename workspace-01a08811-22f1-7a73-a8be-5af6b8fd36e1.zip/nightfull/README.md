# Nightfull

Чистый локальный оверлей для **Minecraft: Bedrock Edition** (Windows 10/11, x64).
Ничего не читает и не пишет в память игры: только перехват `Present`/`ResizeBuffers`
у swapchain и прослушивание ввода. Весь HUD считается из системных часов, счётчиков
процесса и событий клавиатуры/мыши.

## Что внутри

**Модули (все локальные, без единого обращения к игре):**

| Модуль | Что показывает |
|---|---|
| General | Мастер-переключатель всего HUD |
| Themes | Палитра/акцент/градиенты для всех виджетов |
| Watermark | Плашка `Nightfull \| fps \| username` |
| Arraylist | Список включённых модулей (сортировка, фон, линия) |
| FPS | Кадры в секунду (счётчик Present) |
| CPS | Клики в секунду, левая/правая кнопки |
| Keybinds | Какие модули на каких клавишах |
| Time | Часы (12/24, дата, секунды) |
| Memory | RAM процесса из `GetProcessMemoryInfo` |
| MouseStrokes | Шлейф движения мыши |
| Keystrokes | WASD/Space/LMB/RMB + счётчики CPS |
| Crosshair | Прицел (крест/точка/круг), прячется с открытым меню |

**Меню в стиле NebulaClient:** тёмный фон `#17161B`, фиолетовый акцент `#6C6CE5`,
закруглённые карточки модулей, сайдбар `HUD / Visual / Profiles / Settings`,
правая панель настроек выбранного модуля, живые тосты при переключении.

**Конфиг:** `%TEMP%\Nightfull\config.json` (+ `config.json.bak`), автосохранение
раз в ~1.5 сек при изменениях, атомарная запись (tmp → rename). Логи:
`%TEMP%\Nightfull\nightfull.log`.

## Управление

| Клавиша | Действие |
|---|---|
| `INSERT` | Открыть/закрыть меню |
| `END` | Выгрузить DLL из игры |
| `ESC` | Закрыть поле/попап/захват бинда, затем меню |
| `RMB` … (`F`) | Бинды модулей по умолчанию, меняются в меню |

Когда меню открыто, игра не получает ввод (клавиатура глотается, курсор возвращается,
оверлей перехватывает клики). Бинд, совпадающий с клавишей меню, никогда не срабатывает.

## Сборка (Visual Studio 2022)

Требования: **VS 2022** с workload «Desktop development with C++», **Windows SDK 10+**,
**CMake 3.24+** (идёт в составе VS), цель **x64**. Больше ничего: ни vcpkg, ни NuGet —
только системные библиотеки WinSDK (`d3d11 d3d12 dxgi psapi`), ImGui уже лежит в
`third_party/imgui`.

**Вариант A — Visual Studio (проще всего):**

1. `File → Open → Folder…` → открой папку `nightfull`.
2. VS сама обнаружит `CMakeLists.txt` и предложит конфигурацию — выбери **x64-Release**.
3. `Build → Build All` (или `Ctrl+Shift+B`).

**Вариант B — командная строка (x64 Native Tools Command Prompt for VS 2022):**

```bat
cd nightfull
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Готовая DLL: `build\bin\Nightfull.dll`, рядом VS положит папку `fonts\`.
CRT слинкован статически (`/MT`), устанавливать VC++ Redistributable не нужно.

> Шрифты: положи свои `.ttf` в `fonts\` (имена вида `segoeui.ttf`, `arial.ttf`…)
> или оставь папку пустой — тогда Nightfull возьмёт системный `segoeui.ttf`.

## Запуск

1. Запусти Minecraft Bedrock (режим **DirectX 11** рекомендуется; D3D12 тоже
   поддерживается, при первом кадре движок сам выберет бэкенд).
2. Заинжекти любой DLL-инжектор x64 → `Nightfull.dll`.
3. Нажми `INSERT` — откроется меню. `END` — чистая выгрузка из процесса.

Лог подскажет, что пошло не так: `%TEMP%\Nightfull\nightfull.log`.

## Структура проекта

```
nightfull/
├── CMakeLists.txt            # MSVC x64, C++17, только WinSDK-либы
├── README.md                 # этот файл
├── fonts/                    # свои .ttf (опционально, копируются к DLL)
├── third_party/imgui/        # вендоренный Dear ImGui (core + dx11 + dx12 + win32)
└── src/
    ├── dllmain.cpp           # DllMain: поток инициализации, чистая выгрузка
    ├── core/                 # module.h, setting.h, registry, config (JSON без зависимостей)
    ├── modules/              # hud_modules.{h,cpp} — весь ростер + ModuleGuard (тайминги)
    ├── overlay/              # Present/Resize-хуки, WndProc-сабкласс, D3D11/12, unload
    ├── ui/                   # меню Nebula (menu.h/cpp) на собственном gui-примитиве
    └── utils/                # logger, keys (тройной ввод), fonts, gui_render, gui_theme
```

## Как добавить свой модуль

1. В `src/modules/hud_modules.h` объяви класс от `Module`, в `.cpp` реализуй
   `OnRender()` через `gui::` / `ImGui::GetBackgroundDrawList()`.
2. Зарегистрируй в `RegisterAllHudModules()` (`hud_modules.cpp`, конец файла).
3. Новую настройку добавь конструктором `BoolSetting/NumberSetting/EnumSetting/
   StringSetting/ColorSetting/KeySetting` — она сама появится в меню, конфиге
   и поиске. Бинды: `SetDefaultKey(VK_*)` + `SetSupportsKey(true)`.
4. Категорию выбирай из `HUD / Visual`; сами категории меню не трогай.

Правила чистого оверлея (не нарушать): модуль не должен читать память игры,
хукать её функции, слать пакеты или автоматизировать PvP. Разрешены только
системные часы, счётчики своего процесса и события ввода.

## Устранение проблем

- **Меню не открывается по INSERT** — фокус должен быть на окне игры; проверь лог
  (`Nightfull\nightfull.log` рядом с DLL), там видно, зацепился ли Present.
- **Меню открылось, но шрифт «системный»** — в `fonts\` рядом с DLL нет `.ttf`,
  это штатный фолбэк.
- **Чёрный экран / вылет при ресайзе** — движок пересоздаёт swapchain-ресурсы
  сам; если повторилось — пришли лог, там будет `render init failed (N)`.
- **DLL не выгружается по END** — выгрузка отложена до конца кадра; если кадр
  завис, поможет только перезапуск игры.
- **UWP-окно не отдаёт клавиши** — в Bedrock это штатно: движок дублирует ввод
  через `GetAsyncKeyState`-поллинг каждый кадр, меню всё равно работает.

## Лицензии

- Собственный код Nightfull — делай что хочешь (public domain / MIT на выбор).
- Dear ImGui (`third_party/imgui`) — MIT License, © Omar Cornut. Файлы лицензии
  лежат рядом с исходниками ImGui.
