# NIGHTFULL — GUI Design Specification

Клиент: **Nightfull** — визуальный Minecraft Bedrock клиент (1.21.111).
Статус документа: **дизайн и архитектура**. Кода нет и не должно быть на этом этапе.
Философия: `Dark + Glass + Purple + Minimal + Soft + Modern`. Главный принцип: **Premium, not flashy.**

Связь с rendering-исследованием: этот дизайн реализуется поверх будущего rendering foundation
(`Renderer2D / TextRenderer / TextureRenderer / ParticleRenderer` из `API_BLUEPRINT.md`).
Раздел 10–11 фиксируют, какие именно примитивы нужны от rendering-слоя.

> Позиционирование: ранние исследования разбирали архитектуру существующих Bedrock-клиентов
> (включая их feature-набор) как технический материал. Nightfull наследует только
> **рендерные паттерны** (пути рендера, примитивы, очереди кадров). Feature-набор Nightfull —
> строго non-cheat: визуал, HUD, эффекты, интерфейс, персонификация (см. §12).

---

## 1. Full GUI Architecture — дерево интерфейса

```
Nightfull Experience Layer
│
├── Screen Dim Layer (затемнение + blur + vignette поверх мира, мир виден)
│
├── Main Window (центральная панель)
│   ├── Sidebar (постоянная навигация)
│   │   ├── Brand Block (logo + "Nightfull" + "Client Interface")
│   │   ├── Nav Items ×8 (icon + label + shortcut? + hover/active)
│   │   │   ├── 1 Dashboard      (grid)
│   │   │   ├── 2 Visuals        (sparkle)
│   │   │   ├── 3 HUD            (monitor)
│   │   │   ├── 4 Effects        (particles)
│   │   │   ├── 5 Interface      (sliders/layout)
│   │   │   ├── 6 Performance    (activity)
│   │   │   ├── 7 Profiles       (layers)
│   │   │   └── 8 Settings       (gear)
│   │   └── Sidebar Footer (версия клиента + статус "Running")
│   │
│   └── Main Content
│       ├── Content Header (Section Title + описание + контекстные actions)
│       ├── Search / Controls Bar (Search settings… + фильтры/кнопки)
│       ├── Cards Grid (responsive: 3 / 2 / 1 колонки)
│       │   └── Card ×N (header + контролы + опц. preview)
│       └── Footer Status (опц.: hint / количество результатов поиска)
│
├── Floating Widgets (справа/поверх, не перекрывают окно)
│   ├── Status Widget (Nightfull Running, FPS, Ping, Session)
│   └── Active Visuals Widget (активные визуальные функции)
│
├── HUD Layer (всегда поверх мира, под окном GUI)
│   ├── HUD Widgets (FPS / Ping / Coordinates / Clock / Session / Watermark)
│   └── HUD Editor Overlay (selection outlines + handles + labels)
│
├── Notifications Layer (floating cards, очередь сверху/сбоку)
│
└── Overlay Layer (поверх всего)
    ├── Dropdown Menus
    ├── Color Picker Popover
    ├── Tooltips
    └── Modal Dialogs (подтверждения, profile manager)
```

Правила композиции:
- Окно — **один** центральный элемент; всё остальное — floating-слои с понятным z-порядком:
  `Мир < Dim < HUD < Main Window < Floating Widgets < Notifications < Overlay`.
- Sidebar всегда видима, контент никогда не залезает под неё.
- Пустое состояние (поиск без результатов, нет профилей) — отдельный аккуратный empty-state, а не пустая сетка.

---

## 2. Screen Map — экраны и переходы

```
        ┌─────────────────────────────────────────────┐
        │              GUI CLOSED (мир + HUD)          │
        │  keybind → OPEN                             │
        └──────────────┬──────────────────────────────┘
                       ▼
┌──────────────────────────────────────────────────────────────┐
│ MAIN WINDOW (всегда с Sidebar; контент переключается)         │
│                                                              │
│  Dashboard ◄──► Visuals ◄──► HUD ◄──► Effects                 │
│      ↕            ↕            ↕           ↕                  │
│  Interface ◄──► Performance ◄──► Profiles ◄──► Settings       │
│                                                              │
│  Переходы: tab switch (slide+fade 200ms), состояние           │
│  скролла и поиска сохраняется на каждый экран отдельно.      │
└──┬───────────────────────────────┬───────────────────────────┘
   │                               │
   ▼                               ▼
HUD EDITOR MODE              MODALS / POPOVERS
(из раздела HUD)             (dropdown, color picker,
Мир на фоне, виджеты          tooltip, confirm, profile
selectable; Esc/кнопка        editor) — закрываются по
возвращает в раздел HUD.      Esc/клику вне.
```

- Открытие GUI: `0% → opacity + scale(0.97→1.0) → 100%` + появление dim-слоя.
- Закрытие: обратная анимация, быстрее открытия.
- Поиск — глобальный: результаты группируются по экранам, клик ведёт на экран + подсвечивает настройку.
- Deep-link внутри GUI: Dashboard Quick Access → Visuals / HUD / Effects / Profiles.

---

## 3. Component Library

### 3.1. Примитивы отображения
| Компонент | Анатомия | Состояния |
|---|---|---|
| Text (6 уровней) | string + size/weight/color/alignment | default, disabled (opacity) |
| Icon | glyph + size + stroke + color | default, hover (brightness+), active (accent), disabled |
| Divider | 1px line / spacing block | — |
| Badge/Dot | маленькая метка (статус, счётчик) | info/success/warning/error |
| Logo | N-mark / star / moon (монохром + accent варианты) | — |

### 3.2. Карточки
| Тип | Содержимое | Использование |
|---|---|---|
| Standard Card | header? + body | универсальный контейнер |
| Feature Card | icon + title + desc + toggle | вкл/выкл визуальной функции |
| Settings Card | label/value ряды + контролы | группы настроек |
| Information Card | icon + текст (+ action?) | подсказки, статусы |
| Profile Card | preview-swatch + имя + actions | профили тем/настроек |
| Statistic Card | крупное значение + подпись + мини-тренд? | Dashboard, Performance |
| Preview Card | live-preview область + контролы | партикли, темы, HUD |

Анатомия Card Header: `[Icon] Title ......... [optional action] / Description (вторая строка)`.
Никогда: больше одного primary action в header, вложенные карточки глубже 1 уровня.

### 3.3. Контролы
| Компонент | Анатомия | Поведение |
|---|---|---|
| Button (primary/ghost/danger-ghost) | label + icon? + padding | hover glow, pressed scale 0.98, disabled 40% |
| Toggle | pill + knob + label + desc? | OFF: тёмно-серый; ON: purple gradient + soft glow; knob slide ~200ms |
| Slider | `Label \| Value ———●———` | hover (thumb glow), drag, wheel, keyboard ←/→, min/max/step, numeric input по дабл-клику |
| Dropdown | `Mode \| Smooth ˅` → меню | открытие fade+slide 180ms; hover строки; keyboard навигация; скролл при >N пунктов |
| Color Picker | swatch + popover (hue/sat/bright + alpha + HEX/RGB/RGBA поля) | live-применение; HEX-копирование; recent colors |
| Keybind | `Open Menu [ RSHIFT ]` | режим захвата (пульсация рамки), Esc — отмена, Backspace — очистить |
| Search Field | 🔍 + `Search settings…` + clear × | фокус-подсветка; live-фильтр; Esc очищает |
| Tabs/Segmented | 2–N сегментов | sliding indicator 180ms |
| Progress/Bar | track + fill (+ label) | для frame time / memory (только реальные данные) |

### 3.4. Слои и всплывающие
| Компонент | Анатомия | Поведение |
|---|---|---|
| Tooltip | тёмная пилюля + текст | задержка ~400ms, fade 120ms, умное позиционирование |
| Notification | icon + title + message? + progress? | slide/fade in 300ms → visible (TTL) → fade out 250ms; стек max N, старые вытесняются |
| Modal | dim + centered card + actions | scale+fade in; Esc/клик по dim — закрыть (если не критический) |
| Empty State | icon + title + hint + action? | для пустого поиска/профилей |
| Context Menu | список действий | как Dropdown-меню, но по правому клику |

### 3.5. Матрица состояний (для каждого интерактивного компонента)
| Состояние | Background | Border | Text | Icon | Opacity | Animation |
|---|---|---|---|---|---|---|
| Default | surface | subtle | primary | secondary | 100% | — |
| Hover | surface+8% | subtle+accent hint | brighter | brighter | 100% | 150ms ease-out |
| Active/Selected | accent wash | accent | primary | accent | 100% | 180ms |
| Focused | surface | accent 1px | primary | — | 100% | 120ms |
| Pressed | surface−5% | subtle | primary | — | 100% | scale 0.98, 100ms |
| Disabled | surface | subtle | caption | caption | 40% | — |

---

## 4. Design Tokens

### 4.1. Colors (тема Night — базовая)
| Токен | Значение | Назначение |
|---|---|---|
| `bg.deep` | `#07090F` | самый тёмный фон |
| `bg.navy` | `#0B0E17` | фон окна |
| `surface.glass` | `rgba(19,23,38,0.72)` | панели, карточки |
| `surface.raised` | `rgba(28,33,52,0.85)` | popovers, dropdown-меню |
| `surface.hover` | `rgba(255,255,255,0.06)` | hover-wash поверх |
| `surface.active` | `rgba(139,92,246,0.14)` | active-wash |
| `border.subtle` | `rgba(255,255,255,0.08)` | тонкие разделители |
| `border.accent` | `rgba(139,92,246,0.45)` | фокус, selection |
| `text.primary` | `#EDEFF7` | заголовки, основной |
| `text.secondary` | `#9AA0B4` | описания |
| `text.caption` | `#646A86` | подписи, hint'ы |
| `accent.primary` | `#8B5CF6` | violet — основной акцент |
| `accent.light` | `#A78BFA` | lavender — иконки, свечения |
| `accent.deep` | `#6D28D9` | gradient end |
| `accent.glow` | `rgba(139,92,246,0.35)` | мягкое свечение |
| `success` | `#34D399` | приглушённый |
| `warning` | `#FBBF24` | приглушённый |
| `error` | `#F87171` | приглушённый |
| `info` | `#7C8CF8` | приглушённый |
| `dim.ve
...[truncated 17543 chars]