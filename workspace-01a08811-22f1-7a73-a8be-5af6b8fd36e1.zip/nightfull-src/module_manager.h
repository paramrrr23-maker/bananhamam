// module_manager.h - singleton that owns all registered modules.
//
// NOTE: ASCII only in this file.

#pragma once

#include <memory>
#include <vector>

#include "modules/module.h"

namespace modules {

class ModuleManager {
public:
    static ModuleManager& instance();

    // Takes ownership. Called once from module_registry.cpp on init.
    void add(std::unique_ptr<Module> m);

    const std::vector<std::unique_ptr<Module>>& modules() const { return m_modules; }

    // Finds and toggles a module by exact name; returns false if not found.
    bool toggle(const char* name);

private:
    ModuleManager() = default;
    std::vector<std::unique_ptr<Module>> m_modules;
};

// Convenience global accessor (used by ui and overlay).
inline ModuleManager& Modules() { return ModuleManager::instance(); }

} // namespace modules