#!/usr/bin/env python3
"""Temporary first-3-frames tracing to pinpoint the frame AV."""
import sys

BASE = "/home/user/nightfull/"
OV = "src/overlay/overlay.cpp"
MENU = "src/ui/menu.cpp"

ov_pairs = [
    ("""        } else if (!g_renderAborted) {
            // One fused key snapshot per frame, then hotkeys, then the frame.
            keys::BeginFrame();""",
     """        } else if (!g_renderAborted) {
            // One fused key snapshot per frame, then hotkeys, then the frame.
            static int fno = 0;
            const bool trace = ++fno <= 3;
            if (trace) LOG_INFO("trace: present frame %d begin", fno);
            keys::BeginFrame();"""),
    ("""            if (!g_win32Init && g_hwnd) {""",
     """            if (trace) LOG_INFO("trace: hotkeys done");
            if (!g_win32Init && g_hwnd) {"""),
    ("""            EnsureCs();
            EnterCriticalSection(&g_renderCs);""",
     """            if (trace) LOG_INFO("trace: entering render");
            EnsureCs();
            EnterCriticalSection(&g_renderCs);"""),
    ("""            LeaveCriticalSection(&g_renderCs);
            // Serialized unload: runs on this thread right after the frame,""",
     """            LeaveCriticalSection(&g_renderCs);
            if (trace) LOG_INFO("trace: render done");
            // Serialized unload: runs on this thread right after the frame,"""),
    ("""    g_d12alloc->Reset();
    g_d12list->Reset(g_d12alloc, nullptr);""",
     """    static int d12fno = 0;
    const bool dtrace = ++d12fno <= 3;
    g_d12alloc->Reset();
    g_d12list->Reset(g_d12alloc, nullptr);
    if (dtrace) LOG_INFO("trace: d3d12 list reset");"""),
    ("""    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);""",
     """    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);
    if (dtrace) LOG_INFO("trace: d3d12 target set");"""),
    ("""    ImGui_ImplDX12_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ImGui::NewFrame();""",
     """    ImGui_ImplDX12_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ImGui::NewFrame();
    if (dtrace) LOG_INFO("trace: d3d12 newframe done");"""),
    ("""    ui::Frame();
    ImGui::Render();
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12list);""",
     """    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame enter");
    ui::Frame();
    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame exit");
    ImGui::Render();
    if (dtrace) LOG_INFO("trace: d3d12 imgui render done");
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12list);
    if (dtrace) LOG_INFO("trace: d3d12 drawdata done");"""),
    ("""    if (WaitForSingleObject(g_d12event, 1000) != WAIT_OBJECT_0 && !g_d12waitLogged) {
        g_d12waitLogged = true;
        LOG_ERROR("overlay: D3D12 fence wait timed out - continuing unsynchronized");
    }""",
     """    if (WaitForSingleObject(g_d12event, 1000) != WAIT_OBJECT_0 && !g_d12waitLogged) {
        g_d12waitLogged = true;
        LOG_ERROR("overlay: D3D12 fence wait timed out - continuing unsynchronized");
    }
    if (dtrace) LOG_INFO("trace: d3d12 submit done");"""),
]

menu_pairs = [
    ("""void Frame() {
    const float dt = gui::GetDeltaTime();
    ApplyClientModules();""",
     """void Frame() {
    static int uifno = 0;
    const bool utrace = ++uifno <= 3;
    if (utrace) LOG_INFO("trace: ui::Frame %d begin", uifno);
    const float dt = gui::GetDeltaTime();
    ApplyClientModules();
    if (utrace) LOG_INFO("trace: ui apply done");"""),
    ("""    if (!overlay::g_showMenu)
        DispatchBinds();""",
     """    if (!overlay::g_showMenu)
        DispatchBinds();
    if (utrace) LOG_INFO("trace: ui binds done");"""),
    ("""    for (const auto& m : modules().modules()) {
        if (!m->enabled()) continue;
        ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Tick);
        if (m->enabled())
            ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Render);
    }

    AutosaveTick();
    PaintToasts();""",
     """    for (const auto& m : modules().modules()) {
        if (!m->enabled()) continue;
        ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Tick);
        if (m->enabled())
            ModulePhaseGuard::run(m.get(), ModulePhaseGuard::Phase::Render);
    }
    if (utrace) LOG_INFO("trace: ui modules done");

    AutosaveTick();
    if (utrace) LOG_INFO("trace: ui autosave done");
    PaintToasts();
    if (utrace) LOG_INFO("trace: ui toasts done");"""),
]


def apply(path, pairs):
    with open(BASE + path, encoding="utf-8") as f:
        content = f.read()
    for i, (old, new) in enumerate(pairs):
        n = content.count(old)
        if n != 1:
            print(f"FAIL {path} pair {i}: found {n} (expected 1)")
            print("--- old ---")
            print(old)
            return False
        content = content.replace(old, new, 1)
        print(f"ok {path} pair {i}")
    with open(BASE + path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    return True


ok = apply(OV, ov_pairs) and apply(MENU, menu_pairs)
print("ALL OK" if ok else "FAILED")
sys.exit(0 if ok else 1)
