// module_guard.h - crash- and hang-contained module callback invoker.
//
// Every module callback (enable/disable/tick/render) runs through
// ModulePhaseGuard::run(). A faulting module is caught by SEH, logged and
// auto-disabled instead of killing the game; a slow module (>5 ms) is logged,
// and a wedged one (>100 ms) is disabled. g_activeModule/g_activePhase expose
// the in-flight callback for debuggers and watchdogs.

#pragma once

namespace nf {

class Module;

class ModulePhaseGuard {
public:
    enum class Phase { Enable, Disable, Tick, Render };

    static void run(Module* m, Phase phase);
    static const char* phaseName(Phase phase);
};

// In-flight callback markers (watchdog/debugger visibility).
extern const char* g_activeModule;
extern const char* g_activePhase;

} // namespace nf
