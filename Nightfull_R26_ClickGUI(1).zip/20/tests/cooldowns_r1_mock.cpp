
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <strings.h>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#define _MSC_VER 1
#define __try try
#define __except(x) catch(...)
#define __fastcall
#define LOG_INFO(...) ((void)0)
#define _stricmp strcasecmp
#define _TRUNCATE 0
using LONG=int; using LONG64=long long; using ULONGLONG=unsigned long long; using SRWLOCK=int;
template<size_t N> void strcpy_s(char (&d)[N],const char* s) { std::snprintf(d,N,"%s",s); }
template<size_t N> void strncpy_s(char (&d)[N],const char* s,int) { strcpy_s(d,s); }
LONG InterlockedCompareExchange(volatile LONG* v,LONG a,LONG b) { LONG old=*v;if(old==b)*v=a;return old; }
LONG64 InterlockedCompareExchange64(volatile LONG64* v,LONG64 a,LONG64 b) { LONG64 old=*v;if(old==b)*v=a;return old; }
LONG InterlockedExchange(volatile LONG* v,LONG a) { LONG old=*v;*v=a;return old; }
LONG64 InterlockedExchange64(volatile LONG64* v,LONG64 a) { LONG64 old=*v;*v=a;return old; }
void InterlockedIncrement(volatile LONG* v) { *v=*v+1; }
void AcquireSRWLockExclusive(SRWLOCK*) {} void ReleaseSRWLockExclusive(SRWLOCK*) {}
ULONGLONG clockNow=1000; ULONGLONG GetTickCount64() { return clockNow; }
int patch=111; int JavaGamePatch() { return patch; }
bool ui=false,localPresent=true,badStack=false,g_shuttingDown=false;
unsigned char image[4096]{},actor[4096]{},proxy[512]{},inv[64]{},counter[8]{};
unsigned char stacks[9][256]{},item[512]{};
size_t g_gameImageSize=sizeof(image); void* GetModuleHandleW(void*) { return image; }
bool PotionReadBytes(const void* p,void* out,size_t n) { if(!p)return false;std::memcpy(out,p,n);return true; }
bool PotionValidVtable(uintptr_t p) { return p>=(uintptr_t)image && p<(uintptr_t)image+sizeof(image); }
bool JavaReadMsvcString(const void* p,char* out,size_t n) {
 if(p==item+0x100) { std::snprintf(out,n,"minecraft");return true; }
 if(p==item+0xD8) { std::snprintf(out,n,"ender_pearl");return true; } return false;
}
void* getItemMock(void*,int slot) { return badStack?nullptr:stacks[slot]; }
void* HitboxResolveContainerGetItem(void*) { return (void*)&getItemMock; }
bool PotionReadLocalPlayer(void*& out) { out=localPresent?actor:nullptr;return localPresent; }
bool UiInputOwned() { return ui; }
bool ReadTopUiLayer(char* out,size_t n) { std::snprintf(out,n,ui?"inventory_screen":"hud_screen");return true; }
template<class T> void put(void* where,T val) { std::memcpy(where,&val,sizeof(val)); }
namespace overlay {
struct CooldownUseEvent { char itemId[64]{};unsigned long long at=0;unsigned long session=0; };
struct CooldownEventQueue { CooldownUseEvent items[32]{};unsigned int head=0,tail=0;SRWLOCK lock=0; } g_cooldownEvents;
volatile LONG64 g_cdUseAt=0,g_cdDropAt=0;volatile LONG g_cdUseDown=0,g_cdDropDown=0,g_cdSession=1;
void PublishCooldownUse(const char*,unsigned long long at=0);unsigned long GetCooldownSession();

// ABI reference: Flarial OffsetInit init21110 / init2120 / init2160,
// ItemStackBase's x64 layout. Intentionally limited to 1.21.110..119.
// No inventory writes, new hooks, background SDK calls, or signature scans.
static const char* const kCooldownIds[] = {
    "minecraft:sugar", "minecraft:phantom_membrane", "minecraft:ender_eye",
    "minecraft:netherite_scrap", "minecraft:golden_apple",
    "minecraft:enchanted_golden_apple", "minecraft:dried_kelp",
    "minecraft:ender_pearl", "minecraft:chorus_fruit", "minecraft:snowball",
    "minecraft:wind_charge"
};

// CD_PURE_BEGIN: portable decision core, exercised by the regression tests.
struct CooldownStackSample {
    int slot = -1;
    int id = -1;                  // -1 = empty/untracked, count still validated
    int count = 0;
};
static bool CooldownDecreased(const CooldownStackSample& before,
                              const CooldownStackSample& after) {
    if (before.slot < 0 || before.slot != after.slot ||
        before.id < 0 || before.count <= 0) return false;
    if (after.count == 0) return before.count == 1;
    return before.id == after.id && before.count - after.count == 1;
}
static bool CooldownStillSpent(const CooldownStackSample& before,
                              const CooldownStackSample& after) {
    return before.slot == after.slot &&
        ((after.count == 0 && before.count == 1) ||
         (after.id == before.id && after.count > 0 &&
          after.count < before.count));
}
static bool CooldownRecent(unsigned long long now, unsigned long long at,
                           unsigned long long window) {
    return at != 0 && now >= at && now - at <= window;
}
// CD_PURE_END

struct CooldownObserver {
    void* local = nullptr;
    void* registry = nullptr;
    void* inventory = nullptr;
    CooldownStackSample before{};
    CooldownStackSample pendingBefore{};
    ULONGLONG sampledAt = 0;
    ULONGLONG pendingAt = 0;
    ULONGLONG lastLocalAt = 0;
    ULONGLONG lastIntent = 0;
    ULONGLONG diagAt = 0;
    bool baseline = false;
};
static CooldownObserver g_cdObserver;

static void CooldownDiagnostic(const char* reason, ULONGLONG now) {
    if (now < g_cdObserver.diagAt) return;
    g_cdObserver.diagAt = now + 5000ull;
    LOG_INFO("cooldowns: cd-r1 %s", reason);
}

// A readable pointer is not sufficient proof of an Inventory object. Validate
// the MSVC x64 complete-object locator and its concrete RTTI name before ever
// calling Container::getItem. Do not scan for alternative offsets on failure.
static bool CooldownInventoryType(void* inventory) {
    uintptr_t vft = 0, locator = 0;
    uint32_t col[6]{};
    const uintptr_t image = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
    if (!PotionReadBytes(inventory, &vft, sizeof(vft)) || !PotionValidVtable(vft) ||
        !PotionReadBytes(reinterpret_cast<const void*>(vft - sizeof(void*)),
                         &locator, sizeof(locator)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(locator), col, sizeof(col)) ||
        col[0] != 1 || locator < col[5] || locator - col[5] != image ||
        col[3] == 0 || col[3] >= g_gameImageSize) return false;
    char name[64]{};
    if (!PotionReadBytes(reinterpret_cast<const void*>(image + col[3] + 16u),
                         name, sizeof(name) - 1)) return false;
    return std::strcmp(name, ".?AVInventory@@") == 0 ||
           std::strcmp(name, ".?AVPlayerInventory@@") == 0;
}

static bool CooldownReadInventory(void* local, void*& inventory,
                                 void*& getItem, int& slot) {
    void* proxy = nullptr;
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(local) + 0x5B8u), &proxy, sizeof(proxy)) ||
        !proxy ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(proxy) + 0x10u), &slot, sizeof(slot)) ||
        slot < 0 || slot > 8 ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(proxy) + 0xB8u), &inventory, sizeof(inventory)) ||
        !inventory || !CooldownInventoryType(inventory)) return false;
    getItem = HitboxResolveContainerGetItem(inventory);
    return getItem != nullptr;
}

static bool CooldownReadStackUnsafe(void* inventory, void* getItem, int slot,
                                   CooldownStackSample& out) {
    out = {};
    out.slot = slot;
    using GetItemFn = void* (__fastcall*)(void*, int);
    void* stack = reinterpret_cast<GetItemFn>(getItem)(inventory, slot);
    if (!stack) return false;
    uintptr_t vft = 0;
    void* counter = nullptr;
    unsigned char count = 0;
    if (!PotionReadBytes(stack, &vft, sizeof(vft)) || !PotionValidVtable(vft) ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(stack) + 8u), &counter, sizeof(counter)))
        return false;
    if (!counter) return true; // canonical empty ItemStack, not a failed read
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(stack) + 0x22u), &count, sizeof(count)) ||
        count > 64) return false;
    out.count = count;
    if (!count) return true;
    void* item = nullptr; // WeakPtr<Item>::counter->ptr, not the counter itself
    if (!PotionReadBytes(counter, &item, sizeof(item)) || !item ||
        !PotionReadBytes(item, &vft, sizeof(vft)) || !PotionValidVtable(vft))
        return false;
    char ns[64]{}, name[128]{}, id[192]{};
    if (!JavaReadMsvcString(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(item) + 0x100u), ns, sizeof(ns)) ||
        !JavaReadMsvcString(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(item) + 0xD8u), name, sizeof(name)) ||
        !ns[0] || !name[0]) return false;
    if (std::strchr(name, ':')) snprintf(id, sizeof(id), "%s", name);
    else snprintf(id, sizeof(id), "%s:%s", ns, name);
    // Bedrock's older internal identifier for the enchanted apple.
    if (!_stricmp(id, "minecraft:appleEnchanted"))
        strcpy_s(id, "minecraft:enchanted_golden_apple");
    for (int i = 0; i < (int)(sizeof(kCooldownIds) / sizeof(kCooldownIds[0])); ++i) {
        if (!_stricmp(id, kCooldownIds[i])) { out.id = i; break; }
    }
    return true;
}

static bool CooldownReadStack(void* inventory, void* getItem, int slot,
                             CooldownStackSample& out) {
    if (!inventory || !getItem || slot < 0 || slot > 8) return false;
#ifdef _MSC_VER
    __try {
        return CooldownReadStackUnsafe(inventory, getItem, slot, out);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
#else
    // The shipped build.bat uses MSVC. Do not make an unguarded virtual call
    // under a different compiler.
    return false;
#endif
}

static void CooldownNewSession(void* local, void* registry) {
    g_cdObserver = {};
    g_cdObserver.local = local;
    g_cdObserver.registry = registry;
    InterlockedIncrement(&g_cdSession);
    // Old input must not arm the first item after reconnect/respawn.
    InterlockedExchange(&g_cdUseDown, 0);
    InterlockedExchange64(&g_cdUseAt, 0);
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    g_cooldownEvents.head = g_cooldownEvents.tail = 0;
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
    LOG_INFO("cooldowns: cd-r1 session reset");
}

static void CooldownSampleImpl() {
    CooldownObserver& state = g_cdObserver;
    const ULONGLONG now = GetTickCount64();
    if (state.sampledAt && now - state.sampledAt < 40ull) return; // <=25 Hz
    const bool gap = !state.sampledAt || now - state.sampledAt > 500ull;
    state.sampledAt = now;
    if (gap) { state.baseline = false; state.pendingAt = 0; }
    const int patch = JavaGamePatch();
    if (patch < 110 || patch >= 120) {
        CooldownDiagnostic("unsupported game version; inventory reads disabled", now);
        return;
    }
    void* local = nullptr;
    void* registry = nullptr;
    if (!PotionReadLocalPlayer(local) ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(local) + 0x10u), &registry, sizeof(registry))) {
        state.baseline = false;
        state.pendingAt = 0;
        if (state.local && now - state.lastLocalAt > 1000ull)
            CooldownNewSession(nullptr, nullptr);
        CooldownDiagnostic("waiting for local player", now);
        return;
    }
    if (local != state.local || registry != state.registry)
        CooldownNewSession(local, registry);
    state.sampledAt = state.lastLocalAt = now;
    char layer[64]{};
    if (UiInputOwned() || !ReadTopUiLayer(layer, sizeof(layer)) ||
        std::strcmp(layer, "hud_screen") != 0) {
        state.baseline = false;
        state.pendingAt = 0;
        InterlockedExchange(&g_cdUseDown, 0);
        InterlockedExchange64(&g_cdUseAt, 0);
        return;
    }
    void* inventory = nullptr;
    void* getItem = nullptr;
    int slot = -1;
    if (!CooldownReadInventory(local, inventory, getItem, slot)) {
        state.baseline = false;
        state.pendingAt = 0;
        CooldownDiagnostic("inventory layout/RTTI not validated (player+5B8 proxy+B8 slot+10)", now);
        return;
    }
    if (state.inventory != inventory) {
        state.inventory = inventory;
        state.baseline = false;
        state.pendingAt = 0;
        LOG_INFO("cooldowns: cd-r1 inventory reader ready, slot=%d", slot);
    }
    CooldownStackSample current{};
    if (!CooldownReadStack(inventory, getItem, slot, current)) {
        state.baseline = false;
        state.pendingAt = 0;
        CooldownDiagnostic("ItemStack/Item ID read failed; no timer started", now);
        return;
    }
    const ULONGLONG useAt = (ULONGLONG)InterlockedCompareExchange64(&g_cdUseAt, 0, 0);
    const ULONGLONG dropAt = (ULONGLONG)InterlockedCompareExchange64(&g_cdDropAt, 0, 0);
    const bool useDown = InterlockedCompareExchange(&g_cdUseDown, 0, 0) != 0;
    const bool useIntent = useDown || CooldownRecent(now, useAt, 400ull);
    const bool dropping = InterlockedCompareExchange(&g_cdDropDown, 0, 0) != 0 ||
                          CooldownRecent(now, dropAt, 750ull);
    if (useAt && useAt != state.lastIntent) {
        state.lastIntent = useAt;
        LOG_INFO("cooldowns: cd-r1 input slot=%d item=%s count=%d down=%d (intent only)",
                 slot, current.id >= 0 ? kCooldownIds[current.id] : "empty/untracked",
                 current.count, useDown ? 1 : 0);
    }
    if (state.pendingAt) {
        CooldownStackSample check = current;
        const bool readable = current.slot == state.pendingBefore.slot ||
            CooldownReadStack(inventory, getItem, state.pendingBefore.slot, check);
        if (!readable || dropping || !CooldownStillSpent(state.pendingBefore, check)) {
            LOG_INFO("cooldowns: cd-r1 pending cancelled (rollback/drop/item change/read failure)");
            state.pendingAt = 0;
        } else if (now - state.pendingAt >= 300ull) {
            LOG_INFO("cooldowns: cd-r1 consumption item=%s slot=%d count=%d->%d source=inventory+RMB estimate=1",
                     kCooldownIds[state.pendingBefore.id], state.pendingBefore.slot,
                     state.pendingBefore.count, check.count);
            PublishCooldownUse(kCooldownIds[state.pendingBefore.id], state.pendingAt);
            state.pendingAt = 0;
        }
    }
    if (state.baseline && CooldownDecreased(state.before, current)) {
        if (useIntent && !dropping && !state.pendingAt) {
            state.pendingBefore = state.before;
            state.pendingAt = now;
            LOG_INFO("cooldowns: cd-r1 pending item=%s count=%d->%d",
                     kCooldownIds[state.before.id], state.before.count, current.count);
        } else if (!useIntent || dropping) {
            LOG_INFO("cooldowns: cd-r1 decrement ignored (no use input or drop)");
        }
    }
    if (current.id >= 0 && (!state.baseline || current.id != state.before.id ||
                            current.slot != state.before.slot))
        LOG_INFO("cooldowns: cd-r1 selected slot=%d item=%s count=%d",
                 slot, kCooldownIds[current.id], current.count);
    state.before = current;
    state.baseline = true;
}

static void CooldownSample() {
    if (g_shuttingDown) return;
    // The setup boundary may be re-entered. Never block it or race the
    // observer's mutable state; the next frame will sample again.
    static volatile LONG busy = 0;
    if (InterlockedCompareExchange(&busy, 1, 0) != 0) return;
#ifdef _MSC_VER
    __try {
        CooldownSampleImpl();
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_cdObserver.baseline = false;
        g_cdObserver.pendingAt = 0;
        CooldownDiagnostic("guarded read exception; sample discarded", GetTickCount64());
    }
#endif
    InterlockedExchange(&busy, 0);
}

unsigned long GetCooldownSession() {
    return (unsigned long)InterlockedCompareExchange(&g_cdSession, 0, 0);
}

void PublishCooldownUse(const char* namespacedItemId, unsigned long long at) {
    if (!namespacedItemId || !*namespacedItemId) return;
    CooldownUseEvent event{};
    strncpy_s(event.itemId, namespacedItemId, _TRUNCATE);
    event.at = at ? at : GetTickCount64();
    event.session = GetCooldownSession();
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    const unsigned int next = (g_cooldownEvents.head + 1u) % 32u;
    // Retain recent events if the HUD was disabled for a long time.
    if (next == g_cooldownEvents.tail)
        g_cooldownEvents.tail = (g_cooldownEvents.tail + 1u) % 32u;
    g_cooldownEvents.items[g_cooldownEvents.head] = event;
    g_cooldownEvents.head = next;
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
}

int ConsumeCooldownUseEvents(CooldownUseEvent* out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    int count = 0;
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    while (count < maxOut && g_cooldownEvents.tail != g_cooldownEvents.head) {
        out[count++] = g_cooldownEvents.items[g_cooldownEvents.tail];
        g_cooldownEvents.tail = (g_cooldownEvents.tail + 1u) % 32u;
    }
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
    return count;
}


}
struct EnumSetting { int mValue=0; };
struct CooldownsModule {
 struct Active { std::string id,name,icon;unsigned long long endAt;float duration; };
 std::vector<Active> m_active;EnumSetting setting{};EnumSetting* m_mode=&setting;void onRender();
};

namespace {
struct CooldownDefinition {
    const char* id;
    const char* name;
    const char* icon;
    int seconds;
};

const CooldownDefinition* CooldownDefs(int mode, size_t& count) {
    static const CooldownDefinition frizmine[] = {
        {"minecraft:sugar", "Явная Пыль", "S", 30},
        {"minecraft:phantom_membrane", "Божья Аура", "A", 60},
        {"minecraft:ender_eye", "Дезориентация", "E", 30},
        {"minecraft:netherite_scrap", "Трапка", "T", 25},
        {"minecraft:golden_apple", "Золотое Яблоко", "G", 30},
        {"minecraft:enchanted_golden_apple", "Зачарованное Золотое Яблоко", "G", 160},
        {"minecraft:dried_kelp", "Пласт", "P", 25},
        {"minecraft:ender_pearl", "Эндер Жемчуг", "P", 25},
        {"minecraft:chorus_fruit", "Плод Хоруса", "C", 15},
        {"minecraft:snowball", "Снежок", "O", 25},
        {"minecraft:wind_charge", "Заряд Ветра", "W", 15},
    };
    count = mode == 0 ? sizeof(frizmine) / sizeof(frizmine[0]) : 0;
    return mode == 0 ? frizmine : nullptr;
}
}

void CooldownsModule::onRender() {
    // Registry owns exactly one CooldownsModule. These values belong to its
    // single render consumer, never to the game/input threads.
    static unsigned long lastSession = 0;
    static int lastMode = -1;
    const unsigned long session = overlay::GetCooldownSession();
    const int mode = m_mode ? m_mode->mValue : 0;
    const bool modeChanged = lastMode >= 0 && lastMode != mode;
    if (session != lastSession || mode != lastMode) {
        m_active.clear();
        lastSession = session;
        lastMode = mode;
        if (mode != 0)
            LOG_INFO("cooldowns: selected mode has no cooldown table; choose Frizmine");
    }
    overlay::CooldownUseEvent events[32]{};
    const int eventCount = overlay::ConsumeCooldownUseEvents(events, 32);
    size_t defCount = 0;
    const CooldownDefinition* defs = CooldownDefs(m_mode ? m_mode->mValue : 0, defCount);
    const ULONGLONG now = GetTickCount64();
    for (int i = 0; i < eventCount; ++i) {
        if (modeChanged || events[i].session != session || events[i].at > now) continue;
        const CooldownDefinition* def = nullptr;
        for (size_t j = 0; j < defCount; ++j)
            if (!_stricmp(events[i].itemId, defs[j].id)) { def = &defs[j]; break; }
        if (!def) continue;
        const unsigned long long endAt =
            events[i].at + (unsigned long long)def->seconds * 1000ull;
        if (endAt <= now) continue;
        Active* active = nullptr;
        for (Active& item : m_active) if (item.id == def->id) { active = &item; break; }
        // Repeated packets/consumption while already on CD must not restart it.
        if (active && active->endAt > events[i].at) continue;
        if (!active) {
            m_active.push_back({def->id, def->name, def->icon, 0, (float)def->seconds});
            active = &m_active.back();
        }
        active->endAt = endAt;
        LOG_INFO("cooldowns: cd-r1 timer item=%s duration=%ds remaining=%llums",
                 def->id, def->seconds, endAt - now);
    }
    m_active.erase(std::remove_if(m_active.begin(), m_active.end(),
                                  [now](const Active& item) { return item.endAt <= now; }),
                   m_active.end());

}

using namespace overlay;
int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL line "<<__LINE__<<": "<<#x<<"\n";std::abort();}}while(0)
void initMemory() {
 put(actor+0x10,(void*)image);put(actor+0x5B8,(void*)proxy);put(proxy+0x10,0);put(proxy+0xB8,(void*)inv);
 put(inv,(uintptr_t)(image+1024));put(image+1016,(uintptr_t)(image+512));uint32_t col[]={1,0,0,256,0,512};
 std::memcpy(image+512,col,sizeof(col));std::strcpy((char*)image+272,".?AVInventory@@");
 put(item,(uintptr_t)(image+1024));put(counter,(void*)item);
 for(int i=0;i<9;++i)put(stacks[i],(uintptr_t)(image+1024));
}
void count(int n,int slot=0) { put(stacks[slot]+8,n?(void*)counter:nullptr);stacks[slot][0x22]=(unsigned char)n; }
void tick(unsigned long long ms=40) { clockNow+=ms;CooldownSample(); }
void reset() { ui=false;localPresent=true;badStack=false;patch=111;g_cdDropAt=0;g_cdDropDown=0;CooldownNewSession(nullptr,nullptr);count(16);put(proxy+0x10,0);tick(); }
int drain(CooldownUseEvent* out) { return ConsumeCooldownUseEvents(out,32); }
int main() {
 initMemory();CooldownUseEvent events[32]{};
 CHECK(CooldownDecreased({0,7,16},{0,7,15}));CHECK(CooldownDecreased({0,7,1},{0,-1,0}));
 CHECK(!CooldownDecreased({0,7,16},{1,7,15}));CHECK(!CooldownDecreased({0,7,16},{0,8,15}));
 CHECK(!CooldownDecreased({0,7,16},{0,7,14}));CHECK(!CooldownDecreased({0,7,16},{0,7,16}));
 CHECK(!CooldownDecreased({0,7,16},{0,-1,0}));CHECK(!CooldownRecent(100,200,400));
 CHECK(!CooldownRecent(100,0,400));CHECK(CooldownRecent(500,100,400));CHECK(!CooldownRecent(501,100,400));
 reset();CHECK(g_cdObserver.baseline);
 g_cdUseAt=clockNow;g_cdUseDown=1;tick();tick(350);CHECK(drain(events)==0);
 count(15);tick();auto consumed=clockNow;CHECK(drain(events)==0);tick(280);CHECK(drain(events)==0);
 tick(40);CHECK(drain(events)==1);CHECK(std::string(events[0].itemId)=="minecraft:ender_pearl");
 CHECK(events[0].at==consumed);CHECK(events[0].session==GetCooldownSession());tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;tick(350);CHECK(drain(events)==0);
 reset();count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;g_cdDropAt=clockNow;count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;g_cdDropDown=1;
 tick(1000);count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();count(16);tick(100);tick(350);CHECK(drain(events)==0);
 reset();count(1);tick();g_cdUseAt=clockNow;count(0);tick();tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;g_cdUseDown=0;count(15);tick();tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;count(15);tick();ui=true;tick();ui=false;tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();badStack=true;tick(320);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;count(15);tick(1000);tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();put(proxy+0x10,1);tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;count(15,1);put(proxy+0x10,1);tick();tick(320);CHECK(drain(events)==0);
 reset();patch=120;g_cdUseAt=clockNow;count(15);tick(350);CHECK(drain(events)==0);
 reset();std::strcpy((char*)image+272,".?AVNotAnInventory@@");g_cdUseAt=clockNow;count(15);tick(350);
 CHECK(!g_cdObserver.baseline);CHECK(drain(events)==0);initMemory();
 reset();PublishCooldownUse("minecraft:ender_pearl");auto session=GetCooldownSession();localPresent=false;tick(1100);
 CHECK(GetCooldownSession()!=session);CHECK(drain(events)==0);
 for(int i=0;i<40;++i)PublishCooldownUse("minecraft:ender_pearl",100+i);
 CHECK(drain(events)==31);CHECK(events[0].at==109);CHECK(events[30].at==139);
 CooldownsModule hud;PublishCooldownUse("minecraft:ender_pearl",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 auto ends=hud.m_active[0].endAt;CHECK(ends==clockNow+25000);clockNow+=1000;PublishCooldownUse("minecraft:ender_pearl",clockNow);
 hud.onRender();CHECK(hud.m_active[0].endAt==ends);CHECK((ends-clockNow+999)/1000==24);
 clockNow=ends;hud.onRender();CHECK(hud.m_active.empty());PublishCooldownUse("minecraft:sugar",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 hud.setting.mValue=1;hud.onRender();CHECK(hud.m_active.empty());hud.setting.mValue=0;hud.onRender();
 PublishCooldownUse("minecraft:sugar",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 CooldownNewSession(nullptr,nullptr);hud.onRender();CHECK(hud.m_active.empty());
 PublishCooldownUse("minecraft:sugar",clockNow-31000);hud.onRender();CHECK(hud.m_active.empty());
 PublishCooldownUse("minecraft:sugar",clockNow+1);hud.onRender();CHECK(hud.m_active.empty());
 std::cout<<"PASS "<<checks<<" assertions (real observer + real HUD consumer; mocked game/Windows)\n";
}
