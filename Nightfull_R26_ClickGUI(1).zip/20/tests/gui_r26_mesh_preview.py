from pathlib import Path
from PIL import Image
import struct,base64,io,sys
base=Path(sys.argv[1]);a=base.with_suffix('.atlas').read_bytes();w,h=struct.unpack('<ii',a[:8]);alpha=Image.frombytes('L',(w,h),a[8:]);rgba=Image.new('RGBA',(w,h),'white');rgba.putalpha(alpha);png=io.BytesIO();rgba.save(png,format='PNG')
mesh=base64.b64encode(base.with_suffix('.mesh').read_bytes()).decode();atlas=base64.b64encode(png.getvalue()).decode()
html='''<!doctype html><html><head><meta charset="utf-8"><title>Nightfull — native ImGui render</title><style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#1b1e25}canvas{display:block;width:100%;height:100%;object-fit:contain}</style></head><body><canvas width="1440" height="900" aria-label="Native ImGui software preview"></canvas><script>
const bytes=Uint8Array.from(atob('MESH'),c=>c.charCodeAt(0)), dv=new DataView(bytes.buffer);let at=0;const u=()=>{let v=dv.getUint32(at,true);at+=4;return v}, f=()=>{let v=dv.getFloat32(at,true);at+=4;return v};
const canvas=document.querySelector('canvas'), gl=canvas.getContext('webgl2',{antialias:true,preserveDrawingBuffer:true});
function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();gl.attachShader(prog,shader(gl.VERTEX_SHADER,`#version 300 es
in vec2 pos;in vec2 uv;in vec4 col;out vec2 t;out vec4 c;void main(){gl_Position=vec4(pos.x/720.-1.,1.-pos.y/450.,0.,1.);t=uv;c=col;}`));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,`#version 300 es
precision mediump float;in vec2 t;in vec4 c;uniform sampler2D tex;out vec4 color;void main(){color=c*texture(tex,t);}`));gl.linkProgram(prog);gl.useProgram(prog);
const lists=[];let n=u();for(let k=0;k<n;k++){let nv=u(),ni=u(),nc=u();let verts=bytes.slice(at,at+nv*20);at+=nv*20;let idx=bytes.slice(at,at+ni*4);at+=ni*4;let cmds=[];for(let j=0;j<nc;j++)cmds.push({clip:[f(),f(),f(),f()],num:u(),offset:u(),vo:u()});lists.push({verts,idx,cmds});}
const img=new Image();img.onload=()=>{const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);
gl.viewport(0,0,1440,900);gl.clearColor(.1,.1,.12,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.enable(gl.BLEND);gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.enable(gl.SCISSOR_TEST);
for(const l of lists){let vb=gl.createBuffer(),ib=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,l.verts,gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,l.idx,gl.STATIC_DRAW);
for(const cmd of l.cmds){const attrs=[['pos',2,gl.FLOAT,false,0],['uv',2,gl.FLOAT,false,8],['col',4,gl.UNSIGNED_BYTE,true,16]];for(const [name,size,type,norm,off]of attrs){let loc=gl.getAttribLocation(prog,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,type,norm,20,off+cmd.vo*20);}let [x,y,z,w]=cmd.clip;x=Math.max(0,x);y=Math.max(0,y);z=Math.min(1440,z);w=Math.min(900,w);if(z<=x||w<=y)continue;gl.scissor(Math.floor(x),Math.floor(900-w),Math.ceil(z-x),Math.ceil(w-y));gl.drawElements(gl.TRIANGLES,cmd.num,gl.UNSIGNED_INT,cmd.offset*4);}}
window.nativeRendered=true;};img.src='data:image/png;base64,ATLAS';</script></body></html>'''.replace('MESH',mesh).replace('ATLAS',atlas)
base.with_suffix('.html').write_text(html)
