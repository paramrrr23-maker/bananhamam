// client_modules.h - menu + theme configuration holders.
//
// General and Themes are not toggleable features: they are the data behind
// the Settings page. Both are hiddenFromLists and always applied.

#pragma once

#include "core/module.h"

namespace nf {

class GeneralModule : public Module {
public:
    enum Animation { AnimFade = 0, AnimRise, AnimZoom };

    GeneralModule();

    static GeneralModule* instance() { return s_instance; }

    EnumSetting* m_guiAppearance = nullptr; // 0 Light, 1 Dark (ClickGUI only)
    StringSetting* m_guiFavorites = nullptr; // persistent favorite module names
    EnumSetting* m_animation = nullptr;     // menu open animation
    NumberSetting* m_easeSpeed = nullptr;   // transition speed
    NumberSetting* m_scrim = nullptr;       // backdrop darkness 0..1
    NumberSetting* m_guiSize = nullptr;     // whole-interface scale 0.80..1.30
    NumberSetting* m_textScale = nullptr;   // text size multiplier 0.50..2.50
    BoolSetting* m_rightPanels = nullptr;   // secondary page surfaces
    BoolSetting* m_toasts = nullptr;        // bottom-center notifications
    BoolSetting* m_animations = nullptr;    // UI animation master switch
    BoolSetting* m_blur = nullptr;          // translucent overlay panels
    BoolSetting* m_hudEdit = nullptr;       // free-form HUD editor (editmenu)

private:
    static GeneralModule* s_instance;
};

class ThemesModule : public Module {
public:
    enum { ThemeDefault = 0, ThemePurple, ThemeBlue, ThemeCyan, ThemeRed,
           ThemeGreen, ThemeOrange, ThemeMono, ThemeCustom };
    enum { NamingLower = 0, NamingLowerSpaced, NamingNormal, NamingSpaced };

    ThemesModule();

    static ThemesModule* instance() { return s_instance; }

    EnumSetting* m_naming = nullptr;
    EnumSetting* m_theme = nullptr;
    NumberSetting* m_colorSlots = nullptr;
    ColorSetting* m_color1 = nullptr;
    ColorSetting* m_color2 = nullptr;
    ColorSetting* m_color3 = nullptr;
    ColorSetting* m_color4 = nullptr;
    ColorSetting* m_color5 = nullptr;
    ColorSetting* m_color6 = nullptr;
    NumberSetting* m_colorSpeed = nullptr;
    NumberSetting* m_saturation = nullptr;
    // ClickGUI cursor customization (persisted through ordinary settings).
    // Style: 0 Arrow, 1 Ring, 2 Cross, 3 Dot.
    EnumSetting* m_cursorStyle = nullptr;
    NumberSetting* m_cursorScale = nullptr;
    NumberSetting* m_cursorGlow = nullptr;
    BoolSetting* m_cursorTheme = nullptr;
    ColorSetting* m_cursorColor = nullptr;
    // Last applied gallery preset (theme_presets.h index) for the UI
    // highlight. Hidden from every settings list; the colors themselves are
    // what actually persists the theme.
    NumberSetting* m_presetIdx = nullptr;

private:
    static ThemesModule* s_instance;
};

} // namespace nf
