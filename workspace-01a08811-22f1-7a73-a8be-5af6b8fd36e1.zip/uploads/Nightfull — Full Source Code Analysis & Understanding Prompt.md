# NIGHTFULL — FULL SOURCE CODE ANALYSIS & UNDERSTANDING

Я сейчас передам тебе полный `src` исходного кода проекта Nightfull.

Твоя первая и главная задача — **НЕ ИЗМЕНЯТЬ КОД**.

Сначала ты должен **ПОЛНОСТЬЮ разобраться в существующем исходном коде проекта**, его архитектуре, зависимостях, системах, взаимосвязях и принципах работы.

Не начинай реализацию новых функций, не переписывай классы, не создавай новые файлы и не предлагай код до тех пор, пока не закончишь полноценный анализ `src`.

---

# 1. ГЛАВНОЕ ПРАВИЛО

Считай, что ты впервые видишь этот проект.

Не делай предположений о том, как он работает.

Не исходи из названий файлов.

Не предполагай, что определённый класс отвечает за определённую систему только потому, что его название на это похоже.

**Проверяй всё по реальному коду.**

Твоя задача:

> Сначала полностью понять существующий проект, а уже потом работать с ним.

Мне важно, чтобы после анализа ты мог уверенно ответить:

- где находится каждая система;
- кто её вызывает;
- откуда начинается выполнение;
- какие классы связаны друг с другом;
- как данные проходят через систему;
- как работает rendering;
- как работает GUI;
- как работает HUD;
- как работают настройки;
- как хранятся настройки;
- как создаются и регистрируются модули;
- как работает lifecycle;
- какие части проекта уже существуют;
- какие части недоделаны;
- какие части нельзя ломать;
- где безопасно вносить изменения.

---

# 2. НЕ ОГРАНИЧИВАЙСЯ ПОВЕРХНОСТНЫМ ПРОСМОТРОМ

Не делай анализ только по структуре папок.

Не достаточно сказать:

```text
Есть GUI.
Есть Renderer.
Есть Modules.
Есть Settings.
```

Мне нужен настоящий технический разбор.

Для каждой важной системы выясни:

```text
Кто её создаёт?
↓
Кто её инициализирует?
↓
Кто её вызывает?
↓
Какие данные она получает?
↓
Что она изменяет?
↓
Какие классы используют её?
↓
Какие зависимости у неё есть?
↓
Какой lifecycle?
```

---

# 3. СНАЧАЛА ИЗУЧИ ВЕСЬ SRC

Пройди по всему предоставленному `src`.

Не пропускай файлы только потому, что они выглядят незначительными.

Особенно внимательно изучи:

- `.cpp`
- `.h`
- `.hpp`
- rendering classes
- GUI classes
- module classes
- settings
- managers
- utilities
- hooks
- event systems
- initialization
- registration
- resources
- abstractions
- interfaces
- wrappers
- helpers

Если существуют дополнительные файлы, необходимые для понимания `src`, также учитывай их.

---

# 4. СОЗДАЙ КАРТУ ПРОЕКТА

После изучения исходников составь архитектурную карту.

Например:

```text
Nightfull
│
├── Entry Point
│
├── Initialization
│
├── Core
│
├── Module System
│
├── Settings
│
├── Event System
│
├── GUI
│
├── HUD
│
├── Rendering
│
├── Text Rendering
│
├── Texture System
│
├── Animation
│
├── Theme
│
├── Input
│
├── Configuration
│
└── Utilities
```

Но **не используй эту структуру автоматически**.

Создай реальную структуру на основе исходников.

---

# 5. ENTRY POINT

Найди настоящий entry point проекта.

Определи:

- с какого места начинается выполнение;
- какая DLL/библиотека загружается первой;
- какой класс является главным;
- где происходит initialization;
- какие системы создаются;
- в каком порядке они создаются;
- какие зависимости существуют между ними.

Опиши реальный lifecycle:

```text
Process / DLL Load
↓
Initialization
↓
Managers
↓
Renderer
↓
GUI
↓
Modules
↓
Events / Hooks
↓
Runtime
```

Если реальный порядок отличается — покажи реальный порядок.

---

# 6. INITIALIZATION

Полностью разберись в системе инициализации.

Найди:

- init functions;
- constructors;
- registration;
- manager creation;
- renderer initialization;
- module registration;
- settings registration;
- event registration;
- hooks;
- cleanup/shutdown.

Определи:

- что создаётся первым;
- что зависит от чего;
- что может быть создано только после Minecraft;
- что создаётся один раз;
- что создаётся динамически.

---

# 7. MODULE SYSTEM

Полностью исследуй существующую систему модулей.

Определи:

- базовый Module class;
- Module Manager;
- module registration;
- module lifecycle;
- enable/disable;
- settings;
- events;
- rendering callbacks;
- input;
- keybinds;
- module categories.

Построй реальную цепочку:

```text
Module Registration
↓
Module Manager
↓
Module Instance
↓
Settings
↓
Enable / Disable
↓
Events
↓
Rendering / Logic
```

Для каждого важного компонента объясни его роль.

---

# 8. SETTINGS SYSTEM

Очень внимательно изучи существующую систему настроек.

Определи:

- какие типы settings существуют;
- где они создаются;
- где хранятся;
- как получают значения;
- как изменяются;
- как GUI получает их;
- как settings связываются с modules;
- есть ли serialization;
- есть ли default values;
- есть ли reset;
- есть ли visibility/dependencies;
- есть ли ranges;
- есть ли enums;
- есть ли colors;
- есть ли keybinds.

Найди реальный flow:

```text
Setting
↓
Module
↓
Settings Manager
↓
GUI
↓
User Input
↓
Setting Value
↓
Module Behavior
```

Если архитектура другая — опиши настоящую.

---

# 9. GUI SYSTEM

Полностью разберись в существующем GUI.

Определи:

- главный GUI entry point;
- screen/menu system;
- widgets;
- panels;
- categories;
- module cards;
- settings controls;
- input handling;
- mouse;
- keyboard;
- scrolling;
- clipping;
- animations;
- layout;
- rendering.

Особенно важно понять:

**как GUI реально рисуется.**

Опиши pipeline:

```text
GUI Update
↓
Layout
↓
State
↓
Animation
↓
Rendering
```

И отдельно:

```text
Mouse Input
↓
Widget Hit Detection
↓
Interaction
↓
Setting Change
```

---

# 10. RENDERING SYSTEM

Это одна из самых важных частей анализа.

Полностью исследуй rendering foundation.

Найди:

- Render Manager;
- Renderer;
- Render Context;
- 2D renderer;
- 3D renderer;
- text renderer;
- texture renderer;
- shape renderer;
- clipping;
- transforms;
- alpha;
- blending;
- gradients;
- rounded rectangles;
- borders;
- outlines;
- shadows;
- blur;
- glow;
- shaders;
- Minecraft rendering integration.

Для каждого rendering primitive выясни:

```text
Где находится?
Как вызывается?
Какие параметры принимает?
Какой backend использует?
Какие ограничения имеет?
```

---

# 11. RENDERING PIPELINE

Построй реальный pipeline проекта.

Например:

```text
Minecraft Render Event
↓
Nightfull Render Hook
↓
Render Manager
↓
Renderer
↓
Primitive
↓
GPU / Minecraft Rendering Pipeline
```

Но опять же — **не придумывай**.

Покажи реальный pipeline на основе кода.

---

# 12. TEXT RENDERING

Отдельно изучи систему текста.

Определи:

- Font Manager;
- Font Renderer;
- glyph handling;
- font loading;
- text measurement;
- text width;
- text height;
- alignment;
- scaling;
- color;
- alpha;
- shadow;
- clipping.

Объясни, как конкретно рисуется текст.

---

# 13. GUI → RENDERER CONNECTION

Очень важно определить, каким образом GUI использует renderer.

Например:

```text
GUI Widget
↓
Draw Background
↓
Renderer
↓
Draw Rounded Rect
↓
Draw Outline
↓
Draw Text
```

Нужно найти реальные вызовы.

Не описывай абстрактную архитектуру, если в проекте уже есть конкретная.

---

# 14. HUD SYSTEM

Если HUD уже существует, полностью изучи его.

Определи:

- HUD manager;
- HUD modules;
- positioning;
- scaling;
- layout;
- rendering;
- settings;
- editor;
- persistence.

Особенно важно понять, как HUD module взаимодействует с renderer.

---

# 15. THEME SYSTEM

Если существует Theme System:

изучи её полностью.

Найди:

- colors;
- accent;
- background;
- surface;
- text;
- border;
- glow;
- theme switching;
- color storage;
- default values.

Определи, можно ли уже использовать theme colors в HUD/GUI.

---

# 16. EVENT SYSTEM

Полностью разберись в events.

Определи:

- какие events существуют;
- кто их создаёт;
- кто их dispatch'ит;
- кто подписывается;
- lifecycle;
- render events;
- tick/update events;
- input events;
- GUI events.

Построй:

```text
Event Source
↓
Event Dispatcher
↓
Listeners
↓
Modules / GUI / Renderer
```

---

# 17. INPUT SYSTEM

Изучи:

- keyboard input;
- mouse input;
- keybinds;
- mouse buttons;
- click handling;
- focus;
- GUI input;
- game input.

Определи, как событие проходит от Minecraft до Nightfull.

---

# 18. CONFIGURATION / PERSISTENCE

Если проект сохраняет настройки, найди:

- config manager;
- serialization;
- deserialization;
- file format;
- loading;
- saving;
- defaults;
- profiles.

Определи:

```text
Application Start
↓
Load Config
↓
Create Modules
↓
Apply Settings
```

и:

```text
Setting Change
↓
Config State
↓
Save
```

если такая система существует.

---

# 19. DEPENDENCIES

Проанализируй зависимости между системами.

Создай dependency map.

Например:

```text
GUI
 ├── Settings
 ├── Theme
 ├── Renderer
 └── Input

HUD
 ├── Modules
 ├── Settings
 ├── Theme
 └── Renderer

Modules
 ├── Event System
 ├── Settings
 └── Renderer
```

Но опять же — только на основании реального кода.

---

# 20. CALL GRAPH

Для ключевых систем составь упрощённый call graph.

Особенно для:

- initialization;
- GUI opening;
- GUI rendering;
- HUD rendering;
- module enable;
- setting change;
- rendering;
- input.

Например:

```text
Open GUI
↓
GuiManager::open()
↓
Screen::render()
↓
Panel::render()
↓
ModuleCard::render()
↓
Renderer::drawRoundedRect()
```

Используй реальные названия классов и методов из проекта.

---

# 21. DATA FLOW

Для важных данных покажи путь.

Например Settings:

```text
User
↓
GUI
↓
Setting Widget
↓
Setting Object
↓
Module
↓
Runtime Behavior
```

Для rendering:

```text
Module
↓
Render Call
↓
Render Manager
↓
Renderer
↓
Minecraft Graphics
```

---

# 22. УЗКИЕ МЕСТА И ПРОБЛЕМЫ

После полного понимания кода найди:

- архитектурные слабости;
- дублирование;
- tight coupling;
- unnecessary dependencies;
- unsafe assumptions;
- потенциальные crashes;
- lifecycle problems;
- rendering bottlenecks;
- memory issues;
- duplicated rendering logic;
- duplicated settings logic.

Но:

**НЕ ИСПРАВЛЯЙ ИХ.**

Только перечисли.

---

# 23. DEAD CODE

Определи:

- unused classes;
- unused methods;
- abandoned systems;
- TODO;
- FIXME;
- experimental code;
- duplicate implementations.

Не удаляй ничего.

Только укажи, что найдено.

---

# 24. НЕ ДЕЛАЙ ПРЕДПОЛОЖЕНИЙ

Если ты не уверен:

не говори:

> "Вероятно, этот класс отвечает за..."

Вместо этого:

> "По текущему коду не удалось подтвердить..."

или:

> "Требуется дополнительный контекст из файла X."

Мне нужна техническая точность, а не догадки.

---

# 25. НЕ МЕНЯЙ SRC

До завершения анализа:

**НЕ ДЕЛАЙ:**

- refactor;
- rewrite;
- optimization;
- new classes;
- new files;
- deleting files;
- moving files;
- changing APIs;
- changing rendering;
- changing GUI;
- changing modules;
- changing settings.

Сначала только исследование.

---

# 26. ИТОГОВЫЙ ОТЧЁТ

После полного анализа предоставь подробный отчёт.

Структура:

```text
1. Project Overview

2. Project Structure

3. Entry Point

4. Initialization

5. Core Architecture

6. Module System

7. Settings System

8. GUI System

9. HUD System

10. Rendering System

11. Text Rendering

12. Theme System

13. Event System

14. Input System

15. Configuration System

16. Dependency Map

17. Call Graph

18. Data Flow

19. Important Classes

20. Important Methods

21. Existing Rendering Primitives

22. Existing GUI Components

23. Existing HUD Components

24. Existing Settings Types

25. Architectural Problems

26. Dead / Unused Code

27. Missing Pieces

28. Potential Risks

29. What Must NOT Be Changed

30. What Can Be Safely Extended

31. Final Understanding
```

---

# 27. IMPORTANT CLASSES TABLE

Создай таблицу:

| Class | File | Responsibility | Used By | Depends On |
|---|---|---|---|---|

Добавь все ключевые классы.

Не нужно перечислять абсолютно каждый trivial helper, но все архитектурно важные классы должны присутствовать.

---

# 28. IMPORTANT METHODS TABLE

Создай:

| Method | Class | Purpose | Called From | Important Notes |
|---|---|---|---|---|

Особенно для:

- initialization;
- rendering;
- GUI;
- settings;
- modules;
- events;
- input;
- configuration.

---

# 29. RENDERING PRIMITIVES TABLE

Создай:

| Primitive | Existing? | Location | Used By | Parameters | Notes |
|---|---|---|---|---|---|

Например:

- Rounded Rectangle
- Rectangle
- Line
- Text
- Texture
- Gradient
- Blur
- Shadow
- Outline
- Alpha
- Clip
- Transform

Но добавляй только реально существующие или явно отсутствующие primitives.

---

# 30. SETTINGS TABLE

Создай:

| Setting Type | Exists? | Location | Used By | Default | GUI Control |
|---|---|---|---|---|---|

Например:

- Boolean
- Integer
- Float
- Enum
- Color
- Keybind
- String
- Slider
- Multi-select

---

# 31. FINAL UNDERSTANDING

В конце дай раздел:

# "WHAT I NOW UNDERSTAND"

В нём подробно объясни своими словами:

- как устроен Nightfull;
- с чего начинается его работа;
- как создаются системы;
- как создаются modules;
- как работают settings;
- как работает GUI;
- как работает rendering;
- как работает HUD;
- как GUI связан с settings;
- как HUD связан с renderer;
- как Theme связан с UI;
- как input проходит через систему;
- где находятся основные точки расширения.

Я должен получить ощущение, что ты **действительно прочитал и понял исходный код**, а не просто посмотрел названия папок.

---

# 32. CONFIRMATION

После анализа не начинай ничего реализовывать.

В самом конце напиши:

```text
SOURCE ANALYSIS COMPLETE

I have analyzed the provided Nightfull source code and mapped:
- architecture
- initialization
- modules
- settings
- GUI
- HUD
- rendering
- events
- input
- configuration
- dependencies
- data flow
- important classes and methods

No source files were modified during this analysis.

I am ready for the next task.
```

Только после этого жди следующего задания.

---

# ГЛАВНАЯ ЦЕЛЬ

Твоя задача сейчас не "написать что-нибудь".

Твоя задача — **полностью понять существующий Nightfull**.

Не переписывай существующую архитектуру без необходимости.

Не создавай параллельные системы, если в проекте уже есть подходящая система.

Не дублируй renderer, settings manager, theme system, GUI system или module system.

Если я позже попрошу добавить новую функцию, ты должен сначала определить:

```text
Какая существующая система уже отвечает за это?
↓
Можно ли расширить её?
↓
Какие существующие классы нужно использовать?
↓
Где должна находиться новая логика?
↓
Какие существующие API уже можно переиспользовать?
```

Только после этого можно переходить к реализации.

**Сначала полностью изучи SRC. Потом думай. И только после отдельной команды приступай к изменениям.**