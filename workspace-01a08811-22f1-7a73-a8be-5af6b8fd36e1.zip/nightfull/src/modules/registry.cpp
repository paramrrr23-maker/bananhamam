// registry.cpp - builds the module roster (order = menu order).

#include "modules/registry.h"

#include <memory>
#include <utility>

#include "core/module_manager.h"
#include "modules/client_modules.h"
#include "modules/hud_modules.h"
#include "modules/stub_modules.h"
#include "utils/logger.h"

namespace nf {

void RegisterAllModules() {
    using std::make_unique;
    // Always-on HUD chrome (hidden from the menu, render regardless).
    modules().add(make_unique<WatermarkModule>());
    modules().add(make_unique<ArraylistModule>());
    // ClickGUI roster (visible order = web prototype order).
    modules().add(make_unique<HudModule>());          // stub: menu state only
    modules().add(make_unique<CrosshairModule>());    // real
    modules().add(make_unique<SkyboxModule>());       // stub: menu state only
    modules().add(make_unique<KeystrokesModule>());   // real
    modules().add(make_unique<FpsModule>());          // real
    modules().add(make_unique<TargetHudModule>());    // stub: menu state only
    modules().add(make_unique<ZoomModule>());         // stub: menu state only
    modules().add(make_unique<HotbarModule>());       // stub: menu state only
    modules().add(make_unique<TimeChangerModule>());  // stub: menu state only
    // Working HUD extras: kept alive (config + keybinds keep working) but
    // hidden from the prototype menu until their cards exist.
    auto addHidden = [](auto m) {
        m->hiddenFromLists = true;
        modules().add(std::move(m));
    };
    addHidden(make_unique<CpsModule>());
    addHidden(make_unique<KeybindsModule>());
    addHidden(make_unique<TimeModule>());
    addHidden(make_unique<MemoryModule>());
    addHidden(make_unique<MouseStrokesModule>());
    // Client category (menu/theme data holders).
    modules().add(make_unique<GeneralModule>());
    modules().add(make_unique<ThemesModule>());
    LOG_INFO("registry: %d modules", (int)modules().modules().size());
}

} // namespace nf
