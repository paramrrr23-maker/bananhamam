// keys.h - fused per-frame keyboard snapshot.
//
// Producers: the overlay's WndProc subclass feeds legacy WM_KEYDOWN/WM_KEYUP
// plus WM_INPUT and Keyboard::feed via FeedKey. While text capture is enabled,
// physical key edges are layout-translated exactly once, independent of WM_CHAR.
// BeginFrame merges pending state and short-press latches with a fresh async
// poll every fourth frame; stale samples never overwrite newer feed events.
// Consumers ask Down()/
// PressedThisFrame()/Name()/TextInput(). One snapshot per rendered frame;
// Reset() drops all history (called on menu open/close transitions so held
// keys never misfire as fresh presses).

#pragma once

#include <cstddef>

namespace nf {
namespace keys {

// Optional raw sampler used by the overlay when it temporarily masks the
// process-wide Win32 async state from the game. The sampler must return the
// unmasked/original state for Nightfull's own input snapshot.
using AsyncStateSampler = short (*)(int vk);
void SetAsyncStateSampler(AsyncStateSampler sampler);
// Custom GUI text has one source: layout translation of fused physical keys.
// Enable on menu ownership, disable on close. No WM_CHAR dependency in CoreWindow.
void SetTextCapture(bool active);

void BeginFrame();                 // call once per frame, before any query
void Reset();                      // drop all key history + char queue

void FeedKey(unsigned int vk, bool down);  // from WndProc (any thread)
void FeedChar(unsigned int ch);            // from WndProc WM_CHAR (UTF-16 unit)

bool Down(unsigned int vk);
bool PressedThisFrame(unsigned int vk);    // includes down+up between frames
const char* Name(unsigned int vk);         // short display name ("INSERT", "K", ...)

// Appends queued UTF-16 text to a UTF-8 editor buffer (handles backspace).
// Returns true when the buffer changed. When active==false the queue is
// dropped and false is returned.
bool TextInput(char* buf, size_t cap, bool active);

} // namespace keys
} // namespace nf
