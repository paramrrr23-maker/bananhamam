// clickgui_module.h - the ClickGui module (Solstice's ClickGui.hpp).
//
// In Solstice the menu itself is a module: it lives in the Visual category, it
// carries its own settings (style, animation, blur, ease speed, mid-click
// rounding) and the GUI reads them straight off the module. Same here - this
// is the module the menu configures itself with.
//
// NOTE: ASCII only in this file.

#pragma once

#include "modules/module.h"

namespace modules {

class ClickGuiModule : public Module {
public:
    // Glass is first so configs saved before it existed (index 0) land on it.
    enum Animation { ANIM_GLASS = 0, ANIM_ZOOM, ANIM_BOUNCE };

    ClickGuiModule();

    // The registered instance, or nullptr before registration.
    static ClickGuiModule* instance() { return s_instance; }

    EnumSetting*   m_animation        = nullptr;
    NumberSetting* m_blurStrength     = nullptr;
    NumberSetting* m_easeSpeed        = nullptr;
    NumberSetting* m_midclickRounding = nullptr;
    NumberSetting* m_panelOpacity     = nullptr;
    NumberSetting* m_borderOpacity    = nullptr;
    NumberSetting* m_cornerRadius     = nullptr;
    BoolSetting*   m_glass            = nullptr;   // frosted glass material
    NumberSetting* m_transparency     = nullptr;   // glass see-through amount

private:
    static ClickGuiModule* s_instance;
};

} // namespace modules
