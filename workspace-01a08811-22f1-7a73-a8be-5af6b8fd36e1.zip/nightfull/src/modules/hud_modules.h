// hud_modules.h - the curated local-only HUD roster.
//
// Every module here draws from process-local state (ImGui IO, Win32 clock,
// own working set, the module registry). None of them reads game memory.

#pragma once

#include <array>
#include <string>
#include <vector>

#include "core/module.h"

namespace nf {

// Shared 6-corner anchor (module settings store the int).
// NOTE: order is stable API (configs store the index).
inline std::vector<std::string> HudPositionNames() {
    return { "Top Left", "Top Right", "Bottom Left", "Bottom Right", "Top Center", "Bottom Center" };
}

class WatermarkModule : public Module {
public:
    WatermarkModule();
    void onRender() override;
private:
    StringSetting* m_text = nullptr;
    BoolSetting* m_background = nullptr;
    BoolSetting* m_outline = nullptr;
    BoolSetting* m_fps = nullptr;
    BoolSetting* m_clock = nullptr;
    NumberSetting* m_opacity = nullptr;
    NumberSetting* m_scale = nullptr;
};

class ArraylistModule : public Module {
public:
    ArraylistModule();
    void onRender() override;
private:
    BoolSetting* m_showMode = nullptr;
    EnumSetting* m_visibility = nullptr;   // All / Bound
    NumberSetting* m_fontSize = nullptr;
    NumberSetting* m_opacity = nullptr;
    NumberSetting* m_scale = nullptr;
    std::vector<float> m_anim;             // per-registry-index slide 0..1
};

class FpsModule : public Module {
public:
    FpsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

class CpsModule : public Module {
public:
    CpsModule();
    void onTick() override;
    void onRender() override;
private:
    static constexpr int kMaxClicks = 64;
    std::array<unsigned long long, kMaxClicks> m_lmb{};
    std::array<unsigned long long, kMaxClicks> m_rmb{};
    int m_lmbHead = 0, m_rmbHead = 0, m_lmbCount = 0, m_rmbCount = 0;
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_buttons = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    void record(std::array<unsigned long long, kMaxClicks>& b, int& head, int& count,
                unsigned long long now);
    int recent(const std::array<unsigned long long, kMaxClicks>& b, int head, int count,
               unsigned long long now) const;
};

class KeybindsModule : public Module {
public:
    KeybindsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_outline = nullptr;
    NumberSetting* m_opacity = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

class TimeModule : public Module {
public:
    TimeModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_seconds = nullptr;
    BoolSetting* m_24h = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

class MemoryModule : public Module {
public:
    MemoryModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

class MouseStrokesModule : public Module {
public:
    MouseStrokesModule();
    void onEnable() override;
    void onDisable() override;
    void onTick() override;
    void onRender() override;
private:
    struct TrailPoint { ImVec2 pos{}; unsigned long long ms = 0; };
    static constexpr int kMaxPoints = 64;
    static constexpr unsigned long long kLifetimeMs = 260;
    std::array<TrailPoint, kMaxPoints> m_points{};
    int m_count = 0;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    void expire(unsigned long long now);
};

class KeystrokesModule : public Module {
public:
    KeystrokesModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_spacing = nullptr;
    NumberSetting* m_rounding = nullptr;
    BoolSetting* m_showMouse = nullptr;
    ColorSetting* m_pressed = nullptr;
    ColorSetting* m_released = nullptr;
};

class CrosshairModule : public Module {
public:
    CrosshairModule();
    void onRender() override;
private:
    BoolSetting* m_dynamic = nullptr;
    NumberSetting* m_gap = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

} // namespace nf
