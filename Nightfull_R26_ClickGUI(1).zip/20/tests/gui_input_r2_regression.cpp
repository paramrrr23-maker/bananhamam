
#include <algorithm>
#include <array>
#include <cmath>
#include <cassert>
#include <iostream>
#include <cstdarg>
#include "imgui.h"
#include "core/module.h"
using ULONGLONG = unsigned long long;
using LONG = long; using DWORD = unsigned long;
using HWND = unsigned long long;
constexpr int GA_ROOT=2;
ULONGLONG now=100;
ULONGLONG GetTickCount64() { return now; }
HWND fg=20; DWORD fgPid=999; HWND coreParent=20;
HWND GetForegroundWindow() { return fg; }
DWORD GetCurrentProcessId() { return 42; }
DWORD GetWindowThreadProcessId(HWND, DWORD* pid) { if(pid) *pid=fgPid; return 1; }
bool IsChild(HWND parent, HWND child) { return parent==coreParent && child==10; }
HWND GetAncestor(HWND h, int) { return h==10 ? coreParent : h; }
LONG InterlockedCompareExchange(volatile LONG* p, LONG, LONG) { return *p; }
using SRWLOCK=int;
void AcquireSRWLockExclusive(SRWLOCK*) {}
void ReleaseSRWLockExclusive(SRWLOCK*) {}
void AcquireSRWLockShared(SRWLOCK*) {}
void ReleaseSRWLockShared(SRWLOCK*) {}
namespace nf {
namespace gui { ImVec2 GetScreenSize() { return ImVec2(1920,1080); } }
namespace overlay {
bool g_showMenu=false, g_hudEdit=false, g_shuttingDown=false;
HWND g_hwnd=10;
volatile LONG g_appInputActive=1;
bool UiInputOwned() { return g_showMenu || g_hudEdit; }
bool HudEditActive() { return g_hudEdit; }
bool gameplay=true;
bool IsGameplayScreen() { return gameplay; }
struct CrosshairCamera { float right[3]={},up[3]={},forward[3]={}; float focalX=1,focalY=1; };
SRWLOCK g_crosshairCameraLock=0;
CrosshairCamera g_crosshairCamera{};
ULONGLONG g_crosshairCameraAt=0;
bool GameWindowFocused() {
    // UWP's foreground HWND may belong to ApplicationFrameHost, NOT Bedrock.
    // Never use foreground PID inequality as proof that the CoreWindow lost focus.
    DWORD pid = 0;
    const HWND foreground = GetForegroundWindow();
    if (foreground) {
        GetWindowThreadProcessId(foreground, &pid);
        if (pid == GetCurrentProcessId() || foreground == g_hwnd ||
            (g_hwnd && (IsChild(foreground, g_hwnd) ||
                         GetAncestor(g_hwnd, GA_ROOT) == foreground)))
            return true;
    }
    return InterlockedCompareExchange(&g_appInputActive, 0, 0) != 0;
}
bool SoftwareCursorOwned() {
    return UiInputOwned() && !g_shuttingDown && GameWindowFocused();
}
static void PublishCrosshairCamera(const float matrix[16], float fx, float fy) {
    CrosshairCamera camera{};
    float rightLength = 0.0f, upLength = 0.0f;
    for (int i = 0; i < 3; ++i) {
        camera.right[i] = matrix[i];
        camera.up[i] = matrix[4+i];
        rightLength += camera.right[i] * camera.right[i];
        upLength += camera.up[i] * camera.up[i];
    }
    if (!std::isfinite(rightLength) || !std::isfinite(upLength) ||
        rightLength < 0.01f || upLength < 0.01f) return;
    rightLength = std::sqrt(rightLength);
    upLength = std::sqrt(upLength);
    float dot = 0.0f;
    for (int i = 0; i < 3; ++i) {
        camera.right[i] /= rightLength;
        camera.up[i] /= upLength;
        dot += camera.right[i] * camera.up[i];
    }
    if (std::fabs(dot) > 0.05f) return;
    // Bedrock's established row-major view uses -Z forward.
    camera.forward[0] = camera.up[1]*camera.right[2] - camera.up[2]*camera.right[1];
    camera.forward[1] = camera.up[2]*camera.right[0] - camera.up[0]*camera.right[2];
    camera.forward[2] = camera.up[0]*camera.right[1] - camera.up[1]*camera.right[0];
    const float length = std::sqrt(camera.forward[0]*camera.forward[0] +
                                   camera.forward[1]*camera.forward[1] +
                                   camera.forward[2]*camera.forward[2]);
    if (!std::isfinite(length) || length < 0.9f) return;
    for (float& v : camera.forward) v /= length;
    camera.focalX = std::isfinite(fx) && fx > 0.05f ? fx : 1.428148f;
    camera.focalY = std::isfinite(fy) && fy > 0.05f ? fy : 1.428148f;
    AcquireSRWLockExclusive(&g_crosshairCameraLock);
    g_crosshairCamera = camera;
    g_crosshairCameraAt = GetTickCount64();
    ReleaseSRWLockExclusive(&g_crosshairCameraLock);
}
bool GetCrosshairCamera(CrosshairCamera* out) {
    if (!out || UiInputOwned() || !GameWindowFocused()) return false;
    AcquireSRWLockShared(&g_crosshairCameraLock);
    const bool fresh = g_crosshairCameraAt != 0 &&
                       GetTickCount64() - g_crosshairCameraAt < 150;
    if (fresh) *out = g_crosshairCamera;
    ReleaseSRWLockShared(&g_crosshairCameraLock);
    return fresh;
}
void DrawGuiCursor() {
    if (!SoftwareCursorOwned()) return;
    const ImGuiIO& io = ImGui::GetIO();
    const ImVec2 p = io.MousePos;
    if (!std::isfinite(p.x) || !std::isfinite(p.y) ||
        p.x < 0.0f || p.y < 0.0f || p.x >= io.DisplaySize.x || p.y >= io.DisplaySize.y)
        return;
    const float s = std::clamp(io.DisplaySize.y / 1080.0f, 0.9f, 1.8f);
    const ImVec2 arrow[] = {
        p, ImVec2(p.x + 2*s, p.y + 21*s), ImVec2(p.x + 7*s, p.y + 16*s),
        ImVec2(p.x + 11*s, p.y + 25*s), ImVec2(p.x + 15*s, p.y + 23*s),
        ImVec2(p.x + 11*s, p.y + 14*s), ImVec2(p.x + 19*s, p.y + 14*s)
    };
    ImDrawList* d = ImGui::GetForegroundDrawList();
    d->PushClipRectFullScreen();
    // Three triangles form a visible arrow independently of cursor textures.
    d->AddTriangleFilled(arrow[0], arrow[1], arrow[6], IM_COL32(255,255,255,255));
    d->AddQuadFilled(arrow[2], arrow[3], arrow[4], arrow[5], IM_COL32(255,255,255,255));
    d->AddPolyline(arrow, 7, IM_COL32(15,18,22,255), ImDrawFlags_Closed, 1.6f*s);
    d->PopClipRect();
}
} // overlay
ImColor AccentOf(BoolSetting*, ColorSetting*) { return ImColor(80,220,150,255); }
class CrosshairStrokesModule final : public Module {
public:
    CrosshairStrokesModule();
    void onEnable() override;
    void onDisable() override;
    void onRender() override;
private:
    struct Point { float direction[3] = {}; unsigned long long ms = 0; };
    std::array<Point, 64> m_points{};
    int m_count = 0;
    unsigned long long m_sampleAt = 0;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_lifetime = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};
CrosshairStrokesModule::CrosshairStrokesModule()
    : Module("Visual", "Crosshair Strokes",
             "Затухающий след за направлением прицела при повороте камеры.") {
    m_length = addSetting<NumberSetting>("Length", "Максимум точек следа.", 32, 4, 64, 1);
    m_lifetime = addSetting<NumberSetting>("Lifetime", "Затухание следа, мс.", 260, 80, 800, 10);
    m_thickness = addSetting<NumberSetting>("Thickness", "Толщина линии.", 2, 1, 6, 0.5f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Цвет из текущей темы.", true);
    m_color = addSetting<ColorSetting>("Color", "Свой цвет следа.", 0xFF8E5CFF);
}

void CrosshairStrokesModule::onEnable() { m_count = 0; m_sampleAt = 0; }
void CrosshairStrokesModule::onDisable() { m_count = 0; m_sampleAt = 0; }

void CrosshairStrokesModule::onRender() {
    overlay::CrosshairCamera camera{};
    if (overlay::g_showMenu || overlay::HudEditActive() ||
        !overlay::GetCrosshairCamera(&camera) || !overlay::IsGameplayScreen()) {
        m_count = 0; m_sampleAt = 0;
        return;
    }
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x < 2 || screen.y < 2) { m_count = 0; return; }
    const unsigned long long now = GetTickCount64();
    const auto lifetime = (unsigned long long)std::clamp(m_lifetime->mValue, 80.0f, 800.0f);
    const int capacity = std::clamp((int)m_length->mValue, 4, 64);
    int first = 0;
    while (first < m_count && now - m_points[first].ms > lifetime) ++first;
    if (first) {
        for (int i = first; i < m_count; ++i) m_points[i-first] = m_points[i];
        m_count -= first;
    }
    if (m_count) {
        const float* last = m_points[m_count-1].direction;
        const float dot = last[0]*camera.forward[0] + last[1]*camera.forward[1] +
                          last[2]*camera.forward[2];
        if (dot < 0.5f) m_count = 0; // camera cut/large turn: no screen-spanning streak
    }
    if (!m_count || now - m_sampleAt >= 8) {
        while (m_count >= capacity) {
            for (int i = 1; i < m_count; ++i) m_points[i-1] = m_points[i];
            --m_count;
        }
        Point& point = m_points[m_count++];
        std::copy(camera.forward, camera.forward + 3, point.direction);
        point.ms = now;
        m_sampleAt = now;
    }
    const ImColor base = AccentOf(m_useTheme, m_color);
    const float thickness = std::clamp(m_thickness->mValue, 1.0f, 6.0f);
    ImDrawList* draw = ImGui::GetForegroundDrawList();
    draw->PushClipRect(ImVec2(0,0), screen, true);
    ImVec2 previous{};
    bool havePrevious = false;
    // Reproject historic aim DIRECTIONS into the current camera, not desktop
    // cursor positions. The newest endpoint is exactly the in-game crosshair.
    for (int i = 0; i <= m_count; ++i) {
        ImVec2 pos(screen.x * 0.5f, screen.y * 0.5f);
        float life = 1.0f;
        if (i < m_count) {
            const Point& point = m_points[i];
            float x = 0, y = 0, depth = 0;
            for (int j = 0; j < 3; ++j) {
                x += point.direction[j] * camera.right[j];
                y += point.direction[j] * camera.up[j];
                depth += point.direction[j] * camera.forward[j];
            }
            if (depth <= 0.1f) { havePrevious = false; continue; }
            pos.x += x / depth * screen.x * 0.5f * camera.focalX;
            pos.y -= y / depth * screen.y * 0.5f * camera.focalY;
            life = std::clamp(1.0f - (float)(now-point.ms)/(float)lifetime, 0.0f, 1.0f);
        }
        if (!std::isfinite(pos.x) || !std::isfinite(pos.y) ||
            pos.x < 0 || pos.x > screen.x || pos.y < 0 || pos.y > screen.y) {
            havePrevious = false; continue;
        }
        const float dx = pos.x - previous.x, dy = pos.y - previous.y;
        if (havePrevious && dx*dx + dy*dy > 0.04f) {
            const float taper = 0.2f + 0.8f * (float)(i+1)/(float)(m_count+1);
            draw->AddLine(previous, pos,
                ImColor(base.Value.x, base.Value.y, base.Value.z, 0.12f*life*taper),
                thickness + 3.0f);
            draw->AddLine(previous, pos,
                ImColor(base.Value.x, base.Value.y, base.Value.z, 0.9f*life*taper),
                thickness);
        }
        previous = pos;
        havePrevious = true;
    }
    draw->PopClipRect();
}


} // nf
void begin() { ImGui::NewFrame(); }
int finish() { ImGui::Render(); return ImGui::GetDrawData()->TotalVtxCount; }
int main() {
    using namespace nf; using namespace nf::overlay;
    // UWP host PID differs, but its CoreWindow child still owns focus.
    g_appInputActive=0; assert(GameWindowFocused());
    coreParent=0; assert(!GameWindowFocused());
    // Activated CoreWindow remains authoritative if the sandbox hides ancestry.
    g_appInputActive=1; assert(GameWindowFocused());
    // Actual deactivation with an unrelated foreground window disables capture.
    g_appInputActive=0; fg=30; assert(!GameWindowFocused());
    g_appInputActive=1;
    ImGui::CreateContext(); auto& io=ImGui::GetIO();
    io.DisplaySize=ImVec2(1920,1080); io.DeltaTime=1.0f/120;
    io.IniFilename=nullptr; io.Fonts->AddFontDefault(); io.Fonts->Build();
    io.AddMousePosEvent(400,300); io.MouseDrawCursor=false;
    g_showMenu=true; begin(); ImGui::SetMouseCursor(ImGuiMouseCursor_None);
    DrawGuiCursor(); assert(finish()>0); // independent of atlas cursor selection
    g_showMenu=false; begin(); DrawGuiCursor(); assert(finish()==0);
    g_showMenu=true; g_appInputActive=0; begin(); DrawGuiCursor(); assert(finish()==0);
    g_showMenu=false; g_appInputActive=1;
    float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
    PublishCrosshairCamera(identity, 1, 1);
    CrosshairCamera camera{}; assert(GetCrosshairCamera(&camera));
    assert(std::fabs(camera.forward[2]+1)<1e-5f);
    CrosshairStrokesModule trail; trail.onEnable();
    begin(); trail.onRender(); assert(finish()==0); // stationary aim has no streak
    float rotated[16]={};
    const float angle=0.08f;
    rotated[0]=std::cos(angle); rotated[2]=std::sin(angle);
    rotated[5]=1; rotated[8]=-std::sin(angle); rotated[10]=std::cos(angle); rotated[15]=1;
    now+=10; PublishCrosshairCamera(rotated,1,1);
    begin(); trail.onRender(); assert(finish()>0); // rotating camera leaves a trail
    g_showMenu=true; begin(); trail.onRender(); assert(finish()==0);
    g_showMenu=false; now+=10; PublishCrosshairCamera(rotated,1,1);
    begin(); trail.onRender(); assert(finish()==0); // no history leaks across GUI
    now+=200; assert(!GetCrosshairCamera(&camera));
    begin(); trail.onRender(); assert(finish()==0); // stale camera hidden
    now+=1; PublishCrosshairCamera(identity,1,1);
    for(int i=0;i<200;++i) {
        now+=9; float a=i*0.0007f;
        rotated[0]=std::cos(a); rotated[2]=std::sin(a);
        rotated[8]=-std::sin(a); rotated[10]=std::cos(a);
        PublishCrosshairCamera(rotated,1,1);
        begin(); trail.onRender(); finish();
    }
    // Change settings while running; bounded array survives the smaller length.
    static_cast<NumberSetting*>(trail.findSetting("Length"))->mValue=4;
    now+=9; PublishCrosshairCamera(rotated,1,1);
    begin(); trail.onRender(); finish();
    now+=900; PublishCrosshairCamera(rotated,1,1);
    begin(); trail.onRender(); assert(finish()==0); // fully expired history
    gameplay=false; begin(); trail.onRender(); assert(finish()==0);
    ImGui::DestroyContext();
    std::cout << "PASS: UWP focus, explicit GUI cursor, camera basis, real ImGui trail rendering/bounds/expiry\n";
}
