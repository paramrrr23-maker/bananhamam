# Version Compatibility Matrix + Research Backlog

Целевая версия: **Minecraft Bedrock 1.21.111 (Windows)**.

Шкала: **Compatible** (подтверждено для 1.21.111) / **Probably compatible** (сильные основания) / **Version-specific** (требует проверки/обновления) / **Unknown** (данных нет).

Правило ТЗ соблюдено: ничего не переносится на 1.21.111 без пометки об уровне уверенности.

---

## 1. Compatibility Matrix

### 1.1. Архитектурные принципы (не зависят от версии)

| Компонент | Статус | Основание |
|---|---|---|
| Три render path (world/UI/overlay) | Probably compatible | Подтверждены на 3 клиентах разных эпох; сломать это может только реворк рендера игры |
| Формула W2S | Probably compatible | Чистая математика, 3/3 реализаций идентичны |
| FrameSnapshot «матрица+origin+fov» | Probably compatible | Паттерн повторяется у Flarial и Solstice |
| Event bus с отменой | Probably compatible | Паттерн клиента, не игры |
| AABB = {lower, upper} | Probably compatible | Совпадает у всех; размер компонента проверить |
| ParticleType enum (порядок) | Version-specific | Enum игры, мог пополниться; использовать как ориентир, сверить |

### 1.2. Хуки и точки входа

| Точка | Flarial покрывает 1.21.111? | Статус для 1.21.111 | Комментарий |
|---|---|---|---|
| `LevelRenderer::renderLevel` | Есть таблица `1.21.11` | **Probably compatible** | Сигнатура из таблицы 1.21.11 — ближайший кандидат; нужна валидация сканом |
| `ScreenView::setupAndRender` | Есть таблица `1.21.11` | **Probably compatible** | То же |
| `MUIRenderContext` vtable[5]/[7]/[8] | Да, ветка ≥1.21.50 | **Probably compatible** | Индексы стабильны в коде Flarial на всех версиях 1.20–1.21 |
| `drawImage` сигнатура | Ветка `BedrockTextureData` (≥1.21.50) | **Probably compatible** | 111 > 50, других ветвлений в коде нет |
| `Level::addParticleEffect` vtable[242] | Да (без версионных веток) | **Version-specific** | Индекс захардкожен; проверить на 1.21.111 |
| `Level::getRuntimeActorList` sig | Не используется ≥1.21.40 (entt-путь) | **Version-specific** | Для 1.21.111 релевантен entt-путь через `ActorOwnerComponent` |
| entt-реестр + `ActorOwnerComponent` | Да (ветка ≥1.21.40) | **Probably compatible** | 111 > 40; структура компонента — проверить static_assert'ами |
| `Keyboard::feed` / `MouseDevice::feed` | Есть таблица `1.21.11` | **Probably compatible** | Валидация сканом |
| `MeshHelpers::renderMeshImmediately` (4-arg) | Да (ветка ≥1.21.20) | **Probably compatible** | 111 > 20; pad 0x58 проверить |
| `RenderMaterialGroup::createUI` + имена материалов | Да | **Version-specific** | Имена (`selection_box`...) — контент игры, могли переименовать |
| Kiero Present idx (DX11: 8/13, DX12: 140/145) | Н/Д (не игра) | **Compatible** | Индексы DXGI/DX12 API — стабильны вне зависимости от игры |
| Borion-оффсеты (`+0xB0`, `+0x30`, entityIdMap `+0x20/+0x138`, флаги +993/+994) | Нет аналога | **Version-specific** | Эпоха Borion-OSS не установлена; всё перепроверять |
| Borion сигнатуры (tess_begin/vertex/renderImm/uiMaterial) | Нет аналога | **Version-specific** | Перепроверять сканом на 1.21.111 |

### 1.3. Структуры и layout'ы

| Структура | Статус | Комментарий |
|---|---|---|
| `GLMatrix` (16 float) + transpose | Probably compatible | Совпадает во всех клиентах |
| `AABBShapeComponent` (0x20) | Version-specific | Есть `static_assert` — упадёт сам при расхождении; перепроверить |
| `GuiData` (ScreenSize/resolution) | Version-specific | Оффсеты читать из таблиц 1.21.11, валидировать |
| `ClientInstance` (localPlayer/levelRenderer/level) | Version-specific | То же |
| `LevelRendererPlayer` (cameraPos/fov) | Version-specific | То же |
| `TextMeasureData/CaretMeasureData` | Version-specific | То же |
| `BedrockTextureData` layout | Version-specific | Новый тип (≥1.21.50), layout брать из SDK Flarial 1.21.11 и валидировать |
| `NinesliceInfo` (+0x60/+0x64) | Version-specific | «Funny offsets» — хрупкие, перепроверять |
| DX структуры (swapchain/D2D/ImGui) | Compatible | Не зависят от версии игры |

### 1.4. Как читать таблицы Flarial для 1.21.111
- Формат версии: `parts[2].substr(0, len−3)` от UWP-билда (напр. билд `11101` → `1.21.11`). Таблица `init21110` — стартовая точка для наших сигнатур/оффсетов.
- Проверки в коде для 1.21.111 дают: `≥1.21.20 ✔` (renderMeshImmediately-4, drawImage-2120 вторым приоритетом), `≥1.21.40 ✔` (entt entity list), `≥1.21.50 ✔` (drawImage-BedrockTextureData). [I из кода VersionUtils]

### 1.5. Итоговая оценка
- **Совместимо сразу:** DX/Kiero/D2D/ImGui слой, математика W2S, архитектурные паттерны.
- **Вероятно совместимо (нужна валидация сканом):** почти все sig-таблицы `1.21.11` Flarial, vtable-индексы MUIRC, entt-путь entity list, 4-arg renderMeshImmediately, drawImage-BedrockTextureData.
- **Точно перепроверять:** vtable[242] Level, имена материалов, все Borion-оффсеты, layout новых структур, `NinesliceInfo`.

---

## 2. Research Backlog (проверки после получения src)

### A. Аудит src (фаза Audit — первой, до любых предложений)
1. Найти entry point DLL (`DllMain`), порядок инициализации, потоки.
2. Найти текущую архитектуру хуков (библиотека: MinHook/Kiero/своя; место регистрации; вкл/выкл).
3. Найти существующие events / module dispatch (шина, приоритеты, отмена — или прямые вызовы).
4. Найти текущий render hook (если есть): какая точка, какой путь (world/UI/overlay).
5. Найти существующий renderer (если есть): примитивы, бэкенд, координаты.
6. Найти camera access (матрица/origin/fov — что уже читается).
7. Найти entity access (список, фильтры, AABB, позиция).
8. Найти math utilities (векторы/матрицы/AABB/цвета; есть ли glm).
9. Найти GUI (есть ли; какой бэкенд; виджеты).
10. Найти input (хуки/ polling; бинды).
11. Найти config (формат настроек — нужно для GUI/виджетов).
12. Найти sig/offset менеджмент (таблицы? сканер? хардкод?).
13. Определить целевую версию игры, под которую писался src (комментарии, таблицы, README).
14. Собрать dependency graph: кто кого вызывает в render-пути.

### B. Сравнение (фаза Compare)
15. Сопоставить хуки src с картой §2 Knowledge Base — какие точки уже закрыты.
16. Сопоставить renderer src с Renderer2D/3D/Text/Texture blueprint — каких примитивов не хватает.
17. Сопоставить entity/camera доступ с EntityAccess/Camera blueprint.
18. Сопоставить события с картой §3 (каких render-событий нет).
19. Выявить дубли/конфликты (два W2S, два кэша текстур и т.п.).

### C. Пробелы по игре (фаза Identify gaps — независимо от src)
20. Валидировать sig-таблицу `1.21.11` Flarial сканом на 1.21.111 (все render-сигнатуры).
21. Проверить vtable-индексы MUIRC (5/7/8) и Level (242) на 1.21.111.
22. Проверить имена материалов (`selection_box`, `ui_fill_color`, ...) на 1.21.111.
23. Установить layout `BedrockTextureData`, `AABBShapeComponent`, `GuiData`, `LevelRendererPlayer` на 1.21.111.
24. Установить DX-бэкенд по умолчанию на 1.21.111 (DX11 или DX12) и поведение при переключении.
25. Измерить потоки: в каком потоке `renderLevel`/`setupAndRender`/`Present`/`feed`-хуки (thread-id лог).
26. Измерить порядок: `renderLevel` vs чанки/актёры; Present vs render (VSync on/off).
27. Изучить структуры костей актёра (для BoneESP, O5).
28. Изучить `CameraComponent`/пресеты камер (для CinematicCamera-подобных фич).
29. Изучить `AttributesComponent` (здоровье и т.п. для HUD/nametags).
30. Изучить рендер чанков (`RenderChunkCoordinator`) — нужно ли нам туда лезть вообще.
31. Проверить `NinesliceInfo` оффсеты и нужность NineSlice-перехвата.
32. Изучить ImGui-текст: обводка/тень/ outline-стратегии для читаемости ESP-текста.
33. Изучить TextMeasure/CaretMeasure детали (нужны ли нам вообще, если текст свой).
34. Оценить античит/телеметрию риски перехватов (вне deep scope, но зафиксировать).

### D. Проектирование и внедрение (фазы Design → Implement — только после A–C)
35. Спроектировать GameAdapter поверх найденного sig/offset менеджмента.
36. Спроектировать FrameSnapshot + очередь под найденные потоки.
37. Закрыть Required-компоненты (R1–R8) минимальными изменениями.
38. Добавить Useful (U1–U8) по приоритету фич.
39. Написать валидационный стенд: «хук встал → snapshot собирается → W2S проецирует → бокс рисуется».
40. Документировать расхождения src с blueprint (ADR-записи).

---

## 3. Открытые вопросы (Unknown — честно)

1. Точная версия MC у Borion-OSS и Solstice — влияет на доверие к их оффсетам.
2. Точный lifecycle потоков Bedrock 1.21.111 (только измерения на живой игре).
3. Сохраняет ли ImGui-DX11 бэкенд 100% состояния под bgfx-рендером игры (артефакты?).
4. Нужен ли нам вообще путь B (MUIRC), или достаточно A+C.
5. Структура скелета/костей для BoneESP.
6. Детали depth/blend контроля (материалы vs прямые состояния).
