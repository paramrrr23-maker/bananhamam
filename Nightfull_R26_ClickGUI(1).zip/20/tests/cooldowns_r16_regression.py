"""Extract actual R16 observer/HUD consumer; run C++20 tests with ASan/UBSan.

Run: python tests/cooldowns_r16_regression.py (requires g++).
These are test doubles, NOT a Windows build, game ABI test or FPS benchmark.
Durations: wind 15, golden apple 30, enchanted apple 160, disorientation 75,
dust 30, pearl 30, trap 25, plast 25, aura 60 seconds. Other durations unchanged.
Newer consumption refreshes; duplicate/older events do not extend or shorten.
R15 TextHotkeys is retained. Build R16 with the ROOT build.bat in a fresh folder.
Output: build/Nightfull_R16.dll; tag r16-cooldowns-refresh-perf-20260927.
"""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
overlay = (root / "src/overlay/overlay.cpp").read_text(encoding="utf-8")
hud = (root / "src/modules/hud_modules.cpp").read_text(encoding="utf-8")
old = (root / "tests/cooldowns_r5_mock.cpp").read_text(encoding="utf-8")
observer = overlay[overlay.index("// ABI reference: Flarial OffsetInit", overlay.index(
    "// ======================== Cooldowns consumption observer")):
    overlay.index("\nbool ParticleWorldCellSolid(")]
prefix = old[:old.index("// ABI reference: Flarial OffsetInit")]
prefix = prefix.replace("int getItemCalls=0;", "int getItemCalls=0, codeProofCalls=0, javaStringCalls=0;")
prefix = prefix.replace(
    "bool JavaIsGameCodeAddress(uintptr_t address) { return",
    "bool JavaIsGameCodeAddress(uintptr_t address) { ++codeProofCalls; return")
prefix = prefix.replace(
    "bool JavaReadMsvcString(const void* p,char* out,size_t n) {",
    "bool JavaReadMsvcString(const void* p,char* out,size_t n) { ++javaStringCalls;")
prefix = prefix.replace(
    "bool PotionReadBytes(const void* p,void* out,size_t n) { if(!p)return false;std::memcpy(out,p,n);return true; }",
    r"""
// Encode the fixture's current names in release MSVC string layout.
// Production CooldownReadString itself is NOT replaced.
bool PotionReadBytes(const void* p,void* out,size_t n) {
 if(!p || p==reinterpret_cast<void*>(1))return false;
 const char* text=nullptr;
 if(p==rootRaw+0x20) {
   if(!layerReadable)return false;
   text=layerName;
 } else if(p==item+0x100)text=namespaceName;
 else if(p==item+0xD8)text=itemName;
 if(text && n==32) {
   unsigned char raw[32]{};
   size_t size=std::strlen(text),capacity=size<16?15:size;
   if(capacity==15)std::memcpy(raw,text,size+1);
   else std::memcpy(raw,&text,sizeof(text));
   std::memcpy(raw+16,&size,8);std::memcpy(raw+24,&capacity,8);
   std::memcpy(out,raw,32);return true;
 }
 std::memcpy(out,p,n);return true;
}
""")

stub_begin = old.index("struct EnumSetting")
stub_end = old.index("\nnamespace {", stub_begin)
stub = old[stub_begin:stub_end]
stub = """namespace overlay {
bool testEditor=false;int worldReadCalls=0,drawCalls=0;
bool HudEditActive() { return testEditor; }
bool IsInWorld() { ++worldReadCalls;return localPresent; }
}
""" + stub.replace(
    "std::vector<Active> m_active;",
    "struct Anim { std::vector<int> rows; } m_anim; std::vector<Active> m_active;")
defs_begin = hud.index("namespace {", hud.index("// ======================== Cooldowns"))
defs_end = hud.index("\nCooldownsModule::CooldownsModule()", defs_begin)
defs = hud[defs_begin:defs_end]
service = hud[hud.index("void CooldownsModule::serviceItemBinding"):
              hud.index("void CooldownsModule::onRender()")]
consumer_begin = hud.index("void CooldownsModule::onRender()")
consumer_end = hud.index("    const ImVec2 screen", consumer_begin)
consumer = hud[consumer_begin:consumer_end] + "\n++overlay::drawCalls;\n}\n"

tests_begin = old.index("\nusing namespace overlay;", old.index("void CooldownsModule::onRender()"))
tests = old[tests_begin:]
# Expectations changed by the requested timing/refresh semantics.
tests = tests.replace(
    "CHECK(ends==clockNow+25000)", "CHECK(ends==clockNow+30000)")
tests = tests.replace(
    "hud.onRender();CHECK(hud.m_active[0].endAt==ends);CHECK((ends-clockNow+999)/1000==24);",
    "hud.onRender();CHECK(hud.m_active[0].endAt==clockNow+30000);"
    "CHECK(hud.m_active[0].endAt==ends+1000);ends=hud.m_active[0].endAt;")
tests = tests.replace(
    'CHECK((hud.m_active[0].endAt-clockNow+999)/1000==30);',
    'CHECK((hud.m_active[0].endAt-clockNow+999)/1000==75);')
tests = tests.replace("raw=customies:disorientation duration=30s",
                      "raw=customies:disorientation duration=75s")
tests = tests.replace("clockNow+=30000;hud.onRender();CHECK(hud.m_active.empty());",
                      "clockNow+=75000;hud.onRender();CHECK(hud.m_active.empty());")

extra = r'''
 // All requested durations, plus unchanged unmentioned items.
 size_t defCount=0;const auto* defs=CooldownDefs(0,defCount);
 CHECK(defCount==11);const int expected[]={30,60,75,25,30,160,25,30,15,25,15};
 for(size_t i=0;i<defCount;++i)CHECK(defs[i].seconds==expected[i]);
 for(size_t i=0;i<defCount;++i) {
   reset();hud.setting.mValue=0;hud.onRender();
   auto firstAt=clockNow;
   PublishCooldownUse(defs[i].id,firstAt);hud.onRender();
   CHECK(hud.m_active.size()==1);
   CHECK(hud.m_active[0].endAt==firstAt+expected[i]*1000ull);
   clockNow+=1000;
   PublishCooldownUse(defs[i].id,clockNow);hud.onRender();
   const auto refreshedEnd=clockNow+expected[i]*1000ull;
   CHECK(hud.m_active.size()==1);CHECK(hud.m_active[0].endAt==refreshedEnd);
   // Replayed event with a NEW sequence but same timestamp still isn't a new use.
   PublishCooldownUse(defs[i].id,clockNow);
   PublishCooldownUse(defs[i].id,firstAt);hud.onRender();
   CHECK(hud.m_active[0].endAt==refreshedEnd);
   clockNow=refreshedEnd;hud.onRender();CHECK(hud.m_active.empty());
 }
 // Repeated item use before the previous timer expires through actual observer.
 reset();g_cdUseAt=clockNow;count(15);tick();tick(320);hud.onRender();
 CHECK(hud.m_active.size()==1);auto firstEnd=hud.m_active[0].endAt;
 g_cdUseAt=clockNow;count(14);tick();auto secondAt=clockNow;
 tick(320);hud.onRender();
 CHECK(hud.m_active.size()==1);CHECK(hud.m_active[0].endAt==secondAt+30000);
 CHECK(hud.m_active[0].endAt>firstEnd);
 // Two decrements inside settle window coalesce to LATEST confirmed use.
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;count(15);tick();
 auto pending1=g_cdObserver.pendingAt;
 count(14);tick(80);auto pending2=g_cdObserver.pendingAt;
 CHECK(pending2>pending1);tick(280);CHECK(drain(events)==0);
 tick(40);CHECK(drain(events)==1);CHECK(events[0].at==pending2);
 // Click only must never refresh a real active timer.
 reset();g_cdUseAt=clockNow;count(15);tick();tick(320);hud.onRender();
 CHECK(hud.m_active.size()==1);firstEnd=hud.m_active[0].endAt;
 g_cdUseAt=clockNow;tick();tick(320);hud.onRender();
 CHECK(hud.m_active[0].endAt==firstEnd);
 // Drop and rollback while active must not restart the timer.
 g_cdUseAt=clockNow;g_cdDropAt=clockNow;count(14);tick();tick(320);hud.onRender();
 CHECK(hud.m_active[0].endAt==firstEnd);
 reset();g_cdUseAt=clockNow;count(15);tick();tick(320);hud.onRender();
 firstEnd=hud.m_active[0].endAt;
 g_cdUseAt=clockNow;count(14);tick();count(15);tick(320);hud.onRender();
 CHECK(hud.m_active[0].endAt==firstEnd);

 // String-reader edge cases use production code, no API emulation here.
 alignas(8) unsigned char raw[32]{};char text[64]{};
 put(raw+16,size_t(3));put(raw+24,size_t(15));std::memcpy(raw,"abc",4);
 CHECK(CooldownReadString(raw,text,sizeof(text)));CHECK(std::string(text)=="abc");
 CHECK(!CooldownReadString(raw,text,3));CHECK(!CooldownReadString(nullptr,text,64));
 const char* heap="short";put(raw,heap);put(raw+16,size_t(5));put(raw+24,size_t(63));
 CHECK(CooldownReadString(raw,text,64));CHECK(std::string(text)=="short");
 put(raw+24,size_t(3));CHECK(!CooldownReadString(raw,text,64));
 put(raw+24,size_t(1u<<21));CHECK(!CooldownReadString(raw,text,64));
 put(raw+24,size_t(63));put(raw,reinterpret_cast<void*>(1));
 CHECK(!CooldownReadString(raw,text,64));
 std::memset(raw,0,sizeof(raw));put(raw+16,size_t(3));put(raw+24,size_t(15));
 std::memcpy(raw,"a\0b",4);CHECK(!CooldownReadString(raw,text,64));
 std::memcpy(raw,"abcd",4);CHECK(!CooldownReadString(raw,text,64));

 // Cache: one native executable proof per address per second; no cached failures.
 reset();auto fn=reinterpret_cast<uintptr_t>(&getItemMock);
 codeProofCalls=0;for(int i=0;i<100;++i)CHECK(CooldownGameCodeAddress(fn));
 CHECK(codeProofCalls==0);clockNow+=1000;CHECK(CooldownGameCodeAddress(fn));
 CHECK(codeProofCalls==1);
 CHECK(!CooldownGameCodeAddress(1));CHECK(!CooldownGameCodeAddress(1));
 CHECK(codeProofCalls==3);
 CooldownNewSession(nullptr,nullptr);
 CHECK(CooldownGameCodeAddress(fn));CHECK(codeProofCalls==4);
 // Live vtable validation still rejects changed/bad entries immediately.
 reset();put(image+1024+3*sizeof(uintptr_t),(uintptr_t)0);
 calls=getItemCalls;tick();CHECK(!g_cdObserver.baseline);CHECK(getItemCalls==calls);
 initMemory();
 // Simulate 250 game setup callbacks over 1 second, not just 25 sampling ticks.
 reset();codeProofCalls=javaStringCalls=0;calls=getItemCalls;
 for(int i=0;i<250;++i)tick(4);
 CHECK(getItemCalls-calls==25);
 CHECK(javaStringCalls==0);
 CHECK(codeProofCalls<=1); // fixture's eight virtual methods share one address
 std::cout<<"PERF MODEL: 250 setup callbacks, "<<getItemCalls-calls
          <<" getItem calls, "<<codeProofCalls<<" native code proofs, "
          <<javaStringCalls<<" JavaReadMsvcString calls\n";
 // Execute actual production early-return/world gates with drawing replaced.
 reset();hud.onRender();worldReadCalls=drawCalls=0;
 for(int i=0;i<250;++i)hud.onRender();
 CHECK(worldReadCalls==0);CHECK(drawCalls==0);
 testEditor=true;hud.onRender();
 CHECK(worldReadCalls==1);CHECK(drawCalls==1);testEditor=false;
 hud.m_anim.rows.push_back(1);hud.onRender(); // exiting row must keep animating
 CHECK(worldReadCalls==2);CHECK(drawCalls==2);hud.m_anim.rows.clear();
 hud.onRender();CHECK(worldReadCalls==2);CHECK(drawCalls==2);
 PublishCooldownUse("minecraft:sugar",clockNow);hud.onRender();
 CHECK(worldReadCalls==3);CHECK(drawCalls==3);
'''
tests = tests.replace(' std::cout<<"PASS "<<checks', extra + '\n std::cout<<"PASS "<<checks')

# Verify the production idle gate is ahead of world reads/drawing and preserves exits.
render = hud[consumer_begin:hud.index("// ======================== Potions", consumer_begin)]
assert render.index("m_active.empty() && m_anim.rows.empty()") < render.index("overlay::IsInWorld()")
assert "static std::vector<NeonPlateRow> plateRows;" in render
assert "static std::vector<NeonPlateRow> animRows;" in render
assert "static overlay::CooldownUseEvent events[32]" in render
assert "already-on-cooldown" not in render
assert "CooldownReadString(" in observer and "CooldownGameCodeAddress(function)" in observer
assert "HitboxResolveContainerGetItem(candidate.object)" not in observer

code = prefix + observer + "\n}\n" + stub + defs + service + consumer + tests
with tempfile.TemporaryDirectory(prefix="nightfull-cd-r16-") as tmp:
    path = Path(tmp)
    cpp, exe = path / "test.cpp", path / "test"
    cpp.write_text(code, encoding="utf-8")
    subprocess.run([os.environ.get("CXX", "g++"), "-std=c++20", "-O1", "-g",
                    "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                    str(cpp), "-o", str(exe)], check=True)
    subprocess.run([str(exe)], check=True)
print("PASS: production idle-render gate and reused buffers (source assertions)")
