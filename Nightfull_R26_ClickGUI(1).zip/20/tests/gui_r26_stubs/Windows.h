// Test double ONLY. Never add this directory to production build includes.
#pragma once
#include <mutex>
using BYTE = unsigned char;
using UINT = unsigned int;
using DWORD = unsigned long;
using ULONGLONG = unsigned long long;
using WCHAR = char16_t;
using HKL = void*;
using HWND = void*;
struct CRITICAL_SECTION { std::recursive_mutex mutex; };
inline void InitializeCriticalSection(CRITICAL_SECTION*) {}
inline void EnterCriticalSection(CRITICAL_SECTION* c) { c->mutex.lock(); }
inline void LeaveCriticalSection(CRITICAL_SECTION* c) { c->mutex.unlock(); }
enum {
    VK_LBUTTON=1, VK_RBUTTON=2, VK_MBUTTON=4, VK_XBUTTON1=5, VK_XBUTTON2=6, VK_SEPARATOR=0x6C,
    VK_BACK=8, VK_TAB=9, VK_RETURN=13, VK_SHIFT=16, VK_CONTROL=17, VK_MENU=18,
    VK_CAPITAL=20, VK_ESCAPE=27, VK_SPACE=32, VK_PRIOR=33, VK_NEXT=34,
    VK_END=35, VK_HOME=36, VK_LEFT=37, VK_UP=38, VK_RIGHT=39, VK_DOWN=40,
    VK_INSERT=45, VK_DELETE=46, VK_NUMPAD0=96, VK_NUMPAD9=105,
    VK_F1=112, VK_F24=135, VK_NUMLOCK=144, VK_LSHIFT=160, VK_RSHIFT=161,
    VK_LCONTROL=162, VK_RCONTROL=163, VK_LMENU=164, VK_RMENU=165,
    MAPVK_VK_TO_VSC=0
};
inline ULONGLONG testClock = 0;
inline short testAsync[256] = {};
inline bool testRussian = false;
inline bool testCaps = false;
inline unsigned testPolls = 0;
inline short GetAsyncKeyState(int key) { ++testPolls; return testAsync[key]; }
inline short GetKeyState(int key) { return key == VK_CAPITAL && testCaps ? 1 : 0; }
inline ULONGLONG GetTickCount64() { return testClock; }
inline HWND GetForegroundWindow() { return nullptr; }
inline DWORD GetWindowThreadProcessId(HWND, DWORD*) { return 1; }
inline HKL GetKeyboardLayout(DWORD) { return nullptr; }
inline UINT MapVirtualKeyExW(UINT key, UINT, HKL) { return key; }
inline int ToUnicodeEx(UINT key, UINT, const BYTE* state, WCHAR* out, int, UINT, HKL) {
    if (key >= 'A' && key <= 'Z') {
        bool upper = !!(state[VK_SHIFT] & 0x80) != !!(state[VK_CAPITAL] & 1);
        if (testRussian && key == 'F') out[0] = upper ? u'А' : u'а';
        else out[0] = static_cast<WCHAR>(upper ? key : key + 32);
        return 1;
    }
    if (key == VK_SPACE) { out[0] = u' '; return 1; }
    if (key == 0xBF) { out[0] = u'/'; return 1; }
    return 0;
}
#include <cstring>
#include <strings.h>
#include <cfloat>
using HMODULE=void*; using HANDLE=void*; using HRESULT=long;
#define _stricmp strcasecmp
#define CP_UTF8 65001
#define CF_UNICODETEXT 13
inline bool OpenClipboard(void*) {return false;}
inline HANDLE GetClipboardData(int){return nullptr;}
inline void* GlobalLock(HANDLE){return nullptr;}
inline void GlobalUnlock(HANDLE){}
inline void CloseClipboard(){}
inline int WideCharToMultiByte(unsigned,int,const wchar_t* s,int,char* out,int size,void*,void*){int n=0;while(s&&s[n]){if(out&&n<size-1)out[n]=(char)s[n];n++;}if(out&&size)out[std::min(n,size-1)]=0;return n+1;}
inline int MultiByteToWideChar(unsigned,int,const char* s,int,wchar_t* out,int size){int n=0;while(s&&s[n]){if(out&&n<size-1)out[n]=(wchar_t)(unsigned char)s[n];n++;}if(out&&size)out[std::min(n,size-1)]=0;return n+1;}
