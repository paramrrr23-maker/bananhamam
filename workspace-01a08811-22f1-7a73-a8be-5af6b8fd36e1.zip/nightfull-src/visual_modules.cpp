// visual_modules.cpp - Visual-category demo modules.
//
// UI DEMO ONLY - see visual_modules.h. Watermark and Arraylist draw into our
// own ImGui overlay; nothing here touches the game.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "modules/visual/visual_modules.h"
#include "modules/visual/clickgui_module.h"
#include "modules/visual/packet_hud.h"

#include "modules/module_manager.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/build_info.h"
#include "overlay.h"

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <limits>
#include <string>
#include <vector>

namespace modules {

ESP::ESP()
    : Module("Visual", "ESP", "Demo entity overlay (no game effects)")
{
    m_mode      = addSetting<EnumSetting>  ("Mode",      "How entities are boxed", 0,
                                            std::vector<std::string>{ "Box", "Corner", "Outline" });
    m_thickness = addSetting<NumberSetting>("Thickness", "Line thickness", 1.0f, 0.5f, 5.0f, 0.5f);
    m_health    = addSetting<BoolSetting>  ("Health",    "Show the health bar", true);
    m_distance  = addSetting<BoolSetting>  ("Distance",  "Show the distance", false);
    m_color     = addSetting<ColorSetting> ("Color",     "Colour of the boxes", 0.35f, 0.75f, 1.0f, 1.0f);
}

FullBright::FullBright()
    : Module("Visual", "FullBright", "Solstice-style gamma brightness")
{
    m_strength = addSetting<NumberSetting>("Strength", "Target gamma", 13.0f, 1.0f, 16.0f, 0.5f);
    m_gamma    = addSetting<BoolSetting>  ("Gamma",    "Also raise the gamma", true);
}

void FullBright::on_enable() {
    if (m_currentGamma < 1.0f) m_currentGamma = 1.0f;
}

void FullBright::on_disable() {
    m_currentGamma = 1.0f;
}

void FullBright::on_render() {
    const float target = m_gamma && !m_gamma->mValue ? 1.0f
                         : (m_strength ? m_strength->mValue : 13.0f);
    const float step = gui::Clamp(gui::GetDeltaTime() * 10.0f, 0.0f, 1.0f);
    m_currentGamma += (target - m_currentGamma) * step;
}

GuiScale::GuiScale()
    : Module("Visual", "GUI Scale", "Change Minecraft's own interface scale") {
    m_scale = addSetting<NumberSetting>("Scale", "Minecraft GUI scale", 2.0f, 1.0f, 4.0f, 0.1f);
}

VsyncDisabler::VsyncDisabler()
    : Module("Render", "VSync Disabler", "Present frames without a VSync interval") {}

Nametags::Nametags()
    : Module("Visual", "Nametags", "Demo name tags (no game effects)")
{
    m_scale    = addSetting<NumberSetting>("Scale",    "Tag scale", 1.0f, 0.5f, 3.0f, 0.1f);
    m_health   = addSetting<BoolSetting>  ("Health",   "Show health", true);
    m_distance = addSetting<BoolSetting>  ("Distance", "Show distance", false);
    m_items    = addSetting<BoolSetting>  ("Items",    "Show held item", true);
}

NoRender::NoRender()
    : Module("Visual", "NoRender", "Demo render filters (no game effects)")
{
    m_weather   = addSetting<BoolSetting>("Weather",   "Hide rain and snow", true);
    m_particles = addSetting<BoolSetting>("Particles", "Hide particles", false);
    m_entities  = addSetting<BoolSetting>("Entities",  "Hide dropped items", false);
    m_hurtCam   = addSetting<BoolSetting>("Hurt cam",  "Hide the damage shake", true);
}

Zoom::Zoom()
    : Module("Visual", "Zoom", "Demo field of view (no game effects)")
{
    m_fov    = addSetting<NumberSetting>("FOV",    "Zoomed field of view", 30.0f, 10.0f, 90.0f, 5.0f);
    m_smooth = addSetting<NumberSetting>("Smooth", "How fast to zoom", 0.5f, 0.05f, 1.0f, 0.05f);
    m_scroll = addSetting<BoolSetting>  ("Scroll", "Adjust with the wheel", true);
}

// Packet's Watermark::message defaults to "Packet Client"; this client's tag.
const std::string kClientName = "Nightfull";

// Lucide "activity" glyph (the heartbeat/pulse line from the Pulse watermark).
constexpr const char* kPulseIcon = "\xEE\x80\xB8";  // U+E038

// Plain font text on the background draw list (Packet V3 HUD rows).
void HudText(ImFont* font, float size, const ImVec2& pos, const ImColor& c,
             const char* text) {
    ImGui::GetBackgroundDrawList()->AddText(font, size, pos,
                                            ImGui::ColorConvertFloat4ToU32(c.Value), text);
}

// Stand-in for Solstice's drawList->AddShadowRect (that overload no longer
// exists in stock ImGui 1.91.8): concentric fills with a quadratic falloff
// whose summed coverage converges to `alpha`. Solstice uses this both for the
// arraylist backdrop (strength 200) and for the glow (strength 100).
void SolsticeShadow(ImDrawList* d, const ImVec4& r, const ImColor& c,
                    float alpha, float strength) {
    if (alpha <= 0.f || strength <= 0.f) return;
    const float radius = strength * 0.4f;
    constexpr int kLayers = 6;
    float weights[kLayers];
    float sum = 0.f;
    for (int i = 1; i <= kLayers; ++i) {
        const float t = (float)i / (float)kLayers;
        weights[i - 1] = (1.f - t) * (1.f - t);
        sum += weights[i - 1];
    }
    for (int i = kLayers; i >= 1; --i) {
        const float t   = (float)i / (float)kLayers;
        const float pad = radius * t;
        const float a   = alpha * weights[i - 1] / sum;
        d->AddRectFilled(ImVec2(r.x - pad, r.y - pad), ImVec2(r.z + pad, r.w + pad),
                         ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y,
                                                               c.Value.z, a)));
    }
}

// ======================== Watermark (Pulse Visuals style) ===================
Watermark::Watermark()
    : Module("Render", "Watermark", "Pulse-style pill: tag + ping + FPS")
{
    m_text       = addSetting<StringSetting>("Text",       "Watermark tag", "Nightfull", 48);
    m_background = addSetting<BoolSetting>  ("Background", "Draw the dark pill", true);
    m_outline    = addSetting<BoolSetting>  ("Outline",    "Accent stroke around the pill", false);
    m_fps        = addSetting<BoolSetting>  ("FPS",        "FPS segment", true);
    m_ping       = addSetting<BoolSetting>  ("Ping",       "Ping segment (real RakNet ping)", true);
    m_opacity    = addSetting<NumberSetting>("Opacity",    "Pill opacity", 0.9f, 0.0f, 1.0f, 0.05f);
    m_scale      = addSetting<NumberSetting>("Scale",      "Watermark size", 1.0f, 0.5f, 3.0f, 0.1f);
    set_enabled(true);
}

void Watermark::on_render() {
    // The HUD is hidden while the ClickGUI owns the screen.
    if (overlay::g_ShowMenu) return;

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;
    ImDrawList* d    = ImGui::GetBackgroundDrawList();
    ImFont*     font = gui::CurrentFont();
    if (!font) return;

    const float s = m_scale ? m_scale->mValue : 1.0f;
    const float opacity = m_opacity ? m_opacity->mValue : 0.9f;

    const std::string fallback = kClientName;
    const std::string message = (m_text && !m_text->mValue.empty()) ? m_text->mValue : fallback;

    const ImGuiIO& io = ImGui::GetIO();
    const int fps = io.Framerate > 0.1f ? (int)(io.Framerate + 0.5f) : 0;
    char fpsBuf[24];
    sprintf_s(fpsBuf, "%d FPS", fps);
    const bool showFps = !m_fps || m_fps->mValue;

    // Real RakNet average ping from the GetAveragePing hook; the segment is
    // hidden until the game reports a value (negative = no data yet).
    const int ping = overlay::g_pingMs;
    char pingBuf[24];
    sprintf_s(pingBuf, "%d ms", ping);
    const bool showPing = (!m_ping || m_ping->mValue) && ping >= 0;

    const float h   = 28.f * s;
    const float ts  = 12.5f * s;
    const float isz = 13.f * s;
    const float padX = 13.f * s;

    const float nameW = font->CalcTextSizeA(ts, FLT_MAX, 0, message.c_str()).x;
    const float fpsW  = showFps ? font->CalcTextSizeA(ts, FLT_MAX, 0, fpsBuf).x : 0.f;
    const float pingW = showPing ? font->CalcTextSizeA(ts, FLT_MAX, 0, pingBuf).x : 0.f;
    const float sepW  = font->CalcTextSizeA(ts, FLT_MAX, 0, "|").x;
    ImFont* icons = gui::IconFont();
    const bool hasIcon = icons != nullptr;
    const float iconW = hasIcon ? isz : 0.f;
    const float iconGap = hasIcon ? 9.f * s : 0.f;
    const float sepGap = 9.f * s;

    float w = padX * 2.0f + iconW + iconGap + nameW;
    if (showPing) w += sepGap + sepW + sepGap + pingW;
    if (showFps)  w += sepGap + sepW + sepGap + fpsW;

    const float x0 = (screen.x - w) * 0.5f;
    const float y0 = 12.f * s;
    const ImColor accent = gui::GetThemedColor(0);
    const ImColor white(0.96f, 0.97f, 0.98f, 1.0f);
    const ImColor gray(0.45f, 0.45f, 0.50f, 0.8f);

    if (m_background && m_background->mValue)
        gui::FillRect(ImVec4(x0, y0, x0 + w, y0 + h),
                      ImColor(9, 9, 13), opacity, h * 0.5f);
    if (m_outline && m_outline->mValue)
        d->AddRect(ImVec2(x0 + 0.7f, y0 + 0.7f),
                   ImVec2(x0 + w - 0.7f, y0 + h - 0.7f),
                   accent, h * 0.5f - 0.7f, 0, 1.4f);

    const float cy = y0 + h * 0.5f;
    float cx = x0 + padX;
    if (hasIcon) {
        d->AddText(icons, isz, ImVec2(cx, cy - isz * 0.55f), accent, kPulseIcon);
        cx += iconW + iconGap;
    }
    const float nameTh = font->CalcTextSizeA(ts, FLT_MAX, 0, message.c_str()).y;
    d->AddText(font, ts, ImVec2(cx, cy - nameTh * 0.5f),
               ImGui::ColorConvertFloat4ToU32(white.Value), message.c_str());
    cx += nameW;

    // segments: [ping] then [fps], each ' | ' separated
    if (showPing) {
        d->AddText(font, ts, ImVec2(cx + sepGap, cy - sepW * 0.5f),
                   ImGui::ColorConvertFloat4ToU32(gray.Value), "|");
        cx += sepGap + sepW + sepGap;
        d->AddText(font, ts, ImVec2(cx, cy - nameTh * 0.5f),
                   ImGui::ColorConvertFloat4ToU32(white.Value), pingBuf);
        cx += pingW;
    }
    if (showFps) {
        d->AddText(font, ts, ImVec2(cx + sepGap, cy - sepW * 0.5f),
                   ImGui::ColorConvertFloat4ToU32(gray.Value), "|");
        cx += sepGap + sepW + sepGap;
        d->AddText(font, ts, ImVec2(cx, cy - nameTh * 0.5f),
                   ImGui::ColorConvertFloat4ToU32(white.Value), fpsBuf);
    }
}

// ======================== Arraylist (Packet V3 style) =======================
Arraylist::Arraylist()
    : Module("Render", "Arraylist", "Packet V3 enabled-module list")
{
    m_renderMode = addSetting<BoolSetting>  ("Render Mode", "Show the mode next to the name", true);
    m_visibility = addSetting<EnumSetting>  ("Visibility",  "Module visibility", 0,
                                             std::vector<std::string>{ "All", "Bound" });
    m_fontSize   = addSetting<NumberSetting>("Font Size",   "Text size in pixels", 15.0f, 10.0f, 30.0f, 0.5f);
    m_opacity    = addSetting<NumberSetting>("Opacity",     "Plate opacity", 0.55f, 0.0f, 1.0f, 0.05f);
    m_scale      = addSetting<NumberSetting>("Scale",       "Overall scale", 1.0f, 0.6f, 2.0f, 0.05f);
    set_enabled(true);
}

void Arraylist::on_render() {
    if (overlay::g_ShowMenu) return;
    if (!ImGui::GetCurrentContext()) return;

    const ImVec2 display = ImGui::GetIO().DisplaySize;
    if (display.x <= 0.0f || display.y <= 0.0f) return;
    ImFont* font = gui::CurrentFont();
    if (!font) return;

    const float s         = m_scale ? m_scale->mValue : 1.0f;
    const float fontSize  = (m_fontSize ? m_fontSize->mValue : 15.0f) * s;
    const bool  boundOnly = m_visibility && m_visibility->mValue == 1;
    const bool  renderMode = !m_renderMode || m_renderMode->mValue;
    const float bgOpacity = m_opacity ? m_opacity->mValue : 0.55f;

    const auto& registry = Modules().modules();
    const size_t registrySize = registry.size();
    if (m_anim.size() != registrySize) m_anim.assign(registrySize, 0.0f);

    struct Entry {
        size_t      index;
        Module*     mod;
        std::string name;
        std::string modeText;
        float       nameW;
        float       modeW;
    };

    std::vector<Entry> entries;
    entries.reserve(registrySize);
    for (size_t i = 0; i < registrySize; ++i) {
        Module* mod = registry[i].get();
        if (!mod || !mod->name()) continue;
        if (mod == this || mod == ClickGuiModule::instance()) continue;
        const std::string raw = mod->name();
        if (raw == "Watermark") continue;
        if (boundOnly && mod->key() == 0) continue;

        Entry e{};
        e.index = i;
        e.mod   = mod;
        e.name  = raw;
        // The mode suffix is the module's first enum value, like Flarial's
        // getSettingDisplayText ("Sprint Hive" in the V3 videos).
        for (const auto& st : mod->settings()) {
            if (st && st->mType == SettingType::Enum) {
                e.modeText = static_cast<const EnumSetting*>(st.get())->current();
                break;
            }
        }
        if (!renderMode) e.modeText.clear();
        if (!e.modeText.empty()) e.modeText = " " + e.modeText;

        e.nameW = font->CalcTextSizeA(fontSize, FLT_MAX, 0, e.name.c_str()).x;
        e.modeW = e.modeText.empty()
                      ? 0.f
                      : font->CalcTextSizeA(fontSize, FLT_MAX, 0, e.modeText.c_str()).x;
        entries.push_back(std::move(e));
    }

    // Width descending with the name as tie-breaker, like Packet/Solstice.
    std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
        if (a.nameW + a.modeW != b.nameW + b.modeW) return a.nameW + a.modeW > b.nameW + b.modeW;
        return a.name < b.name;
    });

    const ImColor accent = gui::GetThemedColor(0);
    const ImColor nameColor(0.90f, 0.94f, 0.94f, 1.0f);
    const ImColor modeColor(0.62f, 0.64f, 0.64f, 1.0f);
    const ImColor plateColor(0.04f, 0.05f, 0.05f, 1.0f);

    const float dt       = ImGui::GetIO().DeltaTime;
    const float padY     = 3.0f * s;
    const float barW     = 3.0f * s;
    const float barInset = 7.0f * s;
    const float textPad  = 16.0f * s;
    const float platePad = 7.0f * s;
    const float radius   = 5.0f * s;
    const ImDrawFlags leftRound = ImDrawFlags_RoundCornersLeft;

    float y = 6.0f * s;
    for (const Entry& e : entries) {
        float& anim = m_anim[e.index];
        anim = gui::Lerp(anim, e.mod->enabled() ? 1.0f : 0.0f, dt * 12.0f);
        anim = gui::Clamp(anim, 0.0f, 1.0f);
        if (anim < 0.01f) continue;

        const ImVec2 nameSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0, e.name.c_str());
        const float rowH = nameSize.y + padY * 2.0f;

        // Whole row slides in from the right edge as the module enables.
        const float rowRight = display.x + (1.0f - anim) * (e.nameW + e.modeW + 60.0f * s);
        // plate spans from its left edge to past the screen edge
        const float plateX0 = rowRight - (textPad + e.nameW + e.modeW + platePad * 2.0f);
        gui::FillRect(ImVec4(plateX0, y, rowRight + 8.0f * s, y + rowH),
                      plateColor, bgOpacity, radius, nullptr, leftRound);

        // accent pill bar: inset from the row's right, rounded caps
        gui::FillRect(ImVec4(rowRight - barInset - barW, y + padY,
                             rowRight - barInset, y + rowH - padY),
                      accent, 1.0f, barW * 0.5f);

        // text: name (light) + mode (gray), right-aligned before the bar
        const float textRight = rowRight - barInset - barW - 5.0f * s;
        if (!e.modeText.empty()) {
            const ImVec2 ms = font->CalcTextSizeA(fontSize, FLT_MAX, 0, e.modeText.c_str());
            HudText(font, fontSize, ImVec2(textRight - ms.x, y + padY), modeColor, e.modeText.c_str());
        }
        HudText(font, fontSize, ImVec2(textRight - e.modeW - e.nameW, y + padY), nameColor, e.name.c_str());

        y += rowH * anim;
    }
}

Freelook::Freelook()
    : Module("Visual", "Freelook", "Packet-style free camera without wall clipping") {
    m_mode = addSetting<EnumSetting>("Mode", "Camera perspective", 1,
                                      std::vector<std::string>{"First person", "Third person back", "Third person front"});
}

void Freelook::on_enable() {
    redirectMouse = true;
    resetViewTick = -1;
    initialCaptured = false;
    initialViewAngles = ImVec2(0.0f, 0.0f);
    lastCameraAngle = ImVec2(0.0f, 0.0f);
}

void Freelook::on_disable() {
    if (redirectMouse && resetViewTick < 0)
        // Packet uses a delayed reset in first person. A short interpolation
        // gives Bedrock time to accept the restored player-facing angle.
        resetViewTick = isThirdPerson ? 0 : 8;
    else if (!redirectMouse)
        resetViewTick = -1;
}

} // namespace modules
