# Rendering Knowledge Base — Minecraft Bedrock (Windows)

Целевая версия нашего клиента: **1.21.111**.
Источники: **Flarial** (`oAnshull/FlarialClient`), **Solstice** (`AzOxStOz/Solstice-Source`), **Borion-OSS** (`Borion-Updated/Borion-OSS`, форк Horion). OderSo — closed source, данных по коду нет.

Покрытие версий источниками:
- **Flarial**: явные таблицы сигнатур/оффсетов для **1.20.3 → 1.21.11** (формат `VersionUtils`: `1.21.11` покрывает билды 1.21.110–1.21.11x, см. §19). [CONFIRMED]
- **Solstice**: явной таблицы версий в изученном коде не найдено; коммиты 2024 → эпоха ~1.21.0–1.21.2x. [INFERENCE]
- **Borion-OSS**: явной версии MC в изученном коде не зафиксировано; организация активна в 2026 (клиент v26.1X). [UNKNOWN — в бэклоге]

Пометки: **[C]** = точно из кода, **[I]** = вывод, **[U]** = неизвестно.

---

## 1. Minecraft Bedrock rendering pipeline

**Известно точно [C]:**
- Игра рендерит кадр через собственный конвейер поверх **bgfx-абстракции**: Solstice в D3D12-пути кастует контекст к `bgfx_d3d12_RendererContextD3D12` и забирает `ID3D12CommandQueue` (`D3DHook.cpp` ~строка 310). Т.е. у игры есть `bgfx_context` с `getRenderContext()`.
- Финальный графический API на Windows — **DirectX 11 или DirectX 12** (оба поддерживаются; клиент детектит через `swapChain->GetDevice(__uuidof(ID3D11Device)...)` / `ID3D12Device`). Все три клиента вынуждены поддерживать оба бэкенда.
- Ключевые стадии, видимые из хуков: `LevelRenderer::renderLevel` (мир) → `ScreenView::setupAndRender` (UI) → `IDXGISwapChain::Present` (вывод). Плюс мелкие стадии: `RenderChunkCoordinator` (чанки), `ActorRenderDispatcher::render` (актёры), `MinecraftUIRenderContext::drawImage/drawText` (UI-примитивы).
- UWP-платформа: игра работает через CoreWindow swapchain (`CreateSwapchainForCoreWindowHook` у Flarial).

**Version-specific:** внутренности bgfx-контекста, порядок стадий UI, количество буферов swapchain.
**Архитектурное (общее):** мир → UI → Present; наличие in-house рендера поверх DX; двойной бэкенд DX11/DX12.

## 2. Render hooks

**Известно точно [C]:**

| Хук | Flarial | Solstice | Borion | Способ |
|---|---|---|---|---|
| `LevelRenderer::renderLevel` | ✅ sig | — | ✅ sig | MinHook-детур |
| `ScreenView::setupAndRender` | ✅ sig | ✅ sig | ✅ два хука (`UIScene_setupAndRender` + `UIScene_render`) | детур |
| `MUIRenderContext::drawText/drawImage/drawNineSlice` | ✅ vtable[5]/[7]/[8] | ✅ drawImage (индекс из OffsetProvider) | — (вызывает напрямую) | vtable-хук |
| `IDXGISwapChain::Present` | ✅ свои DX11/DX12 хуки | ✅ Kiero (idx 8/13 DX11, 140/145 DX12) | ❌ нет оверлея | vtable/Kiero |
| `ResizeBuffers` | ✅ | ✅ Kiero | ❌ | — |
| `ActorRenderDispatcher::render` | — | ✅ sig | — | детур |
| `Level::addParticleEffect` | ✅ **vtable[242]** Level | — | — | vtable-хук |
| `Keyboard::feed` / `MouseDevice::feed` | ✅ sig | ✅ sig | — (свои: `HIDController::keyMouse`, `ClickFunc`) | детур |
| `LevelRendererPlayer::getFov/renderNameTags`, `bobView`, `BlockLegacy::getRenderLayer`, `ItemRenderer`, `PaintingRenderer` | частично | частично | ✅ sig/vtable | детур |

**Version-specific:** все сигнатуры, vtable-индексы (5/7/8, 242; Present 8/140 — это индексы DXGI/DX, а не игры, они стабильны).
**Архитектурное:** три слоя хуков = три render path (мир / UI / Present); сигнатуры предпочтительнее хардкод-адресов; vtable-хуки для виртуальных методов игры.

## 3. Game/render events

**Известно точно [C]:**
- **Flarial + Solstice**: шина событий **nes::event_dispatcher** (сторонняя header-only lib). События — holder'ы (`nes::make_holder<RenderEvent>()`), есть приоритеты (`IMMEDIATE/HIGH/NORMAL/LOW/LAST` у Flarial), отмена (`isCancelled()` — хук пропускает оригинал).
- Точки генерации render-событий (Flarial): `RenderEvent` + `RenderUnderUIEvent` — из Present-хуков DX11/DX12; `Render3DEvent(level, scn)` — из `renderLevel`; `SetupAndRenderEvent(muirc)` — из `setupAndRender` (кроме debug/toast экранов); `DrawText/DrawImage/DrawNineSliceEvent` — из vtable-хуков MUIRC.
- Модули подписываются на enable и отписываются на disable (`Listen`/`Deafen`), колбэки вида `onRender(RenderEvent&)`.
- HUD-модули сами фильтруют экран: `SDK::getCurrentScreen() == "hud_screen"` (имя слоя из `ScreenView::VisualTree->root->getLayerName()`).
- **Borion**: шины событий нет — прямые виртуальные методы `IModule::onTick/onKeyUpdate/onPreRender/onPostRender/onLevelRender`, диспетчер — `ModuleManager` (`ModuleManager.cpp:160–253`).

**Проверено на:** Flarial 1.20.3–1.21.11; Solstice ~1.21.x; Borion unknown.
**Version-specific:** имена слоёв экранов (`hud_screen` и т.д. — строки игры, стабильны давно, но не гарантированы).
**Архитектурное:** отмена событий → пропуск оригинала; подписка/отписка по enable/disable; разделение 2D/3D/UI событий.

## 4. Camera

**Известно точно [C]:**
- `ClientInstance::getViewMatrix()` → матрица вида (Flarial: `GLMatrix{float[16]}`; Solstice: `glmatrixf`; Borion: `getRefDef()->correct()`).
- `ClientInstance::getFov()` → `vec2(x, y)`, используется прямо в формуле W2S.
- `LevelRenderer::getRendererPlayer()` → `LevelRendererPlayer { getCameraPos()->vec3*, getFovX(), getFovY() }` (Solstice `Rendering/LevelRenderer.hpp`).
- `origin` кадра = `LevelRenderer->origin` (Borion/Flarial) или `RendererPlayer->cameraPos` (Solstice; Flarial `drawQuad` тоже использует `cameraPos`).
- Камера модифицируется хуками: `getFov` (зум), `bobView` (тряска), `getViewPerspective` (перспектива), `CameraComponent` существует в ECS (Solstice SDK, не изучен детально).

**Version-specific:** оффсеты `origin`, `getRefDef`, layout `LevelRendererPlayer`, `CameraComponent`.
**Архитектурное:** связка «матрица вида + origin + fov» собирается в кадр-структуру (`FrameTransform`) один раз за кадр и раздаётся всем потребителям (W2S, ESP).

## 5. Entity system

**Известно точно [C]:**
- Акторы — **ECS**: `EntityContext` + entt-реестр + компоненты (`RenderPositionComponent`, `AABBShapeComponent`, `ActorRotationComponent`, `AttributesComponent`, `StateVectorComponent`, `ActorOwnerComponent`, ...). Подтверждено обоими SDK (Flarial `SDK/Client/Actor/Components/`, Solstice `SDK/Minecraft/Actor/Components/`).
- Локальный игрок: `ClientInstance::getLocalPlayer()` (все три).
- Позиция: `getRenderPositionComponent()->renderPos/mPosition` (сглаженная); Borion по-старому: `getPos()/getPosOld()` + lerp.
- Имя/тип/здоровье: `getNameTag()`, `getEntityTypeId()`, `AttributesComponent` (изучены поверхностно — см. бэклог).
- Фильтры ESP (Borion `ESP.cpp`): пропуск себя, `timeSinceDeath > 0`, друзей, `isInvisible()`, `canAttack()`.

**Version-specific:** layout компонентов, `EntityContext`, имена методов доступа.
**Архитектурное:** ECS-компоненты; единая точка «дай всех актёров» + единый предикат-фильтр.

## 6. AABB

**Известно точно [C]:**
- Структура везде `{ vec3 lower; vec3 upper; }` (Flarial `Utils.hpp:251`, Borion `HMath.h:528` + `isZero` + padding).
- Источник: `Actor->getAABBShapeComponent()->aabb` (+ `Vec2 size`; `static_assert(sizeof == 0x20)` у Flarial).
- Borion строит AABB сам из позиции+размеров для лерпа: `AABB(lerped, width, height, ...)`; `upper.y += 0.1`.
- Потребление: 8 вершин → W2S (2D-бокс) или 12 рёбер через Tessellator (3D-бокс). Обход внешнего контура (outline) — min-angle walk, один алгоритм на оба клиента.

**Version-specific:** размер/состав `AABBShapeComponent` (0x20 на версиях Flarial).
**Архитектурное:** AABB = пара vec3; все боксы строятся из 8 углов; outline = выпуклый обход спроецированных точек.

## 7. Matrices

**Известно точно [C]:**
- Формат матрицы в игре: 16 float, row-major-ish `GLMatrix{matrix[16]}`; перед использованием выполняется **перестановка/транспонирование** (`getMatrixCorrection`, `correct()` — `glm::transpose`).
- Умножение: `clip = mat × vec4(pos−origin, 1)`; дальше перспективное деление вручную (см. §8).
- Источник матрицы для оверлея — очередь `FrameTransform` (мьютекс + задержка `transformDelay`), а не прямое чтение из Present-потока.

**Version-specific:** layout `GLMatrix`, семантика `getRefDef` vs `getViewMatrix`.
**Архитектурное:** матрица всегда корректируется транспонированием; origin вычитается до умножения; матрица + origin + fov путешествуют вместе.

## 8. World-to-screen

**Известно точно [C] — три независимые реализации, формула идентична:**
```cpp
pos -= origin;
t = matrix × vec4(pos, 1);
if (t.z > 0) return false;              // за камерой
screen.x = mX + (mX * t.x / -t.z * fov.x);
screen.y = mY - (mY * t.y / -t.z * fov.y);
```
- Flarial `Matrix::WorldToScreen` (источник: `MC::Transform` из очереди кадров).
- Borion `glmatrixf::OWorldToScreen` (`HMath.h:403`, источник: `refdef/fov/origin`, собранные в `setCtx`).
- Solstice `RenderUtils::worldToScreen` (обёртка над тем же `OWorldToScreen`, источник: `RenderUtils::transform`).
- Размер экрана: `GuiData->ScreenSize` / `mResolution` / `widthGame×heightGame`.

**Version-specific:** откуда берутся матрица/origin/fov/разрешение (оффсеты `GuiData`, `ClientInstance`).
**Архитектурное:** сама формула — чистая математика, от версии не зависит; контракт `bool w2s(world, &screen)`.

## 9. 2D rendering

**Известно точно [C]:**
- **Через игру (Borion):** `tess__begin(tess, format, n)` → `tess_vertex(x, y, 0)` → `meshHelper_renderImm(screenContext2d, tess, uiMaterial)`. Линия = 2 треугольника (6 вершин). Цвет — через `colorHolder` (`setColor` пишет RGBA + флаг-байт). `flush() = renderCtx->flushText(0)`. `uiMaterial` — статический игровой материал, найденный по сигнатуре (LEA-паттерн).
- **Через оверлей (Flarial/Solstice):** `ImGui::GetBackgroundDrawList()->AddLine/AddPolyline/AddConvexPolyFilled/AddRect...` — весь ImGui draw-list API. Плюс D2D-примитивы у Flarial (`D2D::context->DrawLine/...` с брашами).
- ESP-боксы: два режима — полный 3D-каркас (12 рёбер по W2S-точкам) и outline (выпуклый обход). Толщина линии масштабируется от дистанции (`max(0.4, 1/max(1, dist*3))` у Borion).

**Version-specific:** сигнатуры `tess_begin/tess_vertex/renderImm`, оффсеты `screenContext+0xB0` (tessellator) / `+0x30` (colorHolder), статический `uiMaterial`.
**Архитектурное:** 2D-примитивы = тонкая обёртка либо над Tessellator игры, либо над ImGui draw list; контракт «линия/прямоугольник/окружность/текст» одинаков.

## 10. 3D rendering

**Известно точно [C]:**
- Только через Tessellator игры (ни один клиент не делает собственный DX world-рендер): `begin(LineList/LineStrip/QuadList)` → `vertex(world − origin)` → `renderMeshImmediately(scn, tess, material)`.
- Материалы: Flarial создаёт через `RenderMaterialGroup::createUI("selection_box"|"ui_fill_color"|...)`; Borion переиспользует `entityLineMaterial` из `itemInHandRenderer`.
- Форматы вершин Borion (из комментария в коде): 1=quads, 2=tri list, 3=tri strip, 4=line list, 5=line strip.
- Точка вызова: внутри `renderLevel`-хука — Flarial до оригинала (событие), Borion после оригинала (`onLevelRender`, контекст `a2`).
- Заливка: `fillQuad` (QuadList, обе стороны, alpha из `tess->color`); Solstice `drawOutlinedAABB(aabb, filled)` — заливочный полигон alpha 0.25 + полилиния (но это 2D-путь через W2S, не Tessellator).

**Version-specific:** сигнатура `renderMeshImmediately` (3 vs 4 аргумента — см. §7 отчёта P1), имена материалов, `entityLineMaterial`.
**Архитектурное:** «вычти origin → begin → vertices → flush с материалом» — универсальный цикл; глубина/блендинг определяются материалом игры.

## 11. Text rendering

**Известно точно [C]:**
- **Через игру (Borion):** `MUIRenderContext::drawText(font, rect[4], text, color, alpha, alignment, textMeasure, caretMeasure)`; шрифт `minecraftGame->getOldFont()` (остальные геттеры есть, но код форсит OldFont); ширина `renderCtx->getLineLength(font, text, size, false)`; `flushText(0)` в конце. Flarial перехватывает `drawText` (vtable[5]) и умеет дорисовать очередь `SDK::drawTextQueue2` оригинальной функцией.
- **Через оверлей:** Flarial — D2D text + ImGui (`CalcTextSizeA` для замера); Solstice — ImGui (`GetFont()->CalcTextSizeA`, `GetForegroundDrawList`).
- Выравнивание/тень/обводка у игрового пути — параметры `drawText`; у ImGui — ручная отрисовка (детали не изучались — бэклог).

**Version-specific:** сигнатура `drawText` (vtable[5]), `TextMeasureData/CaretMeasureData`, геттеры шрифтов.
**Архитектурное:** две системы координат текста (UI-путь в единицах игры, оверлей в пикселях); контракт «нарисовать/замерить строку».

## 12. Textures

**Известно точно [C]:**
- **Игровые текстуры:** версия ≥1.21.50 использует `BedrockTextureData` вместо `TexturePtr` в `drawImage` (Flarial держит 3 детура). Borion рисует предметы через `ItemRenderer::renderGuiItemNew(&baseActorRenderCtx, item, game, x, y, opacity, scale, enchanted)` — полный игровой рендер предмета с чарами.
- **Свои текстуры в оверлее:** Solstice `D3DHook::createTextureFromFile(path → ID3D11ShaderResourceView + w/h)` + `ImTextureCache` (mutex, map path→texture, `freeCachedTextures`); Flarial `FlarialGUI::LoadAllImages()` + дескрипторный менеджмент под DX12 (консолидированная куча: шрифт ImGui + 300 слотов картинок + 2000 слотов голов игроков).

**Version-specific:** `TexturePtr`→`BedrockTextureData` переход, `renderGuiItemNew`, формат `BedrockTextureData`.
**Архитектурное:** кэш «путь → GPU-текстура»; загрузка файлов — только в Present-потоке (там живёт device).

## 13. Particles

**Известно точно [C]:**
- **Игровые парти
...[truncated 11111 chars]