// overlay.cpp - Present interception, D3D11/D3D12 overlay rendering,
// WndProc input subclass, cursor arbitration and clean unload.
//
// Design notes:
//  * Patch surface: shared DXGI vtable slots for Present (8) /
//    ResizeBuffers (13) + the shared ID3D12CommandQueue slot for
//    ExecuteCommandLists (10), all obtained without touching game code -
//    PLUS one game-function detour, Keyboard::feed (MinHook + signature),
//    installed per explicit user order ("like in the repo") because no
//    in-sandbox Win32 key source exists. Feed use is read+mask only
//    (mirror every transition, swallow presses while the menu is open,
//    swallow the menu key). All patches are restored on unload.
//  * D3D11 path: render into the game's immediate context + our RTV.
//  * D3D12 path: single DIRECT queue of our own for ImGui-owned uploads, but
//    the per-frame UI list is submitted on the GAME's direct queue (learned
//    via an ExecuteCommandLists vtable hook, slot 10 - a system-interface
//    hook like Present, not a game detour). Same-queue FIFO ordering is what
//    keeps our PRESENT<->RT barriers after the game's own transitions; a
//    second racing queue wedged the GPU on frame 1 (dx12c). Our fence still
//    fully serializes each frame (Signal + wait with timeout).
//  * Input: WndProc subclass feeds nf::keys and the ImGui backend; while the
//    menu is open, input messages are swallowed so the game never sees them.
//    The game window gets no legacy key/mouse messages (raw/CoreWindow input
//    path), so we register our OWN raw-input sink (RIDEV_INPUTSINK): WM_INPUT
//    then arrives no matter what the game does, and the subclass parses it
//    (keyboard -> nf::keys, buttons/wheel -> ImGui IO). Mouse buttons are
//    additionally ORed from GetAsyncKeyState, which provably works for mouse
//    (not keys) inside AppContainer. A start-up message census proves which
//    path is alive (see "input census" in the log).
//  * Keyboard: the game's Keyboard::feed is detoured (see above) - the ONLY
//    key source that works inside AppContainer. The raw-input sink + async
//    poll stay fused underneath as fallback; every source merges into the
//    single keys:: edge, so one press is one toggle, never double.
//  * Cursor (in-world): the game re-hides/re-parks the OS cursor every
//    frame, so while the menu is open we detour ShowCursor/SetCursorPos/
//    ClipCursor/SetCapture (reject the grab) + GetRawInputData/Buffer
//    (neutralize what the game reads). Our own raw reads bypass through
//    the originals. ShowCursor bumps are bounded and exactly rebalanced
//    on close - never spin on the display counter (the reference repo
//    documents a hard freeze from exactly that).

#include "overlay/overlay.h"

#include <d3d11.h>
#include <d3d12.h>
#include <dxgi.h>
#include <dxgi1_4.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

#include <MinHook.h>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_dx12.h"
#include "imgui_impl_win32.h"

// Forward declaration: imgui_impl_win32.h intentionally keeps it in `#if 0`
// and asks the caller to declare it (see the comment in that header).
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#include "core/module_guard.h"
#include "ui/menu.h"
#include "utils/config.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/keys.h"
#include "utils/logger.h"

namespace nf {
namespace overlay {

bool g_showMenu = false;
int g_menuKey = VK_INSERT;

namespace {

// ============================ state ============================
constexpr int kPresentIndex = 8;
constexpr int kResizeIndex = 13;
constexpr int kExecIndex = 10;  // ID3D12CommandQueue::ExecuteCommandLists
constexpr int kMaxBuffers = 8;

HMODULE g_hmod = nullptr;
wchar_t g_dllDir[MAX_PATH] = {};
bool g_abort = false;

void** g_vtable = nullptr;
void* g_oPresent = nullptr;
void* g_oResize = nullptr;
void** g_queueVtable = nullptr;
void* g_oExec = nullptr;

// Keyboard::feed detour state (game key source, explicit user order).
using KeyboardFeedFn = void(__cdecl*)(uint32_t, bool);
KeyboardFeedFn g_oFeed = nullptr;
bool g_feedHook = false;

// user32 detour originals (cursor visibility + game input mask, menu-open only).
using GetRawInputDataFn = UINT(WINAPI*)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
using GetRawInputBufferFn = UINT(WINAPI*)(RAWINPUT*, PUINT, UINT);
using SetCursorPosFn = BOOL(WINAPI*)(int, int);
using ClipCursorFn = BOOL(WINAPI*)(const RECT*);
using SetCaptureFn = HWND(WINAPI*)(HWND);
using ShowCursorFn = int(WINAPI*)(BOOL);
GetRawInputDataFn oGetRawInputData = nullptr;
GetRawInputBufferFn oGetRawInputBuffer = nullptr;
SetCursorPosFn oSetCursorPos = nullptr;
ClipCursorFn oClipCursor = nullptr;
SetCaptureFn oSetCapture = nullptr;
ShowCursorFn oShowCursor = nullptr;
bool g_cursorHooks = false;
int g_showBalance = 0;  // our own ShowCursor(TRUE) count: undone exactly on close

HWND g_hwnd = nullptr;
WNDPROC g_origWnd = nullptr;
struct SubHook { HWND h; WNDPROC o; };
std::vector<SubHook> g_subs;  // non-primary process windows we subclassed
bool g_wndHooked = false;

IDXGISwapChain* g_sc = nullptr;
UINT g_w = 0, g_h = 0;

bool g_init = false;          // render objects ready
bool g_usingD3D12 = false;
bool g_imgui = false;         // ImGui context + modules + config ready
bool g_backend11 = false;
bool g_backend12 = false;
bool g_win32Init = false;
bool g_unloadRequested = false;
bool g_shuttingDown = false;
bool g_renderAborted = false;

// D3D11 objects
ID3D11Device* g_d11dev = nullptr;
ID3D11DeviceContext* g_d11ctx = nullptr;
ID3D11RenderTargetView* g_d11rtv = nullptr;

// D3D12 objects (our own queue on the game's device)
ID3D12Device* g_d12dev = nullptr;
ID3D12CommandQueue* g_d12queue = nullptr;
ID3D12CommandQueue* g_gameQueue = nullptr;  // captured, never owned: no Release
ID3D12CommandAllocator* g_d12alloc = nullptr;
ID3D12GraphicsCommandList* g_d12list = nullptr;
ID3D12DescriptorHeap* g_d12rtvHeap = nullptr;
ID3D12DescriptorHeap* g_d12srvHeap = nullptr;
ID3D12Resource* g_d12bufs[kMaxBuffers] = {};
D3D12_CPU_DESCRIPTOR_HANDLE g_d12rtvs[kMaxBuffers] = {};
int g_d12bufCount = 0;
ID3D12Fence* g_d12fence = nullptr;
HANDLE g_d12event = nullptr;
UINT64 g_d12fenceVal = 0;
bool g_d12waitLogged = false;

CRITICAL_SECTION g_renderCs;
bool g_csInit = false;
LONG g_inRender = 0;

bool g_menuWasOpen = false;
bool g_cursorForced = false;
bool g_menuKeyArmed = true;  // menu key re-arms only after a release (no hold-strobe)

// WndProc message census (dumped once at frame 600 - proves which input
// path the game actually delivers to our subclass).
int g_cKeyDown = 0, g_cKeyUp = 0, g_cInput = 0, g_cChar = 0, g_cMouse = 0, g_cBtn = 0;
int g_cRawBtn = 0;  // raw mouse packets carrying button transitions
bool g_legacyCharSeen = false;  // a real WM_CHAR arrived: stop synthesizing text
bool g_legacyWheelSeen = false;  // a real WM_MOUSEWHEEL arrived: stop raw wheel

// Raw-input mouse cache, written on the pump thread (HookWndProc) and
// consumed on the Present thread (ApplyRawMouse). Plain bool/float access:
// a torn read costs at most one frame of a button, never correctness.
bool g_rawBtn[5] = {};
float g_rawWheel = 0.0f, g_rawWheelH = 0.0f;
BYTE g_rawBuf[256] = {};  // scratch for GetRawInputData (keyboard/mouse only)
bool g_rawRegistered = false;

void EnsureCs() {
    if (!g_csInit) { InitializeCriticalSection(&g_renderCs); g_csInit = true; }
}

using PresentFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);
using ResizeFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using ExecFn = void(__stdcall*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);

void PatchVTable(void** vtable, int index, void* hook, void** original);  // defined below
void __stdcall HkExecuteCommandLists(ID3D12CommandQueue* q, UINT n,
                                    ID3D12CommandList* const* lists);  // defined below

void FinishUnload();  // defined below; called from the HkPresent tail
HWND FindGameWindow();  // defined below; used when the swapchain has no OutputWindow
void HandleRawInput(LPARAM l);  // defined below; WM_INPUT -> keys:: + raw mouse cache
void ApplyRawMouse();  // defined below; raw cache -> ImGui IO (post-backend, pre-ImGui)

// ============================ input ============================
bool IsInputMessage(UINT msg) {
    switch (msg) {
        case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        case WM_CHAR: case WM_SYSCHAR: case WM_DEADCHAR:
        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK:
        case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MBUTTONDBLCLK:
        case WM_XBUTTONDOWN: case WM_XBUTTONUP:
        case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_MOUSEMOVE:
        case WM_INPUT:  // raw input dies here too, or the game steers under the menu
            return true;
        default:
            return false;
    }
}

LRESULT CALLBACK HookWndProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    // Always feed our snapshot first (toggle keys must work with menu closed).
    switch (msg) {
        case WM_KEYDOWN: case WM_SYSKEYDOWN:
            if (++g_cKeyDown == 1)
                LOG_INFO("wndproc: first WM_KEYDOWN vk=%02X", (unsigned)w);
            keys::FeedKey((unsigned)w, true);
            break;
        case WM_KEYUP: case WM_SYSKEYUP:
            if (++g_cKeyUp == 1) LOG_INFO("wndproc: first WM_KEYUP");
            keys::FeedKey((unsigned)w, false);
            break;
        case WM_INPUT:
            if (++g_cInput == 1) LOG_INFO("wndproc: first WM_INPUT");
            HandleRawInput(l);
            break;
        case WM_CHAR:
            if (++g_cChar == 1) LOG_INFO("wndproc: first WM_CHAR");
            g_legacyCharSeen = true;
            keys::FeedChar((unsigned)w);
            break;
        case WM_MOUSEMOVE:
            if (++g_cMouse == 1) LOG_INFO("wndproc: first WM_MOUSEMOVE");
            break;
        case WM_LBUTTONDOWN:
            if (++g_cBtn == 1) LOG_INFO("wndproc: first WM_LBUTTONDOWN");
            break;
        case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
            g_legacyWheelSeen = true;
            break;
        case WM_KILLFOCUS:
            keys::Reset();
            for (int i = 0; i < 5; i++) g_rawBtn[i] = false;
            g_rawWheel = 0.0f; g_rawWheelH = 0.0f;
            break;
        default: break;
    }
    if (g_win32Init) ImGui_ImplWin32_WndProcHandler(h, msg, w, l);
    // Menu open: the game sees no input on ANY process window (no camera, no click-through).
    if (g_showMenu && !g_shuttingDown && IsInputMessage(msg)) return 0;
    WNDPROC o = (h == g_hwnd) ? g_origWnd : nullptr;
    if (!o) for (auto& s : g_subs) if (s.h == h) { o = s.o; break; }
    if (o) return CallWindowProcW(o, h, msg, w, l);
    return DefWindowProcW(h, msg, w, l);  // unreachable: we only run where we hooked
}

UINT RawDataOrig(HRAWINPUT h, UINT cmd, LPVOID data, PUINT size, UINT hdr) {
    // Our own raw reads must bypass the detour installed below: while the
    // menu is open the detour neutralizes what the GAME reads, but the menu
    // itself needs the real packets.
    if (oGetRawInputData) return oGetRawInputData(h, cmd, data, size, hdr);
    return GetRawInputData(h, cmd, data, size, hdr);
}

void HandleRawInput(LPARAM l) {
    UINT sz = 0;
    if (RawDataOrig((HRAWINPUT)l, RID_INPUT, nullptr, &sz, sizeof(RAWINPUTHEADER)) != 0)
        return;
    if (sz == 0 || sz > sizeof(g_rawBuf)) return;  // HID blobs: ignore
    if (RawDataOrig((HRAWINPUT)l, RID_INPUT, g_rawBuf, &sz, sizeof(RAWINPUTHEADER)) != sz)
        return;
    const RAWINPUT* ri = (const RAWINPUT*)g_rawBuf;
    if (ri->header.dwType == RIM_TYPEKEYBOARD) {
        const RAWKEYBOARD& k = ri->data.keyboard;
        UINT vk = (UINT)k.VKey;
        // Disambiguate L/R modifiers (raw reports generic VK_SHIFT/CONTROL/MENU).
        if (vk == VK_SHIFT) vk = MapVirtualKeyW(k.MakeCode, MAPVK_VSC_TO_VK_EX);
        else if (vk == VK_CONTROL) vk = (k.Flags & RI_KEY_E0) ? VK_RCONTROL : VK_LCONTROL;
        else if (vk == VK_MENU) vk = (k.Flags & RI_KEY_E0) ? VK_RMENU : VK_LMENU;
        const bool down = (k.Flags & RI_KEY_BREAK) == 0;
        keys::FeedKey(vk, down);
        {
            static int n = 0;
            if (++n <= 20)
                LOG_INFO("rawkey: vk=%02X mapped=%02X %s sc=%02X e0=%d",
                         (unsigned)k.VKey, vk, down ? "down" : "up",
                         (unsigned)k.MakeCode, (k.Flags & RI_KEY_E0) ? 1 : 0);
        }
        // Text synthesis: RIDEV_NOLEGACY kills WM_CHAR, so translate through
        // the layout here. Skipped once a real WM_CHAR proves legacy alive.
        if (down && !g_legacyCharSeen) {
            if (vk == VK_BACK) {
                keys::FeedChar(8);
            } else {
                BYTE kb[256] = {};
                GetKeyboardState(kb);
                WCHAR out[8] = {};
                const int rc = ToUnicode(vk, k.MakeCode, kb, out, 8, 0);
                for (int i = 0; i < rc; i++) keys::FeedChar((unsigned)out[i]);
            }
        }
    } else if (ri->header.dwType == RIM_TYPEMOUSE) {
        const RAWMOUSE& m = ri->data.mouse;
        if (m.usButtonFlags != 0) g_cRawBtn++;
        {
            static bool once = false;
            if (!once && m.usButtonFlags != 0) {
                once = true;
                LOG_INFO("rawmouse: first buttons=%04X", (unsigned)m.usButtonFlags);
            }
        }
        if (m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) g_rawBtn[0] = true;
        if (m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) g_rawBtn[0] = false;
        if (m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) g_rawBtn[1] = true;
        if (m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) g_rawBtn[1] = false;
        if (m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) g_rawBtn[2] = true;
        if (m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_UP) g_rawBtn[2] = false;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN) g_rawBtn[3] = true;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_4_UP) g_rawBtn[3] = false;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_DOWN) g_rawBtn[4] = true;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_UP) g_rawBtn[4] = false;
        // Wheel: raw only while no legacy wheel was ever seen (no double-add).
        // Position comes from the backend's own cursor poll, so relative
        // motion is intentionally ignored here.
        if (!g_legacyWheelSeen) {
            if (m.usButtonFlags & RI_MOUSE_WHEEL)
                g_rawWheel += (float)(short)m.usButtonData / (float)WHEEL_DELTA;
            if (m.usButtonFlags & RI_MOUSE_HWHEEL)
                g_rawWheelH += (float)(short)m.usButtonData / (float)WHEEL_DELTA;
        }
    } else if (ri->header.dwType == RIM_TYPEHID) {
        static bool once = false;
        if (!once) {
            once = true;
            LOG_INFO("rawhid: first HID input (size=%u) - keyboard may be HID-only", sz);
        }
    }
}

void ApplyRawMouse() {
    // Full mouse ownership (the backend is blind here: no legacy messages).
    // Buttons are a PURE level from live sources: raw-input cache OR the
    // async poll (which provably works for mouse, not keys, in AppContainer).
    // Never OR in the previous io.MouseDown - that latches a press forever
    // (only a focus loss clears it: exactly the "one click per alt-tab"
    // bug). Backend edge events, if any legacy message ever arrives, still
    // apply via the event queue on top for their frame. Runs after the
    // backend NewFrame and before ImGui::NewFrame consumes the IO.
    static const unsigned kBtnVk[5] = {
        VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2
    };
    ImGuiIO& io = ImGui::GetIO();
    // Drive the position ourselves every frame: the backend polls the OS
    // cursor only while MouseTrackedArea==0, and a few stray legacy moves
    // poison that forever (plus the UWP foreground window may differ from
    // ours, which also disables its poll). Queued after the backend's own
    // events, so ground truth always wins.
    if (g_hwnd && IsWindow(g_hwnd)) {
        POINT pt{};
        if (GetCursorPos(&pt) && ScreenToClient(g_hwnd, &pt)) {
            io.AddMousePosEvent((float)pt.x, (float)pt.y);
            static bool once = false;
            if (!once) {
                once = true;
                LOG_INFO("mouse: first driven pos=(%ld,%ld)", pt.x, pt.y);
            }
        }
    }
    for (int i = 0; i < 5; i++)
        io.MouseDown[i] = g_rawBtn[i] ||
                          (GetAsyncKeyState(kBtnVk[i]) & 0x8000) != 0;
    if (!g_legacyWheelSeen) {
        io.MouseWheel += g_rawWheel;
        io.MouseWheelH += g_rawWheelH;
    }
    g_rawWheel = 0.0f;
    g_rawWheelH = 0.0f;
}

void RegisterRawInput() {
    // Our OWN raw-input sink (not piggybacking on the game's registration,
    // which may not exist at all on the CoreDispatcher path). RIDEV_INPUTSINK
    // delivers WM_INPUT to our window even unfocused; we deliberately do NOT
    // set RIDEV_NOLEGACY, so the game's own input path is untouched.
    if (!g_hwnd || g_rawRegistered) return;
    RAWINPUTDEVICE rid[2] = {};
    rid[0].usUsagePage = 1; rid[0].usUsage = 6;  // keyboard
    rid[0].dwFlags = RIDEV_INPUTSINK;
    rid[0].hwndTarget = g_hwnd;
    rid[1].usUsagePage = 1; rid[1].usUsage = 2;  // mouse
    rid[1].dwFlags = RIDEV_INPUTSINK;
    rid[1].hwndTarget = g_hwnd;
    if (RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE))) {
        g_rawRegistered = true;
        LOG_INFO("overlay: raw input sink registered on %p", g_hwnd);
    } else {
        LOG_ERROR("overlay: RegisterRawInputDevices failed (err %lu)", GetLastError());
    }
}

void HookOneWindow(HWND h) {
    if (!h || !IsWindow(h)) return;
    if (h == g_hwnd && g_wndHooked) return;
    for (auto& s : g_subs) if (s.h == h) return;  // already hooked: rescan-safe
    WNDPROC o = (WNDPROC)SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)HookWndProc);
    if (!o) {
        LOG_ERROR("overlay: subclass %p failed (err %lu)", h, GetLastError());
        return;
    }
    wchar_t cls[64] = L"?";
    GetClassNameW(h, cls, 64);
    if (!g_wndHooked) {
        // First window: keeps the legacy role (backend + raw sink anchor).
        g_hwnd = h; g_origWnd = o; g_wndHooked = true;
        LOG_INFO("overlay: WndProc subclass installed on %p [%ls] (primary)", h, cls);
        RegisterRawInput();
    } else {
        g_subs.push_back({h, o});
        LOG_INFO("overlay: WndProc subclass installed on %p [%ls] (extra)", h, cls);
    }
}

BOOL CALLBACK HookChildCb(HWND h, LPARAM pid) {
    DWORD wpid = 0; GetWindowThreadProcessId(h, &wpid);
    if (wpid == (DWORD)pid) HookOneWindow(h);
    return TRUE;
}
BOOL CALLBACK HookTopCb(HWND h, LPARAM pid) {
    DWORD wpid = 0; GetWindowThreadProcessId(h, &wpid);
    if (wpid == (DWORD)pid) {
        HookOneWindow(h);
        EnumChildWindows(h, HookChildCb, pid);
    }
    return TRUE;
}
void ScanAndHookProcessWindows() {
    EnumWindows(HookTopCb, (LPARAM)GetCurrentProcessId());
}

void InstallWndHook(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return;
    if (!g_hwnd) g_hwnd = hwnd;  // usable for the Win32 backend even if the subclass fails
    HookOneWindow(hwnd);       // primary: backend + raw sink anchor
    ScanAndHookProcessWindows();  // siblings/children: same swallow rule
}

void RestoreWndHook() {
    if (g_rawRegistered) {
        RAWINPUTDEVICE rid[2] = {};
        rid[0].usUsagePage = 1; rid[0].usUsage = 6; rid[0].dwFlags = RIDEV_REMOVE;
        rid[1].usUsagePage = 1; rid[1].usUsage = 2; rid[1].dwFlags = RIDEV_REMOVE;
        RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE));
        g_rawRegistered = false;
    }
    if (g_wndHooked && g_hwnd && IsWindow(g_hwnd) && g_origWnd) {
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_origWnd);
        LOG_INFO("overlay: WndProc restored");
    }
    for (auto& s : g_subs)
        if (s.h && IsWindow(s.h) && s.o)
            SetWindowLongPtrW(s.h, GWLP_WNDPROC, (LONG_PTR)s.o);
    if (!g_subs.empty())
        LOG_INFO("overlay: %u extra WndProcs restored", (unsigned)g_subs.size());
    g_subs.clear();
    g_wndHooked = false;
    g_origWnd = nullptr;
}

void UpdateCursor() {
    // Software cursor backs the OS one: if the OS cursor ever stays hidden,
    // the GUI remains usable.
    ImGui::GetIO().MouseDrawCursor = g_showMenu;
    if (!g_showMenu) {
        if (g_cursorForced) {
            // Give back exactly what we took, then hands off: the game owns
            // the cursor again (it re-establishes its own clip itself).
            while (g_showBalance > 0) { ShowCursor(FALSE); g_showBalance--; }
            ReleaseCapture();
            ClipCursor(nullptr);
            g_cursorForced = false;
        }
        return;
    }
    if (!g_cursorForced) {
        ClipCursor(nullptr);
        ReleaseCapture();
        g_cursorForced = true;
    }
    // Bounded raise: NEVER while(ShowCursor(TRUE) < 0) - the game pushes the
    // counter down every frame in a world, so an unbounded loop never ends
    // and freezes Present (documented hard-freeze cause). Bump a few times
    // per frame until the OS reports visible; the detour below swallows the
    // game's counter-pushing while open, so this converges in a frame or two.
    for (int i = 0; i < 4 && g_showBalance < 8; i++) {
        CURSORINFO ci{};
        ci.cbSize = sizeof(ci);
        if (GetCursorInfo(&ci) && (ci.flags & CURSOR_SHOWING) != 0) break;
        ShowCursor(TRUE);
        g_showBalance++;
    }
    static HCURSOR arrow = LoadCursorW(nullptr, IDC_ARROW);
    if (arrow) SetCursor(arrow);
}

// Manual mouse feed for ImGui when the Win32 backend is unavailable (no
// window handle / backend init failed). Keyboard keeps working through the
// keys:: poll in all cases.
void PollMouseFallback() {
    ImGuiIO& io = ImGui::GetIO();
    POINT pt{};
    if (GetCursorPos(&pt)) {
        if (g_hwnd) ScreenToClient(g_hwnd, &pt);
        io.MousePos = ImVec2((float)pt.x, (float)pt.y);
    }
    io.MouseDown[0] = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    io.MouseDown[1] = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
    io.MouseDown[2] = (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
    io.MouseDown[3] = (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
    io.MouseDown[4] = (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
}

// ============================ D3D teardown ============================
void ReleaseD3D11() {
    if (g_backend11) { ImGui_ImplDX11_Shutdown(); g_backend11 = false; }
    if (g_d11rtv) { g_d11rtv->Release(); g_d11rtv = nullptr; }
    if (g_d11ctx) { g_d11ctx->Release(); g_d11ctx = nullptr; }
    if (g_d11dev) { g_d11dev->Release(); g_d11dev = nullptr; }
}

void ReleaseD3D12() {
    if (!g_d12dev && !g_backend12) return;
    if (g_backend12) { ImGui_ImplDX12_Shutdown(); g_backend12 = false; }
    if (g_d12queue && g_d12fence && g_d12event) {
        g_d12queue->Signal(g_d12fence, ++g_d12fenceVal);
        g_d12fence->SetEventOnCompletion(g_d12fenceVal, g_d12event);
        WaitForSingleObject(g_d12event, 1000);
    }
    for (int i = 0; i < kMaxBuffers; i++) {
        if (g_d12bufs[i]) { g_d12bufs[i]->Release(); g_d12bufs[i] = nullptr; }
    }
    g_d12bufCount = 0;
    if (g_d12list) { g_d12list->Release(); g_d12list = nullptr; }
    if (g_d12alloc) { g_d12alloc->Release(); g_d12alloc = nullptr; }
    if (g_d12rtvHeap) { g_d12rtvHeap->Release(); g_d12rtvHeap = nullptr; }
    if (g_d12srvHeap) { g_d12srvHeap->Release(); g_d12srvHeap = nullptr; }
    if (g_d12fence) { g_d12fence->Release(); g_d12fence = nullptr; }
    if (g_d12event) { CloseHandle(g_d12event); g_d12event = nullptr; }
    if (g_d12queue) { g_d12queue->Release(); g_d12queue = nullptr; }
    if (g_d12dev) { g_d12dev->Release(); g_d12dev = nullptr; }
}

void TeardownRender() {
    ReleaseD3D11();
    ReleaseD3D12();
    g_sc = nullptr;
    g_init = false;
    g_usingD3D12 = false;
}

// ============================ D3D init ============================
bool EnsureImGui() {
    if (g_imgui) return true;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;      // never write imgui.ini into the game folder
    io.LogFilename = nullptr;
    ImGui::StyleColorsDark();
    if (!fonts::Init(g_dllDir)) LOG_ERROR("overlay: fonts degraded (see log)");
    if (!ui::Init()) { LOG_ERROR("overlay: menu init failed"); return false; }
    g_imgui = true;
    LOG_INFO("overlay: ImGui + menu ready");
    return true;
}

bool InitD3D11(IDXGISwapChain* sc) {
    HRESULT hr = sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_d11dev);
    if (FAILED(hr) || !g_d11dev) return false;
    g_d11dev->GetImmediateContext(&g_d11ctx);
    ID3D11Texture2D* back = nullptr;
    hr = sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back);
    if (FAILED(hr) || !back) { ReleaseD3D11(); return false; }
    hr = g_d11dev->CreateRenderTargetView(back, nullptr, &g_d11rtv);
    back->Release();
    if (FAILED(hr) || !g_d11rtv) { ReleaseD3D11(); return false; }
    if (!EnsureImGui()) { ReleaseD3D11(); return false; }
    if (!g_backend11) {
        ImGui_ImplDX11_Init(g_d11dev, g_d11ctx);
        g_backend11 = true;
    }
    g_usingD3D12 = false;
    LOG_INFO("overlay: D3D11 path engaged");
    return true;
}

bool InitD3D12(IDXGISwapChain* sc) {
    HRESULT hr = sc->GetDevice(__uuidof(ID3D12Device), (void**)&g_d12dev);
    if (FAILED(hr) || !g_d12dev) return false;

    DXGI_SWAP_CHAIN_DESC sd{};
    if (FAILED(sc->GetDesc(&sd)) || sd.BufferCount < 1) { ReleaseD3D12(); return false; }
    const int count = sd.BufferCount > kMaxBuffers ? kMaxBuffers : (int)sd.BufferCount;

    D3D12_COMMAND_QUEUE_DESC qd{};
    qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
    if (FAILED(g_d12dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&g_d12queue))) {
        ReleaseD3D12(); return false;
    }
    // Hook the shared ID3D12CommandQueue vtable to learn the game's direct
    // queue (all queues of one device share the vtable, so ours reveals it).
    if (!g_oExec && g_d12queue) {
        g_queueVtable = *(void***)g_d12queue;
        PatchVTable(g_queueVtable, kExecIndex, (void*)HkExecuteCommandLists, &g_oExec);
        LOG_INFO("overlay: queue hook live (exec=%p)", g_oExec);
    }
    if (FAILED(g_d12dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                               __uuidof(ID3D12CommandAllocator), (void**)&g_d12alloc))) {
        ReleaseD3D12(); return false;
    }
    if (FAILED(g_d12dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_d12alloc,
                                           nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&g_d12list))) {
        ReleaseD3D12(); return false;
    }
    g_d12list->Close();

    D3D12_DESCRIPTOR_HEAP_DESC hd{};
    hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    hd.NumDescriptors = count;
    if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void**)&g_d12rtvHeap))) {
        ReleaseD3D12(); return false;
    }
    const UINT inc = g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_CPU_DESCRIPTOR_HANDLE h = g_d12rtvHeap->GetCPUDescriptorHandleForHeapStart();
    for (int i = 0; i < count; i++) {
        if (FAILED(sc->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&g_d12bufs[i]))) {
            ReleaseD3D12(); return false;
        }
        g_d12dev->CreateRenderTargetView(g_d12bufs[i], nullptr, h);
        g_d12rtvs[i] = h;
        h.ptr += inc;
    }
    g_d12bufCount = count;

    D3D12_DESCRIPTOR_HEAP_DESC shd{};
    shd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    shd.NumDescriptors = 1;
    shd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if (FAILED(g_d12dev->CreateDescriptorHeap(&shd, __uuidof(ID3D12DescriptorHeap), (void**)&g_d12srvHeap))) {
        ReleaseD3D12(); return false;
    }
    if (FAILED(g_d12dev->CreateFence(0, D3D12_FENCE_FLAG_NONE,
                                    __uuidof(ID3D12Fence), (void**)&g_d12fence))) {
        ReleaseD3D12(); return false;
    }
    g_d12event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!g_d12event) { ReleaseD3D12(); return false; }

    if (!EnsureImGui()) { ReleaseD3D12(); return false; }
    if (!g_backend12) {
        // NOTE: do NOT use the legacy ImGui_ImplDX12_Init() overload here: it
        // leaves InitInfo::CommandQueue null, and the backend unconditionally
        // dereferences it on the first NewFrame (font texture upload) -> AV.
        ImGui_ImplDX12_InitInfo init_info{};
        init_info.Device = g_d12dev;
        init_info.CommandQueue = g_d12queue;
        init_info.NumFramesInFlight = 2;
        init_info.RTVFormat = sd.BufferDesc.Format;
        init_info.SrvDescriptorHeap = g_d12srvHeap;
        init_info.LegacySingleSrvCpuDescriptor = g_d12srvHeap->GetCPUDescriptorHandleForHeapStart();
        init_info.LegacySingleSrvGpuDescriptor = g_d12srvHeap->GetGPUDescriptorHandleForHeapStart();
        if (!ImGui_ImplDX12_Init(&init_info)) {
            ReleaseD3D12(); return false;
        }
        g_backend12 = true;
        // Create PSO/root-signature/font-texture NOW (not lazily on the first
        // NewFrame) so a failure is visible here instead of mid-frame.
        if (!ImGui_ImplDX12_CreateDeviceObjects()) {
            LOG_ERROR("overlay: DX12 CreateDeviceObjects failed - aborting D3D12 path");
            ReleaseD3D12(); return false;
        }
        LOG_INFO("overlay: DX12 device objects ready");
    }
    g_usingD3D12 = true;
    LOG_INFO("overlay: D3D12 path engaged (%d buffers, fmt=%d %ux%u sample=%u effect=%d)",
             count, (int)sd.BufferDesc.Format, sd.BufferDesc.Width, sd.BufferDesc.Height,
             sd.SampleDesc.Count, (int)sd.SwapEffect);
    return true;
}

// ============================ frame ============================
void RenderD3D12Frame() {
    int idx = 0;
    IDXGISwapChain3* sc3 = nullptr;
    if (SUCCEEDED(g_sc->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&sc3)) && sc3) {
        idx = (int)sc3->GetCurrentBackBufferIndex();
        sc3->Release();
    }
    if (idx < 0 || idx >= g_d12bufCount) idx = 0;

    static int d12fno = 0;
    const bool dtrace = ++d12fno <= 3;
    static bool resetErrLogged = false;
    const HRESULT hrAlloc = g_d12alloc->Reset();
    const HRESULT hrList = g_d12list->Reset(g_d12alloc, nullptr);
    if ((FAILED(hrAlloc) || FAILED(hrList)) && !resetErrLogged) {
        resetErrLogged = true;
        LOG_ERROR("overlay: D3D12 allocator/list reset failed (%08X/%08X)", hrAlloc, hrList);
    }
    if (dtrace) LOG_INFO("trace: d3d12 list reset");

    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.pResource = g_d12bufs[idx];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    g_d12list->ResourceBarrier(1, &b);
    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);
    if (dtrace) LOG_INFO("trace: d3d12 target set");

    ImGui_ImplDX12_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ApplyRawMouse();
    ImGui::NewFrame();
    if (dtrace) LOG_INFO("trace: d3d12 newframe done");
    gui::BeginFrame(ImVec2((float)g_w, (float)g_h), ImGui::GetIO().MousePos,
                    ImGui::GetIO().DeltaTime);
    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame enter");
    ui::Frame();
    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame exit");
    ImGui::Render();
    if (dtrace) LOG_INFO("trace: d3d12 imgui render done");
    ID3D12DescriptorHeap* heaps[] = { g_d12srvHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), g_d12list);
    if (dtrace) LOG_INFO("trace: d3d12 drawdata done");

    b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    g_d12list->ResourceBarrier(1, &b);
    g_d12list->Close();
    ID3D12CommandList* lists[] = { g_d12list };
    // Same-queue submit: per-queue FIFO guarantees our barriers run after the
    // game's own transitions. Fallback to our queue only if the game queue
    // was never captured (should not happen: the game always Executes before
    // it Presents).
    ID3D12CommandQueue* submitQ = g_gameQueue ? g_gameQueue : g_d12queue;
    if (dtrace)
        LOG_INFO("trace: d3d12 submit queue %p (%s)", submitQ,
                 submitQ == g_gameQueue ? "game" : "own");
    submitQ->ExecuteCommandLists(1, lists);
    submitQ->Signal(g_d12fence, ++g_d12fenceVal);
    g_d12fence->SetEventOnCompletion(g_d12fenceVal, g_d12event);
    if (WaitForSingleObject(g_d12event, 1000) != WAIT_OBJECT_0 && !g_d12waitLogged) {
        g_d12waitLogged = true;
        LOG_ERROR("overlay: D3D12 fence wait timed out - continuing unsynchronized");
    }
    if (dtrace) LOG_INFO("trace: d3d12 submit done");
}

void RenderD3D11Frame() {
    ImGui_ImplDX11_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ApplyRawMouse();
    ImGui::NewFrame();
    gui::BeginFrame(ImVec2((float)g_w, (float)g_h), ImGui::GetIO().MousePos,
                    ImGui::GetIO().DeltaTime);
    ui::Frame();
    ImGui::Render();
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

// ============================ queue hook ============================
void __stdcall HkExecuteCommandLists(ID3D12CommandQueue* q, UINT n,
                                    ID3D12CommandList* const* lists) {
    (void)n; (void)lists;
#ifdef _MSC_VER
    __try {
#endif
        // Capture the game's direct queue for same-queue UI submit. Our own
        // queue (ImGui font upload) must never be captured.
        if (q && q != g_d12queue && q->GetDesc().Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
            if (g_gameQueue != q) {
                g_gameQueue = q;
                LOG_INFO("overlay: game direct queue captured (%p)", q);
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in Execute hook - capture skipped");
    }
#endif
    ExecFn o = (ExecFn)g_oExec;
    if (o) o(q, n, lists);
}

// ============================ signature scan ============================
// Minimal executable-section scanner for Solstice-style "E8 ? ? ? ? ..."
// signatures. Used ONLY for Keyboard::feed; a hook is installed on
// exactly-one-match, never on ambiguity (a lookalike hook would crash).
bool BuildSigPattern(const char* sig, std::vector<uint8_t>& bytes, std::string& mask) {
    bytes.clear();
    mask.clear();
    if (!sig) return false;
    std::istringstream in(sig);
    std::string tok;
    while (in >> tok) {
        if (tok == "?" || tok == "??") {
            bytes.push_back(0);
            mask.push_back('?');
            continue;
        }
        char* end = nullptr;
        const unsigned long v = std::strtoul(tok.c_str(), &end, 16);
        if (!end || *end != '\0' || v > 0xFFul) return false;
        bytes.push_back((uint8_t)v);
        mask.push_back('x');
    }
    return !bytes.empty();
}

// Counts matches (stops at 2); first receives the first hit, or 0.
int ScanSigMatches(HMODULE mod, const char* sig, uintptr_t& first) {
    first = 0;
    std::vector<uint8_t> bytes;
    std::string mask;
    if (!mod || !BuildSigPattern(sig, bytes, mask)) return 0;
    const uint8_t* base = (const uint8_t*)mod;
    const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    const IMAGE_NT_HEADERS* nt = (const IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    int found = 0;
    const size_t len = bytes.size();
    for (WORD s = 0; s < nt->FileHeader.NumberOfSections && found < 2; s++, sec++) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* begin = base + sec->VirtualAddress;
        const uint8_t* end = begin + sec->Misc.VirtualSize;
        for (const uint8_t* p = begin; p + len <= end; p++) {
            bool ok = true;
            for (size_t i = 0; i < len; i++) {
                if (mask[i] == 'x' && p[i] != bytes[i]) { ok = false; break; }
            }
            if (ok) {
                if (found == 0) first = (uintptr_t)p;
                if (++found >= 2) break;
            }
        }
    }
    return found;
}

// ============================ Keyboard::feed detour ============================
void __cdecl HkKeyboardFeed(uint32_t key, bool isDown) {
#ifdef _MSC_VER
    __try {
#endif
        // Mirror every transition for the overlay first.
        keys::FeedKey((unsigned)key, isDown);
        {
            static int n = 0;
            if (++n <= 10)
                LOG_INFO("feedkey: key=%02X %s", key & 0xFFu, isDown ? "down" : "up");
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in feed mirror");
    }
#endif
    // Masking: while the menu is open the game sees no presses (no steering
    // or pause menu under the cursor). The menu key itself is always masked.
    // Releases pass through - a lone release is harmless to the game.
    if (isDown && (g_showMenu || (g_menuKey > 0 && key == (uint32_t)g_menuKey))) return;
    KeyboardFeedFn o = g_oFeed;
    if (o) o(key, isDown);
}

void TryInstallFeedHook() {
    static bool tried = false;
    if (tried) return;
    tried = true;
    // RefSig (Bedrock 1.21.101-1.21.111): match points at "E8 rel32", the
    // function is match + 5 + rel32.
    static const char kSig[] =
        "E8 ? ? ? ? E9 03 03 ? ? 0F BE 73 16 44 0F B7 7B 12 44 0F";
    uintptr_t first = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), kSig, first);
    if (matches != 1 || !first) {
        LOG_INFO("overlay: Keyboard::feed sig matches=%d - feed off (raw/poll only)", matches);
        return;
    }
    const uintptr_t feed = first + 5 + (uintptr_t)(int32_t)*(const int32_t*)(first + 1);
    LOG_INFO("overlay: Keyboard::feed at %p (sig %p)", (void*)feed, (void*)first);
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize failed (%d)", (int)st);
        return;
    }
    st = MH_CreateHook((LPVOID)feed, (LPVOID)&HkKeyboardFeed, (LPVOID*)&g_oFeed);
    if (st != MH_OK || !g_oFeed) {
        LOG_ERROR("overlay: MH_CreateHook(feed) failed (%d)", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)feed);
    g_feedHook = (st == MH_OK);
    LOG_INFO("overlay: Keyboard::feed hook active=%d (%d)", g_feedHook ? 1 : 0, (int)st);
}

// ============================ cursor/raw user32 detours ============================
// In-world Bedrock re-hides, re-centers and clips the OS cursor every frame
// and reads input via raw input (messages and/or the raw buffer). While the
// menu is open these detours reject the grab and neutralize what the game
// reads; while closed every detour is a pure pass-through.
void NeutralizeRawInput(RAWINPUT* ri) {
    if (!ri) return;
    // Only the payload goes inert: the packet keeps its real shape and size.
    // Returning 0/"no data" instead would make game callers parse a RAWINPUT
    // out of a zero-byte buffer (heap UB inside the game).
    if (ri->header.dwType == RIM_TYPEMOUSE) {
        ri->data.mouse.lLastX = 0;
        ri->data.mouse.lLastY = 0;
        ri->data.mouse.usButtonFlags = 0;
        ri->data.mouse.usButtonData = 0;
    } else if (ri->header.dwType == RIM_TYPEKEYBOARD) {
        ri->data.keyboard.Message = WM_NULL;  // ignored by every raw key path
        ri->data.keyboard.VKey = 0;
    }
}

UINT WINAPI HkGetRawInputData(HRAWINPUT h, UINT cmd, LPVOID data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        const UINT ret = oGetRawInputData ? oGetRawInputData(h, cmd, data, size, hdr) : 0;
        if (g_showMenu && cmd == RID_INPUT && data && ret > 0 && ret != (UINT)-1)
            NeutralizeRawInput((RAWINPUT*)data);
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

UINT WINAPI HkGetRawInputBuffer(RAWINPUT* data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        const UINT ret = oGetRawInputBuffer ? oGetRawInputBuffer(data, size, hdr) : 0;
        if (g_showMenu && data && ret > 0 && ret != (UINT)-1) {
            RAWINPUT* ri = data;
            for (UINT i = 0; i < ret; i++) {
                const DWORD step = ri->header.dwSize;
                NeutralizeRawInput(ri);
                if (step < sizeof(RAWINPUTHEADER)) break;  // malformed: stop
                ri = (RAWINPUT*)((BYTE*)ri + step);
            }
        }
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

BOOL WINAPI HkSetCursorPos(int x, int y) {
    if (g_showMenu) return TRUE;  // reject the game's re-center
    return oSetCursorPos ? oSetCursorPos(x, y) : FALSE;
}

BOOL WINAPI HkClipCursor(const RECT* rect) {
    // Our own ClipCursor(nullptr) on open must pass; only new non-null game
    // clips are rejected while the menu owns input.
    if (g_showMenu && rect != nullptr) return TRUE;
    return oClipCursor ? oClipCursor(rect) : FALSE;
}

HWND WINAPI HkSetCapture(HWND hwnd) {
    if (g_showMenu) return nullptr;
    return oSetCapture ? oSetCapture(hwnd) : nullptr;
}

int WINAPI HkShowCursor(BOOL show) {
    // Keep the game from hiding the cursor underneath the menu. Swallowed
    // outright (no original call), so OUR open/close balance below stays
    // exact no matter what the game does while open.
    if (g_showMenu && !show) return 1;
    return oShowCursor ? oShowCursor(show) : 1;
}

void TryInstallCursorHooks() {
    static bool tried = false;
    if (tried) return;
    tried = true;
    HMODULE u32 = GetModuleHandleA("user32.dll");
    if (!u32) {
        LOG_ERROR("overlay: no user32 for cursor hooks");
        return;
    }
    struct Hook { const char* name; LPVOID detour; LPVOID* orig; };
    Hook hooks[] = {
        { "GetRawInputData", (LPVOID)&HkGetRawInputData, (LPVOID*)&oGetRawInputData },
        { "GetRawInputBuffer", (LPVOID)&HkGetRawInputBuffer, (LPVOID*)&oGetRawInputBuffer },
        { "SetCursorPos", (LPVOID)&HkSetCursorPos, (LPVOID*)&oSetCursorPos },
        { "ClipCursor", (LPVOID)&HkClipCursor, (LPVOID*)&oClipCursor },
        { "SetCapture", (LPVOID)&HkSetCapture, (LPVOID*)&oSetCapture },
        { "ShowCursor", (LPVOID)&HkShowCursor, (LPVOID*)&oShowCursor },
    };
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize failed (%d)", (int)st);
        return;
    }
    bool ok = false;
    for (size_t i = 0; i < sizeof(hooks) / sizeof(hooks[0]); i++) {
        FARPROC p = GetProcAddress(u32, hooks[i].name);
        if (!p) {
            LOG_ERROR("overlay: no user32 export %s", hooks[i].name);
            continue;
        }
        st = MH_CreateHook((LPVOID)p, hooks[i].detour, hooks[i].orig);
        if (st != MH_OK || !*hooks[i].orig) {
            LOG_ERROR("overlay: hook %s failed (%d)", hooks[i].name, (int)st);
            continue;
        }
        if (MH_EnableHook((LPVOID)p) == MH_OK) ok = true;
        else LOG_ERROR("overlay: enable %s failed", hooks[i].name);
    }
    g_cursorHooks = ok;
    LOG_INFO("overlay: cursor/raw-block hooks active=%d", ok ? 1 : 0);
}

// ============================ hooks ============================
HRESULT __stdcall HkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        if (g_shuttingDown || !sc) {
            // fall through to the original below
        } else if (!g_init) {
            DXGI_SWAP_CHAIN_DESC sd{};
            if (SUCCEEDED(sc->GetDesc(&sd))) {
                g_w = sd.BufferDesc.Width;
                g_h = sd.BufferDesc.Height;
            }
            if (!g_wndHooked) {
                // UWP/composition swapchains often report a null OutputWindow -
                // fall back to probing the process for its main window.
                HWND target = sd.OutputWindow ? sd.OutputWindow : FindGameWindow();
                if (target) {
                    if (!sd.OutputWindow)
                        LOG_INFO("overlay: swapchain OutputWindow is null - probing found %p", target);
                    InstallWndHook(target);
                } else {
                    LOG_ERROR("overlay: no game window for the input hook - will keep retrying");
                }
            }
            g_sc = sc;
            TryInstallFeedHook();  // game key source (once; raw/poll stay fused underneath)
            TryInstallCursorHooks();  // user32 detours (once; inert while menu closed)
            if (InitD3D11(sc) || InitD3D12(sc)) {
                g_init = true;
            } else {
                TeardownRender();
                static int fails = 0;
                if (++fails == 1 || fails % 600 == 0)
                    LOG_ERROR("overlay: render init failed (%d) - retrying", fails);
            }
        } else if (sc != g_sc) {
            LOG_INFO("overlay: swapchain changed - reinit");
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            LeaveCriticalSection(&g_renderCs);
        } else if (g_usingD3D12 && g_d12dev && FAILED(g_d12dev->GetDeviceRemovedReason())) {
            // The GPU is gone (TDR/fault): drop everything, forget the game
            // queue (it belongs to the dead device) and reinit next frame.
            // The queue vtable hook stays: the new device shares the vtable.
            LOG_ERROR("overlay: D3D12 device removed (%08X) - tearing down for reinit",
                      (unsigned)g_d12dev->GetDeviceRemovedReason());
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            g_gameQueue = nullptr;
            LeaveCriticalSection(&g_renderCs);
        } else if (!g_renderAborted) {
            // One fused key snapshot per frame, then hotkeys, then the frame.
            static int fno = 0;
            const bool trace = ++fno <= 3;
            if (trace) LOG_INFO("trace: present frame %d begin", fno);
            keys::BeginFrame();
            // Input census (~10 s in): proves which input path is alive.
            static bool s_asyncInsert = false, s_asyncK = false, s_asyncM1 = false;
            s_asyncInsert |= (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
            s_asyncK |= (GetAsyncKeyState('K') & 0x8000) != 0;
            s_asyncM1 |= (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            if ((fno % 1800) == 0) ScanAndHookProcessWindows();  // late-created game windows
            if (fno == 600 || fno == 3600) {
                // fgwnd=0 means the backend's own cursor poll never ran (it
                // requires foreground == its window): our driven pos is the
                // only position source then.
                const int fgUs = (GetForegroundWindow() == g_hwnd) ? 1 : 0;
                LOG_INFO("input census(%d): keydown=%d keyup=%d rawinput=%d rawbtn=%d char=%d mousemove=%d lbtn=%d fgwnd=%d asyncEver(insert=%d k=%d m1=%d)",
                         fno, g_cKeyDown, g_cKeyUp, g_cInput, g_cRawBtn, g_cChar, g_cMouse, g_cBtn, fgUs,
                         s_asyncInsert ? 1 : 0, s_asyncK ? 1 : 0, s_asyncM1 ? 1 : 0);
            }
            // The menu key re-arms only after a release, so holding INSERT
            // (or key auto-repeat) can never strobe the menu. mkDown is
            // sampled BEFORE any Reset() in this frame, or the arm would
            // re-engage instantly and the strobe would survive.
            const bool mkDown = keys::Down((unsigned)g_menuKey);
            if (keys::PressedThisFrame((unsigned)g_menuKey) && g_menuKey > 0 && g_menuKeyArmed) {
                g_showMenu = !g_showMenu;
                g_menuKeyArmed = false;
                keys::Reset();
                LOG_INFO("menu: toggle -> %d", g_showMenu ? 1 : 0);
            } else if (keys::PressedThisFrame(VK_ESCAPE) && g_showMenu) {
                // ESC first dismisses transient UI (field/dropdown/popup/bind),
                // and only closes the menu when nothing is open.
                if (!ui::DismissTopmost()) {
                    g_showMenu = false;
                    LOG_INFO("menu: ESC -> closed");
                }
                keys::Reset();
            }
            if (keys::PressedThisFrame(VK_END) && !g_unloadRequested) {
                g_unloadRequested = true;
                LOG_INFO("overlay: unload requested (END)");
            }
            if (g_showMenu != g_menuWasOpen) {
                g_menuWasOpen = g_showMenu;
                keys::Reset();
            }
            if (!mkDown) g_menuKeyArmed = true;
            // No window handle yet (late window creation): keep probing at ~1 Hz.
            if (!g_hwnd) {
                static int probeTick = 0;
                if (++probeTick % 60 == 1) {
                    HWND t = FindGameWindow();
                    if (t) InstallWndHook(t);
                }
            }

            if (trace) LOG_INFO("trace: hotkeys done");
            if (!g_win32Init && g_hwnd) {
                if (ImGui_ImplWin32_Init(g_hwnd)) {
                    g_win32Init = true;
                    LOG_INFO("overlay: Win32 backend bound to %p", g_hwnd);
                } else {
                    static int w32fails = 0;
                    if (++w32fails == 1 || w32fails % 600 == 0)
                        LOG_ERROR("overlay: Win32 backend init failed (%d) - poll fallback only", w32fails);
                }
            }
            if (trace) LOG_INFO("trace: entering render");
            EnsureCs();
            EnterCriticalSection(&g_renderCs);
            if (InterlockedExchange(&g_inRender, 1) == 0) {
                if (g_usingD3D12) RenderD3D12Frame();
                else RenderD3D11Frame();
                UpdateCursor();
                InterlockedExchange(&g_inRender, 0);
            }
            LeaveCriticalSection(&g_renderCs);
            if (trace) LOG_INFO("trace: render done");
            // Serialized unload: runs on this thread right after the frame,
            // so no other Present can interleave with the teardown.
            if (g_unloadRequested && !g_shuttingDown) FinishUnload();
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        if (!g_init) {
            TeardownRender();
            LOG_ERROR("overlay: exception during init - render keeps retrying");
        } else if (!g_renderAborted) {
            g_renderAborted = true;
            InterlockedExchange(&g_inRender, 0);
            LOG_ERROR("overlay: exception in frame - rendering disabled, game untouched");
        }
    }
#endif
    PresentFn o = (PresentFn)g_oPresent;
    const HRESULT opr = o ? o(sc, sync, flags) : E_FAIL;
    {
        static int pret = 0;
        if (++pret <= 3) {
            EnsureCs();
            EnterCriticalSection(&g_renderCs);
            const HRESULT rem =
                (g_usingD3D12 && g_d12dev) ? g_d12dev->GetDeviceRemovedReason() : S_OK;
            LeaveCriticalSection(&g_renderCs);
            LOG_INFO("trace: present returned %08X removed=%08X", (unsigned)opr, (unsigned)rem);
        }
    }
    return opr;
}

HRESULT __stdcall HkResizeBuffers(IDXGISwapChain* sc, UINT count, UINT w, UINT h,
                                 DXGI_FORMAT fmt, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        if (g_init && sc == g_sc) {
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            g_w = w; g_h = h;
            LeaveCriticalSection(&g_renderCs);
            LOG_INFO("overlay: buffers resized %ux%u - reinit next frame", w, h);
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in ResizeBuffers pre-step");
    }
#endif
    ResizeFn o = (ResizeFn)g_oResize;
    return o ? o(sc, count, w, h, fmt, flags) : E_FAIL;
}

void PatchVTable(void** vtable, int index, void* hook, void** original) {
    DWORD old = 0;
    void** slot = vtable + index;
    *original = *slot;
    VirtualProtect(slot, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
    *slot = hook;
    VirtualProtect(slot, sizeof(void*), old, &old);
}

void RestoreVTable() {
    if (!g_vtable) return;
    DWORD old = 0;
    if (g_oPresent) {
        VirtualProtect(g_vtable + kPresentIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_vtable[kPresentIndex] = g_oPresent;
        VirtualProtect(g_vtable + kPresentIndex, sizeof(void*), old, &old);
    }
    if (g_oResize) {
        VirtualProtect(g_vtable + kResizeIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_vtable[kResizeIndex] = g_oResize;
        VirtualProtect(g_vtable + kResizeIndex, sizeof(void*), old, &old);
    }
    if (g_queueVtable && g_oExec) {
        VirtualProtect(g_queueVtable + kExecIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_queueVtable[kExecIndex] = g_oExec;
        VirtualProtect(g_queueVtable + kExecIndex, sizeof(void*), old, &old);
        g_queueVtable = nullptr;
        g_oExec = nullptr;
    }
    g_vtable = nullptr;
    LOG_INFO("overlay: vtable restored");
}

// ============================ unload ============================
DWORD WINAPI ExitThreadProc(LPVOID) {
    Sleep(400);  // let the in-flight Present return through the restored vtable
    FreeLibraryAndExitThread(g_hmod, 0);
    return 0;
}

void FinishUnload() {
    if (g_shuttingDown) return;
    g_shuttingDown = true;
    g_showMenu = false;
    LOG_INFO("overlay: finishing unload");
    if (g_feedHook || g_cursorHooks) {
        // BEFORE anything else: game threads may call these detours at any
        // moment, and they must never run against torn-down state (or an
        // unloaded DLL). Originals are nulled so later readers (HandleRawInput)
        // fall back to the (now unpatched) direct calls.
        MH_DisableHook(MH_ALL_HOOKS);
        MH_RemoveHook(MH_ALL_HOOKS);
        MH_Uninitialize();
        g_feedHook = false;
        g_oFeed = nullptr;
        g_cursorHooks = false;
        oGetRawInputData = nullptr;
        oGetRawInputBuffer = nullptr;
        oSetCursorPos = nullptr;
        oClipCursor = nullptr;
        oSetCapture = nullptr;
        oShowCursor = nullptr;
        LOG_INFO("overlay: MinHook hooks removed (feed + cursor/raw)");
    }
    ui::Shutdown();          // flush config
    EnterCriticalSection(&g_renderCs);
    TeardownRender();
    if (g_win32Init) { ImGui_ImplWin32_Shutdown(); g_win32Init = false; }
    if (g_imgui) { ImGui::DestroyContext(); g_imgui = false; }
    LeaveCriticalSection(&g_renderCs);
    RestoreWndHook();
    RestoreVTable();
    LOG_INFO("overlay: unloaded cleanly");
    logger::Shutdown();
    HANDLE h = CreateThread(nullptr, 0, ExitThreadProc, nullptr, 0, nullptr);
    if (h) CloseHandle(h);
}

// ============================ startup ============================
struct WindowProbe { int found = 0; DWORD pid = 0; HWND hwnd = nullptr; };

BOOL CALLBACK ProbeWindow(HWND h, LPARAM lp) {
    WindowProbe* pr = (WindowProbe*)lp;
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid != pr->pid || !IsWindowVisible(h)) return TRUE;
    RECT rc{};
    if (!GetWindowRect(h, &rc)) return TRUE;
    if (rc.right - rc.left < 200 || rc.bottom - rc.top < 200) return TRUE;
    char cls[64] = {};
    GetClassNameA(h, cls, sizeof(cls));
    if (std::strcmp(cls, "ConsoleWindowClass") == 0) return TRUE;
    pr->found++;
    pr->hwnd = h;
    return FALSE;  // one is enough
}

bool GameWindowExists() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.found > 0;
}

// Same criteria, but returns the handle (for the input hook + Win32 backend).
HWND FindGameWindow() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.hwnd;
}

bool CreateDummySwapchain(void*** vtableOut) {
    WNDCLASSA wc{};
    wc.lpfnWndProc = DefWindowProcA;
    wc.hInstance = g_hmod;
    wc.lpszClassName = "NightfullDummy";
    RegisterClassA(&wc);
    HWND wnd = CreateWindowExA(WS_EX_TOOLWINDOW, "NightfullDummy", "nf",
                               WS_POPUP, 0, 0, 64, 64, nullptr, nullptr, g_hmod, nullptr);
    if (!wnd) return false;

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = wnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* sc = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    const D3D_FEATURE_LEVEL lvl[] = { D3D_FEATURE_LEVEL_11_0 };
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        lvl, 1, D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
    bool ok = false;
    if (SUCCEEDED(hr) && sc) {
        *vtableOut = *(void***)sc;
        ok = true;
    }
    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (sc) sc->Release();
    DestroyWindow(wnd);
    UnregisterClassA("NightfullDummy", g_hmod);
    return ok;
}

} // namespace

void MainThread(HMODULE hModule) {
#ifdef _MSC_VER
    __try {
#endif
        g_hmod = hModule;
        EnsureCs();

        GetModuleFileNameW(hModule, g_dllDir, MAX_PATH);
        wchar_t* slash = wcsrchr(g_dllDir, L'\\');
        if (slash) *slash = 0;

        if (!config::Init(g_dllDir)) {
            // Without a config dir we still run (defaults); logging goes to debugger only.
        }
        wchar_t logPath[MAX_PATH] = {};
        _snwprintf_s(logPath, _TRUNCATE, L"%s\\nightfull.log", config::baseDir().c_str());
        logger::Init(config::baseDir().empty() ? nullptr : logPath);
        LOG_INFO("overlay: worker started, pid=%lu", GetCurrentProcessId());
        LOG_INFO("overlay: build tag dx12i-suball");
        if (!logger::IsFileActive()) {
            // Nothing reaches any file: pop a box, or the failure stays
            // invisible (debugger-only logging helps no one here).
            wchar_t wmsg[512] = {};
            _snwprintf_s(wmsg, _TRUNCATE,
                         L"Nightfull loaded but cannot write its log file.\nLog path: %s\n"
                         L"(Check the folder is writable, and kill zombie game processes.)",
                         config::baseDir().empty() ? L"<no config dir>" : logPath);
            MessageBoxW(nullptr, wmsg, L"Nightfull", MB_OK | MB_ICONERROR | MB_TOPMOST);
        } else {
            char narrow[MAX_PATH] = {};
            WideCharToMultiByte(CP_UTF8, 0, logPath, -1, narrow, (int)sizeof(narrow),
                                nullptr, nullptr);
            LOG_INFO("overlay: log at %s", narrow);
        }

        // Wait until the game owns a real window: creating devices earlier
        // destabilizes engine startup on some builds.
        while (!g_abort && !GameWindowExists()) Sleep(250);
        if (g_abort) return;
        LOG_INFO("overlay: game window detected");

        void** vtable = nullptr;
        int attempts = 0;
        while (!g_abort && !CreateDummySwapchain(&vtable)) {
            if (++attempts % 20 == 1)
                LOG_INFO("overlay: waiting for DXGI (%d)", attempts);
            Sleep(500);
        }
        if (g_abort || !vtable) {
            LOG_ERROR("overlay: dummy swapchain failed - aborting");
            return;
        }
        g_vtable = vtable;
        PatchVTable(vtable, kPresentIndex, (void*)HkPresent, &g_oPresent);
        PatchVTable(vtable, kResizeIndex, (void*)HkResizeBuffers, &g_oResize);
        LOG_INFO("overlay: hooks live (present=%p resize=%p)", g_oPresent, g_oResize);

        // The worker's job is done; everything else runs on hooked threads
        // (unload is serialized in the HkPresent tail). Just park here so an
        // abort during startup can still be observed.
        while (!g_abort) Sleep(500);
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: fatal exception in worker thread");
    }
#endif
}

void NotifyDetach() {
    g_abort = true;
    g_shuttingDown = true;
    g_showMenu = false;
    // Best effort, never blocking: the process is going away.
    RestoreWndHook();
    if (g_csInit) {
        if (TryEnterCriticalSection(&g_renderCs)) {
            TeardownRender();
            LeaveCriticalSection(&g_renderCs);
        }
    }
    RestoreVTable();
}

} // namespace overlay
} // namespace nf
