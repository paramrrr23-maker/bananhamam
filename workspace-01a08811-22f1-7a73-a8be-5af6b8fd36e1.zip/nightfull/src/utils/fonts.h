// fonts.h - font roles loaded from the fonts/ folder next to the DLL.
//
// Roles: UI (Manrope Regular), UISemi (Manrope SemiBold), Bold (Manrope
// Bold), Title (Space Grotesk Bold merged with Manrope Bold so Cyrillic
// falls back cleanly - Space Grotesk has no Cyrillic), Mono
// (JetBrainsMono, values/paths), Icon (Lucide PUA glyphs). Text roles
// rasterize Latin + Cyrillic. Every role falls back to the ImGui default
// font when its file is missing; text roles first try the Windows system
// font (always Cyrillic-capable), so a missing fonts/ folder degrades to
// readable text instead of ???. Icon has no fallback and is skipped.

#pragma once

struct ImFont;

namespace nf {
namespace fonts {

bool Init(const wchar_t* dllDir);  // loads fonts/<role>.ttf; true when all found
void Shutdown();                   // nothing cached outside the atlas; kept for symmetry

ImFont* UI();
ImFont* UISemi();
ImFont* Bold();
ImFont* Title();
ImFont* Mono();
ImFont* Icon();
ImFont* Current();                 // default HUD/menu font (= UI)

} // namespace fonts
} // namespace nf
