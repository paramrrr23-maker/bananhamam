#pragma once
#include <cmath>
#include <cstdint>

// Worker-only state. These are observed client attributes, NOT authoritative
// server damage or attribution to the local player. No fabricated per-hit HP.
namespace nf::target_health {
constexpr std::uint64_t kFreshMs = 250;
constexpr std::uint64_t kHurtGraceMs = 750;
inline bool validPair(float hp, float maxHp) {
    return std::isfinite(hp) && std::isfinite(maxHp) &&
        maxHp > 0.0f && maxHp <= 4096.0f && hp >= 0.0f && hp <= maxHp;
}
inline bool fresh(std::uint64_t now, std::uint64_t at) {
    return at != 0 && now >= at && now - at <= kFreshMs;
}
struct State {
    bool have = false, trusted = false, healthValid = false, pendingHurt = false;
    float hp = 0.0f, maxHp = 0.0f, lost = 0.0f, lastLoss = 0.0f;
    double totalLoss = 0.0;
    std::uint64_t at = 0, hurtAt = 0, lossAt = 0, lossGen = 0;

    void reset() { *this = State{}; }
    void sample(std::uint64_t now, bool ok, float cur, float mx, bool hurtEdge) {
        lost = 0.0f;
        if (!ok || !validPair(cur, mx)) {
            have = trusted = healthValid = pendingHurt = false;
            at = 0;
            return;
        }
        const bool continuous = have && fresh(now, at);
        const bool comparable = continuous && healthValid;
        const bool maxChanged = continuous && mx != maxHp;
        const bool changed = continuous && (cur != hp || maxChanged);
        if (!continuous) {
            // A constant full-health value is indistinguishable from a default
            // remote attribute. Show '?' until a non-full value or change.
            trusted = cur < mx;
            pendingHurt = false;
        } else if (changed) {
            trusted = true;
            pendingHurt = false;
            // Max-health changes can clamp HP; do not count them as damage.
            if (comparable && !maxChanged && cur < hp) {
                lost = hp - cur;
                lastLoss = lost;
                totalLoss += lost;
                lossAt = now;
                ++lossGen;
            }
        }
        // Hurt animation can arrive before the attribute. Repeated edges must
        // not postpone the first deadline forever on an unsynchronised server.
        if (hurtEdge && !changed && !pendingHurt) {
            pendingHurt = true;
            hurtAt = now;
        }
        if (pendingHurt && now >= hurtAt && now - hurtAt >= kHurtGraceMs)
            trusted = false;
        have = true;
        hp = cur; maxHp = mx; at = now;
        healthValid = trusted;
    }
};
// Render consumption: cumulative loss preserves multiple worker changes
// between frames without replaying the same event on subsequent frames.
inline float consumeLoss(double total, double& seen, bool recent) {
    const double delta = total - seen;
    seen = total;
    return recent && std::isfinite(delta) && delta > 0.0 && delta <= 24576.0
        ? static_cast<float>(delta) : 0.0f;
}
} // namespace nf::target_health
