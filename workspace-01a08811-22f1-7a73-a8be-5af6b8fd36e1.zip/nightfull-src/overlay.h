// overlay.h - public interface of the overlay engine.
//
// The engine (overlay.cpp) owns:
//   - finding the game windows and installing the DXGI/D3D12 vtable hooks,
//   - D3D11 + D3D12 rendering of the ImGui frame,
//   - manual mouse/keyboard input polling (UWP never sends WM_* mouse msgs),
//   - SEH-protected init/render and a clean safe-unload path.
//
// The UI (ui/clickgui.cpp) only reads state exposed here and draws widgets.
//
// NOTE: ASCII only in this file.

#pragma once

#include <Windows.h>

namespace overlay {

// --- shared state (read by the UI) ---
extern bool  g_ShowMenu;      // whether the ClickGUI window is visible
extern int   g_clickCount;    // clicks captured by manual polling
extern bool  g_RenderD3D12;   // which renderer is active (true = D3D12)

// --- render-thread progress markers (written by the UI, read by the
// --- watchdog thread) -----------------------------------------------------
// Every module callback runs ON THE GAME'S RENDER THREAD inside hkPresent.
// These two pointers name what that thread is doing right now, so the
// watchdog can log the exact module/phase when the frame stops - instead of
// leaving you with a frozen machine and no clue which module did it.
extern const char* volatile g_activeModuleName;
extern const char* volatile g_activePhase;

// --- lifecycle ---
void MainThread(HMODULE hModule);   // injector thread entry (DllMain spawns it)
void OverlayShutdown();             // full teardown (backends + D3D objects)
void RequestUnload();               // set flag: unhook+shutdown after this frame
void NotifyDetach();                // called from DllMain on DLL_PROCESS_DETACH

// --- per-frame ---
void UpdateInputState();            // poll mouse + hotkeys, feed ImGui IO

// --- keyboard polling (used by the ClickGUI to bind a module to a key) ---
// GetAsyncKeyState is unreliable inside the UWP/AppContainer game process, so
// the overlay polls key state itself; this is that poll exposed to the UI.
bool IsKeyDown(int vk);

// Inject a synthetic key event into the game's own Keyboard::feed detour
// (the same path the AutoSprint module uses). Returns false when the feed
// hook is not active - callers must degrade gracefully (e.g. Text Hotkey).
bool InjectGameKey(int vk, bool down);

// Flarial-style chat send: craft a TextPacket (CHAT, id 9) and push it
// through the game's own LoopbackPacketSender::sendToServer. No chat UI
// involved - the message simply appears in chat. Returns false when the
// game's packet machinery is unavailable (signature/offset mismatch).
bool SendChatText(const char* message);

// Real average ping (ms) captured by the RakPeer::GetAveragePing hook;
// negative until the game reports a value.
extern volatile LONG g_pingMs;

// True while a chat / text-input screen owns the keyboard (published from
// the game's own getScreenName). Global hotkeys and keybinds stay off.
bool IsChatOpen();

// True while the player is inside a world/server (hud_screen, or the local
// player exists when the screen name is unavailable). HUD plates such as
// Potions / Keybinds render only in this state - never in Minecraft's menus.
bool IsInWorld();

// True while the system cursor is visible: the game hides it in-world and
// shows it for every UI screen - a version-independent "screen is up" hint.
bool IsCursorVisible();

// Active mob effects of the local player (Potions HUD). Returns the count
// filled into `out` (0 when unavailable - no player / no component).
struct PotionEffect {
    unsigned int id;         // MobEffect::EffectType
    int duration;            // remaining ticks (20 == 1 s)
    int amplifier;           // 0-based level
    bool noCounter;          // infinite duration
};
int GetPotionEffects(PotionEffect* out, int maxOut);

// Clear every captured keyboard mirror (the watcher's 256-bit state and the
// in-process Keyboard::feed state). Call this when the menu opens/closes:
// those mirrors are only fed while the menu is open, so a stale snapshot left
// over from the previous session would otherwise be read as "held" on the
// first frame of the next one and produce phantom key presses.
void ResetKeyMirrors();

// --- abort flag for the injector thread ---
extern volatile LONG g_SharedAbort;

// --- game-hook shared state (written by the Flarial-port hooks) ---
// BedrockTextureData* of "textures/ui/selected_hotbar_slot" (Animations).
extern void* g_hotbarTextureData;
// Last attack reach in blocks (Reach Display); g_lastHitTickMs is the tick
// count of the attack, g_lastHitValid != 0 once something was hit.
extern float          g_lastHitDistance;
extern unsigned long  g_lastHitTickMs;
extern volatile LONG  g_lastHitValid;

// Crit Particles: the GameMode::attack hook stamps every landed hit here;
// the CritParticles module renders a SystemDLC-style burst off these.
extern volatile LONG  g_critBurstStartMs;
extern volatile LONG  g_critBurstSeed;

// --- Crit Particles (SystemDLC TargetESP-style): entity-centered bursts ----
// The attack hook pushes one burst per landed crit (falling hit, respecting
// the 500 ms damage-immunity window per entity); the module renders the
// shapes around `pos` projected through the game's view matrix.
constexpr int kMaxCritBursts = 12;
struct CritBurst {
    float         pos[3];      // world-space burst center (the hit point)
    unsigned int  entityKey;   // hit-result entity id (damage-window key)
    unsigned int  seed;        // per-burst variation
    unsigned long startMs;     // GetTickCount() of the hit
};
extern CritBurst        g_critBursts[kMaxCritBursts];
extern volatile LONG    g_critBurstHead;   // next write slot (ring buffer)
extern volatile LONG    g_critBurstTick;   // bumped on every push

// Push a burst (called from the GameMode::attack hook on the game thread).
void PushCritBurst(const float pos[3], unsigned int entityKey, unsigned int seed);

// Per-frame camera upkeep for the burst projection (eye-position history for
// the crit check + world->screen matrix discovery). Called from the render
// thread by the CritParticles module.
void UpdateCritCamera();

// Project a world-space point to overlay pixels. False when no view matrix
// has been captured yet or the point is behind the camera. `outDepth` (when
// non-null) receives the view-space forward distance in blocks - the module
// uses it for perspective dot sizing.
bool ProjectWorldToScreen(const float pos[3], float* outX, float* outY,
                          float* outDepth = nullptr);

// Pixels per world block at depth 1 (h/2 / tan(fov/2)) - multiply by a
// world-space size and divide by depth for perspective-correct radii.
float GetCritFocalPx();

// --- Monitoring HUD shared state -------------------------------------------
// Ticks of the LOCAL player per second (Actor::baseTick hook); TPS readout.
extern volatile LONG g_monitorTickCounter;
// Lazily installs the baseTick hook (once; no-op after a failed signature).
void TryInstallBaseTickHook();
// Joined server IP via the RaknetConnector chain; false when not on a server
// (local worlds / menus). outLen must be >= 65.
bool GetServerIpString(char* out, unsigned outLen);
// Local player feet position + velocity via the entt state-vector component.
// False when the player or the component is unavailable.
bool GetLocalPlayerState(float pos[3], float vel[3]);

// --- Target HUD shared state (written by the GameMode::attack hook) ---------
// The last attacked entity and when it was hit; the Target HUD plate fades in
// on an attack and fades out ~2.5 s after the last one.
extern volatile void* g_targetActor;
extern volatile LONG  g_targetTickMs;
// The entity currently under the crosshair (projection-based aim detection;
// null when none / the view matrix is not captured yet).
void* GetCrosshairEntity();

// Recently ticked actors EXCLUDING the local player (Hitboxes ESP and friends).
// Returns the count filled into `out`.
int GetActors(void** out, int maxOut);

// --- damage events ----------------------------------------------------------
// Pushed by the attack hook when the target actually LOST hp (respecting the
// invulnerability window); the Target HUD renders numbers + particles.
struct DamageEvent {
    void*         actor;    // the entity that lost hp
    unsigned long ms;       // GetTickCount() of the damage
    float         amount;   // hp lost
};
constexpr int kMaxDamageEvents = 8;
extern DamageEvent    g_damageEvents[kMaxDamageEvents];   // ring buffer
extern volatile LONG  g_damageHead;                       // total pushes

} // namespace overlay
