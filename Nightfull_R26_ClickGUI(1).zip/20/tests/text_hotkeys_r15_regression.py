"""Production-code regression harness with inline C++ test doubles.

Requires Python 3 and g++ (C++20/ASan/UBSan). This is not a Windows/game test.
The embedded Python/C++ payload below uses '+'-prefixed source lines.
"""

_PAYLOAD = r"""
+from pathlib import Path
+import os
+import subprocess
+import tempfile
+
+ROOT = Path(__file__).resolve().parents[1]
+source = (ROOT / "src/overlay/overlay.cpp").read_text(encoding="utf-8")
+begin = source.index("// ==================== TextPacket chat send")
+end = source.index("#endif // _MSC_VER: native packet chat helpers", begin)
+helpers = source[begin:end] + "#endif\n"
+begin_send = source.index("bool SendChatText(const char* text) {")
+end_send = source.index("\nvoid TryInstallBaseTickHook()", begin_send)
+send = source[begin_send:end_send]
+assert "NF_GUI_TRY" not in helpers + send
+assert "PacketShared" not in helpers + send
+assert "PostMessage" not in send and "SendInput" not in send
+assert "0x1C8, 0x1D0" not in helpers
+
+# Only platform substitutions; function bodies are extracted on every run.
+code = (helpers + send).replace("#ifdef _MSC_VER", "#if 1")
+code = code.replace("std::string", "MockString")
+code = code.replace("__try", "try")
+code = code.replace(
+    "__except (GetExceptionCode() == 0xE06D7363u\n"
+    "                    ? EXCEPTION_CONTINUE_SEARCH : EXCEPTION_EXECUTE_HANDLER)",
+    "catch (const NativeFault&)")
+
+PRELUDE = r'''
+#include <algorithm>
+#include <cassert>
+#include <cstddef>
+#include <cstdint>
+#include <cstdio>
+#include <cstring>
+#include <exception>
+#include <iostream>
+#include <memory>
+#include <new>
+#include <set>
+#include <string>
+#include <vector>
+#define __fastcall
+#define __declspec(x)
+#define _ITERATOR_DEBUG_LEVEL 0
+#define LOG_INFO(...) ((void)0)
+using ULONGLONG = unsigned long long;
+using SRWLOCK = bool;
+#define SRWLOCK_INIT false
+bool TryAcquireSRWLockExclusive(SRWLOCK* p) {
+    if (*p) return false;
+    *p = true; return true;
+}
+void ReleaseSRWLockExclusive(SRWLOCK* p) { *p = false; }
+struct NativeFault {};
+struct Region { uintptr_t start; size_t size; };
+std::vector<Region> regions;
+void registerRegion(void* p, size_t n) {
+    regions.push_back({reinterpret_cast<uintptr_t>(p), n});
+}
+void unregisterRegion(void* p) {
+    auto b = reinterpret_cast<uintptr_t>(p);
+    std::erase_if(regions, [b](Region r) { return r.start == b; });
+}
+bool PotionReadBytes(const void* p, void* out, size_t n) {
+    if (!p || !out || !n) return false;
+    auto b = reinterpret_cast<uintptr_t>(p);
+    for (const auto& r : regions)
+        if (b >= r.start && b - r.start <= r.size &&
+            n <= r.size - (b - r.start)) {
+            std::memcpy(out, p, n); return true;
+        }
+    return false;
+}
+bool failAssign = false;
+// Explicit MSVC string memory model, not libstdc++'s incompatible SSO.
+struct MockString {
+    union Storage { char local[16]; char* heap; Storage() : local{} {} } data;
+    size_t size = 0, capacity = 15;
+    ~MockString() {
+        if (capacity > 15) { unregisterRegion(data.heap); delete[] data.heap; }
+    }
+    MockString() = default;
+    MockString(const MockString&) = delete;
+    const char* c_str() const { return capacity == 15 ? data.local : data.heap; }
+    void assign(const char* s) { assign(s, std::strlen(s)); }
+    void assign(const char* s, size_t n) {
+        if (failAssign) throw std::bad_alloc();
+        if (n > capacity) {
+            auto* p = new char[n + 1];
+            registerRegion(p, n + 1);
+            if (capacity > 15) { unregisterRegion(data.heap); delete[] data.heap; }
+            data.heap = p; capacity = n;
+        }
+        char* dst = capacity == 15 ? data.local : data.heap;
+        std::memcpy(dst, s, n); dst[n] = 0; size = n;
+    }
+    void clear() { assign("", 0); }
+};
+static_assert(sizeof(MockString) == 32);
+ULONGLONG clockMs = 10000;
+ULONGLONG GetTickCount64() { return clockMs; }
+int gamePatch = 111, scanMatches = 1, scanCalls = 0;
+bool codeReadable = true, codeExecutable = true, imageCached = false;
+bool gameplay = true, focused = true, uiOwned = false, g_shuttingDown = false;
+bool nullFactory = false, nativeFactoryFault = false, nativeSendFault = false;
+bool badLayout = false, cppFactoryFault = false, changeWorld = false;
+int packetId = 9, created = 0, destroyed = 0, sent = 0;
+void* g_clientInstance = nullptr;
+void* localPlayer = nullptr;
+std::string deliveredText, deliveredAuthor, scannedSig;
+int JavaGamePatch() { return gamePatch; }
+void CacheGuiGameImage() { imageCached = true; }
+bool IsGameplayScreen() { return gameplay; }
+bool GameWindowFocused() { return focused; }
+bool UiInputOwned() { return uiOwned; }
+bool PotionReadLocalPlayer(void*& out) { out = localPlayer; return out != nullptr; }
+void* GetModuleHandleW(std::nullptr_t) { return reinterpret_cast<void*>(1); }
+std::set<uintptr_t> codeAddresses;
+bool JavaIsGameCodeAddress(uintptr_t p) {
+    return imageCached && codeReadable && codeAddresses.contains(p);
+}
+bool PotionExecutableAddress(uintptr_t p) {
+    return codeExecutable && codeAddresses.contains(p);
+}
+std::shared_ptr<void> fakeCreate(int);
+int ScanSigMatches(void*, const char* sig, uintptr_t& first) {
+    ++scanCalls; scannedSig = sig;
+    first = scanMatches ? reinterpret_cast<uintptr_t>(&fakeCreate) : 0;
+    return scanMatches;
+}
+'''
+
+TESTS = r'''
+struct MockPacket {
+    uintptr_t* vt = nullptr;
+    unsigned char prefix[0x30 - sizeof(void*)] = {};
+    int8_t type = 0;
+    unsigned char pad1[7] = {};
+    MockString name, message;
+    unsigned char middle[0xB8 - 0x78] = {};
+    bool translation = true;
+    unsigned char pad2[7] = {};
+    MockString xuid, platform;
+};
+static_assert(sizeof(MockPacket) == 0x100);
+static_assert(offsetof(MockPacket, name) == 0x38);
+static_assert(offsetof(MockPacket, message) == 0x58);
+static_assert(offsetof(MockPacket, translation) == 0xB8);
+static_assert(offsetof(MockPacket, xuid) == 0xC0);
+static_assert(offsetof(MockPacket, platform) == 0xE0);
+struct MockPlayer { unsigned char pad[0xC18] = {}; MockString name; } player;
+alignas(8) unsigned char client[0x300] = {};
+uintptr_t packetVt[2] = {}, senderVt[3] = {}, senderObject[1] = {};
+int fakeId(void*) { return packetId; }
+void fakeSend(void* s, void* p) {
+    assert(s == senderObject);
+    if (nativeSendFault) throw NativeFault{};
+    auto* packet = static_cast<MockPacket*>(p);
+    assert(packet->type == 1 && !packet->translation);
+    assert(packet->xuid.size == 0 && packet->platform.size == 0);
+    deliveredText = packet->message.c_str();
+    deliveredAuthor = packet->name.c_str();
+    ++sent;
+}
+std::shared_ptr<void> fakeCreate(int id) {
+    assert(id == 9);
+    if (nativeFactoryFault) throw NativeFault{};
+    if (cppFactoryFault) throw std::bad_alloc();
+    if (nullFactory) return {};
+    auto* p = new MockPacket;
+    p->vt = packetVt;
+    if (badLayout) p->xuid.assign("not empty");
+    registerRegion(p, sizeof(*p));
+    ++created;
+    if (changeWorld) localPlayer = nullptr;
+    return std::shared_ptr<void>(p, [](void* obj) {
+        unregisterRegion(obj);
+        delete static_cast<MockPacket*>(obj);
+        ++destroyed;
+    });
+}
+void putSender(size_t offset, void* value) {
+    std::memcpy(client + offset, &value, sizeof(value));
+}
+void reset() {
+    g_createPacket = nullptr; g_packetChatRetryAt = 0;
+    g_packetChatNextSendAt = 0; g_packetChatFaulted = false;
+    assert(!g_packetChatLock);
+    clockMs += 10000;
+    gamePatch = 111; scanMatches = 1; scanCalls = 0;
+    codeReadable = codeExecutable = true; imageCached = false;
+    gameplay = focused = true; uiOwned = g_shuttingDown = false;
+    nullFactory = nativeFactoryFault = nativeSendFault = false;
+    badLayout = cppFactoryFault = changeWorld = failAssign = false;
+    packetId = 9; created = destroyed = sent = 0;
+    g_clientInstance = client; localPlayer = &player;
+    player.name.assign("Player");
+    std::memset(client, 0, sizeof(client));
+    putSender(0xF8, senderObject);
+}
+int checks = 0;
+void check(bool value, const char* label) {
+    if (!value) { std::cerr << "FAIL: " << label << '\n'; std::exit(1); }
+    ++checks; std::cout << "PASS: " << label << '\n';
+}
+int main() {
+    registerRegion(client, sizeof(client)); registerRegion(&player, sizeof(player));
+    registerRegion(packetVt, sizeof(packetVt));
+    registerRegion(senderVt, sizeof(senderVt));
+    registerRegion(senderObject, sizeof(senderObject));
+    packetVt[1] = reinterpret_cast<uintptr_t>(&fakeId);
+    senderVt[2] = reinterpret_cast<uintptr_t>(&fakeSend);
+    senderObject[0] = reinterpret_cast<uintptr_t>(senderVt);
+    codeAddresses = {reinterpret_cast<uintptr_t>(&fakeId),
+                     reinterpret_cast<uintptr_t>(&fakeSend),
+                     reinterpret_cast<uintptr_t>(&fakeCreate)};
+
+    reset();
+    check(SendChatText("hello") && sent == 1 && deliveredText == "hello" &&
+          deliveredAuthor == "Player", "normal message through TextPacket");
+    check(created == destroyed && created == 1 && !g_packetChatLock,
+          "shared packet released and lock unlocked after success");
+    check(scannedSig ==
+          "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 60 "
+          "48 8B 05 ?? ?? ?? ?? 48 33 C4 48 89 44 24 58 48 8B F9 48 89 4C 24 38",
+          "exact Flarial 1.21.11X signature");
+    clockMs += 2499;
+    check(!SendChatText("too soon") && sent == 1, "2.5s shared cooldown");
+    ++clockMs;
+    check(SendChatText("again") && sent == 2 && scanCalls == 1,
+          "cooldown boundary and cached factory");
+
+    reset(); std::string unicode = "\xD0\x9F\xD1\x80\xD0\xB8\xD0\xB2\xD0\xB5\xD1\x82";
+    check(SendChatText(unicode.c_str()) && deliveredText == unicode, "UTF-8 retained");
+    reset(); std::string longText(400, 'x');
+    check(SendChatText(longText.c_str()) && deliveredText == longText &&
+          created == destroyed, "400-byte message with heap storage");
+    reset(); longText.push_back('x');
+    check(!SendChatText(longText.c_str()) && created == 0, "oversize rejected");
+    reset(); check(!SendChatText(nullptr) && !SendChatText("") && scanCalls == 0,
+                   "empty input rejected");
+
+    reset(); scanMatches = 0;
+    check(!SendChatText("x") && scanCalls == 1, "missing signature rejected");
+    scanMatches = 1; clockMs += 4999;
+    check(!SendChatText("x") && scanCalls == 1, "failed scan is rate limited");
+    ++clockMs;
+    check(SendChatText("x") && scanCalls == 2, "missing signature is not latched forever");
+    reset(); scanMatches = 2;
+    check(!SendChatText("x") && created == 0, "ambiguous signature rejected");
+    reset(); codeReadable = false;
+    check(!SendChatText("x") && created == 0, "non-game code rejected");
+    reset(); codeExecutable = false;
+    check(!SendChatText("x") && created == 0, "non-executable factory rejected");
+    for (int patch : {0, 100, 120, 130}) {
+        reset(); gamePatch = patch;
+        check(!SendChatText("x") && scanCalls == 0, "unsupported patch rejected before scan");
+    }
+
+    reset(); putSender(0xF8, nullptr); putSender(0x1C8, senderObject);
+    check(!SendChatText("x") && created == 0, "no guessed 1.21.130 sender fallback");
+    putSender(0xF8, senderObject);
+    check(SendChatText("x") && scanCalls == 1, "sender recovers on next press");
+    reset(); g_clientInstance = nullptr;
+    check(!SendChatText("x"), "no client");
+    g_clientInstance = client;
+    check(SendChatText("x"), "client recovery");
+    reset(); localPlayer = nullptr;
+    check(!SendChatText("x"), "no local player");
+    localPlayer = &player;
+    check(SendChatText("x"), "world join recovery");
+
+    reset(); char name[256] = {};
+    check(ChatReadPlayerName(&player, name, sizeof(name)) &&
+          std::strcmp(name, "Player") == 0, "SSO player name");
+    player.name.assign("A_very_long_player_name_with_heap_storage");
+    player.name.assign("Bob");
+    check(ChatReadPlayerName(&player, name, sizeof(name)) &&
+          std::strcmp(name, "Bob") == 0, "short heap-backed name uses capacity");
+    check(!ChatReadPlayerName(&player, name, 3), "player name buffer bound");
+    player.name.assign("bad\nname");
+    check(!ChatReadPlayerName(&player, name, sizeof(name)), "control bytes rejected");
+
+    reset(); packetId = 10;
+    check(!SendChatText("x") && sent == 0 && created == destroyed, "wrong packet ID released");
+    reset(); badLayout = true;
+    check(!SendChatText("x") && sent == 0 && created == destroyed, "wrong layout released");
+    reset(); nullFactory = true;
+    check(!SendChatText("x") && !g_packetChatFaulted, "empty factory result not a permanent fault");
+    nullFactory = false;
+    check(SendChatText("x"), "empty factory result recovery");
+    reset(); cppFactoryFault = true;
+    check(!SendChatText("x") && !g_packetChatLock && !g_packetChatFaulted,
+          "C++ allocation exception unwinds normally");
+    reset(); failAssign = true;
+    check(!SendChatText("x") && created == destroyed && !g_packetChatLock,
+          "assignment exception releases packet");
+    failAssign = false;
+    reset(); nativeFactoryFault = true;
+    check(!SendChatText("x") && g_packetChatFaulted, "modelled native factory fault disables");
+    nativeFactoryFault = false;
+    check(!SendChatText("x"), "native fault is not repeatedly retried");
+    reset(); nativeSendFault = true;
+    check(!SendChatText("x") && g_packetChatFaulted && created == destroyed,
+          "modelled native send fault releases packet");
+    reset(); changeWorld = true;
+    check(!SendChatText("x") && sent == 0 && created == destroyed,
+          "world change before send cancels cleanly");
+
+    reset(); gameplay = false; check(!SendChatText("x"), "non-gameplay screen gate");
+    reset(); focused = false; check(!SendChatText("x"), "focus gate");
+    reset(); uiOwned = true; check(!SendChatText("x"), "menu gate");
+    reset(); g_shuttingDown = true; check(!SendChatText("x"), "unload gate");
+    reset(); g_packetChatLock = true; check(!SendChatText("x"), "concurrent call rejected");
+    g_packetChatLock = false;
+    check(regions.size() == 6, "no packet or message allocation regions leaked");
+    std::cout << checks << " checks passed (test doubles; not Windows/game verification)\n";
+}
+'''
+
+with tempfile.TemporaryDirectory(prefix="nightfull-chat-test-") as tmp:
+    path = Path(tmp)
+    cpp = path / "chat_test.cpp"
+    exe = path / "chat_test"
+    cpp.write_text(PRELUDE + code + TESTS, encoding="utf-8")
+    cmd = [os.environ.get("CXX", "g++"), "-std=c++20", "-Wall", "-Wextra",
+           "-Werror", "-O1", "-g", "-fsanitize=address,undefined",
+           "-fno-omit-frame-pointer", str(cpp), "-o", str(exe)]
+    subprocess.run(cmd, check=True)
+    subprocess.run([str(exe)], check=True)
"""
exec(compile("\n".join(line[1:] if line.startswith("+") else line
                       for line in _PAYLOAD.splitlines()), __file__, "exec"))
