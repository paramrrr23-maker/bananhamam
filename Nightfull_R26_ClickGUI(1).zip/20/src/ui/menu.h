// menu.h - the Nightfull ClickGUI (single polished renderer).
//
// Layout: SystemDLC-inspired light/dark shell — category sidebar, top search,
// three independently scrolling columns of real module settings, favorites,
// configuration profiles and the existing HUD/theme/cursor controls.
// UI is native ImGui; no embedded browser or HTML runtime.

#pragma once

namespace nf {

class Module;   // core/module.h

namespace ui {

// Register modules + load config + reset state (once, after ImGui context).
bool Init();
// Flush config (unload path).
void Shutdown();

// Full per-frame UI pass. Runs inside the ImGui frame: pushes the theme,
// dispatches keybinds, ticks+renders modules (HUD), autosaves the config
// and draws the menu while it is open or fading.
void Frame();

// Dismiss the topmost transient UI (text field, dropdown, popup, bind
// capture). Returns true when something was dismissed (ESC handling).
bool DismissTopmost();

// True while a text field or a key-capture button owns the keyboard. The
// overlay must not treat the menu key as "toggle menu" during that time.
bool KeyboardCaptured();

// Bottom-left notification ("[Nightfull] ...").
void Toast(const char* fmt, ...);

// Open the ClickGUI on a module's settings page (HUD editor right-click
// parity): selects the module, shows the inspector and raises the menu.
void OpenModuleSettings(Module* m);

} // namespace ui
} // namespace nf
