// module_guard.cpp - crash- and hang-contained module callback invoker.

#include "core/module_guard.h"

#include <Windows.h>

#include "core/module.h"
#include "utils/logger.h"

namespace nf {

const char* g_activeModule = nullptr;
const char* g_activePhase = nullptr;

const char* ModulePhaseGuard::phaseName(Phase phase) {
    switch (phase) {
        case Phase::Enable:  return "enable";
        case Phase::Disable: return "disable";
        case Phase::Tick:    return "tick";
        case Phase::Render:  return "render";
        default:             return "?";
    }
}

void ModulePhaseGuard::run(Module* m, Phase phase) {
    if (!m) return;
    const char* pname = phaseName(phase);
    g_activeModule = m->name();
    g_activePhase = pname;

    LARGE_INTEGER freq{}, t0{}, t1{};
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t0);

#ifdef _MSC_VER
    __try {
#endif
        switch (phase) {
            case Phase::Enable:  m->onEnable();  break;
            case Phase::Disable: m->onDisable(); break;
            case Phase::Tick:    m->onTick();    break;
            case Phase::Render:  m->onRender();  break;
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("guard: fault in %s::%s - module auto-disabled", m->name(), pname);
        m->setEnabled(false);
        g_activeModule = nullptr;
        g_activePhase = nullptr;
        return;
    }
#endif

    QueryPerformanceCounter(&t1);
    if (freq.QuadPart > 0) {
        const double ms = (double)(t1.QuadPart - t0.QuadPart) * 1000.0 / (double)freq.QuadPart;
        if (ms > 100.0) {
            LOG_ERROR("guard: %s::%s took %.1f ms - module auto-disabled", m->name(), pname, ms);
            m->setEnabled(false);
        } else if (ms > 5.0) {
            LOG_INFO("guard: %s::%s slow (%.1f ms)", m->name(), pname, ms);
        }
    }
    g_activeModule = nullptr;
    g_activePhase = nullptr;
}

} // namespace nf
