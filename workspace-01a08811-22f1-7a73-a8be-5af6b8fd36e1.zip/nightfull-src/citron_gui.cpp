// citron_gui.cpp - the Nightfull menu (SystemDLC-style ClickGUI port).
//
// Visual port of CollapseLoader/SystemDLC's ClickGuiScreen (client/gui):
//   window        - 1188x700 pt design, radius 12, background fill + 1pt
//                   border, opens with a 0.93 -> 1.0 scale + 18pt drop
//   sidebar       - 224 pt surface panel (collapses to 48), 48 pt logo row,
//                   section labels, 32 pt category tabs (radius 8, elevated
//                   fill when active/hover), server card at the bottom
//   top bar       - 48 pt, sidebar toggle + page title + icon actions with
//                   1 pt separators, 1 pt bottom border
//   content       - 3-column masonry of module cards (301 pt, radius 14,
//                   background fill + border), 16 pt gaps, smooth scroll with
//                   a 2 pt scrollbar and 64 pt background fades
//   module card   - 56 pt header (category icon, 16 pt name, keybind chip,
//                   28x16 toggle), expands in place; a 2 pt accent ring
//                   flashes when it opens
//   settings      - rows inside the card: 16x16 checkboxes (radius 6),
//                   6 pt sliders with a hover-revealed 10 pt knob, segmented
//                   controls / dropdowns for enums, text fields
//   search        - 448x304 centred modal listing module and setting hits
//   palette       - SystemDLC dark role colors; the interactive color
//                   ("primary") is the client's cycling theme accent
//
// Everything that is "ours" is preserved on top: the module registry, keybind
// capture, friends, config save/load, the glass material + transparency
// settings, the background particle flow and the theme accent.
//
// NOTE: ASCII only in this file.

#include "pch.h"
#include "ui/citron_gui.h"

#include "modules/module.h"
#include "modules/module_guard.h"
#include "modules/module_manager.h"
#include "modules/misc/friends_module.h"
#include "modules/misc/misc_modules.h"
#include "modules/setting.h"
#include "modules/settings/flarial_settings_module.h"
#include "modules/visual/clickgui_module.h"
#include "modules/visual/visual_modules.h"
#include "modules/visual/interface_module.h"
#include "utils/config.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"
#include "utils/logger.h"
#include "overlay.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace ui {

using modules::BoolSetting;
using modules::ClickGuiModule;
using modules::ColorSetting;
using modules::EnumSetting;
using modules::FlarialSettingsModule;
using modules::InterfaceModule;
using modules::Module;
using modules::ModulePhaseGuard;
using modules::NumberSetting;
using modules::StringSetting;
using modules::Setting;
using modules::SettingType;

namespace {

// ======================== SystemDLC palette (roles) ========================
// Dark ThemePalette.INSTANCE2 as UI roles. UpdatePalette() recomputes the
// surface alphas every frame: solid colors when the ClickGui module's Glass
// setting is off, translucent glassmorphism panels when it is on. The accent
// is not stored here - it stays the Interface theme's cycling color.
ImColor kBackground = ImColor(10, 10, 10);            // Void canvas
ImColor kSurface    = ImColor(23, 23, 23);            // raised panels
ImColor kElevated   = ImColor(38, 38, 38);            // hover / controls
ImColor kBorder     = ImColor(64, 64, 64);            // 1 pt separators
ImColor kMutedFg    = ImColor(161, 161, 161);         // secondary text
ImColor kForeground = ImColor(250, 250, 250);         // primary text
// Status pair (kept from the reference palette for destructive actions).
const ImColor kDanger = ImColor(185, 28, 28, 255);
// Solid dark for glyphs painted ON accent fills.
const ImColor kSolid = ImColor(10, 10, 10);

static void UpdatePalette(bool glass, float transparency) {
    if (!glass) return;   // solid SystemDLC palette stays as initialized
    const float t = gui::Clamp(transparency, 0.0f, 1.0f);
    const float a = gui::Clamp(1.0f - 0.55f * t, 0.34f, 1.0f);  // glass factor
    kBackground = ImColor(0.039f, 0.039f, 0.043f, 0.86f * a);
    kSurface    = ImColor(1.0f, 1.0f, 1.0f, 0.045f * a + 0.014f);
    kElevated   = ImColor(1.0f, 1.0f, 1.0f, 0.095f * a + 0.020f);
    kBorder     = ImColor(1.0f, 1.0f, 1.0f, 0.130f * a + 0.045f);
}

// SystemDLC renders 1:1 at 1920x1080 - no extra font lift needed.
constexpr float kFontScale = 1.0f;

// Design space.
constexpr float kWinW = 1188.0f;
constexpr float kWinH = 700.0f;
constexpr float kWinR = 12.0f;
constexpr float kTopH = 48.0f;

// ======================== Lucide glyphs ========================
namespace ic {
const char* const MOUSE    = "\xEE\x8A\x8E";  // U+E28E
const char* const VOLUME   = "\xEE\x86\xAB";  // U+E1AB
const char* const SETTINGS = "\xEE\x85\x94";  // U+E154
const char* const MINUS    = "\xEE\x84\x9C";  // U+E11C
const char* const PLUS     = "\xEE\x88\xA4";  // U+E224
const char* const CLOSE    = "\xEE\x86\xB2";  // U+E1B2
const char* const KEYBOARD = "\xEE\x8A\x84";  // U+E284
const char* const EYE_OFF  = "\xEE\x82\xBB";  // U+E0BB
const char* const SPARKLES = "\xEE\x90\x92";  // U+E412
const char* const ACTIVITY = "\xEE\x80\xB8";  // U+E038
const char* const SLIDERS  = "\xEE\x8A\x9A";  // U+E29A
const char* const PLAY     = "\xEE\x84\xBC";  // U+E13C
const char* const PALETTE  = "\xEE\x87\x9D";  // U+E1DD
const char* const POWER    = "\xEE\x85\x80";  // U+E140
const char* const REFRESH  = "\xEE\x85\x85";  // U+E145
const char* const CHART    = "\xEE\x8A\xA2";  // U+E2A2
const char* const DISC     = "\xEE\x92\x94";  // U+E494
} // namespace ic

// ======================== cross-frame interaction state ========================
Module*        g_bindMod       = nullptr;
Setting*       g_bindSetting   = nullptr;
ColorSetting*  g_openColor     = nullptr;
ImVec2         g_openColorPos  = ImVec2(0, 0);
int            g_colorPopupFrame = -1;

// Active free-text field (StringSetting editing). The buffer mirrors the
// setting's value while the field is active; keys::TextInput feeds it.
StringSetting* g_activeText    = nullptr;
char           g_textBuf[192]  = {};

// ======================== frame context ========================
// Everything is laid out in a 1188x700 pt design space; the ctx converts
// pt -> screen px and handles alpha / hit-testing in pt coordinates.
struct Ctx {
    ImDrawList* d        = nullptr;
    float       s        = 1.0f;   // design pt -> screen px (includes zoom)
    float       anim     = 1.0f;   // global menu fade
    ImVec2      origin   = ImVec2(0, 0);
    float       offsetY  = 0.0f;   // logical Y translation (scroll / slide)
    bool        interact = false;
    float       dt       = 0.016f;
    ImColor     accent   = ImColor(250, 250, 250);

    float  px(float pt) const { return pt * s; }
    ImVec2 P(float x, float y) const {
        return ImVec2(origin.x + x * s, origin.y + (y + offsetY) * s);
    }
    ImVec4 R(float x, float y, float w, float h) const {
        return ImVec4(origin.x + x * s, origin.y + (y + offsetY) * s,
                      origin.x + (x + w) * s,
                      origin.y + (y + h + offsetY) * s);
    }
    ImVec2 M() const {
        const ImVec2 m = gui::GetMousePos();
        return ImVec2((m.x - origin.x) / s,
                      (m.y - origin.y) / s - offsetY);
    }
    bool Hover(float x, float y, float w, float h) const {
        const ImVec2 m = M();
        return m.x >= x && m.y >= y && m.x < x + w && m.y < y + h;
    }
    bool Clicked() const { return interact && ImGui::IsMouseClicked(0); }
};

// ======================== text helpers ========================
ImFont* FontReg()   { ImFont* f = gui::UIFont();    return f ? f : ImGui::GetFont(); }
ImFont* FontSemi()  { return FontReg(); }
ImFont* FontDisplay() {
    ImFont* f = gui::DisplayFont();
    return f ? f : FontSemi();
}
ImFont* FontMono() {
    ImFont* f = gui::MonoFont();
    return f ? f : FontReg();
}
ImFont* FontIcon()  { return gui::IconFont(); }

float TextW(ImFont* f, const char* s, float sizePt, float sPx) {
    if (!f || !s) return 0.0f;
    const float pxF = sizePt * kFontScale * sPx;
    if (pxF <= 0.01f) return 0.0f;
    gui::SetFontOverride(f);
    const float w = gui::GetTextWidth(s, pxF / gui::kFontUnit);
    gui::SetFontOverride(nullptr);
    return w;
}

float TextH(ImFont* f, float sizePt, float sPx) {
    if (!f) return sizePt;
    gui::SetFontOverride(f);
    const float h = gui::GetTextHeight(sizePt * kFontScale * sPx / gui::kFontUnit);
    gui::SetFontOverride(nullptr);
    return (sPx > 0.01f) ? h / sPx : sizePt;
}

void Text(const Ctx& c, float x, float y, const char* s, ImFont* f,
          float sizePt, const ImColor& col, float alphaMul = 1.0f) {
    const float pxF = sizePt * kFontScale * c.s;
    if (pxF <= 0.5f || !s || !*s) return;
    gui::SetFontOverride(f);
    gui::DrawText(c.P(x, y), s, col, pxF / gui::kFontUnit, c.anim * alphaMul,
                  false, c.d);
    gui::SetFontOverride(nullptr);
}

void TextCenter(const Ctx& c, float cx, float cy, const char* s, ImFont* f,
                float sizePt, const ImColor& col, float alphaMul = 1.0f) {
    const float w = TextW(f, s, sizePt, c.s);
    const float h = TextH(f, sizePt, c.s);
    Text(c, cx - w * 0.5f, cy - h * 0.5f, s, f, sizePt, col, alphaMul);
}

// Mono caption (server address, keybind labels).
void MonoText(const Ctx& c, float x, float y, const char* s, float sizePt,
              const ImColor& col, float alphaMul = 1.0f) {
    Text(c, x, y, s, FontMono(), sizePt, col, alphaMul);
}

float HoverAnim(unsigned int id, bool hovered, float dt) {
    static float states[128] = {};
    const unsigned int slot = id & 127u;
    states[slot] = gui::Animate(hovered ? 1.0f : 0.0f, states[slot],
                                gui::Clamp(dt * 14.0f, 0.0f, 1.0f));
    return gui::Clamp(states[slot], 0.0f, 1.0f);
}

unsigned int HoverId(const char* text, unsigned int salt) {
    unsigned int h = 2166136261u ^ salt;
    if (text) {
        for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text);
             *p; ++p) {
            h ^= *p;
            h *= 16777619u;
        }
    }
    return h;
}

// Centered Lucide glyph.
void Glyph(const Ctx& c, float cx, float cy, const char* g, float sizePt,
           const ImColor& col, float alphaMul = 1.0f) {
    ImFont* f = FontIcon();
    if (!f) return;
    const float w = TextW(f, g, sizePt, c.s);
    Text(c, cx - w * 0.5f, cy - w * 0.5f, g, f, sizePt, col, alphaMul);
}

// Magnifier drawn by hand (the bundled glyph set has no search icon).
void SearchGlyph(const Ctx& c, float cx, float cy, float sizePt,
                 const ImColor& col, float alphaMul = 1.0f) {
    const ImColor colA = ImColor(col.Value.x, col.Value.y, col.Value.z,
                                 col.Value.w * c.anim * alphaMul);
    const float r = sizePt * 0.28f;
    c.d->AddCircle(c.P(cx - r * 0.35f, cy - r * 0.35f), c.px(r), colA, 12,
                   c.px(1.4f));
    c.d->AddLine(c.P(cx + r * 0.45f, cy + r * 0.45f),
                 c.P(cx + r * 1.15f, cy + r * 1.15f), colA, c.px(1.4f));
}

// ======================== primitives ========================
void FillR(const Ctx& c, float x, float y, float w, float h,
           const ImColor& col, float radiusPt, float alphaMul = 1.0f) {
    c.d->AddRectFilled(c.P(x, y), c.P(x + w, y + h),
                       ImColor(col.Value.x, col.Value.y, col.Value.z,
                               col.Value.w * c.anim * alphaMul),
                       c.px(radiusPt));
}

void StrokeR(const Ctx& c, float x, float y, float w, float h,
             const ImColor& col, float radiusPt, float thicknessPt = 1.0f,
             float alphaMul = 1.0f) {
    c.d->AddRect(c.P(x, y), c.P(x + w, y + h),
                 ImColor(col.Value.x, col.Value.y, col.Value.z,
                         col.Value.w * c.anim * alphaMul),
                 c.px(radiusPt), ImDrawFlags_None, c.px(thicknessPt));
}

void HLine(const Ctx& c, float x, float y, float w, float alphaMul = 1.0f) {
    FillR(c, x, y, w, 1.0f, kBorder, 0.0f, alphaMul);
}

void VLine(const Ctx& c, float x, float y, float h, float alphaMul = 1.0f) {
    FillR(c, x, y, 1.0f, h, kBorder, 0.0f, alphaMul);
}

// Expander chevron (used by the enum dropdown buttons).
void Chevron(const Ctx& c, float cx, float cy, float open) {
    const float r    = 3.5f;
    const float apex = gui::Lerp(3.0f, -3.0f, open);
    const float side = -apex;
    const ImColor col = ImColor((int)kMutedFg.Value.x, (int)kMutedFg.Value.y,
                                (int)kMutedFg.Value.z, (int)(255.0f * c.anim));
    c.d->AddLine(c.P(cx - r, cy + side), c.P(cx, cy + apex), col, c.px(1.2f));
    c.d->AddLine(c.P(cx, cy + apex), c.P(cx + r, cy + side), col, c.px(1.2f));
}

// ======================== SystemDLC widgets ========================

// 28x16 toggle: track glides border -> accent, knob foreground -> background.
bool SSDToggle(Ctx& c, float x, float cy, bool on, float& t) {
    const float w = 28.0f, h = 16.0f;
    const float y = cy - h * 0.5f;
    t = gui::Animate(on ? 1.0f : 0.0f, t, c.dt * 9.0f);
    t = gui::Clamp(t, 0.0f, 1.0f);

    const bool hit = c.Hover(x - 2.0f, y - 2.0f, w + 4.0f, h + 4.0f);
    const unsigned int id = 0x71u ^
        (unsigned int)(std::fabs(x) * 3.0f + std::fabs(cy) * 17.0f);
    const float hover = HoverAnim(id, hit, c.dt);

    FillR(c, x, y, w, h, gui::LerpColor(kBorder, c.accent, t), 8.0f);
    if (hover > 0.01f)
        StrokeR(c, x - 1.0f, y - 1.0f, w + 2.0f, h + 2.0f, c.accent, 9.0f,
                1.0f, 0.45f * hover);

    const float knobX = x + 2.0f + t * (w - 12.0f - 4.0f);
    c.d->AddCircleFilled(c.P(knobX + 6.0f, y + 8.0f), c.px(6.0f),
                         ImColor(gui::LerpColor(kForeground, kBackground, t).Value.x,
                                 gui::LerpColor(kForeground, kBackground, t).Value.y,
                                 gui::LerpColor(kForeground, kBackground, t).Value.z,
                                 c.anim));
    if (hit && c.Clicked()) return true;
    return false;
}

// 16x16 checkbox: background fill + border when off, accent fill + surface
// check when on.
bool SSDCheckbox(Ctx& c, float x, float y, bool on, float& t) {
    t = gui::Animate(on ? 1.0f : 0.0f, t, c.dt * 9.0f);
    t = gui::Clamp(t, 0.0f, 1.0f);
    const bool hit = c.Hover(x - 2.0f, y - 2.0f, 20.0f, 20.0f);
    const unsigned int id = 0x72u ^
        (unsigned int)(std::fabs(x) * 5.0f + std::fabs(y) * 13.0f);
    const float hover = HoverAnim(id, hit, c.dt);

    FillR(c, x, y, 16.0f, 16.0f,
          gui::LerpColor(kBackground, c.accent, t), 6.0f);
    StrokeR(c, x, y, 16.0f, 16.0f,
            gui::LerpColor(kBorder, c.accent, t), 6.0f, 1.0f);
    if (hover > 0.01f)
        StrokeR(c, x - 1.0f, y - 1.0f, 18.0f, 18.0f, c.accent, 7.0f, 1.0f,
                0.4f * hover);
    if (t > 0.01f) {
        const ImColor chk = ImColor(kSolid.Value.x, kSolid.Value.y,
                                    kSolid.Value.z, c.anim * t);
        c.d->AddLine(c.P(x + 4.0f, y + 8.0f), c.P(x + 6.8f, y + 10.8f), chk,
                     c.px(1.6f));
        c.d->AddLine(c.P(x + 6.8f, y + 10.8f), c.P(x + 12.0f, y + 5.0f), chk,
                     c.px(1.6f));
    }
    if (hit && c.Clicked()) return true;
    return false;
}

// Keybind chip: keyboard glyph + label, accent fill while listening.
bool SSDKeybindChip(Ctx& c, float rightX, float cy, const char* label,
                    bool listening) {
    const char* txt = listening ? "..." : label;
    const float tw  = TextW(FontMono(), txt, 11.0f, c.s);
    const float w   = std::fmax(4.0f + 16.0f + 4.0f + tw + 4.0f, 48.0f);
    const float h   = 20.0f;
    const float x   = rightX - w;
    const float y   = cy - h * 0.5f;
    const bool  hov = c.Hover(x, y, w, h);
    const float hover = HoverAnim(HoverId(label, 0x73u), hov, c.dt);

    if (listening) {
        FillR(c, x, y, w, h, c.accent, 4.0f);
    } else {
        FillR(c, x, y, w, h,
              gui::LerpColor(kElevated, kBorder, 0.45f * hover), 4.0f);
    }
    const ImColor iconCol = listening ? kBackground
                                      : gui::LerpColor(kForeground, c.accent,
                                                       0.35f * hover);
    const ImColor txtCol  = listening ? kBackground : kMutedFg;
    if (FontIcon()) Glyph(c, x + 4.0f + 8.0f, cy, ic::KEYBOARD, 11.0f, iconCol);
    MonoText(c, x + 4.0f + 16.0f + 4.0f, cy - TextH(FontMono(), 11.0f, c.s) * 0.5f,
             txt, 11.0f, txtCol);

    if (hov && c.Clicked()) return true;
    return false;
}

// Top-bar icon action: 14 pt glyph over a 28 pt hover box.
bool SSDIconButton(Ctx& c, float cx, float cy, const char* glyph) {
    const bool  hov   = c.Hover(cx - 14.0f, cy - 14.0f, 28.0f, 28.0f);
    const float hover = HoverAnim(HoverId(glyph, 0x74u), hov, c.dt);
    if (hover > 0.01f)
        FillR(c, cx - 14.0f, cy - 14.0f, 28.0f, 28.0f, kElevated, 6.0f,
              0.85f * hover);
    if (FontIcon())
        Glyph(c, cx, cy, glyph, 14.0f,
              gui::LerpColor(kMutedFg, kForeground, hover));
    if (hov && c.Clicked()) return true;
    return false;
}

// Sidebar / section tab: 32 pt row, radius 8, elevated fill when active or
// hovered. labelAlpha fades the captions while the sidebar is collapsed.
bool SSDIconTab(Ctx& c, float x, float y, float w, const char* glyph,
                const char* label, bool active, float labelAlpha) {
    const bool  hov   = c.Hover(x, y, w, 32.0f);
    const float hover = HoverAnim(HoverId(label, 0x75u), hov, c.dt);
    float fill = 0.0f;
    if (active)     fill = 1.0f;
    else if (hover > 0.01f) fill = 0.82f * hover;
    if (fill > 0.001f)
        FillR(c, x, y, w, 32.0f, kElevated, 8.0f, fill);

    const ImColor iconCol = active ? c.accent : kForeground;
    if (FontIcon()) Glyph(c, x + 16.0f, y + 16.0f, glyph, 16.0f, iconCol);
    const float th = TextH(FontReg(), 14.0f, c.s);
    Text(c, x + 32.0f, y + 16.0f - th * 0.5f, label, FontReg(), 14.0f,
         kForeground, labelAlpha);

    if (hov && c.Clicked()) return true;
    return false;
}

// 12 pt section label above sidebar groups (fades out when collapsed).
void SSDSectionLabel(const Ctx& c, float x, float y, const char* label,
                     float alpha) {
    const float th = TextH(FontReg(), 12.0f, c.s);
    Text(c, x, y + 16.0f - th * 0.5f, label, FontReg(), 12.0f, kMutedFg,
         alpha);
}

// 6 pt slider with a hover-revealed 10 pt knob. Returns true when changed.
bool SSDSlider(Ctx& c, float x, float y, float w, NumberSetting* ns) {
    const float span = ns->mMax - ns->mMin;
    const float posF = (span > 0.0f) ? (ns->mValue - ns->mMin) / span : 0.0f;
    ns->sliderEase = gui::Animate(posF, ns->sliderEase, c.dt * 15.0f);
    ns->sliderEase = gui::Clamp(ns->sliderEase, 0.0f, 1.0f);

    const unsigned int id = 0x76u ^
        (unsigned int)(std::fabs(x) * 7.0f + std::fabs(y) * 19.0f);
    const bool  hitZone = c.Hover(x, y - 12.0f, w, 30.0f);
    const float hover   = HoverAnim(id, hitZone || ns->isDragging, c.dt);

    FillR(c, x, y, w, 6.0f, kElevated, 3.0f);
    if (ns->sliderEase > 0.001f)
        FillR(c, x, y, w * ns->sliderEase, 6.0f, c.accent, 3.0f);
    if (hover > 0.01f) {
        const float hx = x + w * ns->sliderEase;
        c.d->AddCircleFilled(c.P(hx, y + 3.0f), c.px(5.0f),
                             ImColor(kBackground.Value.x, kBackground.Value.y,
                                     kBackground.Value.z, c.anim * hover));
        c.d->AddCircle(c.P(hx, y + 3.0f), c.px(5.0f),
                       ImColor(kForeground.Value.x, kForeground.Value.y,
                               kForeground.Value.z, c.anim * hover), 12,
                       c.px(1.15f));
    }

    bool changed = false;
    if (c.interact && c.Hover(x, y - 12.0f, w, 30.0f) &&
        ImGui::IsMouseClicked(0)) {
        ns->isDragging = true;
        changed = true;
    }
    if (!ImGui::IsMouseDown(0)) ns->isDragging = false;
    if (c.interact && ns->isDragging) {
        float t = gui::Clamp((c.M().x - x) / w, 0.0f, 1.0f);
        float v = ns->mMin + t * span;
        v = std::round(v / ns->mStep) * ns->mStep;
        v = gui::Clamp(v, ns->mMin, ns->mMax);
        if (std::fabs(v - ns->mValue) > 1e-4f) {
            ns->mValue = v;
            changed = true;
        }
    }
    return changed;
}

// Two-option segmented control.
bool SSDSegmented(Ctx& c, float x, float y, float w, EnumSetting* es) {
    const float h    = 24.0f;
    const float segW = (w - 4.0f) * 0.5f;
    const bool  hit  = c.Hover(x, y, w, h);
    FillR(c, x, y, w, h, kElevated, 8.0f);

    const int sel = es->mValue >= 0 && es->mValue < 2 ? es->mValue : 0;
    FillR(c, x + 2.0f + sel * segW, y + 2.0f, segW, h - 4.0f, kBackground,
          6.0f);

    for (int i = 0; i < 2; i++) {
        const float th = TextH(FontReg(), 12.0f, c.s);
        TextCenter(c, x + 2.0f + segW * (float)i + segW * 0.5f, y + h * 0.5f,
                   es->mValues[i].c_str(), FontReg(), 12.0f,
                   i == sel ? kForeground : kMutedFg);
    }
    if (hit && c.Clicked()) {
        const float mx = c.M().x;
        es->setValue(mx >= x + segW ? 1 : 0);
        return true;
    }
    return false;
}

// Enum dropdown button (3+ options). The open panel is drawn in the overlay
// pass; see CitronGui::render.
bool SSDDropdownButton(Ctx& c, float x, float y, float w, EnumSetting* es,
                       bool open, float& ddX, float& ddY) {
    const float h = 24.0f;
    const bool  hit = c.Hover(x, y, w, h);
    FillR(c, x, y, w, h, kElevated, 8.0f);
    if (hit) StrokeR(c, x, y, w, h, kBorder, 8.0f, 1.0f, 0.6f);
    const char* val = es->mValue >= 0 &&
                      es->mValue < (int)es->mValues.size()
                          ? es->mValues[es->mValue].c_str() : "";
    const float th = TextH(FontReg(), 12.0f, c.s);
    Text(c, x + 10.0f, y + h * 0.5f - th * 0.5f, val, FontReg(), 12.0f,
         kForeground);
    Chevron(c, x + w - 14.0f, y + h * 0.5f, open ? 1.0f : 0.0f);
    ddX = x;
    ddY = y + h + 4.0f;
    if (hit && c.Clicked()) return true;
    return false;
}

// 20x20 color swatch. Returns true when clicked (opens the picker).
bool SSDColorSwatch(Ctx& c, float x, float y, const ImColor& col) {
    FillR(c, x, y, 20.0f, 20.0f, col, 6.0f);
    StrokeR(c, x, y, 20.0f, 20.0f, kBorder, 6.0f, 1.0f);
    const bool hov = c.Hover(x, y, 20.0f, 20.0f);
    if (hov) StrokeR(c, x - 1.0f, y - 1.0f, 22.0f, 22.0f, kForeground, 7.0f,
                     1.0f, 0.5f);
    if (hov && c.Clicked()) return true;
    return false;
}

// 32 pt action button (icon + label), elevated fill.
bool SSDButton(Ctx& c, float x, float y, float w, const char* glyph,
               const char* label) {
    const float h = 32.0f;
    const bool  hit = c.Hover(x, y, w, h);
    const float hover = HoverAnim(HoverId(label, 0x77u), hit, c.dt);
    FillR(c, x, y, w, h, kElevated, 8.0f);
    if (hover > 0.01f)
        StrokeR(c, x, y, w, h, c.accent, 8.0f, 1.0f, 0.55f * hover);
    const float tw = TextW(FontReg(), label, 13.0f, c.s);
    const float total = 16.0f + 6.0f + tw;
    const float sx = x + w * 0.5f - total * 0.5f;
    if (FontIcon()) Glyph(c, sx + 8.0f, y + h * 0.5f, glyph, 14.0f, kForeground);
    const float th = TextH(FontReg(), 13.0f, c.s);
    Text(c, sx + 16.0f + 6.0f, y + h * 0.5f - th * 0.5f, label, FontReg(),
         13.0f, kForeground);
    if (hit && c.Clicked()) return true;
    return false;
}

// ======================== pages ========================
enum Tab {
    TAB_ALL = 0,
    TAB_RENDER, TAB_VISUAL, TAB_MOVEMENT, TAB_PLAYER, TAB_COMBAT, TAB_MISC,
    TAB_THEME,
    TAB_SETTINGS,
    TAB_FRIENDS,
};
const int kPageCount = 10;

struct PageDef { const char* label; const char* icon; };
const PageDef kPages[kPageCount] = {
    { "All",      ic::SLIDERS  },
    { "Render",   ic::ACTIVITY },
    { "Visual",   ic::EYE_OFF  },
    { "Movement", ic::PLAY     },
    { "Player",   ic::MOUSE    },
    { "Combat",   ic::POWER    },
    { "Misc",     ic::CHART    },
    { "Theme",    ic::PALETTE  },
    { "Settings", ic::SETTINGS },
    { "Friends",  ic::SPARKLES },
};

// Registry category -> module page, or -1 when the category has no page.
int CategoryToPage(const char* cat) {
    if (!cat) return -1;
    if (!std::strcmp(cat, "Render"))   return TAB_RENDER;
    if (!std::strcmp(cat, "Visual"))   return TAB_VISUAL;
    if (!std::strcmp(cat, "Movement")) return TAB_MOVEMENT;
    if (!std::strcmp(cat, "Player"))   return TAB_PLAYER;
    if (!std::strcmp(cat, "Combat"))   return TAB_COMBAT;
    if (!std::strcmp(cat, "Misc"))     return TAB_MISC;
    return -1;
}

const char* CategoryIcon(const char* cat) {
    const int p = CategoryToPage(cat);
    return (p >= 0) ? kPages[p].icon : kPages[TAB_ALL].icon;
}

// Vertical value formatter: no trailing zeros.
std::string FmtVal(float v, float step) {
    char b[32];
    if (step >= 0.99f)      sprintf_s(b, "%.0f", v);
    else if (step >= 0.095f) sprintf_s(b, "%.1f", v);
    else                     sprintf_s(b, "%.2f", v);
    return std::string(b);
}

// Trim surrounding whitespace from a typed nickname.
std::string TrimName(const char* s) {
    if (!s) return std::string();
    const std::string in(s);
    const size_t a = in.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return std::string();
    const size_t b = in.find_last_not_of(" \t\r\n");
    return in.substr(a, b - a + 1);
}

float WheelNotches() {
    return ImGui::GetIO().MouseWheel;
}

// Lowercase ASCII into a fixed buffer (search matching).
void LowerCopy(char* dst, size_t cap, const char* src) {
    size_t i = 0;
    for (; src && src[i] && i + 1 < cap; ++i)
        dst[i] = (char)std::tolower((unsigned char)src[i]);
    dst[i] = 0;
}

// ---------------- setting row metrics (shared by cards and pages) ----------
float RowHeight(Setting* s) {
    switch (s->mType) {
        case SettingType::Bool:   return 24.0f;
        case SettingType::Number: return 46.0f;
        case SettingType::Color:  return 24.0f;
        case SettingType::Enum:   return 30.0f;
        case SettingType::String: return 52.0f;
        default:                  return 0.0f;
    }
}

} // namespace

// ======================== particles (kept "Activity" flow) ========================
void CitronGui::InitParticles() {
    if (m_particlesReady) return;
    m_particlesReady = true;
    for (size_t i = 0; i < m_particles.size(); ++i) {
        Particle& p = m_particles[i];
        const float fi = static_cast<float>(i);
        p.x = std::fmod(0.071f + fi * 0.137f, 1.0f);
        p.y = std::fmod(0.163f + fi * 0.083f, 1.0f);
        p.vx = -0.010f + std::fmod(fi * 0.017f, 0.024f);
        p.vy = -0.014f + std::fmod(fi * 0.011f, 0.022f);
        p.size = 0.75f + std::fmod(fi * 0.43f, 1.7f);
        p.phase = fi * 0.91f;
    }
}

void CitronGui::DrawParticles(const ImVec2& screen, const ImColor& accent,
                              float animation, float dt) {
    InitParticles();
    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw || animation <= 0.001f) return;

    const float step = gui::Clamp(dt, 0.0f, 0.05f);
    for (size_t i = 0; i < m_particles.size(); ++i) {
        Particle& p = m_particles[i];
        p.x += p.vx * step;
        p.y += p.vy * step;
        p.phase += step * (0.8f + p.size * 0.15f);
        if (p.x < -0.04f) p.x = 1.04f;
        if (p.x > 1.04f) p.x = -0.04f;
        if (p.y < -0.04f) p.y = 1.04f;
        if (p.y > 1.04f) p.y = -0.04f;

        const float pulse = 0.5f + 0.5f * std::sinf(p.phase);
        const float alpha = animation * (0.055f + pulse * 0.095f);
        const ImVec2 pos(screen.x * p.x, screen.y * p.y);
        draw->AddCircleFilled(pos, 0.65f + p.size * 0.35f,
                              ImColor(accent.Value.x, accent.Value.y,
                                      accent.Value.z, alpha), 6);

        if ((i % 3u) == 0u) {
            const Particle& q = m_particles[(i + 7u) % m_particles.size()];
            const ImVec2 other(screen.x * q.x, screen.y * q.y);
            const float dx = other.x - pos.x;
            const float dy = other.y - pos.y;
            const float d2 = dx * dx + dy * dy;
            if (d2 < 150.0f * 150.0f) {
                const float linkAlpha = alpha * (1.0f - std::sqrt(d2) / 150.0f) * 0.42f;
                draw->AddLine(pos, other,
                              ImColor(accent.Value.x, accent.Value.y,
                                      accent.Value.z, linkAlpha), 0.7f);
            }
        }
    }
}

// ======================== main render ========================
void CitronGui::render(float animation, float inScale, bool isEnabled) {
    if (!ImGui::GetCurrentContext()) return;

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;

    const auto& mods = modules::Modules().modules();
    m_modAnim.resize(mods.size(), 0.0f);
    m_modHover.resize(mods.size(), 0.0f);
    m_ringAnim.resize(mods.size(), 0.0f);

    for (size_t i = 0; i < mods.size(); i++) {
        m_modAnim[i] = gui::Animate(mods[i]->enabled() ? 1.0f : 0.0f,
                                    m_modAnim[i], gui::GetDeltaTime() * 9.0f);
        m_ringAnim[i] = gui::Animate(0.0f, m_ringAnim[i],
                                     gui::Clamp(gui::GetDeltaTime() * 2.4f,
                                                0.0f, 1.0f));
    }

    // Menu closed - drop transient interaction state.
    if (!isEnabled) {
        g_bindMod     = nullptr;
        g_bindSetting = nullptr;
        g_openColor   = nullptr;
        g_activeText  = nullptr;
        m_ddSetting   = nullptr;
        m_searchOpen  = false;
        CloseAddFriend();
    }

    // Sidebar collapse glide.
    m_sideAnim = gui::Animate(m_sideOpen ? 1.0f : 0.0f, m_sideAnim,
                              gui::Clamp(gui::GetDeltaTime() * 8.0f, 0.0f, 1.0f));
    m_sideAnim = gui::Clamp(m_sideAnim, 0.0f, 1.0f);

    // SystemDLC scale: 1.0 at 1920x1080, clamped to fit smaller screens.
    float sBase = std::fmin(std::fmin(screen.x / 1920.0f, screen.y / 1080.0f),
                            std::fmin(screen.x * 0.96f / kWinW,
                                      screen.y * 0.96f / kWinH));
    if (sBase <= 0.01f) return;

    // Open animation: 0.93 -> 1.0 scale around the center + an 18 pt drop.
    const float openE = gui::Clamp(animation, 0.0f, 1.0f);
    const float easeO = 1.0f - (1.0f - openE) * (1.0f - openE);
    const float popScale = 0.93f + 0.07f * easeO;
    const float dropY    = (1.0f - easeO) * 18.0f;

    const ImVec2 center(screen.x * 0.5f, screen.y * 0.5f);
    const float  designW = kWinW * sBase * popScale;
    const float  designH = kWinH * sBase * popScale;
    ImVec4 baseWin(center.x - designW * 0.5f + m_winOffset.x,
                   center.y - designH * 0.5f + m_winOffset.y + dropY * sBase,
                   center.x + designW * 0.5f + m_winOffset.x,
                   center.y + designH * 0.5f + m_winOffset.y + dropY * sBase);
    const ImVec4 win = gui::ScaleToPoint(
        baseWin, ImVec4(center.x, center.y, center.x, center.y), inScale);

    const float sEff = sBase * (gui::RectW(win) / (kWinW * sBase * popScale));

    Ctx c;
    c.d        = ImGui::GetBackgroundDrawList();
    c.s        = sEff;
    c.anim     = animation;
    c.origin   = ImVec2(win.x, win.y);
    c.interact = isEnabled && !m_searchOpen &&
                 (!ImGui::GetIO().WantCaptureMouse || !g_openColor);
    c.dt       = gui::GetDeltaTime();
    c.accent   = gui::GetThemedColor(0);

    ClickGuiModule* cgSettings = ClickGuiModule::instance();
    const bool  glassOn = cgSettings && cgSettings->m_glass &&
                          cgSettings->m_glass->mValue;
    const float glassT  = (cgSettings && cgSettings->m_transparency)
                              ? cgSettings->m_transparency->mValue : 0.55f;
    UpdatePalette(glassOn, glassT);

    DrawParticles(screen, c.accent, animation, c.dt);

    gui::FillShadowRect(ImVec4(win.x, win.y, win.z, win.w), c.accent,
                        animation * 0.10f, 14.0f, 0, 18.0f, c.d);

    c.d->PushClipRect(ImVec2(win.x - 1.0f, win.y - 1.0f),
                      ImVec2(win.z + 1.0f, win.w + 1.0f), true);

    // --- window frame -------------------------------------------------------
    c.d->AddRectFilled(c.P(0, 0), c.P(kWinW, kWinH),
                       ImColor(kBackground.Value.x, kBackground.Value.y,
                               kBackground.Value.z,
                               kBackground.Value.w * animation),
                       c.px(kWinR));
    c.d->AddRect(c.P(0, 0), c.P(kWinW, kWinH),
                 ImColor(kBorder.Value.x, kBorder.Value.y, kBorder.Value.z,
                         kBorder.Value.w * animation),
                 c.px(kWinR), ImDrawFlags_None, c.px(1.0f));

    if (sEff > 0.05f) {
        // ==================== layout metrics ====================
        const float sideW = gui::Lerp(48.0f, 224.0f, m_sideAnim);
        const float contentX = sideW + 1.0f;
        const float contentW = kWinW - contentX;
        const float contentY = kTopH + 1.0f;
        const float contentH = kWinH - contentY;

        // ==================== sidebar ====================
        FillR(c, 0.0f, 0.0f, sideW, kWinH, kSurface, kWinR);
        FillR(c, sideW - 13.0f, 0.0f, 13.0f, kWinH, kSurface, 0.0f);
        VLine(c, sideW, 0.0f, kWinH);
        HLine(c, 0.0f, kTopH, sideW);

        // Logo row (48 pt): activity glyph + serif wordmark.
        if (FontIcon()) Glyph(c, 24.0f, 24.0f, ic::ACTIVITY, 16.0f, c.accent);
        const float wmW = TextW(FontDisplay(), "Nightfull", 16.0f, c.s);
        if (wmW > 0.0f)
            Text(c, 40.0f, 24.0f - TextH(FontDisplay(), 16.0f, c.s) * 0.5f,
                 "Nightfull", FontDisplay(), 16.0f, kForeground, m_sideAnim);

        const float itemX = 8.0f;
        const float itemW = sideW - 16.0f;
        float sy = kTopH + 8.0f;
        SSDSectionLabel(c, itemX + 8.0f, sy, "CATEGORIES", m_sideAnim);
        sy += 32.0f;
        for (int i = TAB_ALL; i <= TAB_MISC; i++) {
            if (SSDIconTab(c, itemX, sy, itemW, kPages[i].icon, kPages[i].label,
                           m_tab == i, m_sideAnim)) {
                if (m_tab != i) {
                    CloseAddFriend();
                    m_titleDir  = i > m_tab ? 1 : -1;
                    m_titleT    = 0.0f;
                    m_pageSlideT = 0.0f;
                    m_ddSetting = nullptr;
                }
                m_tab = i;
            }
            sy += 36.0f;
        }
        sy += 6.0f;
        SSDSectionLabel(c, itemX + 8.0f, sy, "CLIENT", m_sideAnim);
        sy += 32.0f;
        for (int i = TAB_THEME; i <= TAB_FRIENDS; i++) {
            if (SSDIconTab(c, itemX, sy, itemW, kPages[i].icon, kPages[i].label,
                           m_tab == i, m_sideAnim)) {
                if (m_tab != i) {
                    CloseAddFriend();
                    m_titleDir  = i > m_tab ? 1 : -1;
                    m_titleT    = 0.0f;
                    m_pageSlideT = 0.0f;
                    m_ddSetting = nullptr;
                }
                m_tab = i;
            }
            sy += 36.0f;
        }

        // Server card at the bottom (client info + live ping).
        const float srvY = kWinH - 18.0f - 32.0f;
        FillR(c, itemX, srvY, 32.0f, 32.0f, kElevated, 8.0f);
        StrokeR(c, itemX, srvY, 32.0f, 32.0f, kBorder, 8.0f, 1.0f);
        TextCenter(c, itemX + 16.0f, srvY + 16.0f, "N", FontDisplay(), 15.0f,
                   kForeground);
        const float nameW = TextW(FontReg(), "Nightfull", 14.0f, c.s);
        Text(c, itemX + 40.0f, srvY + 3.0f, "Nightfull", FontReg(), 14.0f,
             kForeground, m_sideAnim);
        {
            char sub[48];
            sprintf_s(sub, "1.21.111 | %d ms", (int)overlay::g_pingMs);
            MonoText(c, itemX + 40.0f, srvY + 18.0f, sub, 10.0f, kMutedFg,
                     m_sideAnim);
        }
        (void)nameW;

        // ==================== top bar ====================
        HLine(c, contentX, kTopH, contentW);

        // Sidebar toggle.
        if (SSDIconButton(c, contentX + 24.0f, 24.0f, ic::SLIDERS)) {
            m_sideOpen = !m_sideOpen;
        }
        VLine(c, contentX + 48.0f, 15.0f, 18.0f, 0.8f);

        // Page title with slide-in on change.
        m_titleT = gui::Animate(1.0f, m_titleT, gui::Clamp(c.dt * 6.0f, 0.0f, 1.0f));
        m_titleT = gui::Clamp(m_titleT, 0.0f, 1.0f);
        {
            const float slide = (1.0f - m_titleT) * 6.0f * (float)m_titleDir;
            const float th = TextH(FontReg(), 14.0f, c.s);
            Text(c, contentX + 64.0f,
                 24.0f - th * 0.5f + slide, kPages[std::max(0, std::min(kPageCount - 1, m_tab))].label,
                 FontReg(), 14.0f, kForeground,
                 0.4f + 0.6f * m_titleT);
        }

        // Right icon actions: collapse all, search, glass.
        float rx = kWinW - 24.0f;
        if (SSDIconButton(c, rx, 24.0f, ic::SPARKLES)) {
            if (cgSettings && cgSettings->m_glass) {
                cgSettings->m_glass->setValue(!cgSettings->m_glass->mValue);
                LOG_INFO("menu: glass -> %s",
                         cgSettings->m_glass->mValue ? "ON" : "OFF");
            }
        }
        rx -= 36.0f;
        VLine(c, rx + 8.0f, 15.0f, 18.0f, 0.8f);
        {
            // search icon is drawn by hand; reuse the icon-button hitbox
            const bool  hov = c.Hover(rx - 14.0f, 10.0f, 28.0f, 28.0f);
            const float hover = HoverAnim(0x5E1u, hov, c.dt);
            if (hover > 0.01f)
                FillR(c, rx - 14.0f, 10.0f, 28.0f, 28.0f, kElevated, 6.0f,
                      0.85f * hover);
            SearchGlyph(c, rx, 24.0f, 14.0f,
                        gui::LerpColor(kMutedFg, kForeground, hover));
            if (hov && c.Clicked()) {
                m_searchOpen = true;
                m_searchSel  = -1;
                m_searchScrollTo = 0.0f;
                m_searchFrame = ImGui::GetFrameCount();
            }
        }
        rx -= 36.0f;
        VLine(c, rx + 8.0f, 15.0f, 18.0f, 0.8f);
        if (SSDIconButton(c, rx, 24.0f, ic::MINUS)) {
            for (const auto& m : mods) m->showSettings = false;
        }

        // ==================== content ====================
        // Page switch slide.
        m_pageSlideT = gui::Animate(1.0f, m_pageSlideT,
                                    gui::Clamp(c.dt * 4.5f, 0.0f, 1.0f));
        m_pageSlideT = gui::Clamp(m_pageSlideT, 0.0f, 1.0f);

        const int page = std::max(0, std::min(kPageCount - 1, m_tab));
        const float knownContent = m_pageContentHeight[page];
        const float pageMax = std::fmax(0.0f, knownContent - contentH);
        if (c.interact && pageMax > 0.0f &&
            c.Hover(contentX, contentY, contentW, contentH)) {
            const float notches = WheelNotches();
            if (notches != 0.0f) {
                m_pageScrollTo[page] -= notches * 48.0f;
                m_ddSetting = nullptr;
            }
        }
        m_pageScrollTo[page] = gui::Clamp(m_pageScrollTo[page], 0.0f, pageMax);
        m_pageScroll[page] = gui::Animate(m_pageScrollTo[page],
                                          m_pageScroll[page], c.dt * 14.0f);
        m_pageScroll[page] = gui::Clamp(m_pageScroll[page], 0.0f, pageMax);

        const Ctx baseContent = c;
        c.d->PushClipRect(baseContent.P(contentX, contentY),
                          baseContent.P(kWinW, kWinH), true);
        c.offsetY = -m_pageScroll[page] + (1.0f - m_pageSlideT) * 10.0f;

        float contentBottom = 0.0f;

        if (page <= TAB_MISC) {
            // ---------------- module masonry ----------------
            const char* wantedCategory = nullptr;
            if (page >= TAB_RENDER) {
                switch (page) {
                    case TAB_RENDER:   wantedCategory = "Render";   break;
                    case TAB_VISUAL:   wantedCategory = "Visual";   break;
                    case TAB_MOVEMENT: wantedCategory = "Movement"; break;
                    case TAB_PLAYER:   wantedCategory = "Player";   break;
                    case TAB_COMBAT:   wantedCategory = "Combat";   break;
                    case TAB_MISC:     wantedCategory = "Misc";     break;
                    default: break;
                }
            }

            const float colW  = gui::Lerp(358.0f, 301.0f, m_sideAnim);
            const float gap   = 16.0f;
            const int   cols  = 3;
            float colY[cols];
            for (int i = 0; i < cols; i++) colY[i] = 0.0f;

            for (size_t i = 0; i < mods.size(); i++) {
                Module* m = mods[i].get();
                if (wantedCategory && (!m->category() ||
                    std::strcmp(m->category(), wantedCategory) != 0))
                    continue;

                // --- measure the card ---
                float setH = 0.0f;
                bool  hasVisible = false;
                for (const auto& sPtr : m->settings()) {
                    Setting* s = sPtr.get();
                    if (!s->mIsVisible()) continue;
                    setH += RowHeight(s);
                    hasVisible = true;
                }
                const bool isTextHotkey =
                    std::strcmp(m->name(), modules::TextHotkey::kModuleName) == 0;
                if (isTextHotkey) { setH += 32.0f; hasVisible = true; }
                if (hasVisible && setH > 0.0f) setH -= 0.0f;
                const float gapN = std::fmax(0.0f, setH > 0.0f ? 1.0f : 0.0f);
                (void)gapN;

                m->cAnim = gui::Animate(
                    (m->showSettings && hasVisible) ? 1.0f : 0.0f,
                    m->cAnim, c.dt * 8.0f);
                m->cAnim = gui::Clamp(m->cAnim, 0.0f, 1.0f);

                const float collapsedH = 56.0f;
                const float expandedH  = 73.0f + setH + 16.0f;
                const float cardH = collapsedH +
                                    (expandedH - collapsedH) * m->cAnim;

                // --- place in the shortest column ---
                int col = 0;
                for (int k = 1; k < cols; k++)
                    if (colY[k] < colY[col]) col = k;
                const float cardX = contentX + 16.0f + (float)col * (colW + gap);
                const float cardY = contentY + 16.0f + colY[col];
                colY[col] += cardH + gap;

                // cull fully clipped cards
                if (cardY + cardH < contentY || cardY > kWinH) continue;

                // --- draw the card ---
                float& ma = m_modAnim[i];
                float& mh = m_modHover[i];
                const bool rowHovered = c.Hover(cardX, cardY, colW, collapsedH);
                mh = gui::Animate(rowHovered ? 1.0f : 0.0f, mh,
                                  gui::Clamp(c.dt * 12.0f, 0.0f, 1.0f));

                FillR(c, cardX, cardY, colW, cardH, kBackground,
                      14.0f, 0.55f);
                StrokeR(c, cardX, cardY, colW, cardH, kBorder, 14.0f, 1.0f);
                if (m_ringAnim[i] > 0.01f)
                    StrokeR(c, cardX, cardY, colW, cardH, c.accent, 14.0f,
                            2.0f, 0.9f * m_ringAnim[i]);

                // header
                if (FontIcon())
                    Glyph(c, cardX + 28.0f, cardY + 28.0f,
                          CategoryIcon(m->category()), 16.0f, kForeground);
                const std::string title = gui::ApplyNaming(m->name());
                const float nth = TextH(FontReg(), 16.0f, c.s);
                Text(c, cardX + 46.0f, cardY + 28.0f - nth * 0.5f,
                     title.c_str(), FontReg(), 16.0f, kForeground);

                const float cyRow = cardY + 28.0f;
                bool toggled = false;
                if (SSDToggle(c, cardX + colW - 60.0f, cyRow, m->enabled(), ma)) {
                    toggled = true;
                    m->toggle();
                    LOG_INFO("menu: %s -> %s", m->name(),
                             m->enabled() ? "ON" : "OFF");
                    ModulePhaseGuard::run(m, m->enabled()
                                              ? ModulePhaseGuard::ENABLE
                                              : ModulePhaseGuard::DISABLE);
                }

                const char* kn = m->key() > 0 ? keys::Name(m->key()) : "None";
                if (SSDKeybindChip(c, cardX + colW - 84.0f, cyRow, kn,
                                   g_bindMod == m)) {
                    g_bindMod     = m;
                    g_bindSetting = nullptr;
                }

                // expand: left click on the free header area or right click
                const bool onControls =
                    c.Hover(cardX + colW - 150.0f, cardY, 150.0f, collapsedH);
                if (hasVisible && !toggled && rowHovered && !onControls &&
                    c.Clicked()) {
                    m->showSettings = !m->showSettings;
                    if (m->showSettings) m_ringAnim[i] = 1.0f;
                }
                if (hasVisible && rowHovered && ImGui::IsMouseClicked(1) &&
                    c.interact && !onControls) {
                    m->showSettings = !m->showSettings;
                    if (m->showSettings) m_ringAnim[i] = 1.0f;
                }

                // ---- expanded settings ----
                if (m->cAnim > 0.01f && hasVisible) {
                    c.d->PushClipRect(c.P(cardX, cardY),
                                      c.P(cardX + colW, cardY + cardH), true);
                    HLine(c, cardX + 16.0f, cardY + 56.0f, colW - 32.0f,
                          0.8f * m->cAnim);
                    float syy = cardY + 73.0f;
                    const float rowW = colW - 32.0f;
                    const float rowX = cardX + 16.0f;
                    bool first = true;
                    for (const auto& sPtr : m->settings()) {
                        Setting* s = sPtr.get();
                        if (!s->mIsVisible()) continue;
                        const float rh = RowHeight(s);
                        const std::string sname =
                            gui::ApplyNaming(s->mName.c_str());

                        switch (s->mType) {
                            case SettingType::Bool: {
                                BoolSetting* bs = static_cast<BoolSetting*>(s);
                                const float th = TextH(FontReg(), 14.0f, c.s);
                                Text(c, rowX, syy + 12.0f - th * 0.5f,
                                     sname.c_str(), FontReg(), 14.0f,
                                     kForeground, m->cAnim);
                                bs->boolScale = gui::Animate(
                                    bs->mValue ? 1.0f : 0.0f, bs->boolScale,
                                    c.dt * 9.0f);
                                if (SSDCheckbox(c, rowX + rowW - 16.0f,
                                                syy + 4.0f, bs->mValue,
                                                bs->boolScale))
                                    bs->mValue = !bs->mValue;
                                break;
                            }
                            case SettingType::Number: {
                                NumberSetting* ns = static_cast<NumberSetting*>(s);
                                const float th = TextH(FontReg(), 14.0f, c.s);
                                Text(c, rowX, syy + 7.0f - th * 0.5f,
                                     sname.c_str(), FontReg(), 14.0f,
                                     kForeground, m->cAnim);
                                const std::string val =
                                    FmtVal(ns->mValue, ns->mStep);
                                const float vw = TextW(FontMono(), val.c_str(),
                                                       12.0f, c.s);
                                MonoText(c, rowX + rowW - vw, syy + 7.0f -
                                         TextH(FontMono(), 12.0f, c.s) * 0.5f,
                                         val.c_str(), 12.0f, c.accent,
                                         m->cAnim);
                                SSDSlider(c, rowX, syy + 26.0f, rowW, ns);
                                break;
                            }
                            case SettingType::Color: {
                                ColorSetting* cs = static_cast<ColorSetting*>(s);
                                const float th = TextH(FontReg(), 14.0f, c.s);
                                Text(c, rowX, syy + 12.0f - th * 0.5f,
                                     sname.c_str(), FontReg(), 14.0f,
                                     kForeground, m->cAnim);
                                if (SSDColorSwatch(c, rowX + rowW - 20.0f,
                                                   syy + 2.0f,
                                                   cs->getAsImColor())) {
                                    g_openColor      = cs;
                                    g_openColorPos   = ImVec2(
                                        win.z - 340.0f * sBase,
                                        win.y + 60.0f * sBase);
                                    g_colorPopupFrame = ImGui::GetFrameCount();
                                }
                                break;
                            }
                            case SettingType::Enum: {
                                EnumSetting* es = static_cast<EnumSetting*>(s);
                                const float th = TextH(FontReg(), 14.0f, c.s);
                                Text(c, rowX, syy + 12.0f - th * 0.5f,
                                     sname.c_str(), FontReg(), 14.0f,
                                     kForeground, m->cAnim);
                                const float ctrlW = std::fmin(170.0f,
                                                              rowW * 0.55f);
                                if ((int)es->mValues.size() == 2) {
                                    SSDSegmented(c, rowX + rowW - ctrlW,
                                                 syy + 3.0f, ctrlW, es);
                                } else {
                                    const bool open = (m_ddSetting == (void*)es);
                                    float ddx = 0.0f, ddy = 0.0f;
                                    if (SSDDropdownButton(
                                            c, rowX + rowW - ctrlW, syy + 3.0f,
                                            ctrlW, es, open, ddx, ddy)) {
                                        if (open) {
                                            m_ddSetting = nullptr;
                                        } else {
                                            m_ddSetting = es;
                                            m_ddPos = ImVec2(
                                                ddx, ddy + c.offsetY);
                                            m_ddW = ctrlW;
                                            m_ddFrame = ImGui::GetFrameCount();
                                        }
                                    }
                                }
                                break;
                            }
                            case SettingType::String: {
                                StringSetting* ss = static_cast<StringSetting*>(s);
                                const float th = TextH(FontReg(), 14.0f, c.s);
                                Text(c, rowX, syy + 1.0f, sname.c_str(),
                                     FontReg(), 14.0f, kForeground, m->cAnim);

                                const bool macroRow =
                                    m->key() >= 0 &&
                                    std::strcmp(m->name(),
                                                modules::TextHotkey::kModuleName) == 0 &&
                                    modules::TextHotkey::IsMacroName(s->mName);
                                float fieldW = rowW;
                                if (macroRow) {
                                    modules::TextHotkey* thm =
                                        static_cast<modules::TextHotkey*>(m);
                                    // delete cross
                                    const float dsz = 24.0f;
                                    const float dx = rowX + rowW - dsz;
                                    const bool dh = c.Hover(dx, syy + 21.0f,
                                                            dsz, dsz);
                                    const float dhov = HoverAnim(
                                        HoverId(s->mName.c_str(), 0x99u),
                                        dh, c.dt);
                                    if (dhov > 0.01f)
                                        FillR(c, dx, syy + 21.0f, dsz, dsz,
                                              gui::LerpColor(kElevated, kDanger,
                                                             dhov), 6.0f);
                                    if (FontIcon())
                                        Glyph(c, dx + dsz * 0.5f,
                                              syy + 21.0f + dsz * 0.5f,
                                              ic::CLOSE, 13.0f,
                                              dhov > 0.5f ? kForeground
                                                          : kMutedFg);
                                    if (dh && c.Clicked()) {
                                        if (g_activeText == ss)
                                            g_activeText = nullptr;
                                        thm->RemoveMacro(ss);
                                        break;
                                    }
                                    // bind chip
                                    if (SSDKeybindChip(
                                            c, dx - 6.0f, syy + 33.0f,
                                            s->mKey > 0 ? keys::Name(s->mKey)
                                                        : "None",
                                            g_bindSetting == ss)) {
                                        g_bindSetting = ss;
                                        g_bindMod     = nullptr;
                                    }
                                    fieldW = dx - 6.0f - 90.0f - rowX;
                                    if (fieldW < 80.0f) fieldW = 80.0f;
                                }

                                const float fdy = syy + 21.0f;
                                const bool active = (g_activeText == ss);
                                FillR(c, rowX, fdy, fieldW, 26.0f, kElevated,
                                      8.0f);
                                StrokeR(c, rowX, fdy, fieldW, 26.0f,
                                        active ? c.accent : kBorder, 8.0f,
                                        active ? 1.2f : 1.0f, m->cAnim);
                                if (active) {
                                    keys::TextInput(g_textBuf, sizeof(g_textBuf), true);
                                    size_t len = strlen(g_textBuf);
                                    if (len > ss->mMaxLength) {
                                        g_textBuf[ss->mMaxLength] = 0;
                                        len = ss->mMaxLength;
                                    }
                                    ss->mValue.assign(g_textBuf);
                                    Text(c, rowX + 10.0f,
                                         fdy + 13.0f -
                                             TextH(FontReg(), 12.0f, c.s) * 0.5f,
                                         g_textBuf, FontReg(), 12.0f,
                                         kForeground);
                                    if ((ImGui::GetFrameCount() / 30) % 2 == 0) {
                                        const float tw2 = TextW(
                                            FontReg(), g_textBuf, 12.0f, c.s);
                                        FillR(c, rowX + 10.0f + tw2 + 1.0f,
                                              fdy + 6.0f, 1.5f, 14.0f,
                                              c.accent, 0.0f, 0.9f);
                                    }
                                    if (keys::PressedThisFrame(VK_RETURN))
                                        g_activeText = nullptr;
                                } else {
                                    const bool empty = ss->mValue.empty();
                                    Text(c, rowX + 10.0f,
                                         fdy + 13.0f -
                                             TextH(FontReg(), 12.0f, c.s) * 0.5f,
                                         empty ? "click to type..."
                                               : ss->mValue.c_str(),
                                         FontReg(), 12.0f,
                                         empty ? kMutedFg : kForeground);
                                    if (c.Hover(rowX, fdy, fieldW, 26.0f) &&
                                        c.Clicked()) {
                                        g_activeText = ss;
                                        const size_t n = ss->mValue.copy(
                                            g_textBuf, sizeof(g_textBuf) - 1);
                                        g_textBuf[n] = 0;
                                    }
                                }
                                break;
                            }
                            default: break;
                        }
                        syy += rh + (first ? 16.0f : 16.0f);
                        first = false;
                    }

                    // Text Hotkey: "+ Add macro" under the entries.
                    if (isTextHotkey) {
                        if (SSDButton(c, rowX, syy, 140.0f, ic::PLUS,
                                      "Add macro")) {
                            static_cast<modules::TextHotkey*>(m)->AddMacro();
                        }
                    }

                    c.d->PopClipRect();
                }

                contentBottom = std::fmax(contentBottom,
                                          (cardY - contentY) + cardH);
            }
        }
        else if (page == TAB_THEME) {
            // ---------------- theme page ----------------
            InterfaceModule* im = InterfaceModule::instance();
            if (im) {
                const float cardW = contentW - 32.0f;
                const float cardX = contentX + 16.0f;
                float yC = contentY + 16.0f;

                // ACCENT swatches
                {
                    const int nThemes = (int)im->m_theme->mValues.size();
                    const float cardH = 16.0f + 20.0f + 8.0f + 28.0f + 16.0f;
                    FillR(c, cardX, yC, cardW, cardH, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Accent", FontReg(),
                         14.0f, kForeground);
                    float sx = cardX + 16.0f;
                    for (int t = 0; t < nThemes; t++) {
                        const ImColor col = gui::PaletteSwatch(t);
                        FillR(c, sx, yC + 44.0f, 28.0f, 28.0f, col, 8.0f);
                        if (t == im->m_theme->mValue)
                            StrokeR(c, sx - 3.0f, yC + 41.0f, 34.0f, 34.0f,
                                    c.accent, 10.0f, 2.0f);
                        else if (c.Hover(sx, yC + 44.0f, 28.0f, 28.0f))
                            StrokeR(c, sx - 2.0f, yC + 42.0f, 32.0f, 32.0f,
                                    kForeground, 9.0f, 1.0f, 0.5f);
                        if (c.Hover(sx, yC + 44.0f, 28.0f, 28.0f) && c.Clicked())
                            im->m_theme->setValue(t);
                        sx += 36.0f;
                    }
                    yC += cardH + 16.0f;
                }

                // custom colours (visible only on Custom)
                if (im->m_colors->mIsVisible()) {
                    const float cardH = 16.0f + 20.0f + 8.0f + 28.0f + 16.0f;
                    FillR(c, cardX, yC, cardW, cardH, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Custom colors",
                         FontReg(), 14.0f, kForeground);
                    ColorSetting* slots[] = { im->m_color1, im->m_color2,
                                              im->m_color3, im->m_color4,
                                              im->m_color5, im->m_color6 };
                    float sx = cardX + 16.0f;
                    for (int i = 0; i < 6; i++) {
                        const bool vis = slots[i] && slots[i]->mIsVisible();
                        FillR(c, sx, yC + 44.0f, 28.0f, 28.0f,
                              vis ? slots[i]->getAsImColor()
                                  : ImColor(0, 0, 0, 0),
                              8.0f, vis ? 1.0f : 0.25f);
                        StrokeR(c, sx, yC + 44.0f, 28.0f, 28.0f, kBorder, 8.0f,
                                1.0f, vis ? 1.0f : 0.25f);
                        if (vis && c.Hover(sx, yC + 44.0f, 28.0f, 28.0f) &&
                            c.Clicked()) {
                            g_openColor       = slots[i];
                            g_openColorPos    = ImVec2(win.z - 340.0f * sBase,
                                                       win.y + 60.0f * sBase);
                            g_colorPopupFrame = ImGui::GetFrameCount();
                        }
                        sx += 36.0f;
                    }
                    yC += cardH + 16.0f;

                    // colour slots slider
                    {
                        const float cardH2 = 16.0f + 20.0f + 46.0f + 16.0f;
                        FillR(c, cardX, yC, cardW, cardH2, kBackground, 14.0f,
                              0.55f);
                        StrokeR(c, cardX, yC, cardW, cardH2, kBorder, 14.0f,
                                1.0f);
                        Text(c, cardX + 16.0f, yC + 16.0f, "Color slots",
                             FontReg(), 14.0f, kForeground);
                        const std::string val = FmtVal(im->m_colors->mValue, 1.0f);
                        const float vw = TextW(FontMono(), val.c_str(), 12.0f, c.s);
                        MonoText(c, cardX + cardW - 16.0f - vw, yC + 17.0f,
                                 val.c_str(), 12.0f, c.accent);
                        SSDSlider(c, cardX + 16.0f, yC + 52.0f, cardW - 32.0f,
                                  im->m_colors);
                        yC += cardH2 + 16.0f;
                    }

                    if (im->m_saturation->mIsVisible()) {
                        const float cardH3 = 16.0f + 20.0f + 46.0f + 16.0f;
                        FillR(c, cardX, yC, cardW, cardH3, kBackground, 14.0f,
                              0.55f);
                        StrokeR(c, cardX, yC, cardW, cardH3, kBorder, 14.0f,
                                1.0f);
                        Text(c, cardX + 16.0f, yC + 16.0f, "Saturation",
                             FontReg(), 14.0f, kForeground);
                        const std::string val =
                            FmtVal(im->m_saturation->mValue, 0.01f);
                        const float vw = TextW(FontMono(), val.c_str(), 12.0f, c.s);
                        MonoText(c, cardX + cardW - 16.0f - vw, yC + 17.0f,
                                 val.c_str(), 12.0f, c.accent);
                        SSDSlider(c, cardX + 16.0f, yC + 52.0f, cardW - 32.0f,
                                  im->m_saturation);
                        yC += cardH3 + 16.0f;
                    }
                }

                // naming
                {
                    const float cardH4 = 16.0f + 20.0f + 30.0f + 16.0f;
                    FillR(c, cardX, yC, cardW, cardH4, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH4, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Naming", FontReg(),
                         14.0f, kForeground);
                    const bool open = (m_ddSetting == (void*)im->m_namingStyle);
                    float ddx = 0.0f, ddy = 0.0f;
                    if (SSDDropdownButton(c, cardX + cardW - 16.0f - 170.0f,
                                          yC + 14.0f, 170.0f,
                                          im->m_namingStyle, open, ddx, ddy)) {
                        if (open) m_ddSetting = nullptr;
                        else {
                            m_ddSetting = im->m_namingStyle;
                            m_ddPos = ImVec2(ddx, ddy + c.offsetY);
                            m_ddW = 170.0f;
                            m_ddFrame = ImGui::GetFrameCount();
                        }
                    }
                    yC += cardH4 + 16.0f;
                }

                // accent motion (the color-cycling speed)
                {
                    const float cardH5 = 16.0f + 20.0f + 46.0f + 16.0f;
                    FillR(c, cardX, yC, cardW, cardH5, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH5, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Accent motion",
                         FontReg(), 14.0f, kForeground);
                    const std::string val =
                        FmtVal(im->m_colorSpeed->mValue, 0.05f);
                    const float vw = TextW(FontMono(), val.c_str(), 12.0f, c.s);
                    MonoText(c, cardX + cardW - 16.0f - vw, yC + 17.0f,
                             val.c_str(), 12.0f, c.accent);
                    SSDSlider(c, cardX + 16.0f, yC + 52.0f, cardW - 32.0f,
                              im->m_colorSpeed);
                    yC += cardH5 + 16.0f;
                }

                contentBottom = (yC - contentY);
            }
        }
        else if (page == TAB_SETTINGS) {
            // ---------------- config / client settings page ----------------
            ClickGuiModule* cg = ClickGuiModule::instance();
            FlarialSettingsModule* fs = FlarialSettingsModule::instance();
            const float cardW = contentW - 32.0f;
            const float cardX = contentX + 16.0f;
            float yC = contentY + 16.0f;

            if (cg) {
                // CONFIG card
                {
                    const float cardH = 16.0f + 20.0f + 12.0f + 32.0f + 10.0f +
                                        18.0f + 16.0f;
                    FillR(c, cardX, yC, cardW, cardH, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Config", FontReg(),
                         14.0f, kForeground);
                    if (SSDButton(c, cardX + 16.0f, yC + 48.0f, 180.0f,
                                  ic::PLAY, "Save Config")) {
                        config::Save();
                        LOG_INFO("menu: config saved");
                    }
                    if (SSDButton(c, cardX + 206.0f, yC + 48.0f, 180.0f,
                                  ic::REFRESH, "Load Config")) {
                        config::Load();
                        LOG_INFO("menu: config loaded");
                    }
                    Text(c, cardX + 16.0f, yC + cardH - 24.0f,
                         "Changes autosave 1.5 s after the last edit",
                         FontReg(), 12.0f, kMutedFg);
                    yC += cardH + 16.0f;
                }

                // MENU card (animation + glass material)
                {
                    float rows = 0.0f;
                    rows += 30.0f + 16.0f;   // animation dropdown
                    rows += 24.0f + 16.0f;   // glass checkbox
                    rows += 7.0f * (46.0f + 16.0f);
                    const float cardH = 16.0f + 20.0f + 12.0f + rows + 4.0f;
                    FillR(c, cardX, yC, cardW, cardH, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, cardH, kBorder, 14.0f, 1.0f);
                    Text(c, cardX + 16.0f, yC + 16.0f, "Menu", FontReg(),
                         14.0f, kForeground);
                    float syy = yC + 48.0f;
                    const float rowW = cardW - 32.0f;
                    const float rowX = cardX + 16.0f;

                    // animation dropdown
                    {
                        const bool open =
                            (m_ddSetting == (void*)cg->m_animation);
                        float ddx = 0.0f, ddy = 0.0f;
                        if (SSDDropdownButton(c, rowX + rowW - 170.0f, syy,
                                              170.0f, cg->m_animation, open,
                                              ddx, ddy)) {
                            if (open) m_ddSetting = nullptr;
                            else {
                                m_ddSetting = cg->m_animation;
                                m_ddPos = ImVec2(ddx, ddy + c.offsetY);
                                m_ddW = 170.0f;
                                m_ddFrame = ImGui::GetFrameCount();
                            }
                        }
                        const float th = TextH(FontReg(), 14.0f, c.s);
                        Text(c, rowX, syy + 12.0f - th * 0.5f, "Animation",
                             FontReg(), 14.0f, kForeground);
                        syy += 30.0f + 16.0f;
                    }
                    // glass checkbox
                    if (cg->m_glass) {
                        const float th = TextH(FontReg(), 14.0f, c.s);
                        Text(c, rowX, syy + 12.0f - th * 0.5f, "Glass",
                             FontReg(), 14.0f, kForeground);
                        cg->m_glass->boolScale = gui::Animate(
                            cg->m_glass->mValue ? 1.0f : 0.0f,
                            cg->m_glass->boolScale, c.dt * 9.0f);
                        if (SSDCheckbox(c, rowX + rowW - 16.0f, syy + 4.0f,
                                        cg->m_glass->mValue,
                                        cg->m_glass->boolScale))
                            cg->m_glass->setValue(!cg->m_glass->mValue);
                        syy += 24.0f + 16.0f;
                    }
                    // sliders
                    struct NumRow { const char* label; NumberSetting* ns; };
                    const NumRow numrows[] = {
                        { "Ease Speed",        cg->m_easeSpeed         },
                        { "Blur Strength",     cg->m_blurStrength      },
                        { "Transparency",      cg->m_transparency      },
                        { "Panel Opacity",     cg->m_panelOpacity      },
                        { "Border Opacity",    cg->m_borderOpacity     },
                        { "Corner Radius",     cg->m_cornerRadius      },
                        { "MidClick Rounding", cg->m_midclickRounding  },
                    };
                    for (const NumRow& r : numrows) {
                        if (!r.ns) continue;
                        const float th = TextH(FontReg(), 14.0f, c.s);
                        Text(c, rowX, syy + 7.0f - th * 0.5f, r.label,
                             FontReg(), 14.0f, kForeground);
                        const std::string val = FmtVal(r.ns->mValue, r.ns->mStep);
                        const float vw = TextW(FontMono(), val.c_str(), 12.0f, c.s);
                        MonoText(c, rowX + rowW - vw,
                                 syy + 7.0f - TextH(FontMono(), 12.0f, c.s) * 0.5f,
                                 val.c_str(), 12.0f, c.accent);
                        SSDSlider(c, rowX, syy + 26.0f, rowW, r.ns);
                        syy += 46.0f + 16.0f;
                    }
                    yC += cardH + 16.0f;
                }
            }

            if (fs) {
                // FLARIAL HUD card
                float rows = 3.0f * (46.0f + 16.0f) + 2.0f * (24.0f + 16.0f);
                const float cardH = 16.0f + 20.0f + 12.0f + rows + 4.0f;
                FillR(c, cardX, yC, cardW, cardH, kBackground, 14.0f, 0.55f);
                StrokeR(c, cardX, yC, cardW, cardH, kBorder, 14.0f, 1.0f);
                Text(c, cardX + 16.0f, yC + 16.0f, "HUD", FontReg(), 14.0f,
                     kForeground);
                float syy = yC + 48.0f;
                const float rowW = cardW - 32.0f;
                const float rowX = cardX + 16.0f;
                struct NumRow { const char* label; NumberSetting* ns; };
                const NumRow numrows[] = {
                    { "HUD Scale",   fs->m_hudScale   },
                    { "HUD Padding", fs->m_hudPadding },
                    { "Font Scale",  fs->m_fontScale  },
                };
                for (const NumRow& r : numrows) {
                    if (!r.ns) continue;
                    const float th = TextH(FontReg(), 14.0f, c.s);
                    Text(c, rowX, syy + 7.0f - th * 0.5f, r.label, FontReg(),
                         14.0f, kForeground);
                    const std::string val = FmtVal(r.ns->mValue, r.ns->mStep);
                    const float vw = TextW(FontMono(), val.c_str(), 12.0f, c.s);
                    MonoText(c, rowX + rowW - vw,
                             syy + 7.0f - TextH(FontMono(), 12.0f, c.s) * 0.5f,
                             val.c_str(), 12.0f, c.accent);
                    SSDSlider(c, rowX, syy + 26.0f, rowW, r.ns);
                    syy += 46.0f + 16.0f;
                }
                struct BoolRow { const char* label; BoolSetting* bs; };
                const BoolRow boolrows[] = {
                    { "Hide in menu", fs->m_hideHudInMenu },
                    { "Text shadows", fs->m_shadows       },
                };
                for (const BoolRow& r : boolrows) {
                    if (!r.bs) continue;
                    const float th = TextH(FontReg(), 14.0f, c.s);
                    Text(c, rowX, syy + 12.0f - th * 0.5f, r.label, FontReg(),
                         14.0f, kForeground);
                    r.bs->boolScale = gui::Animate(r.bs->mValue ? 1.0f : 0.0f,
                                                   r.bs->boolScale, c.dt * 9.0f);
                    if (SSDCheckbox(c, rowX + rowW - 16.0f, syy + 4.0f,
                                    r.bs->mValue, r.bs->boolScale))
                        r.bs->mValue = !r.bs->mValue;
                    syy += 24.0f + 16.0f;
                }
                yC += cardH + 16.0f;
            }

            contentBottom = (yC - contentY);
        }
        else if (page == TAB_FRIENDS) {
            // ---------------- friends page ----------------
            modules::FriendsModule*  fm = modules::FriendsModule::instance();
            modules::MidClickModule* mc = modules::MidClickModule::instance();
            const float cardW = 300.0f;
            const float cardX = contentX + 16.0f;
            float yC = contentY + 16.0f;

            // Mid Click card
            {
                FillR(c, cardX, yC, cardW, 56.0f, kBackground, 14.0f, 0.55f);
                StrokeR(c, cardX, yC, cardW, 56.0f, kBorder, 14.0f, 1.0f);
                if (FontIcon())
                    Glyph(c, cardX + 28.0f, yC + 28.0f, ic::MOUSE, 16.0f,
                          kForeground);
                const float nth = TextH(FontReg(), 16.0f, c.s);
                Text(c, cardX + 46.0f, yC + 28.0f - nth * 0.5f, "Mid Click",
                     FontReg(), 16.0f, kForeground);
                if (mc) {
                    const bool hit = SSDToggle(c, cardX + cardW - 60.0f,
                                               yC + 28.0f, mc->enabled(),
                                               m_midClickAnim);
                    if (hit) {
                        mc->toggle();
                        LOG_INFO("menu: Mid Click -> %s",
                                 mc->enabled() ? "ON" : "OFF");
                        ModulePhaseGuard::run(
                            mc, mc->enabled() ? ModulePhaseGuard::ENABLE
                                              : ModulePhaseGuard::DISABLE);
                    }
                }
                yC += 56.0f + 16.0f;
            }

            // Add Friend form card (inline, SystemDLC FriendAddForm style)
            {
                FillR(c, cardX, yC, cardW, 78.0f, kBackground, 14.0f, 0.55f);
                StrokeR(c, cardX, yC, cardW, 78.0f, kBorder, 14.0f, 1.0f);
                FillR(c, cardX + 16.0f, yC + 23.0f, 32.0f, 32.0f, kElevated,
                      8.0f);
                if (FontIcon())
                    Glyph(c, cardX + 32.0f, yC + 39.0f, ic::PLUS, 15.0f,
                          c.accent);

                const float fx = cardX + 56.0f;
                const float fy = yC + 23.0f;
                const float fw = 168.0f;
                const bool focused = m_addFriendOpen;
                FillR(c, fx, fy, fw, 32.0f, kElevated, 8.0f);
                StrokeR(c, fx, fy, fw, 32.0f,
                        focused ? c.accent : kBorder, 8.0f, focused ? 1.2f : 1.0f);
                const bool hasText = m_friendBuf[0] != 0;
                const float th2 = TextH(FontReg(), 13.0f, c.s);
                Text(c, fx + 10.0f, fy + 16.0f - th2 * 0.5f,
                     hasText ? m_friendBuf : "Nickname...",
                     FontReg(), 13.0f, hasText ? kForeground : kMutedFg,
                     hasText ? 1.0f : 0.7f);
                if (focused && ((ImGui::GetFrameCount() / 30) % 2 == 0)) {
                    const float tw2 = TextW(FontReg(), m_friendBuf, 13.0f, c.s);
                    FillR(c, fx + 10.0f + tw2 + 2.0f, fy + 8.0f, 1.5f, 16.0f,
                          c.accent, 0.0f, 0.9f);
                }
                if (c.Hover(fx, fy, fw, 32.0f) && c.Clicked() &&
                    !m_addFriendOpen) {
                    m_addFriendOpen  = true;
                    m_addFriendFrame = ImGui::GetFrameCount();
                    m_friendDup      = false;
                }
                if (!c.Hover(cardX, yC, cardW, 78.0f) && c.Clicked() &&
                    m_addFriendOpen)
                    m_addFriendOpen = false;

                // submit
                {
                    const float bx = cardX + cardW - 16.0f - 32.0f;
                    const bool hov = c.Hover(bx, fy, 32.0f, 32.0f);
                    if (hov) FillR(c, bx, fy, 32.0f, 32.0f, c.accent, 8.0f);
                    if (FontIcon())
                        Glyph(c, bx + 16.0f, fy + 16.0f, ic::PLUS, 14.0f,
                              hov ? kSolid : kMutedFg);
                    if (hov && c.Clicked()) CommitAddFriend();
                }
                if (m_friendDup)
                    Text(c, fx, yC + 62.0f, "Already in your friends list",
                         FontReg(), 11.0f, c.accent, 0.9f);

                if (focused) {
                    if (keys::TextInput(m_friendBuf, sizeof(m_friendBuf), true))
                        m_friendDup = false;
                    if (keys::PressedThisFrame(VK_RETURN)) CommitAddFriend();
                }
                yC += 78.0f + 16.0f;
            }

            // Friends list
            if (fm) {
                const auto&  fl    = fm->friends();
                const size_t count = fl.size();
                const float rowGap = 12.0f;

                for (size_t i = 0; i < count; i++) {
                    const std::string& name = fl[i];
                    FillR(c, cardX, yC, cardW, 56.0f, kBackground, 14.0f, 0.55f);
                    StrokeR(c, cardX, yC, cardW, 56.0f, kBorder, 14.0f, 1.0f);
                    FillR(c, cardX + 12.0f, yC + 12.0f, 32.0f, 32.0f, kElevated,
                          8.0f);
                    const char initial = name.empty() ? '?'
                                        : (char)std::toupper((unsigned char)name[0]);
                    const char ic2[2] = { initial, 0 };
                    TextCenter(c, cardX + 28.0f, yC + 28.0f, ic2, FontDisplay(),
                               15.0f, kForeground);
                    const float nth = TextH(FontReg(), 15.0f, c.s);
                    Text(c, cardX + 56.0f, yC + 28.0f - nth * 0.5f,
                         name.c_str(), FontReg(), 15.0f, kForeground);

                    // remove button
                    const float bx = cardX + cardW - 12.0f - 24.0f;
                    const bool  hov = c.Hover(bx, yC + 16.0f, 24.0f, 24.0f);
                    const float dhov = HoverAnim(
                        HoverId(name.c_str(), 0xA1u), hov, c.dt);
                    if (dhov > 0.01f)
                        FillR(c, bx, yC + 16.0f, 24.0f, 24.0f,
                              gui::LerpColor(kElevated, kDanger, dhov), 6.0f);
                    if (FontIcon())
                        Glyph(c, bx + 12.0f, yC + 28.0f, ic::MINUS, 13.0f,
                              dhov > 0.5f ? kForeground : kMutedFg);
                    if (hov && c.Clicked()) {
                        fm->removeFriend(name);
                        fm->showToast(name, false);
                        LOG_INFO("menu: friend removed %s", name.c_str());
                    }
                    yC += 56.0f + rowGap;
                }

                if (count == 0)
                    Text(c, cardX, yC,
                         "No friends yet - add one above, or middle-click a player",
                         FontReg(), 12.0f, kMutedFg, 0.8f);
            }

            contentBottom = (yC - contentY);
        }

        // Friends page keeps its own (page) scroll: wheel is enabled there too.
        m_pageContentHeight[page] = std::fmax(0.0f, contentBottom - 16.0f);

        // top/bottom content fades
        {
            const float maxScroll = std::fmax(
                0.0f, m_pageContentHeight[page] - contentH);
            const float aTop = gui::Clamp(m_pageScroll[page] / 48.0f, 0.0f, 1.0f);
            const float aBot = gui::Clamp((maxScroll - m_pageScroll[page]) / 48.0f,
                                          0.0f, 1.0f);
            const float fadeH = 64.0f;
            const ImColor bg = kBackground;
            if (aTop > 0.001f) {
                c.d->AddRectFilledMultiColor(
                    baseContent.P(contentX, contentY),
                    baseContent.P(kWinW, contentY + fadeH),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z,
                            bg.Value.w * animation * 0.9f * aTop),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z,
                            bg.Value.w * animation * 0.9f * aTop),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z, 0.0f),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z, 0.0f));
            }
            if (aBot > 0.001f) {
                c.d->AddRectFilledMultiColor(
                    baseContent.P(contentX, kWinH - fadeH),
                    baseContent.P(kWinW, kWinH),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z, 0.0f),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z, 0.0f),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z,
                            bg.Value.w * animation * 0.9f * aBot),
                    ImColor(bg.Value.x, bg.Value.y, bg.Value.z,
                            bg.Value.w * animation * 0.9f * aBot));
            }
        }

        // scrollbar
        {
            const float maxScroll = std::fmax(
                0.0f, m_pageContentHeight[page] - contentH);
            if (maxScroll > 0.0f) {
                const float sbW = 2.0f;
                const float sbX = kWinW - 8.0f;
                const float thumbH = std::fmax(
                    28.0f, contentH * contentH /
                               std::fmax(1.0f, m_pageContentHeight[page]));
                const float thumbY = contentY + 4.0f +
                    (contentH - 8.0f - thumbH) *
                        (m_pageScroll[page] / maxScroll);
                FillR(c, sbX, thumbY, sbW, thumbH, kMutedFg, 1.0f, 0.45f);
            }
        }

        c.d->PopClipRect();
        c.offsetY = 0.0f;

        // ==================== open enum dropdown (overlay) ====================
        if (m_ddSetting) {
            EnumSetting* es = static_cast<EnumSetting*>(m_ddSetting);
            const int   n   = (int)es->mValues.size();
            const float panelH = std::fmin((float)n * 30.0f + 8.0f, 240.0f);
            const float panelW = std::fmax(m_ddW, 170.0f);
            float px2 = m_ddPos.x;
            float py2 = m_ddPos.y;
            if (py2 + panelH > kWinH - 8.0f)
                py2 = m_ddPos.y - panelH - 28.0f;
            FillR(c, px2, py2, panelW, panelH, kSurface, 8.0f);
            StrokeR(c, px2, py2, panelW, panelH, kBorder, 8.0f, 1.0f);
            c.d->PushClipRect(c.P(px2, py2), c.P(px2 + panelW, py2 + panelH),
                              true);
            const int scrollN = (n * 30 + 8 > 240)
                                    ? (int)((n * 30 + 8 - 240) / 30) + 1 : 0;
            (void)scrollN;
            const int maxVisible = (int)((panelH - 8.0f) / 30.0f);
            for (int j = 0; j < n && j < maxVisible + 1; j++) {
                const float iy = py2 + 4.0f + (float)j * 30.0f;
                const bool hov = c.Hover(px2 + 4.0f, iy, panelW - 8.0f, 28.0f);
                if (hov)
                    FillR(c, px2 + 4.0f, iy, panelW - 8.0f, 28.0f, kElevated,
                          6.0f, 0.6f);
                if (j == es->mValue) {
                    c.d->AddCircleFilled(c.P(px2 + 14.0f, iy + 14.0f),
                                         c.px(3.0f),
                                         ImColor(c.accent.Value.x,
                                                 c.accent.Value.y,
                                                 c.accent.Value.z, c.anim));
                }
                const float th = TextH(FontReg(), 12.0f, c.s);
                Text(c, px2 + 26.0f, iy + 14.0f - th * 0.5f,
                     es->mValues[j].c_str(), FontReg(), 12.0f,
                     j == es->mValue ? kForeground : kMutedFg);
                if (hov && c.Clicked()) {
                    es->setValue(j);
                    m_ddSetting = nullptr;
                }
            }
            c.d->PopClipRect();

            if (c.interact && ImGui::IsMouseClicked(0) &&
                !c.Hover(px2, py2, panelW, panelH) &&
                ImGui::GetFrameCount() != m_ddFrame)
                m_ddSetting = nullptr;
        }
    }

    c.d->PopClipRect();

    // ==================== search modal (screen space) ====================
    if (m_searchOpen && animation > 0.05f) {
        Ctx sc;
        sc.d        = ImGui::GetBackgroundDrawList();
        sc.s        = sBase;
        sc.anim     = animation;
        sc.interact = isEnabled && !ImGui::GetIO().WantCaptureMouse;
        sc.dt       = c.dt;
        sc.accent   = c.accent;

        const float pw = 448.0f, ph = 304.0f;
        const float pxs = (screen.x / sBase - pw) * 0.5f;
        const float pys = (screen.y / sBase - ph) * 0.5f;

        // dim behind (like the reference's search scrim)
        sc.d->AddRectFilled(ImVec2(0, 0), screen,
                            ImColor(0, 0, 0, (int)(128.0f * animation)));

        FillR(sc, pxs, pys, pw, ph, kBackground, 12.0f);
        StrokeR(sc, pxs, pys, pw, ph, kBorder, 12.0f, 1.0f);

        // input row
        SearchGlyph(sc, pxs + 22.0f, pys + 20.0f, 14.0f, kMutedFg);
        const bool hasQ = m_searchBuf[0] != 0;
        const float th = TextH(FontReg(), 14.0f, sc.s);
        Text(sc, pxs + 40.0f, pys + 20.0f - th * 0.5f,
             hasQ ? m_searchBuf : "Search modules and settings...",
             FontReg(), 14.0f, hasQ ? kForeground : kMutedFg,
             hasQ ? 1.0f : 0.6f);
        if (((ImGui::GetFrameCount() / 30) % 2) == 0) {
            const float tw = TextW(FontReg(),
                                   hasQ ? m_searchBuf : "", 14.0f, sc.s);
            FillR(sc, pxs + 40.0f + tw + 2.0f, pys + 12.0f, 1.5f, 16.0f,
                  c.accent, 0.0f, 0.9f);
        }
        HLine(sc, pxs + 1.0f, pys + 40.0f, pw - 2.0f);

        // build results (bounded by the registry size)
        m_searchIdx.clear();
        m_searchKind.clear();
        m_searchText.clear();
        {
            char q[64];
            LowerCopy(q, sizeof(q), m_searchBuf);
            const bool filtering = q[0] != 0;
            for (size_t i = 0; i < mods.size() &&
                               m_searchIdx.size() < 32; i++) {
                Module* m = mods[i].get();
                const int pg = CategoryToPage(m->category());
                if (pg < 0) continue;
                char nl[96];
                LowerCopy(nl, sizeof(nl), m->name());
                const bool modHit = !filtering || std::strstr(nl, q) != nullptr;
                if (modHit) {
                    m_searchIdx.push_back((int)i);
                    m_searchKind.push_back(0);
                    m_searchText.push_back(std::string());
                }
                if (filtering) {
                    for (const auto& sPtr : m->settings()) {
                        if (m_searchIdx.size() >= 32) break;
                        Setting* s = sPtr.get();
                        if (!s->mIsVisible()) continue;
                        char sl[96];
                        LowerCopy(sl, sizeof(sl), s->mName.c_str());
                        if (std::strstr(sl, q) != nullptr &&
                            std::strstr(nl, q) == nullptr) {
                            m_searchIdx.push_back((int)i);
                            m_searchKind.push_back(1);
                            m_searchText.push_back(
                                gui::ApplyNaming(s->mName.c_str()));
                        }
                    }
                }
            }
        }

        // results viewport
        const float vx = pxs + 4.0f;
        const float vy = pys + 41.0f;
        const float vw2 = pw - 8.0f;
        const float vh2 = ph - 41.0f - 8.0f;
        const float rowH2 = 32.0f;
        const float rowGap2 = 4.0f;
        const size_t nR = m_searchIdx.size();
        const float contentH2 =
            nR ? (float)nR * (rowH2 + rowGap2) - rowGap2 : 0.0f;
        const float maxScroll2 = std::fmax(0.0f, contentH2 - vh2);
        if (sc.interact && maxScroll2 > 0.0f &&
            sc.Hover(vx, vy, vw2, vh2)) {
            const float notches = WheelNotches();
            if (notches != 0.0f) m_searchScrollTo -= notches * 48.0f;
        }
        m_searchScrollTo = gui::Clamp(m_searchScrollTo, 0.0f, maxScroll2);
        m_searchScroll = gui::Animate(m_searchScrollTo, m_searchScroll,
                                      sc.dt * 14.0f);
        m_searchScroll = gui::Clamp(m_searchScroll, 0.0f, maxScroll2);

        sc.d->PushClipRect(sc.P(vx, vy), sc.P(vx + vw2, vy + vh2), true);
        if (nR == 0) {
            Text(sc, pxs + 16.0f, pys + 52.0f,
                 hasQ ? "No matches" : "Type to search", FontReg(), 12.0f,
                 kMutedFg, 0.8f);
        }
        for (size_t r = 0; r < nR; r++) {
            const float ry = vy - m_searchScroll + (float)r * (rowH2 + rowGap2);
            if (ry + rowH2 <= vy || ry >= vy + vh2) continue;
            Module* m = mods[(size_t)m_searchIdx[r]].get();
            const bool selRow = ((int)r == m_searchSel);
            const bool hov = sc.Hover(vx, ry, vw2, rowH2);
            if (selRow || hov)
                FillR(sc, vx, ry, vw2, rowH2, kElevated, 8.0f,
                      selRow ? 1.0f : 0.6f);
            if (FontIcon())
                Glyph(sc, vx + 20.0f, ry + 16.0f, CategoryIcon(m->category()),
                      14.0f, kForeground);
            const std::string tname = gui::ApplyNaming(m->name());
            float tx = vx + 36.0f;
            Text(sc, tx, ry + 10.0f, tname.c_str(), FontReg(), 14.0f,
                 kForeground);
            if (m_searchKind[r] == 1 && r < m_searchText.size()) {
                tx += TextW(FontReg(), tname.c_str(), 14.0f, sc.s) + 6.0f;
                Text(sc, tx, ry + 12.0f, m_searchText[r].c_str(), FontReg(),
                     12.0f, kMutedFg);
            }
            if (hov && sc.Clicked()) {
                m_searchSel = (int)r;
                // activate below (same as Enter)
                const int pg = CategoryToPage(m->category());
                if (pg >= 0) {
                    if (m_tab != pg) {
                        m_titleDir  = pg > m_tab ? 1 : -1;
                        m_titleT    = 0.0f;
                        m_pageSlideT = 0.0f;
                    }
                    m_tab = pg;
                    m->showSettings = m_searchKind[r] == 1 || m->showSettings;
                    if (m_searchKind[r] == 1 && (size_t)m_searchIdx[r] <
                        m_ringAnim.size())
                        m_ringAnim[(size_t)m_searchIdx[r]] = 1.0f;
                }
                m_searchOpen = false;
                m_searchBuf[0] = 0;
            }
        }
        sc.d->PopClipRect();

        // keyboard: arrows + enter + escape, fed by the overlay key snapshot
        if (nR > 0) {
            if (keys::PressedThisFrame(0x26)) {  // VK_UP
                m_searchSel = m_searchSel <= 0 ? (int)nR - 1 : m_searchSel - 1;
                const float selTop = (float)m_searchSel * (rowH2 + rowGap2);
                if (selTop < m_searchScrollTo)
                    m_searchScrollTo = std::fmax(0.0f, selTop - 4.0f);
                else if (selTop + rowH2 > m_searchScrollTo + vh2)
                    m_searchScrollTo = selTop + rowH2 - vh2 + 4.0f;
            }
            if (keys::PressedThisFrame(0x28)) {  // VK_DOWN
                m_searchSel = m_searchSel >= (int)nR - 1 ? 0 : m_searchSel + 1;
                const float selTop = (float)m_searchSel * (rowH2 + rowGap2);
                if (selTop < m_searchScrollTo)
                    m_searchScrollTo = std::fmax(0.0f, selTop - 4.0f);
                else if (selTop + rowH2 > m_searchScrollTo + vh2)
                    m_searchScrollTo = selTop + rowH2 - vh2 + 4.0f;
            }
            if (keys::PressedThisFrame(VK_RETURN) && m_searchSel >= 0 &&
                m_searchSel < (int)nR) {
                Module* m = mods[(size_t)m_searchIdx[(size_t)m_searchSel]].get();
                const int pg = CategoryToPage(m->category());
                if (pg >= 0) {
                    if (m_tab != pg) {
                        m_titleDir  = pg > m_tab ? 1 : -1;
                        m_titleT    = 0.0f;
                        m_pageSlideT = 0.0f;
                    }
                    m_tab = pg;
                    const bool settingHit =
                        m_searchKind[(size_t)m_searchSel] == 1;
                    m->showSettings = settingHit || m->showSettings;
                    if ((size_t)m_searchIdx[(size_t)m_searchSel] <
                        m_ringAnim.size())
                        m_ringAnim[(size_t)m_searchIdx[(size_t)m_searchSel]] =
                            1.0f;
                }
                m_searchOpen = false;
                m_searchBuf[0] = 0;
            }
        }
        keys::TextInput(m_searchBuf, sizeof(m_searchBuf), true);
        if (keys::PressedThisFrame(VK_ESCAPE)) {
            m_searchOpen = false;
            m_searchBuf[0] = 0;
        }

        // click outside dismisses (not on the opening frame)
        if (sc.interact && ImGui::IsMouseClicked(0) &&
            !sc.Hover(pxs, pys, pw, ph) &&
            ImGui::GetFrameCount() != m_searchFrame) {
            m_searchOpen = false;
            m_searchBuf[0] = 0;
        }
    }

    // ==================== keybind capture ====================
    if (g_bindMod) {
        for (int vk = 8; vk <= 0xFE && g_bindMod; vk++) {
            if (keys::PressedThisFrame(vk)) {
                g_bindMod->setKey(vk == VK_ESCAPE ? 0 : vk);
                LOG_INFO("menu: bound %s -> %s", g_bindMod->name(),
                         (vk == VK_ESCAPE) ? "none" : keys::Name(vk));
                g_bindMod = nullptr;
            }
        }
    }
    if (g_bindSetting) {
        for (int vk = 8; vk <= 0xFE && g_bindSetting; vk++) {
            if (keys::PressedThisFrame(vk)) {
                Setting* s = static_cast<Setting*>(g_bindSetting);
                s->mKey = (vk == VK_ESCAPE) ? 0 : vk;
                LOG_INFO("menu: bound setting %s -> %s", s->mName.c_str(),
                         (vk == VK_ESCAPE) ? "none" : keys::Name(vk));
                g_bindSetting = nullptr;
            }
        }
    }

    // ==================== colour picker popup ====================
    if (g_openColor) {
        ColorSetting* cs = static_cast<ColorSetting*>(g_openColor);
        const float w = 320.0f, h = 320.0f;
        ImVec2 pos = g_openColorPos;
        if (pos.x + w > screen.x) pos.x = screen.x - w - 8.0f;
        if (pos.y + h > screen.y) pos.y = screen.y - h - 8.0f;
        ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
        ImGui::Begin("##nf_color", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoTitleBar);
        ImGui::ColorPicker4("##nf_picker", cs->mValue,
                            ImGuiColorEditFlags_AlphaBar);
        if (ImGui::Button("Close", ImVec2(-1.0f, 0.0f)))
            g_openColor = nullptr;
        ImGui::End();

        if (ImGui::IsMouseClicked(0) && !ImGui::GetIO().WantCaptureMouse &&
            ImGui::GetFrameCount() != g_colorPopupFrame)
            g_openColor = nullptr;
    }

    // ==================== window drag (top bar + logo row) ====================
    if (sEff > 0.05f) {
        static bool   s_dragging = false;
        static ImVec2 s_grab(0, 0);
        const float sideW = gui::Lerp(48.0f, 224.0f, m_sideAnim);
        const bool overTop = c.Hover(sideW + 52.0f, 0.0f,
                                     kWinW - sideW - 202.0f, kTopH);
        const bool overLogo = c.Hover(0.0f, 0.0f, sideW, kTopH);
        if (c.interact && !s_dragging && (overTop || overLogo) &&
            ImGui::IsMouseClicked(0)) {
            s_dragging = true;
            s_grab     = gui::GetMousePos();
        }
        if (s_dragging) {
            if (ImGui::IsMouseDown(0)) {
                const ImVec2 mp = gui::GetMousePos();
                m_winOffset.x += mp.x - s_grab.x;
                m_winOffset.y += mp.y - s_grab.y;
                s_grab = mp;
            } else {
                s_dragging = false;
            }
        }
        if (!isEnabled) s_dragging = false;
    }
}

// ======================== friends form actions ========================
void CitronGui::OpenAddFriend() {
    m_addFriendOpen  = true;
    m_addFriendFrame = ImGui::GetFrameCount();
    m_friendBuf[0]   = 0;
    m_friendDup      = false;
}

void CitronGui::CloseAddFriend() {
    m_addFriendOpen  = false;
    m_friendBuf[0]   = 0;
    m_friendDup      = false;
}

void CitronGui::CommitAddFriend() {
    modules::FriendsModule* fm = modules::FriendsModule::instance();
    if (!fm) { CloseAddFriend(); return; }

    const std::string name = TrimName(m_friendBuf);
    if (name.empty()) { CloseAddFriend(); return; }

    if (!fm->addFriend(name)) {
        m_friendDup = true;
        return;
    }

    fm->showToast(name, true);
    LOG_INFO("menu: friend added %s (%d total)", name.c_str(),
             (int)fm->friends().size());
    CloseAddFriend();
}

} // namespace ui
