// overlay.h - the engine facade: lifecycle + shared menu state.
//
// The overlay owns: DXGI Present/ResizeBuffers interception (direct vtable
// patch, no MinHook), D3D11 primary + D3D12 (own command queue) rendering,
// the WndProc input subclass, cursor arbitration and clean unload.
// Game integration is deliberately limited to presenting pixels and reading
// window input: no game function is detoured, no game memory is read.

#pragma once

#include <Windows.h>

namespace nf {
namespace overlay {

// Menu visibility (written by the hotkey path, read by menu + HUD gating).
extern bool g_showMenu;
// ClickGUI toggle key (default INSERT; editable from the menu quick settings).
extern int g_menuKey;

// Worker thread body (spawned from DllMain, never on the loader lock).
void MainThread(HMODULE hModule);

// Best-effort teardown on process detach (never blocks).
void NotifyDetach();

} // namespace overlay
} // namespace nf
