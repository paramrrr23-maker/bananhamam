// bedrock_entt.hpp - Bedrock entity-component access, replicating Flarial's
// SDK (EntityContext.hpp + MobEffectsComponent.hpp) on top of the pinned
// vanilla entt (skypjack/entt @ 303801c, vendored in third_party/entt).
//
// CRITICAL: the component structs below live in the GLOBAL namespace with
// the exact names the game uses ("MobEffectsComponent", "MobEffectInstance",
// "EntityId", ...). entt keys component pools by a compile-time hash of the
// MSVC FUNCSIG of the type_hash<T> instantiation, which embeds the type name
// as written - so our instantiation hashes to the SAME pool key as the
// game's own component access code. Do not rename or wrap in a namespace.
//
// NOTE: ASCII only in this file. Effect display names live in the HUD module.

#pragma once

#include <cstdint>
#include <string>
#include <type_traits>
#include <vector>

#include <entt/entt.hpp>

class EntityId;

// ---- EntityId (Bedrock packs ids with 0x3FFFF entity / 0x3FFF version) ----
struct EntityIdTraits {
    using value_type = EntityId;  // fwd-declared below

    using entity_type  = std::uint32_t;
    using version_type = std::uint16_t;

    static constexpr entity_type entity_mask  = 0x3FFFF;
    static constexpr entity_type version_mask = 0x3FFF;
};

template <>
class entt::entt_traits<EntityId>
    : public entt::basic_entt_traits<EntityIdTraits> {
public:
    static constexpr entity_type page_size = 2048;
};

class EntityId : public entt::entt_traits<EntityId> {
public:
    entity_type mRawId{};

    constexpr EntityId() = default;
    template <typename T, typename = std::enable_if_t<std::is_integral<T>::value>>
    constexpr EntityId(T rawId) : mRawId(static_cast<entity_type>(rawId)) {}

    [[nodiscard]] constexpr bool isNull() const { return *this == entt::null; }
    [[nodiscard]] constexpr operator entity_type() const { return mRawId; }
    constexpr bool operator==(const EntityId& other) const { return mRawId == other.mRawId; }
};

struct IEntityComponent {};

// Component traits for Bedrock entities (in-place delete, 128-page), same as
// Flarial's EntityContext.hpp.
template <typename Type>
struct entt::component_traits<Type, std::enable_if_t<std::is_base_of_v<IEntityComponent, Type>>> {
    using type = Type;
    static constexpr bool in_place_delete = true;
    static constexpr std::size_t page_size = 128 * !std::is_empty_v<Type>;
};

template <typename Type>
struct entt::storage_type<Type, EntityId> {
    using type = entt::basic_storage<Type, EntityId>;
};

// ---- MobEffectsComponent (global names matching the game's own) -----------
// The vector element type is irrelevant for the pool key (only the class
// name is hashed); the real instances are read through the 1.21.30 layout.
struct MobEffectInstance {};

struct MobEffectsComponent : IEntityComponent {
    std::vector<MobEffectInstance> effects;
};

// ---- Typed view over the effect vector (1.21.30+ instance layout) ---------
struct MobEffectInstanceData1_21_30 {
    std::uint32_t id;            // MobEffect::EffectType
    int duration;                // in ticks (20 == 1 s)
    float unknown;
    int durationEasy;
    int durationNormal;
    int durationHard;
    char pad_0018[0x8];
    int amplifier;
    bool displayOnScreenTextureAnimation;
    bool ambient;
    bool noCounter;
    bool effectVisible;
    char pad_0028[0x60];
};
static_assert(sizeof(MobEffectInstanceData1_21_30) == 0x88);

// ---- EntityContext (lives at Actor + 0x8, verbatim layout) ----------------
namespace V1_20_50 {

class EntityRegistry : public std::enable_shared_from_this<EntityRegistry> {
public:
    std::string name;
    entt::basic_registry<EntityId> ownedRegistry;
    std::uint32_t id;
};

struct EntityContext {
    EntityRegistry& registry;
    entt::basic_registry<EntityId>& enttRegistry;
    EntityId entity;

    [[nodiscard]] bool isValid() const { return enttRegistry.valid(entity); }

    template <typename T>
    [[nodiscard]] T* tryGetComponent() {
        if (!isValid()) return nullptr;
        return enttRegistry.try_get<T>(entity);
    }
};
static_assert(sizeof(EntityContext) == 0x18);

} // namespace V1_20_50
