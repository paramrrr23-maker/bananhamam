
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <strings.h>
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#define _MSC_VER 1
#define __try try
#define __except(x) catch(...)
#define __fastcall
#define LOG_INFO(...) ((void)0)
#define _stricmp strcasecmp
#define _TRUNCATE 0
using LONG=int; using LONG64=long long; using ULONGLONG=unsigned long long; using SRWLOCK=int;
template<size_t N> void strcpy_s(char (&d)[N],const char* s) { std::snprintf(d,N,"%s",s); }
template<size_t N> void strncpy_s(char (&d)[N],const char* s,int) { strcpy_s(d,s); }
LONG InterlockedCompareExchange(volatile LONG* v,LONG a,LONG b) { LONG old=*v;if(old==b)*v=a;return old; }
LONG64 InterlockedCompareExchange64(volatile LONG64* v,LONG64 a,LONG64 b) { LONG64 old=*v;if(old==b)*v=a;return old; }
LONG InterlockedExchange(volatile LONG* v,LONG a) { LONG old=*v;*v=a;return old; }
LONG64 InterlockedExchange64(volatile LONG64* v,LONG64 a) { LONG64 old=*v;*v=a;return old; }
void InterlockedIncrement(volatile LONG* v) { *v=*v+1; }
void AcquireSRWLockExclusive(SRWLOCK*) {} void ReleaseSRWLockExclusive(SRWLOCK*) {}
ULONGLONG clockNow=1000; ULONGLONG GetTickCount64() { return clockNow; }
int patch=111; int JavaGamePatch() { return patch; }
bool ui=false,localPresent=true,badStack=false,g_shuttingDown=false,layerReadable=true;
const char* layerName="hud_screen";
const char* itemName="ender_pearl";
int getItemCalls=0;
unsigned char image[4096]{},actor[4096]{},proxy[512]{},inv[64]{},counter[8]{};
unsigned char stacks[9][256]{},item[512]{};
unsigned char screenRaw[128]{},treeRaw[64]{},rootRaw[256]{},clientRaw[512]{},gameRaw[512]{};
void* g_clientInstance=clientRaw;
void* g_screenView=nullptr;
bool g_mouseFeedHook=true;
size_t g_gameImageSize=sizeof(image); void* GetModuleHandleW(void*) { return image; }
bool PotionReadBytes(const void* p,void* out,size_t n) { if(!p)return false;std::memcpy(out,p,n);return true; }
bool PotionValidVtable(uintptr_t p) { return p>=(uintptr_t)image && p<(uintptr_t)image+sizeof(image); }
bool JavaReadMsvcString(const void* p,char* out,size_t n) {
 if(p==rootRaw+0x20 && layerReadable) { std::snprintf(out,n,"%s",layerName);return true; }
 if(p==item+0x100) { std::snprintf(out,n,"minecraft");return true; }
 if(p==item+0xD8) { std::snprintf(out,n,"%s",itemName);return true; } return false;
}
void* getItemMock(void*,int slot) { ++getItemCalls;return badStack?nullptr:stacks[slot]; }
bool JavaIsGameCodeAddress(uintptr_t address) { return address==(uintptr_t)&getItemMock; }
void* HitboxResolveContainerGetItem(void*) { return (void*)&getItemMock; }
bool PotionReadLocalPlayer(void*& out) { out=localPresent?actor:nullptr;return localPresent; }
bool UiInputOwned() { return ui; }
bool ReadTopUiLayer(char* out,size_t n) {
 if(!g_screenView)return false;
 std::snprintf(out,n,"%s",layerName);return layerReadable;
}
template<class T> void put(void* where,T val) { std::memcpy(where,&val,sizeof(val)); }
namespace overlay {
struct CooldownUseEvent { char itemId[64]{};unsigned long long at=0;unsigned long session=0; };
struct CooldownEventQueue { CooldownUseEvent items[32]{};unsigned int head=0,tail=0;SRWLOCK lock=0; } g_cooldownEvents;
volatile LONG64 g_cdUseAt=0,g_cdDropAt=0;volatile LONG g_cdUseDown=0,g_cdDropDown=0,g_cdSession=1,g_cdMouseEvents=0;
void PublishCooldownUse(const char*,unsigned long long at=0);unsigned long GetCooldownSession();

// ABI reference: Flarial OffsetInit init21110 / init2120 / init2160,
// ItemStackBase's x64 layout. Intentionally limited to 1.21.110..119.
// No inventory writes, new hooks, background SDK calls, or signature scans.
static const char* const kCooldownIds[] = {
    "minecraft:sugar", "minecraft:phantom_membrane", "minecraft:ender_eye",
    "minecraft:netherite_scrap", "minecraft:golden_apple",
    "minecraft:enchanted_golden_apple", "minecraft:dried_kelp",
    "minecraft:ender_pearl", "minecraft:chorus_fruit", "minecraft:snowball",
    "minecraft:wind_charge"
};

// CD_PURE_BEGIN: portable decision core, exercised by the regression tests.
struct CooldownStackSample {
    int slot = -1;
    int id = -1;                  // -1 = empty/untracked, count still validated
    int count = 0;
    char rawId[192]{};             // diagnostics also show untracked item IDs
};
static bool CooldownDecreased(const CooldownStackSample& before,
                              const CooldownStackSample& after) {
    if (before.slot < 0 || before.slot != after.slot ||
        before.id < 0 || before.count <= 0) return false;
    if (after.count == 0) return before.count == 1;
    return before.id == after.id && before.count - after.count == 1;
}
static bool CooldownStillSpent(const CooldownStackSample& before,
                              const CooldownStackSample& after) {
    return before.slot == after.slot &&
        ((after.count == 0 && before.count == 1) ||
         (after.id == before.id && after.count > 0 &&
          after.count < before.count));
}
static bool CooldownRecent(unsigned long long now, unsigned long long at,
                           unsigned long long window) {
    return at != 0 && now >= at && now - at <= window;
}
// CD_PURE_END

struct CooldownObserver {
    void* local = nullptr;
    void* registry = nullptr;
    void* inventory = nullptr;
    CooldownStackSample before{};
    CooldownStackSample pendingBefore{};
    ULONGLONG sampledAt = 0;
    ULONGLONG pendingAt = 0;
    ULONGLONG lastLocalAt = 0;
    ULONGLONG lastIntent = 0;
    ULONGLONG diagAt = 0;
    ULONGLONG gateDiagAt = 0;
    ULONGLONG statusAt = 0;
    ULONGLONG modalUntil = 0;
    unsigned long passiveSkipped = 0;
    int lastGate = 0;
    bool baseline = false;
};
static CooldownObserver g_cdObserver;

static void CooldownDiagnostic(const char* reason, ULONGLONG now) {
    if (now < g_cdObserver.diagAt) return;
    g_cdObserver.diagAt = now + 5000ull;
    LOG_INFO("cooldowns: cd-r4 %s", reason);
}

// ScreenView is supplied by the already-installed setup hook. Do not require
// its first word to be a game vtable: that unrelated GUI-cache condition made
// r2 discard every in-world sample. Only bounded, guarded field/string reads.
static bool CooldownReadLayer(void* screenView, char* out, size_t cap,
                              const char** stage = nullptr) {
    if (stage) *stage = "screen pointer";
    if (!out || cap < 2) return false;
    out[0] = 0;
    if (!screenView) return false;
    void* tree = nullptr;
    void* root = nullptr;
    if (stage) *stage = "screen+48 -> tree";
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(screenView) + 0x48u), &tree, sizeof(tree)) ||
        !tree) return false;
    if (stage) *stage = "tree+8 -> root";
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(tree) + 8u), &root, sizeof(root)) ||
        !root) return false;
    if (stage) *stage = "root screen-name";
    const size_t offsets[] = {0x20u, 0x18u};
    for (size_t offset : offsets) {
        char name[64]{};
        if (!JavaReadMsvcString(reinterpret_cast<const void*>(
                reinterpret_cast<uintptr_t>(root) + offset), name, sizeof(name)) ||
            !name[0]) continue;
        // Keep the candidate in diagnostics even when it is not a screen ID.
        snprintf(out, cap, "%s", name);
        const size_t len = std::strlen(name);
        if (len < 7 || std::strcmp(name + len - 7, "_screen")) continue;
        bool valid = true;
        for (size_t i = 0; i < len; ++i)
            if (!((name[i] >= 'a' && name[i] <= 'z') ||
                  (name[i] >= '0' && name[i] <= '9') || name[i] == '_'))
                valid = false;
        if (valid) {
            if (stage) *stage = "ready";
            return true;
        }
    }
    return false;
}

// Flarial offsets inherited by 1.21.11x: ClientInstance::minecraftGame
// init2140 +0xD0, MinecraftGame::mouseGrabbed init2190 +0x1B8.
// Read only, version-gated by the caller, and not a generic in-world fallback:
// a local player alone cannot distinguish HUD from inventory or chat.
static int CooldownMouseGrabbed() {
    void* game = nullptr;
    uintptr_t vft = 0;
    unsigned char grabbed = 0;
    if (!g_clientInstance ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(g_clientInstance) + 0xD0u), &game, sizeof(game)) ||
        !game || !PotionReadBytes(game, &vft, sizeof(vft)) || !PotionValidVtable(vft) ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(game) + 0x1B8u), &grabbed, sizeof(grabbed)) ||
        grabbed > 1) return -1;
    return (int)grabbed;
}

// >0 means gameplay accepted; <0 means no item sampling. A known non-HUD
// screen is authoritative even if the mouse-grab flag says otherwise.
static int CooldownScreenGate(bool owned, bool knownLayer,
                              const char* layer, int grabbed) {
    if (owned) return -1;
    if (knownLayer) return std::strcmp(layer, "hud_screen") == 0 ? 1 : -2;
    if (grabbed == 1) return 2;
    return grabbed == 0 ? -3 : -4;
}

static bool CooldownPassiveLayer(const char* layer) {
    // These two layers were interleaved with hud_screen in the r3 log.
    // They are not modal screens and must not erase input or pending uses.
    return !std::strcmp(layer, "toast_screen") ||
           !std::strcmp(layer, "debug_screen");
}

static bool CooldownImageRange(uintptr_t address, size_t size) {
    const uintptr_t image = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
    return image && size <= g_gameImageSize && address >= image &&
           address - image <= g_gameImageSize - size;
}

// Result: 1 known Inventory, 0 RTTI absent/unreadable, -1 readable wrong type.
// Missing RTTI is not evidence that the pinned SDK object path is invalid.
// But a readable, contradictory type MUST NOT use the structural fallback.
static int CooldownInventoryType(void* inventory, char* typeName, size_t cap,
                                  const char*& stage) {
    if (typeName && cap) typeName[0] = 0;
    uintptr_t vft = 0, locator = 0;
    uint32_t col[6]{};
    const uintptr_t image = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
    stage = "object-vtable";
    if (!PotionReadBytes(inventory, &vft, sizeof(vft)) ||
        !CooldownImageRange(vft, 8 * sizeof(uintptr_t))) return 0;
    stage = "locator-pointer";
    if (vft < sizeof(void*) ||
        !CooldownImageRange(vft - sizeof(void*), sizeof(void*)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(vft - sizeof(void*)),
                         &locator, sizeof(locator)) ||
        !CooldownImageRange(locator, sizeof(col))) return 0;
    stage = "locator-fields";
    if (!PotionReadBytes(reinterpret_cast<const void*>(locator), col, sizeof(col)) ||
        col[0] != 1 || locator < col[5] || locator - col[5] != image ||
        col[3] == 0 || col[3] >= g_gameImageSize) return 0;
    char name[64]{};
    stage = "type-name";
    const uintptr_t nameAt = image + col[3] + 16u;
    // Stop at the terminator instead of requiring 63 readable bytes after it.
    bool terminated = false;
    for (size_t i = 0; i < sizeof(name) - 1; ++i) {
        if (!CooldownImageRange(nameAt + i, 1) ||
            !PotionReadBytes(reinterpret_cast<const void*>(nameAt + i), name + i, 1))
            return 0;
        if (!name[i]) { terminated = true; break; }
    }
    if (!terminated) {
        if (typeName && cap) snprintf(typeName, cap, "%s", name);
        stage = "type-name-too-long";
        return -1; // a real but unrecognized type, often a shared_ptr counter
    }
    if (!name[0]) return 0;
    if (typeName && cap) snprintf(typeName, cap, "%s", name);
    if (!std::strcmp(name, ".?AVInventory@@") ||
        !std::strcmp(name, ".?AVPlayerInventory@@")) {
        stage = "known-inventory";
        return 1;
    }
    stage = "wrong-type";
    return -1;
}

struct CooldownInventoryCandidate {
    size_t offset = 0;
    void* object = nullptr;
    void* getItem = nullptr;
    uintptr_t vft = 0;
    int rtti = 0;
    char type[64]{};
    const char* stage = "pointer";
    bool valid = false;
};

static void CooldownProbeInventory(void* proxy, size_t offset,
                                   CooldownInventoryCandidate& candidate) {
    candidate = {};
    candidate.offset = offset;
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(proxy) + offset),
            &candidate.object, sizeof(candidate.object)) || !candidate.object)
        return;
    candidate.stage = "vtable";
    if (!PotionReadBytes(candidate.object, &candidate.vft, sizeof(candidate.vft)) ||
        !CooldownImageRange(candidate.vft, 8 * sizeof(uintptr_t)) ||
        !PotionValidVtable(candidate.vft)) return;
    uintptr_t functions[8]{};
    candidate.stage = "virtual-methods";
    if (!PotionReadBytes(reinterpret_cast<const void*>(candidate.vft),
                         functions, sizeof(functions))) return;
    for (uintptr_t function : functions)
        if (!JavaIsGameCodeAddress(function)) return;
    candidate.rtti = CooldownInventoryType(candidate.object, candidate.type,
                                           sizeof(candidate.type), candidate.stage);
    if (candidate.rtti < 0) return;
    // The offset alternatives are restricted to the two published layouts:
    // +B8 from the Flarial table, +B0 already used by this source's Target HUD.
    // This is not a heap scan. No methods have been called during validation.
    candidate.getItem = HitboxResolveContainerGetItem(candidate.object);
    if (!candidate.getItem ||
        reinterpret_cast<uintptr_t>(candidate.getItem) != functions[7]) {
        candidate.stage = "getItem-mismatch";
        return;
    }
    candidate.valid = true;
}

static bool CooldownReadInventory(void* local, void*& inventory,
                                 void*& getItem, int& slot, const char*& stage,
                                 char* typeName, size_t cap, size_t& layoutOffset,
                                 int& rttiProof) {
    inventory = nullptr;
    getItem = nullptr;
    layoutOffset = 0;
    rttiProof = 0;
    void* proxy = nullptr;
    stage = "player+5B8 -> proxy";
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(local) + 0x5B8u), &proxy, sizeof(proxy)) ||
        !proxy) return false;
    stage = "proxy+10 -> selected slot";
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(proxy) + 0x10u), &slot, sizeof(slot)) ||
        slot < 0 || slot > 8) return false;
    CooldownInventoryCandidate candidates[2]{};
    CooldownProbeInventory(proxy, 0xB8u, candidates[0]);
    CooldownProbeInventory(proxy, 0xB0u, candidates[1]);
    CooldownInventoryCandidate* chosen = nullptr;
    bool ambiguous = false;
    for (auto& candidate : candidates) {
        if (!candidate.valid) continue;
        if (chosen && chosen->object != candidate.object) ambiguous = true;
        else if (!chosen) chosen = &candidate;
    }
    stage = ambiguous ? "ambiguous-inventory" : "no-validated-inventory";
    if (ambiguous || !chosen) {
        const ULONGLONG now = GetTickCount64();
        if (now >= g_cdObserver.diagAt) {
            g_cdObserver.diagAt = now + 5000ull;
            for (const auto& c : candidates)
                LOG_INFO("cooldowns: cd-r4 inventory candidate offset=+%llX object=%p vtable=%p stage=%s rtti=%d type=%s valid=%d",
                         (unsigned long long)c.offset, c.object,
                         reinterpret_cast<void*>(c.vft), c.stage, c.rtti,
                         c.type[0] ? c.type : "<absent>", c.valid ? 1 : 0);
            LOG_INFO("cooldowns: cd-r4 inventory selection=%s slot=%d", stage, slot);
        }
        return false;
    }
    inventory = chosen->object;
    getItem = chosen->getItem;
    layoutOffset = chosen->offset;
    rttiProof = chosen->rtti;
    if (typeName && cap)
        snprintf(typeName, cap, "%s", chosen->type[0] ? chosen->type : "<structural>");
    stage = "ready";
    return true;
}

static bool CooldownReadStackUnsafe(void* inventory, void* getItem, int slot,
                                   CooldownStackSample& out) {
    out = {};
    out.slot = slot;
    using GetItemFn = void* (__fastcall*)(void*, int);
    void* stack = reinterpret_cast<GetItemFn>(getItem)(inventory, slot);
    if (!stack) return false;
    uintptr_t vft = 0;
    void* counter = nullptr;
    unsigned char count = 0;
    if (!PotionReadBytes(stack, &vft, sizeof(vft)) || !PotionValidVtable(vft) ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(stack) + 8u), &counter, sizeof(counter)))
        return false;
    if (!counter) return true; // canonical empty ItemStack, not a failed read
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(stack) + 0x22u), &count, sizeof(count)) ||
        count > 64) return false;
    out.count = count;
    if (!count) return true;
    void* item = nullptr; // WeakPtr<Item>::counter->ptr, not the counter itself
    if (!PotionReadBytes(counter, &item, sizeof(item)) || !item ||
        !PotionReadBytes(item, &vft, sizeof(vft)) || !PotionValidVtable(vft))
        return false;
    char ns[64]{}, name[128]{}, id[192]{};
    if (!JavaReadMsvcString(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(item) + 0x100u), ns, sizeof(ns)) ||
        !JavaReadMsvcString(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(item) + 0xD8u), name, sizeof(name)) ||
        !ns[0] || !name[0]) return false;
    if (std::strchr(name, ':')) snprintf(id, sizeof(id), "%s", name);
    else snprintf(id, sizeof(id), "%s:%s", ns, name);
    // Bedrock's older internal identifier for the enchanted apple.
    if (!_stricmp(id, "minecraft:appleEnchanted"))
        strcpy_s(id, "minecraft:enchanted_golden_apple");
    strcpy_s(out.rawId, id);
    for (int i = 0; i < (int)(sizeof(kCooldownIds) / sizeof(kCooldownIds[0])); ++i) {
        if (!_stricmp(id, kCooldownIds[i])) { out.id = i; break; }
    }
    return true;
}

static bool CooldownReadStack(void* inventory, void* getItem, int slot,
                             CooldownStackSample& out) {
    if (!inventory || !getItem || slot < 0 || slot > 8) return false;
#ifdef _MSC_VER
    __try {
        return CooldownReadStackUnsafe(inventory, getItem, slot, out);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
#else
    // The shipped build.bat uses MSVC. Do not make an unguarded virtual call
    // under a different compiler.
    return false;
#endif
}

static void CooldownNewSession(void* local, void* registry) {
    g_cdObserver = {};
    g_cdObserver.local = local;
    g_cdObserver.registry = registry;
    InterlockedIncrement(&g_cdSession);
    // Old input must not arm the first item after reconnect/respawn.
    InterlockedExchange(&g_cdUseDown, 0);
    InterlockedExchange64(&g_cdUseAt, 0);
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    g_cooldownEvents.head = g_cooldownEvents.tail = 0;
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
    LOG_INFO("cooldowns: cd-r4 session reset");
}

static void CooldownSampleImpl(void* screenView) {
    CooldownObserver& state = g_cdObserver;
    const ULONGLONG now = GetTickCount64();
    // Process screen classification BEFORE the 25 Hz inventory limit. A toast
    // must not consume the sampling budget; a modal must not be missed merely
    // because its underlying HUD rendered a few milliseconds earlier.
    char layer[64]{};
    const char* layerStage = "unknown";
    const bool layerKnown = CooldownReadLayer(screenView, layer, sizeof(layer), &layerStage);
    const bool owned = UiInputOwned();
    if (!owned && layerKnown && CooldownPassiveLayer(layer)) {
        ++state.passiveSkipped;
        return;
    }
    if (owned || (layerKnown && std::strcmp(layer, "hud_screen") != 0)) {
        const int blockedGate = owned ? -1 : -2;
        state.baseline = false;
        state.pendingAt = 0;
        state.modalUntil = now + 250ull;
        InterlockedExchange(&g_cdUseDown, 0);
        InterlockedExchange64(&g_cdUseAt, 0);
        if (state.lastGate != blockedGate || now >= state.gateDiagAt) {
            state.lastGate = blockedGate;
            state.gateDiagAt = now + 5000ull;
            LOG_INFO("cooldowns: cd-r4 modal gate=%d layer=%s", blockedGate,
                     layer[0] ? layer : "<unreadable>");
        }
        return;
    }
    if (now < state.modalUntil) return;
    if (state.sampledAt && now - state.sampledAt < 40ull) return; // <=25 Hz
    const bool gap = !state.sampledAt || now - state.sampledAt > 500ull;
    state.sampledAt = now;
    if (gap) { state.baseline = false; state.pendingAt = 0; }
    const int patch = JavaGamePatch();
    if (patch < 110 || patch >= 120) {
        CooldownDiagnostic("unsupported game version; inventory reads disabled", now);
        return;
    }
    void* local = nullptr;
    void* registry = nullptr;
    if (!PotionReadLocalPlayer(local) ||
        !PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(local) + 0x10u), &registry, sizeof(registry))) {
        state.baseline = false;
        state.pendingAt = 0;
        if (state.local && now - state.lastLocalAt > 1000ull)
            CooldownNewSession(nullptr, nullptr);
        CooldownDiagnostic("waiting for local player", now);
        return;
    }
    if (local != state.local || registry != state.registry)
        CooldownNewSession(local, registry);
    state.sampledAt = state.lastLocalAt = now;
    const int grabbed = layerKnown ? -1 : CooldownMouseGrabbed();
    const int gate = CooldownScreenGate(owned, layerKnown, layer, grabbed);
    if (state.lastGate != gate || now >= state.gateDiagAt) {
        state.lastGate = gate;
        state.gateDiagAt = now + 5000ull;
        LOG_INFO("cooldowns: cd-r4 gate=%d screen=%p cached=%p layer=%s layerStage=%s grabbed=%d mouseHook=%d mouseEvents=%ld passiveSkipped=%lu",
                 gate, screenView, g_screenView, layer[0] ? layer : "<unreadable>",
                 layerStage, grabbed, g_mouseFeedHook ? 1 : 0,
                 InterlockedCompareExchange(&g_cdMouseEvents, 0, 0), state.passiveSkipped);
    }
    if (gate < 0) {
        state.baseline = false;
        state.pendingAt = 0;
        InterlockedExchange(&g_cdUseDown, 0);
        InterlockedExchange64(&g_cdUseAt, 0);
        return;
    }
    void* inventory = nullptr;
    void* getItem = nullptr;
    int slot = -1;
    const char* inventoryStage = "unknown";
    char inventoryType[64]{};
    size_t inventoryOffset = 0;
    int inventoryRtti = 0;
    if (!CooldownReadInventory(local, inventory, getItem, slot, inventoryStage,
                               inventoryType, sizeof(inventoryType),
                               inventoryOffset, inventoryRtti)) {
        state.baseline = false;
        state.pendingAt = 0;
        char why[256]{};
        snprintf(why, sizeof(why), "inventory blocked stage=%s slot=%d type=%s",
                 inventoryStage, slot, inventoryType[0] ? inventoryType : "<unreadable>");
        CooldownDiagnostic(why, now);
        return;
    }
    if (state.inventory != inventory) {
        state.inventory = inventory;
        state.baseline = false;
        state.pendingAt = 0;
        LOG_INFO("cooldowns: cd-r4 inventory reader ready slot=%d offset=+%llX rtti=%d type=%s",
                 slot, (unsigned long long)inventoryOffset, inventoryRtti, inventoryType);
    }
    CooldownStackSample current{};
    if (!CooldownReadStack(inventory, getItem, slot, current)) {
        state.baseline = false;
        state.pendingAt = 0;
        CooldownDiagnostic("ItemStack/Item ID read failed; no timer started", now);
        return;
    }
    const ULONGLONG useAt = (ULONGLONG)InterlockedCompareExchange64(&g_cdUseAt, 0, 0);
    const ULONGLONG dropAt = (ULONGLONG)InterlockedCompareExchange64(&g_cdDropAt, 0, 0);
    const bool useDown = InterlockedCompareExchange(&g_cdUseDown, 0, 0) != 0;
    const bool useIntent = useDown || CooldownRecent(now, useAt, 400ull);
    const bool dropping = InterlockedCompareExchange(&g_cdDropDown, 0, 0) != 0 ||
                          CooldownRecent(now, dropAt, 750ull);
    if (now >= state.statusAt) {
        state.statusAt = now + 5000ull;
        LOG_INFO("cooldowns: cd-r3 sample slot=%d item=%s tracked=%d count=%d useDown=%d useRecent=%d pending=%d",
                 current.slot, current.rawId[0] ? current.rawId : "<empty>",
                 current.id >= 0 ? 1 : 0, current.count, useDown ? 1 : 0,
                 CooldownRecent(now, useAt, 400ull) ? 1 : 0, state.pendingAt ? 1 : 0);
    }
    if (useAt && useAt != state.lastIntent) {
        state.lastIntent = useAt;
        LOG_INFO("cooldowns: cd-r1 input slot=%d item=%s count=%d down=%d (intent only)",
                 slot, current.id >= 0 ? kCooldownIds[current.id] : "empty/untracked",
                 current.count, useDown ? 1 : 0);
    }
    if (state.pendingAt) {
        CooldownStackSample check = current;
        const bool readable = current.slot == state.pendingBefore.slot ||
            CooldownReadStack(inventory, getItem, state.pendingBefore.slot, check);
        if (!readable || dropping || !CooldownStillSpent(state.pendingBefore, check)) {
            LOG_INFO("cooldowns: cd-r1 pending cancelled (rollback/drop/item change/read failure)");
            state.pendingAt = 0;
        } else if (now - state.pendingAt >= 300ull) {
            LOG_INFO("cooldowns: cd-r1 consumption item=%s slot=%d count=%d->%d source=inventory+RMB estimate=1",
                     kCooldownIds[state.pendingBefore.id], state.pendingBefore.slot,
                     state.pendingBefore.count, check.count);
            PublishCooldownUse(kCooldownIds[state.pendingBefore.id], state.pendingAt);
            state.pendingAt = 0;
        }
    }
    if (state.baseline && CooldownDecreased(state.before, current)) {
        if (useIntent && !dropping && !state.pendingAt) {
            state.pendingBefore = state.before;
            state.pendingAt = now;
            LOG_INFO("cooldowns: cd-r1 pending item=%s count=%d->%d",
                     kCooldownIds[state.before.id], state.before.count, current.count);
        } else if (!useIntent || dropping) {
            LOG_INFO("cooldowns: cd-r1 decrement ignored (no use input or drop)");
        }
    }
    if (current.id >= 0 && (!state.baseline || current.id != state.before.id ||
                            current.slot != state.before.slot))
        LOG_INFO("cooldowns: cd-r1 selected slot=%d item=%s count=%d",
                 slot, kCooldownIds[current.id], current.count);
    state.before = current;
    state.baseline = true;
}

static void CooldownSample(void* screenView) {
    if (g_shuttingDown) return;
    // The setup boundary may be re-entered. Never block it or race the
    // observer's mutable state; the next frame will sample again.
    static volatile LONG busy = 0;
    if (InterlockedCompareExchange(&busy, 1, 0) != 0) return;
#ifdef _MSC_VER
    __try {
        CooldownSampleImpl(screenView);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_cdObserver.baseline = false;
        g_cdObserver.pendingAt = 0;
        CooldownDiagnostic("guarded read exception; sample discarded", GetTickCount64());
    }
#endif
    InterlockedExchange(&busy, 0);
}

unsigned long GetCooldownSession() {
    return (unsigned long)InterlockedCompareExchange(&g_cdSession, 0, 0);
}

void PublishCooldownUse(const char* namespacedItemId, unsigned long long at) {
    if (!namespacedItemId || !*namespacedItemId) return;
    CooldownUseEvent event{};
    strncpy_s(event.itemId, namespacedItemId, _TRUNCATE);
    event.at = at ? at : GetTickCount64();
    event.session = GetCooldownSession();
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    const unsigned int next = (g_cooldownEvents.head + 1u) % 32u;
    // Retain recent events if the HUD was disabled for a long time.
    if (next == g_cooldownEvents.tail)
        g_cooldownEvents.tail = (g_cooldownEvents.tail + 1u) % 32u;
    g_cooldownEvents.items[g_cooldownEvents.head] = event;
    g_cooldownEvents.head = next;
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
}

int ConsumeCooldownUseEvents(CooldownUseEvent* out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    int count = 0;
    AcquireSRWLockExclusive(&g_cooldownEvents.lock);
    while (count < maxOut && g_cooldownEvents.tail != g_cooldownEvents.head) {
        out[count++] = g_cooldownEvents.items[g_cooldownEvents.tail];
        g_cooldownEvents.tail = (g_cooldownEvents.tail + 1u) % 32u;
    }
    ReleaseSRWLockExclusive(&g_cooldownEvents.lock);
    return count;
}


}
struct EnumSetting { int mValue=0; };
struct CooldownsModule {
 struct Active { std::string id,name,icon;unsigned long long endAt;float duration; };
 std::vector<Active> m_active;EnumSetting setting{};EnumSetting* m_mode=&setting;void onRender();
};

namespace {
struct CooldownDefinition {
    const char* id;
    const char* name;
    const char* icon;
    int seconds;
};

const CooldownDefinition* CooldownDefs(int mode, size_t& count) {
    static const CooldownDefinition frizmine[] = {
        {"minecraft:sugar", "Явная Пыль", "S", 30},
        {"minecraft:phantom_membrane", "Божья Аура", "A", 60},
        {"minecraft:ender_eye", "Дезориентация", "E", 30},
        {"minecraft:netherite_scrap", "Трапка", "T", 25},
        {"minecraft:golden_apple", "Золотое Яблоко", "G", 30},
        {"minecraft:enchanted_golden_apple", "Зачарованное Золотое Яблоко", "G", 160},
        {"minecraft:dried_kelp", "Пласт", "P", 25},
        {"minecraft:ender_pearl", "Эндер Жемчуг", "P", 25},
        {"minecraft:chorus_fruit", "Плод Хоруса", "C", 15},
        {"minecraft:snowball", "Снежок", "O", 25},
        {"minecraft:wind_charge", "Заряд Ветра", "W", 15},
    };
    count = mode == 0 ? sizeof(frizmine) / sizeof(frizmine[0]) : 0;
    return mode == 0 ? frizmine : nullptr;
}
}

void CooldownsModule::onRender() {
    // Registry owns exactly one CooldownsModule. These values belong to its
    // single render consumer, never to the game/input threads.
    static unsigned long lastSession = 0;
    static int lastMode = -1;
    const unsigned long session = overlay::GetCooldownSession();
    const int mode = m_mode ? m_mode->mValue : 0;
    const bool modeChanged = lastMode >= 0 && lastMode != mode;
    if (session != lastSession || mode != lastMode) {
        m_active.clear();
        lastSession = session;
        lastMode = mode;
        if (mode != 0)
            LOG_INFO("cooldowns: selected mode has no cooldown table; choose Frizmine");
    }
    overlay::CooldownUseEvent events[32]{};
    const int eventCount = overlay::ConsumeCooldownUseEvents(events, 32);
    size_t defCount = 0;
    const CooldownDefinition* defs = CooldownDefs(m_mode ? m_mode->mValue : 0, defCount);
    const ULONGLONG now = GetTickCount64();
    for (int i = 0; i < eventCount; ++i) {
        if (modeChanged || events[i].session != session || events[i].at > now) continue;
        const CooldownDefinition* def = nullptr;
        for (size_t j = 0; j < defCount; ++j)
            if (!_stricmp(events[i].itemId, defs[j].id)) { def = &defs[j]; break; }
        if (!def) continue;
        const unsigned long long endAt =
            events[i].at + (unsigned long long)def->seconds * 1000ull;
        if (endAt <= now) continue;
        Active* active = nullptr;
        for (Active& item : m_active) if (item.id == def->id) { active = &item; break; }
        // Repeated packets/consumption while already on CD must not restart it.
        if (active && active->endAt > events[i].at) continue;
        if (!active) {
            m_active.push_back({def->id, def->name, def->icon, 0, (float)def->seconds});
            active = &m_active.back();
        }
        active->endAt = endAt;
        LOG_INFO("cooldowns: cd-r1 timer item=%s duration=%ds remaining=%llums",
                 def->id, def->seconds, endAt - now);
    }
    m_active.erase(std::remove_if(m_active.begin(), m_active.end(),
                                  [now](const Active& item) { return item.endAt <= now; }),
                   m_active.end());

}

using namespace overlay;
int checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::cerr<<"FAIL line "<<__LINE__<<": "<<#x<<"\n";std::abort();}}while(0)
void initMemory() {
 put(screenRaw+0x48,(void*)treeRaw);put(treeRaw+8,(void*)rootRaw);
 put(clientRaw+0xD0,(void*)gameRaw);put(gameRaw,(uintptr_t)(image+1024));gameRaw[0x1B8]=1;
 put(actor+0x10,(void*)image);put(actor+0x5B8,(void*)proxy);put(proxy+0x10,0);put(proxy+0xB8,(void*)inv);
 put(inv,(uintptr_t)(image+1024));put(image+1016,(uintptr_t)(image+512));uint32_t col[]={1,0,0,256,0,512};
 for(int i=0;i<8;++i)put(image+1024+i*sizeof(uintptr_t),(uintptr_t)&getItemMock);
 put(proxy+0xB0,(void*)nullptr);
 std::memcpy(image+512,col,sizeof(col));std::strcpy((char*)image+272,".?AVInventory@@");
 put(item,(uintptr_t)(image+1024));put(counter,(void*)item);
 for(int i=0;i<9;++i)put(stacks[i],(uintptr_t)(image+1024));
}
void count(int n,int slot=0) { put(stacks[slot]+8,n?(void*)counter:nullptr);stacks[slot][0x22]=(unsigned char)n; }
void tick(unsigned long long ms=40) { clockNow+=ms;CooldownSample(screenRaw); }
void reset() {
 ui=false;localPresent=true;badStack=false;patch=111;layerReadable=true;layerName="hud_screen";
 itemName="ender_pearl";
 g_clientInstance=clientRaw;gameRaw[0x1B8]=1;
 g_cdDropAt=0;g_cdDropDown=0;CooldownNewSession(nullptr,nullptr);count(16);put(proxy+0x10,0);tick();
}
int drain(CooldownUseEvent* out) { return ConsumeCooldownUseEvents(out,32); }
int main() {
 initMemory();CooldownUseEvent events[32]{};
 // Reproduce r2's missing cache, while the live hook argument is readable and
 // deliberately has no vtable. The real new field reader must still find HUD.
 char layer[64]{};
 CHECK(g_screenView==nullptr);
 CHECK(!ReadTopUiLayer(layer,sizeof(layer)));
 CHECK(!PotionValidVtable(*(uintptr_t*)screenRaw));
 CHECK(CooldownReadLayer(screenRaw,layer,sizeof(layer)));
 CHECK(std::string(layer)=="hud_screen");
 CHECK(CooldownMouseGrabbed()==1);
 CHECK(CooldownScreenGate(false,true,"hud_screen",-1)==1);
 CHECK(CooldownScreenGate(false,true,"inventory_screen",1)<0);
 CHECK(CooldownScreenGate(false,true,"chat_screen",1)<0);
 CHECK(CooldownScreenGate(false,true,"pause_screen",1)<0);
 CHECK(CooldownScreenGate(true,true,"hud_screen",1)<0);
 CHECK(CooldownScreenGate(false,false,"",1)==2);
 CHECK(CooldownScreenGate(false,false,"",0)<0);
 CHECK(CooldownScreenGate(false,false,"",-1)<0);
 CHECK(CooldownDecreased({0,7,16},{0,7,15}));CHECK(CooldownDecreased({0,7,1},{0,-1,0}));
 CHECK(!CooldownDecreased({0,7,16},{1,7,15}));CHECK(!CooldownDecreased({0,7,16},{0,8,15}));
 CHECK(!CooldownDecreased({0,7,16},{0,7,14}));CHECK(!CooldownDecreased({0,7,16},{0,7,16}));
 CHECK(!CooldownDecreased({0,7,16},{0,-1,0}));CHECK(!CooldownRecent(100,200,400));
 CHECK(!CooldownRecent(100,0,400));CHECK(CooldownRecent(500,100,400));CHECK(!CooldownRecent(501,100,400));
 reset();CHECK(g_cdObserver.baseline);
 g_cdUseAt=clockNow;g_cdUseDown=1;tick();tick(350);CHECK(drain(events)==0);
 count(15);tick();auto consumed=clockNow;CHECK(drain(events)==0);tick(280);CHECK(drain(events)==0);
 tick(40);CHECK(drain(events)==1);CHECK(std::string(events[0].itemId)=="minecraft:ender_pearl");
 CHECK(events[0].at==consumed);CHECK(events[0].session==GetCooldownSession());tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;tick(350);CHECK(drain(events)==0);
 reset();count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;g_cdDropAt=clockNow;count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;g_cdDropDown=1;
 tick(1000);count(15);tick();tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();count(16);tick(100);tick(350);CHECK(drain(events)==0);
 reset();count(1);tick();g_cdUseAt=clockNow;count(0);tick();tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;g_cdUseDown=0;count(15);tick();tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;count(15);tick();ui=true;tick();ui=false;tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();badStack=true;tick(320);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;count(15);tick(1000);tick(350);CHECK(drain(events)==0);
 reset();g_cdUseAt=clockNow;count(15);tick();put(proxy+0x10,1);tick(320);CHECK(drain(events)==1);
 reset();g_cdUseAt=clockNow;count(15,1);put(proxy+0x10,1);tick();tick(320);CHECK(drain(events)==0);
 reset();patch=120;g_cdUseAt=clockNow;count(15);tick(350);CHECK(drain(events)==0);
 // Full observer with a missing UI layer and explicit grabbed-mouse fallback.
 reset();layerReadable=false;tick();CHECK(g_cdObserver.lastGate==2);
 CHECK(g_cdObserver.baseline);g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(drain(events)==1);
 // A named inventory must win over a stale grabbed flag.
 reset();layerName="inventory_screen";g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(g_cdObserver.lastGate==-2);CHECK(!g_cdObserver.baseline);CHECK(drain(events)==0);
 reset();layerName="chat_screen";g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(drain(events)==0);
 // Unknown screen plus a released mouse is blocked, not treated as gameplay.
 reset();layerReadable=false;gameRaw[0x1B8]=0;g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(g_cdObserver.lastGate==-3);CHECK(drain(events)==0);
 // Invalid bool and missing client do not silently count as captured mouse.
 reset();layerReadable=false;gameRaw[0x1B8]=2;
 CHECK(CooldownMouseGrabbed()==-1);tick();CHECK(g_cdObserver.lastGate==-4);
 g_clientInstance=nullptr;CHECK(CooldownMouseGrabbed()==-1);
 reset();CHECK(std::string(g_cdObserver.before.rawId)=="minecraft:ender_pearl");
 reset();std::strcpy((char*)image+272,".?AVNotAnInventory@@");g_cdUseAt=clockNow;count(15);tick(350);
 CHECK(!g_cdObserver.baseline);CHECK(drain(events)==0);initMemory();
 // Missing RTTI may use the pinned path, but must still pass vtable/method proof.
 reset();put(image+1016,(uintptr_t)0);tick();
 CHECK(g_cdObserver.baseline);g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(drain(events)==1);
 initMemory();reset();
 // Null RTTI with an invalid virtual method must NEVER call that object.
 put(image+1016,(uintptr_t)0);put(image+1024+3*sizeof(uintptr_t),(uintptr_t)0);
 int calls=getItemCalls;tick();CHECK(!g_cdObserver.baseline);
 CHECK(getItemCalls==calls);initMemory();
 // Readable wrong RTTI remains a hard rejection, not a fallback.
 reset();std::strcpy((char*)image+272,".?AVRefCountBase@@");calls=getItemCalls;
 tick();CHECK(!g_cdObserver.baseline);CHECK(getItemCalls==calls);initMemory();
 // +B0 points to Inventory, +B8 to a counter-like object with too few methods.
 reset();unsigned char control[64]{};
 put(control,(uintptr_t)(image+1536));
 put(image+1536,(uintptr_t)&getItemMock);
 put(image+1536+sizeof(uintptr_t),(uintptr_t)&getItemMock);
 put(proxy+0xB8,(void*)control);put(proxy+0xB0,(void*)inv);
 tick();CHECK(g_cdObserver.baseline);g_cdUseAt=clockNow;count(15);tick();tick(320);
 CHECK(drain(events)==1);initMemory();
 // Distinct plausible containers are ambiguous: no call is made to either.
 reset();unsigned char other[64]{};put(other,(uintptr_t)(image+1024));
 put(proxy+0xB0,(void*)other);calls=getItemCalls;tick();
 CHECK(!g_cdObserver.baseline);CHECK(getItemCalls==calls);initMemory();
 // Two layout slots pointing to the same object are not ambiguous.
 reset();put(proxy+0xB0,(void*)inv);tick();CHECK(g_cdObserver.baseline);initMemory();
 // Notifications/debug hooks between HUD samples preserve input and pending use.
 reset();g_cdUseAt=clockNow;g_cdUseDown=1;count(15);tick();
 auto pending=g_cdObserver.pendingAt;CHECK(pending!=0);
 layerName="toast_screen";tick(10);CHECK(g_cdObserver.pendingAt==pending);
 CHECK(g_cdUseDown==1);
 layerName="debug_screen";tick(10);CHECK(g_cdObserver.pendingAt==pending);
 layerName="hud_screen";tick(300);CHECK(drain(events)==1);
 CHECK(g_cdObserver.passiveSkipped==2);
 // A passive call immediately before the HUD must not steal its sample budget.
 reset();g_cdUseAt=clockNow;count(15);layerName="toast_screen";tick(40);
 layerName="hud_screen";tick(1);CHECK(g_cdObserver.pendingAt!=0);
 tick(320);CHECK(drain(events)==1);
 // Modal arriving inside the 40 ms sampling budget must cancel immediately.
 reset();g_cdUseAt=clockNow;count(15);tick();CHECK(g_cdObserver.pendingAt!=0);
 layerName="inventory_screen";tick(1);CHECK(g_cdObserver.pendingAt==0);
 layerName="hud_screen";tick(40);CHECK(!g_cdObserver.baseline);
 tick(300);CHECK(drain(events)==0);
 // Passive panels never turn inventory or pause into gameplay.
 reset();layerName="pause_screen";tick(1);CHECK(!g_cdObserver.baseline);
 layerName="toast_screen";tick(300);CHECK(!g_cdObserver.baseline);
 CHECK(drain(events)==0);
 // The two items reported by the user, including full stacks and final item.
 for(const char* used : {"sugar","ender_eye"}) {
   reset();itemName=used;tick();g_cdUseAt=clockNow;count(15);
   tick();layerName="toast_screen";tick(100);layerName="hud_screen";tick(220);
   CHECK(drain(events)==1);
   CHECK(std::string(events[0].itemId)==std::string("minecraft:")+used);
   reset();itemName=used;count(1);tick();g_cdUseAt=clockNow;count(0);
   tick();tick(320);CHECK(drain(events)==1);
   CHECK(std::string(events[0].itemId)==std::string("minecraft:")+used);
 }
 reset();PublishCooldownUse("minecraft:ender_pearl");auto session=GetCooldownSession();localPresent=false;tick(1100);
 CHECK(GetCooldownSession()!=session);CHECK(drain(events)==0);
 for(int i=0;i<40;++i)PublishCooldownUse("minecraft:ender_pearl",100+i);
 CHECK(drain(events)==31);CHECK(events[0].at==109);CHECK(events[30].at==139);
 CooldownsModule hud;PublishCooldownUse("minecraft:ender_pearl",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 auto ends=hud.m_active[0].endAt;CHECK(ends==clockNow+25000);clockNow+=1000;PublishCooldownUse("minecraft:ender_pearl",clockNow);
 hud.onRender();CHECK(hud.m_active[0].endAt==ends);CHECK((ends-clockNow+999)/1000==24);
 clockNow=ends;hud.onRender();CHECK(hud.m_active.empty());PublishCooldownUse("minecraft:sugar",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 hud.setting.mValue=1;hud.onRender();CHECK(hud.m_active.empty());hud.setting.mValue=0;hud.onRender();
 PublishCooldownUse("minecraft:sugar",clockNow);hud.onRender();CHECK(hud.m_active.size()==1);
 CooldownNewSession(nullptr,nullptr);hud.onRender();CHECK(hud.m_active.empty());
 PublishCooldownUse("minecraft:sugar",clockNow-31000);hud.onRender();CHECK(hud.m_active.empty());
 PublishCooldownUse("minecraft:sugar",clockNow+1);hud.onRender();CHECK(hud.m_active.empty());
 std::cout<<"PASS "<<checks<<" assertions (real observer + real HUD consumer; mocked game/Windows)\n";
}
