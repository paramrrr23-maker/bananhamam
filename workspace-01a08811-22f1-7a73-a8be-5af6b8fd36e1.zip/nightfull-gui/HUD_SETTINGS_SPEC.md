# NIGHTFULL — HUD Module Settings Specification

Статус: **UX/UI + архитектурная спецификация**. Кода нет.
Покрывает: единую систему настроек всех HUD-модулей, наследование, темы, редактор, пресеты, привязку к рендер-примитивам.
Связанные документы: `GUI_DESIGN_SPEC.md` (токены, компоненты, анимации), `../research/API_BLUEPRINT.md` (rendering layer).

---

## 0. Анализ референса (NebulaClient, скриншот)

### 0.1. Что забираем — визуальный язык и паттерны (контент игнорируем)

| Паттерн на скрине | Решение для Nightfull |
|---|---|
| Композиция: Sidebar + Content + правые floating-панели + верхняя инфо-полоса | ✅ Подтверждает архитектуру GUI_DESIGN_SPEC §1. Оставляем как есть |
| Карточка: icon + title + toggle справа вверху, desc второй строкой, ряды `label + control` | ✅ Уже в спеке (§3.2–3.3). Референс валидирует: слайдер = `Label ──●── value`, дропдаун — full-width строка |
| Toggle pill + knob, фиолетовый ON | ✅ Совпадает со спекой |
| Тонкие слайдеры со светящимся thumb, значение справа (`16.0`, `4.5`, `90°`) | ✅ Совпадает; фиксируем формат value: right-aligned, secondary text |
| Keybind-панель: строки `Name ......... [key]` с keycap-чипом | ✅ Забираем keycap-стиль (скруглённый чип, mono-текст) — см. §14 addendum |
| Active Modules: строки `Name .... toggle` | ✅ Паттерн для ArrayList (в спеке уже есть) |
| Potion Effects: `icon + Name .... timer` с правым выравниванием времени | ✅ Забираем как layout модуля Potions (см. §10.1) |
| Верхняя полоса: `FPS: 240  Ping: 32ms / coords` | ✅ Паттерн компактных HUD-виджетов без фона (text-only режим) |
| Чат-нотификации слева внизу `[Nebula] ...` | ✅ Паттерн Notifications (наш стиль — floating cards, §10.12) |
| Version-карточка справа внизу (logo + name + version) | ✅ Забираем как Status Widget (см. §14 addendum) |
| Сетка 3 колонки, воздух, тёмно-фиолетовая гамма | ✅ Совпадает; плотность — ориентир для desktop ≥1600px |

### 0.2. Что НЕ переносим (чит-контент референса — запрещён ТЗ Nightfull)

Категории Combat / Movement / Player / World / Misc в их смысле, и все модули:
Kill Aura, Auto Clicker, Hitbox (resize), Reach, Criticals, Velocity, No Slow, Fly, No Fall,
Through Walls, Aura Settings (Priority/Sort — target selection), Show Range/FOV (combat).
Правило ТЗ: названия на референсе — демонстрационные, в Nightfull им нет места.
Переиспользуются только **паттерны компоновки** (карточка настроек, слайдер с value, панель-список).

### 0.3. Вывод
Референс подтверждает 90% GUI_DESIGN_SPEC. Дельты (keycap-чип, potion-row layout, version widget)
вынесены в §14 как точечные дополнения, а не ревизия спеки.

---

## 1. Архитектура HUD-модуля (единая схема)

Каждый модуль = **Shared Schema** (одна на всех) + **Module Specific** (контент модуля).
Никаких индивидуальных Appearance-систем: все модули ссылаются на одни и те же группы.

```
HUD Module
├── 1. Enabled                    → §2.1 (toggle + анимация появления)
├── 2. Position                    → §2.2 (anchor + X/Y + offset + drag)
├── 3. Size                        → §2.3 (scale + width/height auto/fixed)
├── 4. Layout                      → §2.4 (padding + spacing + alignment)
├── 5. Appearance                  → §2.5 (background/glass/outline/shadow/glow/radius)
├── 6. Colors                      → §3 (роли цветов, Default/Custom)
├── 7. Typography                  → §2.6 (font/size/weight/spacing/alignment)
├── 8. Icons                       → §2.7 (show/size/position/color)
├── 9. Separators                  → §2.8 (для списков)
├── 10. Animation                  → §7 (entry/exit/update)
├── 11. Visibility                 → §8 (контексты: игра/меню/пауза/GUI)
└── 12. Module Specific            → §10 (контент: что показывать и как)
```

Правило: новая настройка сначала пробует лечь в Shared Schema; в Specific попадает только то,
что бессмысленно для других модулей (например, `Show Amplifier` — только Potions).

---

## 2. Shared Settings Reference (типы, диапазоны, дефолты)

Дефолты ниже = `HUD Module Defaults` (переопределяются Global HUD Style, см. §3.4).

### 2.1. Enabled
| Настройка | Тип | Поведение |
|---|---|---|
| Enabled | Toggle | ON: модуль появляется с entry-анимацией; OFF: exit-анимация → полностью скрыт (не занимает место, не рендерится) |

### 2.2. Position
| Настройка | Тип | Значения |
|---|---|---|
| Anchor | Dropdown (9) | TopLeft / TopCenter / TopRight / CenterLeft / Center / CenterRight / BottomLeft / BottomCenter / BottomRight |
| X / Y | Number (px, unscaled) | смещение от anchor; drag в HUD Editor меняет их же |
| X Offset / Y Offset | Number | микро-сдвиг (то же, что X/Y — в UI показываем как одну пару; Offset используется пресетами) |
| Drag | HUD Editor | свободное перемещение мышью; после drag anchor = ближайший, X/Y пересчитываются |

Инвариант: позиция всегда выражается как `anchor + (X, Y)` — drag лишь пересчитывает эту пару.
Nudge клавишами: стрелки ±1px (Shift: ±10px).

### 2.3. Size
| Настройка | Тип | Значения |
|---|---|---|
| Scale | Slider 50–200% (step 5, def 100) | мастер-множитель: текст, иконки, фон, outline, spacing, паддинги — всё целиком через Transform |
| Width / Height | Auto / Fixed | Auto: по контенту (+padding). Fixed: px-значение (unscaled, до Scale) + clip/ellipsis контента |

Порядок применения: `layout в unscaled-единицах → Scale-трансформ → raster`.

### 2.4. Layout
| Настройка | Тип | Значения |
|---|---|---|
| Padding | Uniform (def 12) / Custom (L/R/T/B 0–32) | внутренние отступы; Uniform ↔ Custom переключатель |
| Item Spacing | Slider 0–24 (def 8) | расстояние между строками/элементами списка |
| Row/Column Spacing | Slider 0–24 | для сеточных модулей (Armor) |
| Content Alignment | Left / Center / Right | выравнивание контента внутри модуля |
| Text Alignment | Left / Center / Right | выравнивание текста (может отличаться от content) |

### 2.5. Appearance
| Группа | Настройки |
|---|---|
| Background | Enabled (def ON) · Style: Solid / Glass / Gradient / Transparent (def Glass) · Color (role `background`, Default) · Opacity 0–100 (def 72) · Blur 0–100 (def 40, только для Glass) · Gradient (см. §3.5) |
| Glass | Enabled (def ON при Style=Glass) · Blur Amount 0–100 · Opacity 0–100 · Tint: Default/Custom · Tint Opacity · Highlight ON/OFF · Highlight Opacity. Определение: Glass = translucent bg + blur + top-highlight + subtle border. Fallback без blur: Solid-translucent (§4) |
| Corner Radius | Linked (def 12) / Custom (TL/TR/BL/BR 0–20). Пресеты: 0/4/6/8/10/12/16/20 |
| Outline | Enabled (def ON) · Width 1–4px (def 1) · Opacity 0–100 (def 100) · Color (role `outline`, Default→`theme.border`) · Style: Solid (v1; Inner/Outer — позже) |
| Shadow | Enabled (def ON) · Opacity 0–100 (def 35) · Blur 0–32 (def 16) · Offset X/Y −16…+16 (def 0/4) |
| Glow | Enabled (def OFF) · Color (role `glow`, Default→`theme.accent`) · Opacity 0–100 (def 35) · Strength 0–100 (def 40) · Radius 0–32 (def 16). Только для акцентов (watermark, важные индикаторы) |

Раздельные opacity (прозрачность по частям): Background Opacity · Content Opacity · Border Opacity · Shadow Opacity.
Финальная alpha элемента = произведение цепочки (global × module × part). Формула в §3.4.

### 2.6. Typography (ссылается на единый шрифт клиента)
| Настройка | Тип |
|---|---|
| Font | Dropdown (1–3 семейства клиента; def Primary) |
| Font Size | Slider 9–24 (def по роли: title 14 / body 13 / caption 11) |
| Font Weight | Normal / Medium / SemiBold / Bold (def по роли) |
| Letter Spacing | Slider −1…+4px (def 0; для Title caps до +2) |
| Line Height | Slider 100–160% (def 130) |
| Text Style caps | Title Uppercase ON/OFF (для `KEYBINDS`, `EFFECTS` заголовков) |

### 2.7. Icons
| Настройка | Тип |
|---|---|
| Show Icons | Toggle (def ON, где применимо) |
| Icon Size | Slider 12–32 (def 16) |
| Icon Spacing | Slider 0–16 (def 8, отступ до текста) |
| Icon Position | Left / Right |
| Icon Color | Role `icon` (Default→`theme.accent` для акцентных / `theme.text` для нейтральных — решает модуль, см. §10) |

### 2.8. Separators (модули-списки)
| Настройка | Тип |
|---|---|
| Separator | Toggle (def ON для Potions/ArrayList/Keybinds) |
| Style | Solid / Faded (gradient к краям) / Dotted |
| Color | Role→`theme.border` (Default) / Custom |
| Opacity / Width | 0–100 (def 60) / 1–2px (def 1) |

### 2.9. Content Opacity (контент отдельно от фона)
Content Opacity 0–100 (def 100) — текст+иконки. Позволяет «призрачный текст на плотном фоне» и наоборот.

---

## 3. Цвет и наследование (ядро системы)

### 3.1. Color Mode: Default vs Custom
Каждая цветовая роль имеет режим:
- **Default** — ссылка на Design Token: `ref:theme.accent` (не значение!). Хранится референс, резолвится при рендере.
- **Custom** — литерал пользователя (HEX/RGBA + alpha), открывается полноценный Color Picker (Hue/Sat/Bright/Alpha/HEX/RGB/RGBA + preview + recent).

Запрет ТЗ: `Default = #9B5CFF` как захардкоженное значение — недопустимо нигде.

### 3.2. Цветовые роли модуля (каждая — Default/Custom)
| Роль | Default Token | Комментарий |
|---|---|---|
| `primary` | `theme.accent` | главный акцент модуля |
| `secondary` | `theme.primary` | второй акцент (градиенты, пары) |
| `text` | `theme.text` | основной текст |
| `textSecondary` | `theme.secondaryText` | описания, значения |
| `icon` | `theme.accent` или `theme.text` | решает модуль (§10) |
| `background` | `theme.surface` | фон модуля |
| `tint` | `theme.navy` | тинт glass |
| `outline` | `theme.border` | outline/border |
| `glow` | `theme.accent` | свечение |
| `success/warning/error/info` | семантические токены | только Notifications/статусы, приглушённые |

### 3.3. Цепочка наследования (порядок резолва)
```
Theme Tokens (Night/Aurora/...)
  → Global HUD Style (accent/opacity/glass/...)
    → HUD Module Defaults (дефолты §2)
      → Individual Module Overrides (то, что поменял юзер)
        → Live Preview → Render
```
Правила:
- На каждом уровне значение либо **унаследовано** (ссылка вверх), либо **переопределено** (своё).
- UI-маркер: унаследованное значение показывает бейдж `Default` + источник (`Theme`/`Global`); переопределённое — кнопку `[ Use Default ]` (Reset, §3.6).
- Смена темы (`Night → Aurora`): всё, что Default, пересчитывается мгновенно; Custom не трогаем.
- Пример из ТЗ работает буквально: ArrayList=Default → следит за Global Accent; Keybinds=Custom Cyan → стоит.

### 3.4. Global HUD Style + Override-переключатель
Глобальные: Global Scale · Global Opacity · Global Glass · Global Blur · Global Outline ·
Global Shadow · Global Glow · Global Accent (режим Default/Custom сам по себе).
- `Override Individual Modules = OFF` (def): модули наследуют global (индивидуальные панели показывают значения как read-only + `Default`).
- `= ON`: каждый модуль может переопределять; неуказанное продолжает наследоваться.
- Финальная alpha: `α_final = α_global × α_module × α_part` (каждая 0–1).

### 3.5. Gradient
Gradient ON/OFF · Type: Horizontal / Vertical / Diagonal / Radial ·
Start Color (Default→`theme.accent`) · End Color (Default→`theme.primary`) · Angle (для linear, 0–360).
Использование: фоны модулей, ArrayList-текст (опц.), полосы-индикаторы. Умеренно (см. premium-правила).

### 3.6. Reset / Use Default
- Per-setting: кнопка `[ Use Default ]` рядом с любым переопределённым значением.
- Per-module: `[ Reset Module ]` — сброс всего модуля к Module Defaults.
- Global: `[ Reset All HUD ]` (+ confirm-modal).
- После Reset значение снова становится ссылкой вверх по цепочке.

---

## 4. Glass: определение и фолбэки

Glass (включён) = `translucent background (Opacity) + backdrop blur (Blur Amount) + top inner highlight + subtle border`.
- Tint: подкрашивание blur-слоя (`Default → theme.navy`, Tint Opacity def 50).
- Highlight: верхняя 1px светлая линия + мягкий верхний градиент (Highlight Opacity def 25).
- Фолбэк, если rendering foundation не даёт blur: автоматически `Solid-translucent`
  (тот же цвет/opacity, highlight остаётся, badge в UI `Blur unavailable` — честно, без эмуляции шумом).
- Blur Amount 0 = прозрачный фон без размытия (не то же, что Transparent style: highlight/border остаются).

---

## 5. Position / Scale — инварианты

1. Позиция = `anchor + (X, Y)` всегда; drag пересчитывает пару, а не вводит 4-й параметр.
2. Scale — пост-трансформ всего модуля (включая outline/shadow — они масштабируются, как требует ТЗ).
3. HUD Editor показывает: subtle outline + bounding box + имя модуля + X/Y + W/H + handles (corners — resize при Fixed, edges — nudge-зона).
4. Snap: опциональный snap к краям экрана и к другим модулям (toggle в редакторе, def ON, threshold 6px) + направляющие.
5. Координаты хранятся в unscaled px относительно anchor при базовом разрешении; при смене разрешения anchor держит модуль на месте.

---

## 6. Типографика/иконки/сепараторы — см. §2.6–2.8 (shared, без дублирования)

Дополнительно: моноширинный стек для чисел/таймеров/координат (чтобы цифры не «прыгали»):
`Font Mono` опция у FPS/Coordinates/Clock/Ping/таймеров Potions.

---

## 7. Animation

| Параметр | Значения |
|---|---|
| Animation | ON/OFF (мастер; def ON) |
| Entry / Exit / Update | независимые типы: Fade / Slide / Scale / Fade+Slide / None |
| Direction (для Slide) | Auto (от anchor) / Up / Down / Left / Right |
| Speed | Slow (400ms) / Normal (250ms) / Fast (150ms) / Custom (ms) |
| Intensity | 0–100 (def 70): амплитуда slide (4–16px) и глубина fade/scale |
| Stagger (списки) | 0–80ms задержки между строками (def 25) |
| Key Press Highlight | для Keybinds: вспышка строки при нажатии (120ms) |
| Update | для чисел: morph/crossfade значения (def: crossfade 150ms) |

Связь с `prefers-reduced-motion` (GUI_DESIGN_SPEC §5.5): при включённой — только Fade ≤120ms,
Stagger/Scale/Slide отключаются автоматически.

---

## 8. Visibility (контексты)

| Контекст | Def | Смысл |
|---|---|---|
| Show In Game | ON | обычный геймплей |
| Show When GUI Open | ON (HUD), OFF (редактор-спец.) | поверх/под окном GUI (z-order §1 GUI spec) |
| Show In Menus | OFF | инвентарь/настройки мира |
| Show In Pause | OFF | пауза (Esc) |
| Show In Screens | OFF | прочие экраны (чат? — решает модуль; чат открыт = In Game + Chat flag) |

Дополнительно: `Hide When` условия у отдельных модулей (например, Potions: `Hide When Empty` def ON).

---

## 9. HUD Editor (Edit HUD)

Режим (кнопка из раздела HUD + keybind):
1. Мир на фоне (dim слабее, чем у главного окна: 35%), HUD-виджеты selectable.
2. Клик — выбор: subtle outline (`theme.accent`, 1px) + corner handles + label `Module · X,Y · WxH`.
3. Drag — перемещение (обновляет anchor+X/Y); handles — resize (только Fixed W/H); стрелки — nudge.
4. Панель инспектора справа: быстрые поля (Enabled/Position/Scale/Opacity/Glass/Outline) + кнопка `Open Full Settings` (переход в карточку модуля).
5. Esc / `Done` — выход; изменения применяются live (те же Preview-объекты, §12).
6. Пустое место — клик снимает выбор; Del — не удаляет, а предлагает Disable (модули системные).

---

## 10. Per-Module Specs (Shared + Specific)

Легенда: всё из §2 — Shared (S) по умолчанию; ниже у каждого модуля — только Specific (M) + отклонения shared-дефолтов.

### 10.1. Potions / Effects (информационный список эффектов)
Layout-образец (из референса): `✦ EFFECTS / icon Name ........ timer`.
- (M) Content: Show Duration (def ON) · Show Amplifier (def ON, римские: `II`) · Show Icon (def ON) ·
  Sort Mode: Duration / Name / Amplifier (def Duration) · Order: Asc/Desc (def Asc — скоро кончающиеся сверху) ·
  Max Items 1–10 (def 5) · Hide When Empty (def ON) · Title: Show (ON) / Text (`Effects`) / Icon ✦
- Shared-отклонения: Separator ON · mono-таймеры ON · Icon Color Default→`theme.text` (нейтральные иконки зелий)
- Состояния: `No effects` empty-state (caption, не пустая карточка)

### 10.2. ArrayList (активные визуальные/utility-модули)
- (M) Content: Sorting: Alphabetical / Length / Priority / Custom (def Priority) ·
  Direction: Top→Bottom / Bottom→Top (def Top→Bottom) · Show Count Badge (def ON) ·
  Item Style: Text / Pill / Bar (Bar = акцентная полоска слева, def Pill) ·
  Gradient Text: OFF/ON (Start/End роли, §3.5) · Rainbow/Dynamic cosmetic: OFF/ON (def OFF; десатурированный, в рамках палитры — см. premium-правила) ·
  Exclude list (какие модули не показывать)
- Shared-отклонения: Background def Transparent+Text-shadow (компактный стиль) или Glass-card (на выбор: `List Style: Minimal / Card`) · Stagger ON

### 10.3. Keybinds (таблица биндов безопасных функций)
- (M) Content: Show Title (ON) / Title Text (`Keybinds`) · Keycap Style: Key Background (role bg, def raised) / Key Text (mono, def ON) / Key Border (subtle) / Key Radius (def 6) ·
  Show Unbound (def OFF) · Press Highlight (§7) · Columns: 1/2 (def 1)
- Layout-образец: `HUD ........ [RSHIFT]` (keycap-чип справа, моноширинный)

### 10.4. FPS
- (M) Content: Format: `FPS: {v}` / `{v} FPS` / `{v}` (def `FPS: {v}`) · Decimals 0–1 (def 0) ·
  Prefix/Suffix custom · Thresholds: Warn <60 (warning color) / Crit <30 (error color), toggle def ON ·
  Show Frame Time (def OFF, `· 4.2ms`)
- Shared-отклонения: Background def OFF (text-only) · mono ON · Update-animation crossfade

### 10.5. Coordinates
- (M) Content: Format: `X: {x} Y: {y} Z: {z}` / compact / per-axis lines · Decimals 0–2 (def 1) ·
  Axis Visibility: X/Y/Z toggles (def все ON) · Labels ON/OFF · Dimension Suffix (def OFF: `· Overworld`) ·
  ⚠️ Non-cheat guard: только собственные координаты; никаких entity/player-поисков, вейпоинтов на игроков, трекинга (зафиксировано ТЗ)
- Shared-отклонения: mono ON · Background def OFF

### 10.6. Ping
- (M) Content: Format `Ping: {v}ms` / `{v}ms` · Thresholds (как FPS: warn >120, crit >250) ·
  Unavailable State: `—` + caption `offline` (не придумывать значения!)
- Shared-отклонения: mono ON · Background def OFF

### 10.7. Clock
- (M) Content: 24h/12h (def 24h) · Seconds ON/OFF (def OFF) · Date ON/OFF (def OFF, формат `dd.MM`) ·
  Timezone: Local / UTC / Custom offset · Label prefix (`🕐`? — нет: только текст/иконка из набора)
- Shared-отклонения: mono ON

### 10.8. Session Info (локальная сводка)
- (M) Content: Rows toggles: Session Time / Server / FPS / Ping / Coordinates (def: Time+Server ON, остальные OFF — чтобы не дублировать отдельные виджеты) ·
  Row Style: `Label .... Value` · Server Name Source: `world/server string` (только отображаем, не собираем лишнего)
- Shared-отклонения: Separator ON · Card style def Glass

### 10.9. Watermark (`Nightfull`)
- (M) Content: Text (def `Nightfull`, editable) · Show Logo (def ON) · Logo Size 14–28 · Suffix: version / FPS / none (def version) ·
  Layout: Horizontal (logo+text) / Stacked
- Shared-отклонения: Glow def ON (мягкий, accent, 25%) — единственный модуль с glow по умолчанию · Background def Glass-subtle

### 10.10. Armor / Equipment (прочность/иконки)
- (M) Content: Slots: Helmet/Chest/Legs/Boots + MainHand/OffHand toggles · Display: Icon / Icon+Bar / Icon+% ·
  Durability Bar (gradient green→amber→red, семантические цвета — исключение из accent-правила, обосновано) ·
  Low-Durability Warn <10% (warning pulse, toggle) · Order: Armor→Hands / Hands→Armor · Direction: Vertical/Horizontal
- Shared-отклонения: Spacing Row/Col · Icon Size def 20

### 10.11. Server Info (безопасная инфо-строка)
- (M) Content: Show Address (def OFF — приватность!) / Show Name (ON) / Player Count (ON, `12/100`) / MOTD line (OFF) ·
  ⚠️ Privacy: адрес сервера скрыт по умолчанию; включается явно (см. Settings→Privacy)
- Shared-отклонения: mono для счётчиков

### 10.12. Notifications (очередь floating cards)
- (M) Layout: Position (TopRight/TopCenter/BottomRight/BottomLeft, def TopRight) · Max Visible 1–5 (def 3) ·
  Width Fixed 240–360 (def 300) · Duration: Info 3s / Success 3s / Warning 4.5s / Error 6s (Custom ms) ·
  Progress Bar (TTL-индикатор, def ON) · Sound: none (v1; системный звук — позже, отдельный флаг) ·
  Queue overflow: вытеснение старых (def) / collapse `+N more`
- Types: Information / Success / Warning / Error — icon + accent-полоса + приглушённый цвет (не кислотные)
- Shared-отклонения: Entry Slide+Fade def · Stagger 60ms

### 10.13. Performance (FPS/frame/memory — только реальные данные)
- (M) Content: Rows: FPS / Frame Time / Memory / Render Time / UI Render Time / Particle Count / GPU Resources —
  каждый toggle (def: FPS+Frame+Memory ON) · Graph: mini-sparkline для Frame Time (ON/OFF, def ON) ·
  Unavailable: строка показывает `n/a` (честно, без заглушек)
- Shared-отклонения: mono ON · Separator ON

### 10.14. Custom Text (пользовательская строка)
- (M) Content: Text (multiline, max 3 строки) · Variables: `{fps} {ping} {x} {y} {z} {time} {session} {user}` (подстановка live) ·
  Condition: Always / In Game Only
- Shared-отклонения: нет (чистый shared + текст)

### 10.15. Custom Image (пользовательская картинка)
- (M) Content: Source: File (png/jpg, max 2MB, локально) · Fit: Contain / Cover / Stretch · Aspect Lock (def ON) ·
  Image Opacity · Tint (Default none / Custom) · ⚠️ Privacy: только локальные файлы, без URL (v1)
- Shared-отклонения: Background def OFF · Outline def OFF · Radius по картинке

---

## 11. Global HUD Style: пресеты и настройки

### 11.1. Пресеты (остаются в Nightfull design language)
| Preset | Background | Glass/Blur | Outline | Shadow | Glow | Radius | Content |
|---|---|---|---|---|---|---|---|
| **Default** (def) | Glass 72% | ON/40 | 1px subtle | ON soft | OFF | 12 | text 100% |
| Minimal | Transparent | OFF | OFF | OFF | OFF | 8 | text 100% + text-shadow |
| Glass | Glass 55% | ON/70 | 1px faint | ON strong | OFF | 16 | text 100% |
| Compact | Solid 88% | OFF | 1px | OFF | OFF | 8 | spacing −25%, padding −25% |
| Transparent | Transparent | OFF | OFF | OFF | OFF | — | text 90% + shadow |
| Neon | Glass 60% | ON/30 | 1px accent 60% | ON | ON soft 25% | 10 | — |
| Custom | = текущие значения (сохранение снапшота) | — | — | — | — | — | — |

Пресет применяется как пакет: проставляет Global-уровень (не трогая Individual Overrides; с флагом `Apply to overrides` — и их, с confirm).

### 11.2. Global HUD Settings (раздел `HUD Appearance`)
Global Scale · Global Opacity · Global Glass · Global Blur · Global Outline · Global Shadow ·
Global Glow · Global Accent (Default=theme.accent/Custom) · `Override Individual Modules` (§3.4) ·
`[ Reset All HUD ]` (§3.6).
Каждый global-контрол показывает, сколько модулей его наследует (`Inherited by 12/15`).

---

## 12. Live Preview

- Каждый модуль в своих
...[truncated 5421 chars]